import os
import shutil
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
from tqdm import tqdm

# =========================
# EINSTELLUNGEN
# =========================
BASE_DIR = "/home/mitte/crack_project/datasets/better_dataset_evtl"

# True  = Dateien verschieben
# False = Dateien kopieren
MOVE_FILES = True

MAX_WORKERS = min(16, os.cpu_count() or 1)
OVERWRITE = False

SPLITS = ["train", "val", "test"]

FOLDER_PAIRS = {
    "images": "images_512px_hard_negatives",
    "masks": "masks_512px_hard_negatives",
}

PREFIX = "hn"


def collect_file_tasks(base_dir: Path):
    tasks = []

    for split in SPLITS:
        for src_folder, dst_folder in FOLDER_PAIRS.items():
            src_dir = base_dir / split / src_folder
            dst_dir = base_dir / split / dst_folder

            if not src_dir.exists():
                print(f"[WARN] Quellordner nicht gefunden: {src_dir}")
                continue

            dst_dir.mkdir(parents=True, exist_ok=True)

            for file_path in src_dir.iterdir():
                if file_path.is_file() and file_path.name.startswith(PREFIX):
                    target_path = dst_dir / file_path.name
                    tasks.append((file_path, target_path))

    return tasks


def process_file(task):
    src, dst = task

    try:
        if dst.exists():
            if OVERWRITE:
                dst.unlink()
            else:
                return f"Übersprungen: {dst}"

        if MOVE_FILES:
            shutil.move(str(src), str(dst))
            return f"Verschoben: {src} -> {dst}"
        else:
            shutil.copy2(src, dst)
            return f"Kopiert: {src} -> {dst}"

    except Exception as e:
        return f"Fehler bei {src}: {e}"


def main():
    base_dir = Path(BASE_DIR)

    if not base_dir.exists():
        print(f"[FEHLER] BASE_DIR existiert nicht: {base_dir}")
        return

    tasks = collect_file_tasks(base_dir)

    if not tasks:
        print("Keine Dateien mit Prefix 'hn' gefunden.")
        return

    print(f"Gefundene hn-Dateien: {len(tasks)}")
    print(f"Modus: {'Verschieben' if MOVE_FILES else 'Kopieren'}")

    results = []

    with ThreadPoolExecutor(max_workers=MAX_WORKERS) as executor:
        for result in tqdm(
            executor.map(process_file, tasks),
            total=len(tasks),
            desc="Verarbeite Dateien",
            unit="Datei"
        ):
            results.append(result)

    errors = [r for r in results if r.startswith("Fehler")]
    skipped = [r for r in results if r.startswith("Übersprungen")]
    success = len(results) - len(errors) - len(skipped)

    print("\n===== FERTIG =====")
    print(f"Erfolgreich: {success}")
    print(f"Übersprungen: {len(skipped)}")
    print(f"Fehler: {len(errors)}")

    if errors:
        print("\nFehler:")
        for err in errors[:10]:
            print(err)


if __name__ == "__main__":
    main()