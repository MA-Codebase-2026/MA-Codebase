#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Vergleicht zwei binäre Masken pixelweise und erstellt eine Fehler-Visualisierung.

Zusätzlich werden alle Metriken gemeinsam in genau einer TXT- und einer
JSON-Datei ausgegeben:
- normal über alle Pixel
- in einer BALANCED CRACK ROI (alle GT-Risspixel plus gleich viele gesampelte
  negative Pixel, bevorzugt aus dem rissnahen Ring)

Darstellung:
- True Positive (TP): weiß
- False Positive (FP): rot
- False Negative (FN): blau
- True Negative (TN): schwarz

Wichtig:
MASK_PRED_PATH und MASK_GT_PATH direkt unten im Code eintragen.

Definition:
- Ground Truth (GT): Referenzmaske
- Prediction (PRED): zu prüfende Maske

FP = Prediction ist Riss, Ground Truth aber nicht.
FN = Ground Truth ist Riss, Prediction aber nicht.
"""

import json
import math
from datetime import datetime
from pathlib import Path
from typing import Any

import cv2
import numpy as np


# ============================================================
# PFADE DIREKT HIER EINTRAGEN
# ============================================================

# Zu prüfende / vorhergesagte / ungenaue Maske:
MASK_PRED_PATH = Path("/home/mitte/crack_project/test_images/10_Bilder_test/masks/5_64702f5f34_90_grad_x3840_y4864.png")

# Ground-Truth / Referenzmaske:
MASK_GT_PATH = Path("/home/mitte/crack_project/test_images/10_Bilder_test/masks/5_64702f5f34_90_grad_x3840_y4864_2.png")

# Ausgabedatei:
OUTPUT_MASK_PATH = Path("/home/mitte/crack_project/test_images/unterschied_betterdataset_und_perfect_label/diff.png")

# Beide Metrikbereiche werden gemeinsam in diesen zwei Dateien gespeichert.
# Die Namen werden automatisch aus OUTPUT_MASK_PATH abgeleitet.
OUTPUT_METRICS_TXT_PATH = OUTPUT_MASK_PATH.with_name(
    f"{OUTPUT_MASK_PATH.stem}_metrics.txt"
)
OUTPUT_METRICS_JSON_PATH = OUTPUT_MASK_PATH.with_name(
    f"{OUTPUT_MASK_PATH.stem}_metrics.json"
)


# ============================================================
# EINSTELLUNGEN
# ============================================================

# Pixel > THRESHOLD werden als positiver Maskenpixel gewertet.
THRESHOLD = 127

# True Positives zusätzlich weiß darstellen.
# Falls False, bleiben TP-Pixel schwarz und nur FP/FN werden farbig gezeigt.
SHOW_TRUE_POSITIVES = True

# Einstellungen für den gesampelten Bereich (BALANCED CRACK ROI).
ROI_RING_RADIUS_PX = 10
ROI_NEGATIVE_TO_POSITIVE_RATIO = 1.0
ROI_RANDOM_SEED = 42

EPS = 1e-12


# ============================================================
# FUNKTIONEN
# ============================================================

def load_binary_mask(path: str, threshold: int = 127) -> np.ndarray:
    """
    Lädt eine Maske als Graustufenbild und wandelt sie in bool um.
    """
    image = cv2.imread(path, cv2.IMREAD_GRAYSCALE)

    if image is None:
        raise FileNotFoundError(f"Maske konnte nicht geladen werden: {path}")

    return image > threshold


def safe_div(numerator: float, denominator: float) -> float:
    return float(numerator / denominator) if denominator > 0 else 0.0


def compute_metrics(pred_mask: np.ndarray, gt_mask: np.ndarray) -> dict[str, Any]:
    """Berechnet alle verfügbaren Metriken aus zwei binären Masken."""
    if pred_mask.shape != gt_mask.shape:
        raise ValueError(
            "Die beiden Masken haben unterschiedliche Größen:\n"
            f"Prediction: {pred_mask.shape}\n"
            f"Ground Truth: {gt_mask.shape}"
        )

    pred = pred_mask.astype(bool).reshape(-1)
    gt = gt_mask.astype(bool).reshape(-1)

    tp = int(np.count_nonzero(pred & gt))
    fp = int(np.count_nonzero(pred & ~gt))
    fn = int(np.count_nonzero(~pred & gt))
    tn = int(np.count_nonzero(~pred & ~gt))
    total = tp + fp + fn + tn

    precision = safe_div(tp, tp + fp)
    recall = safe_div(tp, tp + fn)
    specificity = safe_div(tn, tn + fp)
    npv = safe_div(tn, tn + fn)
    iou = safe_div(tp, tp + fp + fn)
    dice = safe_div(2 * tp, 2 * tp + fp + fn)
    f1 = safe_div(2 * precision * recall, precision + recall)
    f2 = safe_div(5 * precision * recall, 4 * precision + recall)
    accuracy = safe_div(tp + tn, total)
    fpr = safe_div(fp, fp + tn)
    fnr = safe_div(fn, fn + tp)
    balanced_error = 0.5 * (fpr + fnr)
    balanced_accuracy = 1.0 - balanced_error
    prevalence = safe_div(tp + fn, total)
    predicted_positive_rate = safe_div(tp + fp, total)

    # Average Precision für eine bereits binarisierte Prediction. Für echte
    # Probability-AP wären Wahrscheinlichkeitswerte statt einer Binärmaske nötig.
    binary_ap = (
        precision * recall + prevalence * (1.0 - recall)
        if (tp + fn) > 0
        else 0.0
    )

    mcc_denominator = math.sqrt(
        float(tp + fp) * float(tp + fn) * float(tn + fp) * float(tn + fn)
    )
    mcc = (
        float((tp * tn) - (fp * fn)) / mcc_denominator
        if mcc_denominator > EPS
        else 0.0
    )

    # Gleich gewichtete Distanz im Dice-/F2-Fehlerraum; kleiner ist besser.
    d_score = math.sqrt(
        0.5 * (1.0 - dice) ** 2 + 0.5 * (1.0 - f2) ** 2
    )

    return {
        "TP": tp,
        "FP": fp,
        "FN": fn,
        "TN": tn,
        "Total_pixels": total,
        "Positive_GT_pixels": tp + fn,
        "Negative_GT_pixels": tn + fp,
        "Predicted_positive_pixels": tp + fp,
        "Predicted_negative_pixels": tn + fn,
        "Precision": precision,
        "Recall": recall,
        "Specificity": specificity,
        "NPV": npv,
        "IoU": iou,
        "Dice": dice,
        "F1": f1,
        "F2": f2,
        "Binary_average_precision": binary_ap,
        "Accuracy": accuracy,
        "Accuracy_percent": accuracy * 100.0,
        "Balanced_error": balanced_error,
        "Balanced_accuracy": balanced_accuracy,
        "FPR": fpr,
        "FNR": fnr,
        "Prevalence": prevalence,
        "Predicted_positive_rate": predicted_positive_rate,
        "MCC": mcc,
        "D": d_score,
    }


def compare_masks(
    pred_mask: np.ndarray,
    gt_mask: np.ndarray,
) -> tuple[np.ndarray, dict[str, Any]]:
    """
    Vergleicht Prediction und Ground Truth pixelweise.

    Rückgabe:
    - RGB/BGR-Visualisierung
    - Statistik
    """
    if pred_mask.shape != gt_mask.shape:
        raise ValueError(
            "Die beiden Masken haben unterschiedliche Größen:\n"
            f"Prediction: {pred_mask.shape}\n"
            f"Ground Truth: {gt_mask.shape}"
        )

    pred = pred_mask.astype(bool)
    gt = gt_mask.astype(bool)

    true_positive = pred & gt
    false_positive = pred & ~gt
    false_negative = ~pred & gt
    true_negative = ~pred & ~gt

    h, w = pred.shape

    # OpenCV verwendet BGR.
    output = np.zeros((h, w, 3), dtype=np.uint8)

    # TP = weiß
    if SHOW_TRUE_POSITIVES:
        output[true_positive] = (255, 255, 255)

    # FP = rot (BGR: 0,0,255)
    output[false_positive] = (0, 0, 255)

    # FN = blau (BGR: 255,0,0)
    output[false_negative] = (255, 0, 0)

    # TN bleibt schwarz

    return output, compute_metrics(pred, gt)


def build_balanced_crack_roi_sample(
    pred_mask: np.ndarray,
    gt_mask: np.ndarray,
    ring_radius_px: int,
    negative_to_positive_ratio: float,
    random_seed: int,
) -> tuple[np.ndarray, np.ndarray, dict[str, Any]]:
    """
    Sampelt alle positiven GT-Pixel und gleich viele negative Pixel.

    Negative Pixel werden zuerst aus einem rissnahen Ring und bei Bedarf aus
    dem weiter entfernten Hintergrund gezogen.
    """
    if pred_mask.shape != gt_mask.shape:
        raise ValueError(
            f"Prediction {pred_mask.shape} und GT {gt_mask.shape} sind ungleich."
        )
    if ring_radius_px < 0:
        raise ValueError("ROI_RING_RADIUS_PX darf nicht negativ sein.")
    if negative_to_positive_ratio < 0:
        raise ValueError("ROI_NEGATIVE_TO_POSITIVE_RATIO darf nicht negativ sein.")

    pred = pred_mask.astype(bool)
    gt = gt_mask.astype(bool)
    positive_indices = np.flatnonzero(gt.reshape(-1))
    positive_count = int(positive_indices.size)
    stats: dict[str, Any] = {
        "status": "ok",
        "positive_pixels": positive_count,
        "target_negative_pixels": 0,
        "negative_pixels_sampled": 0,
        "ring_pixels_available": 0,
        "ring_pixels_sampled": 0,
        "far_background_pixels_available": 0,
        "far_background_pixels_sampled": 0,
        "negative_shortfall": 0,
        "sampled_pixels_total": 0,
    }

    if positive_count == 0:
        stats["status"] = "skipped_no_positive_gt_pixels"
        return np.empty(0, bool), np.empty(0, bool), stats

    if ring_radius_px == 0:
        dilated = gt.copy()
    else:
        kernel_size = 2 * ring_radius_px + 1
        kernel = cv2.getStructuringElement(
            cv2.MORPH_ELLIPSE, (kernel_size, kernel_size)
        )
        dilated = cv2.dilate(gt.astype(np.uint8), kernel, iterations=1).astype(bool)

    ring_indices = np.flatnonzero((dilated & ~gt).reshape(-1))
    far_indices = np.flatnonzero((~dilated).reshape(-1))
    target_negative = max(
        0, int(round(positive_count * negative_to_positive_ratio))
    )
    stats["target_negative_pixels"] = target_negative
    stats["ring_pixels_available"] = int(ring_indices.size)
    stats["far_background_pixels_available"] = int(far_indices.size)

    rng = np.random.default_rng(random_seed)
    ring_count = min(target_negative, int(ring_indices.size))
    if ring_count == ring_indices.size:
        sampled_ring = ring_indices
    else:
        sampled_ring = rng.choice(ring_indices, size=ring_count, replace=False)

    remaining = target_negative - ring_count
    far_count = min(remaining, int(far_indices.size))
    if far_count == far_indices.size:
        sampled_far = far_indices
    else:
        sampled_far = rng.choice(far_indices, size=far_count, replace=False)

    negative_indices = np.concatenate((sampled_ring, sampled_far)).astype(np.int64)
    sample_indices = np.concatenate((positive_indices, negative_indices))
    pred_flat = pred.reshape(-1)
    gt_flat = gt.reshape(-1)

    stats["negative_pixels_sampled"] = int(negative_indices.size)
    stats["ring_pixels_sampled"] = int(sampled_ring.size)
    stats["far_background_pixels_sampled"] = int(sampled_far.size)
    stats["negative_shortfall"] = max(
        0, target_negative - int(negative_indices.size)
    )
    stats["sampled_pixels_total"] = int(sample_indices.size)

    return pred_flat[sample_indices], gt_flat[sample_indices], stats


def print_statistics(stats: dict[str, Any], title: str) -> None:
    print()
    print("=" * 60)
    print(title)
    print("=" * 60)

    print(f"True Positive  (TP): {stats['TP']} px")
    print(f"False Positive (FP): {stats['FP']} px")
    print(f"False Negative (FN): {stats['FN']} px")
    print(f"True Negative  (TN): {stats['TN']} px")

    print()
    for key, value in stats.items():
        if key in {"TP", "FP", "FN", "TN"}:
            continue
        if isinstance(value, float):
            print(f"{key:<27}: {value:.6f}")
        else:
            print(f"{key:<27}: {value}")

    print()
    print("Farben der Ausgabemaske:")
    print("  Rot    = False Positive")
    print("  Blau   = False Negative")

    if SHOW_TRUE_POSITIVES:
        print("  Weiß   = True Positive")

    print("  Schwarz= True Negative")


def json_safe(value: Any) -> Any:
    if isinstance(value, dict):
        return {str(key): json_safe(item) for key, item in value.items()}
    if isinstance(value, (list, tuple)):
        return [json_safe(item) for item in value]
    if isinstance(value, (np.integer,)):
        return int(value)
    if isinstance(value, (np.floating,)):
        return float(value) if np.isfinite(value) else None
    if isinstance(value, Path):
        return str(value)
    return value


def format_txt_value(value: Any) -> str:
    if isinstance(value, float):
        return f"{value:.6f}" if np.isfinite(value) else "nan"
    return str(value)


def write_metrics_files(
    txt_path: Path,
    json_path: Path,
    metadata: dict[str, Any],
    normal_metrics: dict[str, Any],
    sampled_metrics: dict[str, Any] | None,
    sampling: dict[str, Any],
) -> None:
    """Schreibt beide Metrikbereiche gemeinsam in eine TXT und eine JSON."""
    txt_path.parent.mkdir(parents=True, exist_ok=True)
    json_path.parent.mkdir(parents=True, exist_ok=True)

    lines = [
        "=" * 90,
        "MASKENVERGLEICH: NORMALE UND GESAMPELTE METRIKEN",
        "=" * 90,
        "METADATEN",
    ]
    lines.extend(
        f"{key}: {format_txt_value(value)}" for key, value in metadata.items()
    )
    lines.extend(("", "-" * 90, "NORMALE METRIKEN / ALLE PIXEL", "-" * 90))
    lines.extend(
        f"{key}: {format_txt_value(value)}"
        for key, value in normal_metrics.items()
    )
    lines.extend(("", "-" * 90, "SAMPLE-KONFIGURATION UND -STATISTIK", "-" * 90))
    lines.extend(
        f"{key}: {format_txt_value(value)}" for key, value in sampling.items()
    )
    lines.extend(("", "-" * 90, "METRIKEN IM GESAMPELTEN BEREICH", "-" * 90))
    if sampled_metrics is None:
        lines.append("Nicht berechenbar: keine positiven GT-Pixel im Samplebereich.")
    else:
        lines.extend(
            f"{key}: {format_txt_value(value)}"
            for key, value in sampled_metrics.items()
        )
    txt_path.write_text("\n".join(lines) + "\n", encoding="utf-8")

    payload = {
        "metadata": metadata,
        "normal_metrics_all_pixels": normal_metrics,
        "sampled_region": {
            "sampling": sampling,
            "metrics": sampled_metrics,
        },
    }
    json_path.write_text(
        json.dumps(json_safe(payload), indent=2, ensure_ascii=False, allow_nan=False)
        + "\n",
        encoding="utf-8",
    )


# ============================================================
# MAIN
# ============================================================

def main() -> None:
    pred_path = Path(MASK_PRED_PATH)
    gt_path = Path(MASK_GT_PATH)
    output_path = Path(OUTPUT_MASK_PATH)
    metrics_txt_path = Path(OUTPUT_METRICS_TXT_PATH)
    metrics_json_path = Path(OUTPUT_METRICS_JSON_PATH)

    print(f"Prediction-Maske:  {pred_path}")
    print(f"Ground-Truth-Maske: {gt_path}")

    pred_mask = load_binary_mask(
        str(pred_path),
        threshold=THRESHOLD,
    )

    gt_mask = load_binary_mask(
        str(gt_path),
        threshold=THRESHOLD,
    )

    comparison, stats = compare_masks(
        pred_mask,
        gt_mask,
    )

    sampled_pred, sampled_gt, sampling_stats = build_balanced_crack_roi_sample(
        pred_mask,
        gt_mask,
        ring_radius_px=ROI_RING_RADIUS_PX,
        negative_to_positive_ratio=ROI_NEGATIVE_TO_POSITIVE_RATIO,
        random_seed=ROI_RANDOM_SEED,
    )
    sampled_stats = (
        compute_metrics(sampled_pred, sampled_gt)
        if sampled_gt.size > 0
        else None
    )

    output_path.parent.mkdir(
        parents=True,
        exist_ok=True,
    )

    success = cv2.imwrite(
        str(output_path),
        comparison,
    )

    if not success:
        raise IOError(
            f"Ausgabemaske konnte nicht gespeichert werden: {output_path}"
        )

    metadata = {
        "created_at": datetime.now().isoformat(timespec="seconds"),
        "prediction_mask": str(pred_path),
        "ground_truth_mask": str(gt_path),
        "comparison_mask": str(output_path),
        "mask_threshold": THRESHOLD,
        "width_px": int(pred_mask.shape[1]),
        "height_px": int(pred_mask.shape[0]),
    }
    sampling_report = {
        "region": "BALANCED CRACK ROI",
        "description": (
            "Alle GT-Risspixel plus gesampelte negative Pixel; zuerst aus dem "
            "rissnahen Ring, danach aus dem weiteren Hintergrund."
        ),
        "ring_radius_px": ROI_RING_RADIUS_PX,
        "negative_to_positive_ratio": ROI_NEGATIVE_TO_POSITIVE_RATIO,
        "random_seed": ROI_RANDOM_SEED,
        **sampling_stats,
    }
    write_metrics_files(
        metrics_txt_path,
        metrics_json_path,
        metadata,
        stats,
        sampled_stats,
        sampling_report,
    )

    print_statistics(stats, "MASKENVERGLEICH / ALLE PIXEL")
    if sampled_stats is not None:
        print_statistics(sampled_stats, "MASKENVERGLEICH / GESAMPELTER BEREICH")
    else:
        print("\nSample-Metriken nicht berechenbar: keine positiven GT-Pixel.")

    print()
    print(f"Vergleichsmaske gespeichert unter:")
    print(output_path)
    print(f"Metriken (TXT):  {metrics_txt_path}")
    print(f"Metriken (JSON): {metrics_json_path}")


if __name__ == "__main__":
    main()
