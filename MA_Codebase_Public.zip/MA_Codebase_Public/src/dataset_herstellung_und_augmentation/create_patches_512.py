from __future__ import annotations

import os
from pathlib import Path
from concurrent.futures import ProcessPoolExecutor, as_completed

import numpy as np
from PIL import Image

from tqdm import tqdm


# ============================
# HIER DEIN INPUT ROOT EINTRAGEN
# Struktur:
# INPUT_DIR/
#   train/images, train/masks
#   val/images,   val/masks
#   test/images,  test/masks
#
# Output wird je Split neben images/masks angelegt als:
#   images_512px, masks_512px
#   images_512px_hard_negatives, masks_512px_hard_negatives
# ============================
INPUT_DIR = Path("/home/mitte/crack_project/datasets/perfect_label")
# ============================

WINDOW_SIZE = 512
STRIDE = 256
WHITE_THRESHOLD = 0   # Pixel > threshold zählen als "Riss"

# Ryzen 7 (8C/16T): meist gut mit 16 logical threads
MAX_WORKERS = min(16, os.cpu_count() or 16)

# Dateiendungen, die als Input akzeptiert werden
IMAGE_EXTS = [".png", ".jpg", ".jpeg", ".tif", ".tiff", ".bmp", ".JPG"]


def iter_windows_cover_all(width: int, height: int, window: int, stride: int):
    """
    Sliding windows, aber nimmt auch den Rand mit:
    - normale Schritte stride
    - zusätzlich letztes Fenster so, dass es am Rand endet (ohne Padding)
    """
    if width <= 0 or height <= 0:
        return

    last_x = max(width - window, 0)
    last_y = max(height - window, 0)

    xs = list(range(0, last_x + 1, stride))
    ys = list(range(0, last_y + 1, stride))

    if not xs:
        xs = [0]
    if not ys:
        ys = [0]

    if xs[-1] != last_x:
        xs.append(last_x)
    if ys[-1] != last_y:
        ys.append(last_y)

    for y in ys:
        for x in xs:
            yield x, y


def find_mask_for_image(img_path: Path, masks_dir: Path) -> Path | None:
    direct = masks_dir / img_path.name
    if direct.exists():
        return direct
    for ext in IMAGE_EXTS:
        candidate = masks_dir / f"{img_path.stem}{ext}"
        if candidate.exists():
            return candidate
    return None


def _save_image_fast(arr: np.ndarray, out_path: Path):
    out_path.parent.mkdir(parents=True, exist_ok=True)
    img = Image.fromarray(arr)

    suffix = out_path.suffix.lower()
    if suffix == ".png":
        # schnellere PNGs: weniger Kompression -> deutlich schneller
        img.save(out_path, compress_level=1, optimize=False)
    elif suffix in [".jpg", ".jpeg"]:
        img.save(out_path, quality=95, subsampling=0, optimize=False)
    else:
        img.save(out_path)


def _process_one_pair(task):
    """
    Worker-Funktion: verarbeitet genau 1 Bild/Masken-Paar.
    Rückgabe: (img_name, patches_total, patches_hardneg, error)
    """
    (
        img_path_str,
        mask_path_str,
        out_img_dir_str,
        out_msk_dir_str,
        hn_img_dir_str,
        hn_msk_dir_str,
        window,
        stride,
        white_thr,
    ) = task

    img_path = Path(img_path_str)
    mask_path = Path(mask_path_str)

    out_img_dir = Path(out_img_dir_str)
    out_msk_dir = Path(out_msk_dir_str)
    hn_img_dir = Path(hn_img_dir_str)
    hn_msk_dir = Path(hn_msk_dir_str)

    # Laden -> NumPy
    img = Image.open(img_path).convert("RGB")
    msk = Image.open(mask_path).convert("L")

    if img.size != msk.size:
        return (img_path.name, 0, 0, f"SIZE_MISMATCH img={img.size} mask={msk.size}")

    img_np = np.asarray(img)  # (H,W,3)
    msk_np = np.asarray(msk)  # (H,W)

    h, w = msk_np.shape
    stem = img_path.stem
    img_suf = img_path.suffix
    msk_suf = mask_path.suffix

    patches_total = 0
    patches_hn = 0

    for x, y in iter_windows_cover_all(w, h, window, stride):
        m_view = msk_np[y : y + window, x : x + window]
        if m_view.shape[0] != window or m_view.shape[1] != window:
            continue

        has_crack = (m_view.max() > white_thr)
        i_view = img_np[y : y + window, x : x + window, :]

        patch_base = f"{stem}_x{x}_y{y}"
        out_img_name = f"{patch_base}{img_suf}"
        out_msk_name = f"{patch_base}{msk_suf}"

        if not has_crack:
            _save_image_fast(i_view.copy(), hn_img_dir / out_img_name)
            _save_image_fast(m_view.copy(), hn_msk_dir / out_msk_name)
            patches_hn += 1
        else:
            _save_image_fast(i_view.copy(), out_img_dir / out_img_name)
            _save_image_fast(m_view.copy(), out_msk_dir / out_msk_name)

        patches_total += 1

    return (img_path.name, patches_total, patches_hn, None)


def main():
    splits = ["train", "val", "test"]

    all_tasks = []
    all_missing = []
    split_stats = {}

    for split in splits:
        images_dir = INPUT_DIR / split / "images"
        masks_dir = INPUT_DIR / split / "masks"

        out_img_dir = INPUT_DIR / split / "images_512px"
        out_msk_dir = INPUT_DIR / split / "masks_512px"
        hn_img_dir = INPUT_DIR / split / "images_512px_hard_negatives"
        hn_msk_dir = INPUT_DIR / split / "masks_512px_hard_negatives"

        # Output-Ordner anlegen
        out_img_dir.mkdir(parents=True, exist_ok=True)
        out_msk_dir.mkdir(parents=True, exist_ok=True)
        hn_img_dir.mkdir(parents=True, exist_ok=True)
        hn_msk_dir.mkdir(parents=True, exist_ok=True)

        # Bildliste sammeln
        image_paths = []
        for ext in IMAGE_EXTS:
            image_paths.extend(images_dir.glob(f"*{ext}"))
        image_paths = sorted(set(image_paths))

        if not image_paths:
            print(f"Keine Bilder gefunden in: {images_dir}")
            split_stats[split] = (0, 0, 0)
            continue

        tasks = []
        missing = []
        for img_path in image_paths:
            mask_path = find_mask_for_image(img_path, masks_dir)
            if mask_path is None:
                missing.append(f"{split}/{img_path.name}")
                continue

            tasks.append(
                (
                    str(img_path),
                    str(mask_path),
                    str(out_img_dir),
                    str(out_msk_dir),
                    str(hn_img_dir),
                    str(hn_msk_dir),
                    WINDOW_SIZE,
                    STRIDE,
                    WHITE_THRESHOLD,
                )
            )

        split_stats[split] = (len(image_paths), len(tasks), len(missing))
        all_tasks.extend(tasks)
        all_missing.extend(missing)

    total_images = sum(v[0] for v in split_stats.values())
    total_pairs = sum(v[1] for v in split_stats.values())
    total_missing = sum(v[2] for v in split_stats.values())

    print("=== DATASET ÜBERSICHT ===")
    for s in splits:
        n_imgs, n_pairs, n_miss = split_stats[s]
        print(f"{s:5s}: Bilder={n_imgs:6d} | mit Maske={n_pairs:6d} | fehlend={n_miss:6d}")
    print("=========================")
    print(f"Gesamt Bilder:   {total_images}")
    print(f"Gesamt mit Maske:{total_pairs}")
    print(f"Gesamt fehlend:  {total_missing}")
    print(f"Worker:          {MAX_WORKERS}")

    if not all_tasks:
        print("Keine gültigen Bild/Masken-Paare gefunden. Abbruch.")
        return

    processed = 0
    total_patches = 0
    total_hn = 0
    errors = 0

    with ProcessPoolExecutor(max_workers=MAX_WORKERS) as ex:
        futures = [ex.submit(_process_one_pair, t) for t in all_tasks]

        for fut in tqdm(as_completed(futures), total=len(futures)):
            img_name, p_total, p_hn, err = fut.result()
            processed += 1
            total_patches += p_total
            total_hn += p_hn
            if err:
                errors += 1
                print(f"[ERROR] {img_name}: {err}")

            if processed % 100 == 0 or processed == len(all_tasks):
                print(
                    f"Progress: {processed}/{len(all_tasks)} | "
                    f"patches={total_patches} | hard_neg={total_hn} | errors={errors}"
                )

    if all_missing:
        print("\nBeispiele fehlender Masken (erste 20):")
        for n in all_missing[:20]:
            print(f"  - {n}")

    print("\nFERTIG")
    print(f"Verarbeitet:   {processed}")
    print(f"Total patches: {total_patches}")
    print(f"Hard negatives:{total_hn}")
    print(f"Errors:        {errors}")


if __name__ == "__main__":
    main()