#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Label-Noise-Verlauf über mehrere Trainings-Runs und alle Epoch-Checkpoints.

WICHTIGE IDEE
-------------
Die Originalbilder werden NICHT als Ganzes auf 512x512 heruntergerechnet.

Stattdessen:
1. Das Originalbild bleibt in seiner nativen Auflösung.
2. Es wird in überlappende Patches zerlegt (z.B. 512x512, Overlap 64).
3. Jeder Patch wird mit dem jeweiligen Epoch-Checkpoint inferiert.
4. Die Patch-Wahrscheinlichkeiten werden wieder zu einer Probability-Map
   in ORIGINALBILDGRÖSSE zusammengesetzt (Stitching / Mittelung im Overlap).
5. Daraus entstehen Overlay, Heatmap, Binärmaske und optional FP/FN-Karte.

Dadurch bleiben kleine / dünne Risse wesentlich besser erhalten als bei einem
globalen Downscaling eines großen Originalbildes auf nur 512x512.

RUN-AUSWAHL
-----------
RUN_SELECTION_MODE = "all"
    -> analysiert alle passenden Run-Unterordner in OUTPUTS_ROOT.

RUN_SELECTION_MODE = "selected"
    -> analysiert nur die explizit in RUN_NAMES eingetragenen Runs.

Erwartete Struktur
------------------
OUTPUTS_ROOT/
├── RUN_A/
│   ├── models/
│   │   ├── RUN_A_epoch_1.keras
│   │   └── ...
│   └── metrics/
│       └── *.json
├── RUN_B/
│   └── ...
└── ...

ANALYSE_BILDER_DIR/
├── bild_001.png
├── bild_002.png
└── masks/                  # optional
    ├── bild_001.png
    └── bild_002.png

Alternativ kann GT_MASK_DIR explizit gesetzt werden.
"""

from __future__ import annotations

import csv
import gc
import importlib.util
import json
import math
import os
import re
import sys
import traceback
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Iterable

os.environ.setdefault("TF_GPU_ALLOCATOR", "cuda_malloc_async")
os.environ.setdefault("KERAS_BACKEND", "tensorflow")
os.environ.setdefault("TF_CPP_MIN_LOG_LEVEL", "1")

import cv2
import numpy as np
import tensorflow as tf


# =============================================================================
# CUSTOM-LAYER-FALLBACKS FUER GESPEICHERTE .KERAS-MODELLE
# =============================================================================

@tf.keras.utils.register_keras_serializable(
    package="crack_segmentation",
    name="AddPositionEmbedding",
)
class AddPositionEmbedding(tf.keras.layers.Layer):
    """
    Trainierbares ViT-Positions-Embedding.

    Erwartete gespeicherte Keras-Konfiguration:
    registered_name = "crack_segmentation>AddPositionEmbedding"
    """

    def __init__(
        self,
        num_tokens: int,
        embed_dim: int,
        **kwargs,
    ):
        super().__init__(**kwargs)
        self.num_tokens = int(num_tokens)
        self.embed_dim = int(embed_dim)
        self.position_embedding = None

    def build(self, input_shape):
        self.position_embedding = self.add_weight(
            name="position_embedding",
            shape=(1, self.num_tokens, self.embed_dim),
            initializer="random_normal",
            trainable=True,
        )
        super().build(input_shape)

    def call(self, inputs):
        x = tf.convert_to_tensor(inputs)
        return x + tf.cast(self.position_embedding, x.dtype)

    def get_config(self):
        config = super().get_config()
        config.update({
            "num_tokens": self.num_tokens,
            "embed_dim": self.embed_dim,
        })
        return config


def register_builtin_custom_objects() -> None:
    """Registriert lokale Fallback-Layer explizit bei Keras."""
    custom_objects = tf.keras.utils.get_custom_objects()
    custom_objects["AddPositionEmbedding"] = AddPositionEmbedding
    custom_objects["crack_segmentation>AddPositionEmbedding"] = AddPositionEmbedding



# =============================================================================
# 1. BENUTZERKONFIGURATION
# =============================================================================

# -------------------------------------------------------------------------
# Quellbilder für die Analyse
# -------------------------------------------------------------------------
ANALYSE_BILDER_DIR = Path(
    "/home/mitte/crack_project/test_images/10_Bilder_test"
)

# Optional:
# None -> automatisch masks/, mask/, gt/, ground_truth/, labels/ suchen.
# Path("/...") -> diesen GT-Ordner erzwingen.
GT_MASK_DIR: Path | None = None

# Bilder optional rekursiv suchen.
RECURSIVE_IMAGE_SEARCH = False


# -------------------------------------------------------------------------
# Haupt-Outputs-Ordner mit allen Trainings-Runs
# -------------------------------------------------------------------------
OUTPUTS_ROOT = Path(
    "/home/mitte/crack_project/outputs"
)


# -------------------------------------------------------------------------
# Run-Auswahl
# -------------------------------------------------------------------------
# "all":
#   Alle Unterordner von OUTPUTS_ROOT analysieren, die einen models/-Ordner
#   mit mindestens einem .keras-Checkpoint besitzen.
#
# "selected":
#   Nur die unten in RUN_NAMES eingetragenen Runs analysieren.
RUN_SELECTION_MODE = "selected"

RUN_NAMES = [
    "unetpp_512px_f16-256_BetterDataset_focal_attention_vit",
    "unetpp_512px_f8-128_BaselineDataset",
    "unetpp_512px_f8-128_mixedDatasets",
]


# -------------------------------------------------------------------------
# Checkpoint-Auswahl
# -------------------------------------------------------------------------
# None = keine Begrenzung.
START_EPOCH: int | None = None
END_EPOCH: int | None = None


# -------------------------------------------------------------------------
# Patch-Inferenz
# -------------------------------------------------------------------------
# Normalerweise wird PATCH_SIZE aus der jeweiligen Run-JSON bzw. aus dem
# Modellinput gelesen. Dieser Wert ist nur Fallback.
DEFAULT_PATCH_SIZE = 512

# Overlap zwischen Nachbarpatches.
# 64 bei 512px Patches ist ein guter Startwert.
PATCH_OVERLAP = 64

# Batchgröße für die Patch-Inferenz.
INFERENCE_BATCH_SIZE = 8


# -------------------------------------------------------------------------
# Threshold
# -------------------------------------------------------------------------
# None:
#   Threshold aus der Run-JSON lesen, sonst Fallback 0.5.
#
# Zahl:
#   global für alle Runs überschreiben.
GLOBAL_THRESHOLD_OVERRIDE: float | None = None

DEFAULT_THRESHOLD = 0.5


# -------------------------------------------------------------------------
# Mixed Precision
# -------------------------------------------------------------------------
# True:
#   Policy aus der JSON übernehmen, wenn dort mixed_float16 erkannt wird.
#
# False:
#   immer float32 verwenden.
USE_MIXED_PRECISION_FROM_METADATA = True


# -------------------------------------------------------------------------
# Ausgabe / Visualisierung
# -------------------------------------------------------------------------
PREDICTION_OVERLAY_ALPHA = 0.45

# Prediction Overlay = rot (BGR).
PREDICTION_OVERLAY_COLOR_BGR = (0, 0, 255)

# Fehlerkarte:
ERROR_COLOR_TN_BGR = (0, 0, 0)         # schwarz
ERROR_COLOR_TP_BGR = (255, 255, 255)   # weiß
ERROR_COLOR_FP_BGR = (255, 0, 0)       # blau
ERROR_COLOR_FN_BGR = (0, 0, 255)       # rot

VALID_IMAGE_EXTENSIONS = {
    ".png", ".jpg", ".jpeg", ".bmp", ".tif", ".tiff", ".webp"
}


# -------------------------------------------------------------------------
# Custom-Layer / Trainingsmodule
# -------------------------------------------------------------------------
# Falls ein .keras-Modell eigene Layer verwendet, kannst du hier die
# Trainingsdatei(en) eintragen, damit die serialisierbaren Klassen vor dem
# model-load registriert werden.
CUSTOM_MODULE_PATHS: list[Path] = [
    # Path("/home/mitte/crack_project/trainings/mein_training.py"),
]


# =============================================================================
# 2. DATENKLASSEN
# =============================================================================

@dataclass(frozen=True)
class RunMetadata:
    run_name: str
    patch_height: int
    patch_width: int
    threshold: float
    mixed_precision_policy: str
    metadata_path: Path | None


@dataclass(frozen=True)
class Checkpoint:
    epoch: int
    path: Path


@dataclass
class PatchInfo:
    x: int
    y: int
    valid_width: int
    valid_height: int
    patch_rgb: np.ndarray


# =============================================================================
# 3. HILFSFUNKTIONEN
# =============================================================================

def log(message: str) -> None:
    print(message, flush=True)


def json_safe(value: Any) -> Any:
    if isinstance(value, Path):
        return str(value)
    if isinstance(value, np.generic):
        return value.item()
    if isinstance(value, np.ndarray):
        return value.tolist()
    if isinstance(value, dict):
        return {str(k): json_safe(v) for k, v in value.items()}
    if isinstance(value, (list, tuple)):
        return [json_safe(v) for v in value]
    return value


def save_json(path: Path, data: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + ".tmp")
    with tmp.open("w", encoding="utf-8") as file:
        json.dump(json_safe(data), file, indent=2, ensure_ascii=False)
    tmp.replace(path)


def safe_div(numerator: float, denominator: float, eps: float = 1e-7) -> float:
    return float((numerator + eps) / (denominator + eps))


def imread_color(path: Path) -> np.ndarray:
    raw = np.fromfile(str(path), dtype=np.uint8)
    image = cv2.imdecode(raw, cv2.IMREAD_COLOR)
    if image is None:
        raise ValueError(f"Bild konnte nicht gelesen werden: {path}")
    return image


def imread_gray(path: Path) -> np.ndarray:
    raw = np.fromfile(str(path), dtype=np.uint8)
    image = cv2.imdecode(raw, cv2.IMREAD_GRAYSCALE)
    if image is None:
        raise ValueError(f"Maske konnte nicht gelesen werden: {path}")
    return image


def imwrite(path: Path, image: np.ndarray) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    suffix = path.suffix.lower()

    if suffix not in VALID_IMAGE_EXTENSIONS:
        suffix = ".png"
        path = path.with_suffix(".png")

    ok, encoded = cv2.imencode(suffix, image)
    if not ok:
        raise IOError(f"OpenCV konnte Datei nicht kodieren: {path}")
    encoded.tofile(str(path))


# =============================================================================
# 4. JSON-METADATEN
# =============================================================================

def iter_json_items(value: Any) -> Iterable[tuple[str, Any]]:
    if isinstance(value, dict):
        for key, child in value.items():
            yield str(key), child
            yield from iter_json_items(child)
    elif isinstance(value, list):
        for child in value:
            yield from iter_json_items(child)


def find_first_value(data: Any, candidate_keys: Iterable[str]) -> Any | None:
    candidates = {str(key).lower() for key in candidate_keys}

    for key, value in iter_json_items(data):
        if key.lower() in candidates:
            return value

    return None


def parse_resolution(value: Any) -> tuple[int, int] | None:
    if value is None:
        return None

    if isinstance(value, (int, float, np.integer, np.floating)):
        size = int(value)
        if size > 0:
            return size, size

    if isinstance(value, str):
        numbers = [int(x) for x in re.findall(r"\d+", value)]
        if len(numbers) >= 2:
            return numbers[0], numbers[1]
        if len(numbers) == 1 and numbers[0] > 0:
            return numbers[0], numbers[0]

    if isinstance(value, (list, tuple)):
        numbers = []
        for item in value:
            try:
                numbers.append(int(item))
            except (TypeError, ValueError):
                continue

        if len(numbers) >= 2:
            return numbers[0], numbers[1]

        if len(numbers) == 1:
            return numbers[0], numbers[0]

    if isinstance(value, dict):
        lowered = {str(k).lower(): v for k, v in value.items()}

        height = (
            lowered.get("height")
            or lowered.get("h")
            or lowered.get("rows")
        )

        width = (
            lowered.get("width")
            or lowered.get("w")
            or lowered.get("cols")
        )

        if height is not None and width is not None:
            try:
                return int(height), int(width)
            except (TypeError, ValueError):
                pass

    return None


def normalize_mixed_precision(value: Any) -> str:
    if not USE_MIXED_PRECISION_FROM_METADATA:
        return "float32"

    if isinstance(value, bool):
        return "mixed_float16" if value else "float32"

    if value is None:
        return "float32"

    text = str(value).strip().lower()

    if (
        "mixed_float16" in text
        or text in {"fp16", "float16", "mixed", "true", "1"}
    ):
        return "mixed_float16"

    return "float32"


def metadata_score(data: Any) -> int:
    keys = {key.lower() for key, _ in iter_json_items(data)}

    score = 0

    for group in (
        {"run_name", "run", "name"},
        {"patch_resolution", "patch_size", "img_size", "image_size", "input_size"},
        {"threshold", "segmentation_threshold", "mask_threshold"},
        {"mixed_precision_policy", "mixed_precision", "precision_policy"},
    ):
        if keys.intersection(group):
            score += 1

    return score


def auto_find_metadata_json(
    run_dir: Path,
) -> tuple[Path | None, dict[str, Any] | None]:

    metrics_dir = run_dir / "metrics"

    if not metrics_dir.is_dir():
        return None, None

    candidates = sorted(metrics_dir.glob("*.json"))

    best_path = None
    best_data = None
    best_score = -1

    for path in candidates:
        try:
            with path.open("r", encoding="utf-8") as file:
                data = json.load(file)
        except Exception:
            continue

        score = metadata_score(data)

        lower_name = path.name.lower()
        if any(token in lower_name for token in ("config", "metadata", "run")):
            score += 1

        if score > best_score:
            best_score = score
            best_path = path
            best_data = data

    return best_path, best_data


def load_run_metadata(run_dir: Path) -> RunMetadata:
    metadata_path, data = auto_find_metadata_json(run_dir)

    if data is None:
        data = {}
        log(
            f"[WARNUNG] {run_dir.name}: keine brauchbare JSON gefunden. "
            "Patchgröße/Threshold werden aus Modell bzw. Defaults bestimmt."
        )

    run_name_value = find_first_value(
        data,
        ["run_name", "run", "name", "experiment_name"],
    )

    run_name = (
        str(run_name_value).strip()
        if run_name_value
        else run_dir.name
    )

    resolution_value = find_first_value(
        data,
        [
            "patch_resolution",
            "patch_size",
            "img_size",
            "image_size",
            "input_size",
            "input_resolution",
        ],
    )

    resolution = (
        parse_resolution(resolution_value)
        or (DEFAULT_PATCH_SIZE, DEFAULT_PATCH_SIZE)
    )

    threshold_value = find_first_value(
        data,
        [
            "threshold",
            "segmentation_threshold",
            "mask_threshold",
            "prediction_threshold",
        ],
    )

    try:
        threshold = float(threshold_value)
    except (TypeError, ValueError):
        threshold = DEFAULT_THRESHOLD

    if GLOBAL_THRESHOLD_OVERRIDE is not None:
        threshold = float(GLOBAL_THRESHOLD_OVERRIDE)

    precision_value = find_first_value(
        data,
        [
            "mixed_precision_policy",
            "mixed_precision",
            "precision_policy",
            "dtype_policy",
        ],
    )

    return RunMetadata(
        run_name=run_name,
        patch_height=int(resolution[0]),
        patch_width=int(resolution[1]),
        threshold=threshold,
        mixed_precision_policy=normalize_mixed_precision(precision_value),
        metadata_path=metadata_path,
    )


# =============================================================================
# 5. RUN- UND CHECKPOINT-AUSWAHL
# =============================================================================

def run_has_checkpoints(run_dir: Path) -> bool:
    models_dir = run_dir / "models"

    if not models_dir.is_dir():
        return False

    return any(models_dir.glob("*.keras"))


def discover_runs() -> list[Path]:
    if not OUTPUTS_ROOT.is_dir():
        raise FileNotFoundError(
            f"OUTPUTS_ROOT existiert nicht: {OUTPUTS_ROOT}"
        )

    mode = RUN_SELECTION_MODE.strip().lower()

    if mode == "all":
        runs = sorted(
            path.resolve()
            for path in OUTPUTS_ROOT.iterdir()
            if path.is_dir() and run_has_checkpoints(path)
        )

    elif mode == "selected":
        if not RUN_NAMES:
            raise ValueError(
                'RUN_SELECTION_MODE="selected", aber RUN_NAMES ist leer.'
            )

        runs = []

        for run_name in RUN_NAMES:
            run_dir = (OUTPUTS_ROOT / run_name).resolve()

            if not run_dir.is_dir():
                log(
                    f"[WARNUNG] Run nicht gefunden und wird übersprungen: "
                    f"{run_name}"
                )
                continue

            if not run_has_checkpoints(run_dir):
                log(
                    f"[WARNUNG] Kein .keras-Checkpoint in: {run_dir / 'models'}"
                )
                continue

            runs.append(run_dir)

    else:
        raise ValueError(
            'RUN_SELECTION_MODE muss "all" oder "selected" sein.'
        )

    if not runs:
        raise RuntimeError("Keine analysierbaren Trainings-Runs gefunden.")

    return runs


def extract_epoch_number(path: Path) -> int | None:
    name = path.stem

    for pattern in (
        r"(?:epoch|epoche)[_-]?(\d+)",
        r"(?:epoch|epoche)\s*(\d+)",
    ):
        match = re.search(pattern, name, flags=re.IGNORECASE)
        if match:
            return int(match.group(1))

    # Fallback: letzte Zifferngruppe.
    numbers = re.findall(r"(\d+)", name)

    if numbers:
        return int(numbers[-1])

    return None


def discover_checkpoints(run_dir: Path) -> list[Checkpoint]:
    models_dir = run_dir / "models"

    found: list[Checkpoint] = []

    for path in models_dir.glob("*.keras"):
        epoch = extract_epoch_number(path)

        if epoch is None:
            log(
                f"[WARNUNG] Epochennummer nicht erkannt: {path.name}"
            )
            continue

        if START_EPOCH is not None and epoch < START_EPOCH:
            continue

        if END_EPOCH is not None and epoch > END_EPOCH:
            continue

        found.append(
            Checkpoint(
                epoch=epoch,
                path=path.resolve(),
            )
        )

    found.sort(key=lambda item: (item.epoch, item.path.name))

    return found


# =============================================================================
# 6. INPUT-BILDER / GROUND TRUTH
# =============================================================================

def collect_images(
    directory: Path,
    recursive: bool = False,
) -> list[Path]:

    if not directory.is_dir():
        raise FileNotFoundError(
            f"ANALYSE_BILDER_DIR existiert nicht: {directory}"
        )

    iterator = (
        directory.rglob("*")
        if recursive
        else directory.iterdir()
    )

    return sorted(
        path.resolve()
        for path in iterator
        if (
            path.is_file()
            and path.suffix.lower() in VALID_IMAGE_EXTENSIONS
        )
    )


def resolve_image_dir() -> Path:
    """
    Wenn ANALYSE_BILDER_DIR selbst Bilder enthält -> direkt verwenden.

    Falls dort keine Bilder liegen, aber ANALYSE_BILDER_DIR/images existiert,
    wird dieser Unterordner verwendet.
    """
    root = ANALYSE_BILDER_DIR.resolve()

    if collect_images(root, recursive=False):
        return root

    images_subdir = root / "images"

    if images_subdir.is_dir() and collect_images(
        images_subdir,
        recursive=False,
    ):
        return images_subdir.resolve()

    return root


def auto_detect_gt_dir(images_dir: Path) -> Path | None:
    if GT_MASK_DIR is not None:
        path = GT_MASK_DIR.resolve()

        if not path.is_dir():
            raise FileNotFoundError(
                f"GT_MASK_DIR existiert nicht: {path}"
            )

        return path

    # Unterhalb des Bilderordners.
    for name in ("masks", "mask", "gt", "ground_truth", "labels"):
        candidate = images_dir / name

        if candidate.is_dir():
            return candidate.resolve()

    # Geschwisterordner.
    for name in ("masks", "mask", "gt", "ground_truth", "labels"):
        candidate = images_dir.parent / name

        if candidate.is_dir():
            return candidate.resolve()

    return None


def build_gt_map(gt_dir: Path | None) -> dict[str, Path]:
    if gt_dir is None:
        return {}

    result: dict[str, Path] = {}

    for path in gt_dir.rglob("*"):
        if (
            path.is_file()
            and path.suffix.lower() in VALID_IMAGE_EXTENSIONS
        ):
            result.setdefault(
                path.stem.lower(),
                path.resolve(),
            )

    return result


# =============================================================================
# 7. CUSTOM-LAYER / MODELLLADEN
# =============================================================================

def import_custom_modules() -> None:
    for index, path in enumerate(CUSTOM_MODULE_PATHS):
        path = path.resolve()

        if not path.is_file():
            raise FileNotFoundError(
                f"Custom-Modul nicht gefunden: {path}"
            )

        module_name = f"_label_noise_custom_{index}_{path.stem}"

        spec = importlib.util.spec_from_file_location(
            module_name,
            str(path),
        )

        if spec is None or spec.loader is None:
            raise ImportError(
                f"Custom-Modul konnte nicht geladen werden: {path}"
            )

        module = importlib.util.module_from_spec(spec)
        sys.modules[module_name] = module
        spec.loader.exec_module(module)

        log(f"[OK] Custom-Modul geladen: {path}")


def register_optional_packages() -> None:
    for package_name in ("keras_hub", "transformers"):
        try:
            __import__(package_name)
        except Exception:
            pass


def load_model(path: Path) -> tf.keras.Model:
    register_builtin_custom_objects()

    custom_objects = {
        "AddPositionEmbedding": AddPositionEmbedding,
        "crack_segmentation>AddPositionEmbedding": AddPositionEmbedding,
    }

    try:
        return tf.keras.models.load_model(
            path,
            compile=False,
            safe_mode=False,
            custom_objects=custom_objects,
        )
    except TypeError:
        return tf.keras.models.load_model(
            path,
            compile=False,
            custom_objects=custom_objects,
        )


def get_model_input_hw(
    model: tf.keras.Model,
    metadata_hw: tuple[int, int],
) -> tuple[int, int]:

    shape = model.input_shape

    if isinstance(shape, list):
        shape = shape[0]

    if (
        not isinstance(shape, (tuple, list))
        or len(shape) < 4
        or shape[1] is None
        or shape[2] is None
    ):
        return metadata_hw

    model_hw = (
        int(shape[1]),
        int(shape[2]),
    )

    if model_hw != metadata_hw:
        log(
            f"[INFO] Modellinput {model_hw[0]}x{model_hw[1]} "
            f"überschreibt JSON-Patchgröße "
            f"{metadata_hw[0]}x{metadata_hw[1]}."
        )

    return model_hw


def get_model_input_channels(model: tf.keras.Model) -> int:
    shape = model.input_shape

    if isinstance(shape, list):
        shape = shape[0]

    if (
        isinstance(shape, (tuple, list))
        and len(shape) >= 4
        and shape[-1] is not None
    ):
        return int(shape[-1])

    return 3


# =============================================================================
# 8. PATCH-EXTRAKTION
# =============================================================================

def compute_patch_positions(
    length: int,
    patch_size: int,
    overlap: int,
) -> list[int]:

    if patch_size <= 0:
        raise ValueError("patch_size muss > 0 sein.")

    if not 0 <= overlap < patch_size:
        raise ValueError(
            "PATCH_OVERLAP muss >= 0 und kleiner als Patchgröße sein."
        )

    if length <= patch_size:
        return [0]

    stride = patch_size - overlap

    positions = list(
        range(
            0,
            max(length - patch_size + 1, 1),
            stride,
        )
    )

    final_position = length - patch_size

    if not positions or positions[-1] != final_position:
        positions.append(final_position)

    return positions


def extract_patches(
    image_bgr: np.ndarray,
    patch_hw: tuple[int, int],
    channels: int,
) -> list[PatchInfo]:

    patch_h, patch_w = patch_hw

    if patch_h != patch_w:
        # Das Skript unterstützt auch rechteckige Patches, aber der Overlap
        # wird für beide Achsen gleich interpretiert.
        pass

    image_h, image_w = image_bgr.shape[:2]

    y_positions = compute_patch_positions(
        image_h,
        patch_h,
        PATCH_OVERLAP,
    )

    x_positions = compute_patch_positions(
        image_w,
        patch_w,
        PATCH_OVERLAP,
    )

    patches: list[PatchInfo] = []

    for y in y_positions:
        for x in x_positions:
            crop = image_bgr[
                y:min(y + patch_h, image_h),
                x:min(x + patch_w, image_w),
            ]

            valid_h, valid_w = crop.shape[:2]

            padded = np.zeros(
                (patch_h, patch_w, 3),
                dtype=np.uint8,
            )

            padded[:valid_h, :valid_w] = crop

            if channels == 3:
                patch_input = cv2.cvtColor(
                    padded,
                    cv2.COLOR_BGR2RGB,
                )

            elif channels == 1:
                gray = cv2.cvtColor(
                    padded,
                    cv2.COLOR_BGR2GRAY,
                )
                patch_input = gray[..., None]

            else:
                raise ValueError(
                    f"Nicht unterstützte Kanalzahl: {channels}"
                )

            patch_input = (
                patch_input.astype(np.float32) / 255.0
            )

            patches.append(
                PatchInfo(
                    x=x,
                    y=y,
                    valid_width=valid_w,
                    valid_height=valid_h,
                    patch_rgb=patch_input,
                )
            )

    return patches


# =============================================================================
# 9. MODELL-OUTPUT
# =============================================================================

def normalize_model_output(output: Any) -> tf.Tensor:
    if isinstance(output, dict):
        for key in (
            "predictions",
            "probabilities",
            "logits",
            "output",
        ):
            if key in output:
                return tf.convert_to_tensor(output[key])

        return tf.convert_to_tensor(
            next(iter(output.values()))
        )

    if isinstance(output, (list, tuple)):
        if not output:
            raise ValueError("Leere Modell-Output-Liste.")

        return tf.convert_to_tensor(output[0])

    return tf.convert_to_tensor(output)


def output_to_probability_maps(output: Any) -> np.ndarray:
    tensor = tf.cast(
        normalize_model_output(output),
        tf.float32,
    )

    if tensor.shape.rank == 4:
        channels = tensor.shape[-1]

        if channels == 1:
            tensor = tensor[..., 0]

            min_value = float(tf.reduce_min(tensor).numpy())
            max_value = float(tf.reduce_max(tensor).numpy())

            if min_value < 0.0 or max_value > 1.0:
                tensor = tf.math.sigmoid(tensor)

        elif channels == 2:
            min_value = float(tf.reduce_min(tensor).numpy())
            max_value = float(tf.reduce_max(tensor).numpy())

            channel_sum = float(
                tf.reduce_mean(
                    tf.reduce_sum(tensor, axis=-1)
                ).numpy()
            )

            already_probability = (
                min_value >= 0.0
                and max_value <= 1.0
                and abs(channel_sum - 1.0) < 0.05
            )

            if not already_probability:
                tensor = tf.nn.softmax(
                    tensor,
                    axis=-1,
                )

            tensor = tensor[..., 1]

        else:
            raise ValueError(
                f"Nicht unterstützte Output-Kanäle: "
                f"{tensor.shape}"
            )

    elif tensor.shape.rank == 3:
        min_value = float(tf.reduce_min(tensor).numpy())
        max_value = float(tf.reduce_max(tensor).numpy())

        if min_value < 0.0 or max_value > 1.0:
            tensor = tf.math.sigmoid(tensor)

    else:
        raise ValueError(
            f"Nicht unterstützte Modell-Ausgabe: {tensor.shape}"
        )

    tensor = tf.clip_by_value(
        tensor,
        0.0,
        1.0,
    )

    return tensor.numpy().astype(np.float32)


# =============================================================================
# 10. PATCH-INFERENZ UND STITCHING
# =============================================================================

def predict_original_image_with_patches(
    model: tf.keras.Model,
    image_bgr: np.ndarray,
    patch_hw: tuple[int, int],
    input_channels: int,
) -> np.ndarray:
    """
    Ergebnis:
        Probability-Map exakt in Originalbildgröße.

    KEIN globales Resizing des Originalbildes.
    """
    image_h, image_w = image_bgr.shape[:2]

    patches = extract_patches(
        image_bgr=image_bgr,
        patch_hw=patch_hw,
        channels=input_channels,
    )

    probability_sum = np.zeros(
        (image_h, image_w),
        dtype=np.float32,
    )

    weight_sum = np.zeros(
        (image_h, image_w),
        dtype=np.float32,
    )

    total_patches = len(patches)

    for start in range(
        0,
        total_patches,
        INFERENCE_BATCH_SIZE,
    ):
        batch_infos = patches[
            start:start + INFERENCE_BATCH_SIZE
        ]

        batch_input = np.stack(
            [info.patch_rgb for info in batch_infos],
            axis=0,
        ).astype(np.float32)

        output = model(
            batch_input,
            training=False,
        )

        batch_probabilities = output_to_probability_maps(
            output
        )

        if batch_probabilities.shape[0] != len(batch_infos):
            raise RuntimeError(
                "Output-Batchgröße stimmt nicht mit Input-Batchgröße überein."
            )

        for info, probability in zip(
            batch_infos,
            batch_probabilities,
        ):
            # Falls ein Modell wider Erwarten nicht exakt die Patchgröße
            # zurückgibt, nur DANN wird die Modell-Outputmap auf die Patchgröße
            # angepasst. Das Originalbild selbst wird nicht skaliert.
            patch_h, patch_w = patch_hw

            if probability.shape[:2] != (patch_h, patch_w):
                probability = cv2.resize(
                    probability.astype(np.float32),
                    (patch_w, patch_h),
                    interpolation=cv2.INTER_LINEAR,
                )

            probability_crop = probability[
                :info.valid_height,
                :info.valid_width,
            ]

            y1 = info.y
            y2 = info.y + info.valid_height
            x1 = info.x
            x2 = info.x + info.valid_width

            probability_sum[y1:y2, x1:x2] += probability_crop
            weight_sum[y1:y2, x1:x2] += 1.0

    weight_sum[weight_sum == 0.0] = 1.0

    return probability_sum / weight_sum


# =============================================================================
# 11. GT / VISUALISIERUNG
# =============================================================================

def load_gt_binary(
    gt_path: Path | None,
    original_hw: tuple[int, int],
) -> np.ndarray | None:

    if gt_path is None:
        return None

    gt = imread_gray(gt_path)

    original_h, original_w = original_hw

    if gt.shape[:2] != (original_h, original_w):
        # GT-Masken sind diskrete Klassen -> IMMER nearest-neighbor.
        gt = cv2.resize(
            gt,
            (original_w, original_h),
            interpolation=cv2.INTER_NEAREST,
        )

    return (gt > 127).astype(np.uint8)


def create_prediction_overlay(
    original_bgr: np.ndarray,
    binary_mask: np.ndarray,
) -> np.ndarray:

    overlay = original_bgr.copy()

    color_layer = np.zeros_like(
        original_bgr,
        dtype=np.uint8,
    )

    color_layer[:] = PREDICTION_OVERLAY_COLOR_BGR

    blended = cv2.addWeighted(
        original_bgr,
        1.0 - PREDICTION_OVERLAY_ALPHA,
        color_layer,
        PREDICTION_OVERLAY_ALPHA,
        0.0,
    )

    mask = binary_mask.astype(bool)

    overlay[mask] = blended[mask]

    return overlay


def create_heatmap(
    probability: np.ndarray,
) -> np.ndarray:

    prob_uint8 = np.clip(
        np.round(probability * 255.0),
        0,
        255,
    ).astype(np.uint8)

    return cv2.applyColorMap(
        prob_uint8,
        cv2.COLORMAP_JET,
    )


def create_error_map(
    gt_binary: np.ndarray,
    pred_binary: np.ndarray,
) -> np.ndarray:

    gt = gt_binary.astype(bool)
    pred = pred_binary.astype(bool)

    tp = np.logical_and(gt, pred)
    fp = np.logical_and(~gt, pred)
    fn = np.logical_and(gt, ~pred)

    result = np.zeros(
        (*gt.shape, 3),
        dtype=np.uint8,
    )

    result[:] = ERROR_COLOR_TN_BGR
    result[tp] = ERROR_COLOR_TP_BGR
    result[fp] = ERROR_COLOR_FP_BGR
    result[fn] = ERROR_COLOR_FN_BGR

    return result


# =============================================================================
# 12. METRIKEN
# =============================================================================

def confusion_counts(
    gt_binary: np.ndarray,
    pred_binary: np.ndarray,
) -> tuple[int, int, int, int]:

    gt = gt_binary.astype(bool)
    pred = pred_binary.astype(bool)

    tp = int(np.logical_and(gt, pred).sum())
    fp = int(np.logical_and(~gt, pred).sum())
    fn = int(np.logical_and(gt, ~pred).sum())
    tn = int(np.logical_and(~gt, ~pred).sum())

    return tp, fp, fn, tn


def metrics_from_confusion(
    tp: int,
    fp: int,
    fn: int,
    tn: int,
) -> dict[str, float]:

    precision = safe_div(
        tp,
        tp + fp,
    )

    recall = safe_div(
        tp,
        tp + fn,
    )

    dice = safe_div(
        2 * tp,
        2 * tp + fp + fn,
    )

    iou = safe_div(
        tp,
        tp + fp + fn,
    )

    accuracy = safe_div(
        tp + tn,
        tp + tn + fp + fn,
    )

    return {
        "precision": precision,
        "recall": recall,
        "dice_f1": dice,
        "iou": iou,
        "accuracy": accuracy,
    }


# =============================================================================
# 13. CSV
# =============================================================================

PER_IMAGE_FIELDS = [
    "run_name",
    "epoch",
    "checkpoint",
    "image",
    "gt_available",
    "threshold",
    "patch_height",
    "patch_width",
    "patch_overlap",
    "tp",
    "fp",
    "fn",
    "tn",
    "precision",
    "recall",
    "dice_f1",
    "iou",
    "accuracy",
    "mean_probability",
    "max_probability",
    "predicted_crack_fraction",
    "gt_crack_fraction",
]


SUMMARY_FIELDS = [
    "run_name",
    "epoch",
    "checkpoint",
    "images_total",
    "images_with_gt",
    "threshold",
    "patch_height",
    "patch_width",
    "patch_overlap",
    "tp",
    "fp",
    "fn",
    "tn",
    "precision",
    "recall",
    "dice_f1",
    "iou",
    "accuracy",
]


def write_csv(
    path: Path,
    rows: list[dict[str, Any]],
    fieldnames: list[str],
) -> None:

    path.parent.mkdir(
        parents=True,
        exist_ok=True,
    )

    with path.open(
        "w",
        encoding="utf-8",
        newline="",
    ) as file:

        writer = csv.DictWriter(
            file,
            fieldnames=fieldnames,
        )

        writer.writeheader()

        for row in rows:
            writer.writerow(
                {
                    key: row.get(key, "")
                    for key in fieldnames
                }
            )


# =============================================================================
# 14. CHECKPOINT-VERARBEITUNG
# =============================================================================

def process_checkpoint(
    run_name: str,
    checkpoint: Checkpoint,
    model: tf.keras.Model,
    image_paths: list[Path],
    gt_map: dict[str, Path],
    epoch_dir: Path,
    patch_hw: tuple[int, int],
    input_channels: int,
    threshold: float,
) -> tuple[list[dict[str, Any]], dict[str, Any]]:

    images_output_dir = epoch_dir / "images"

    images_output_dir.mkdir(
        parents=True,
        exist_ok=True,
    )

    per_image_rows: list[dict[str, Any]] = []

    total_tp = 0
    total_fp = 0
    total_fn = 0
    total_tn = 0

    images_with_gt = 0

    for image_index, image_path in enumerate(
        image_paths,
        start=1,
    ):
        original_bgr = imread_color(
            image_path
        )

        image_h, image_w = original_bgr.shape[:2]

        probability = predict_original_image_with_patches(
            model=model,
            image_bgr=original_bgr,
            patch_hw=patch_hw,
            input_channels=input_channels,
        )

        # Die Probability-Map ist bereits exakt in Originalbildgröße.
        pred_binary = (
            probability >= threshold
        ).astype(np.uint8)

        overlay = create_prediction_overlay(
            original_bgr,
            pred_binary,
        )

        heatmap = create_heatmap(
            probability
        )

        imwrite(
            images_output_dir
            / f"{image_path.stem}__overlay.png",
            overlay,
        )

        imwrite(
            images_output_dir
            / f"{image_path.stem}__heatmap.png",
            heatmap,
        )

        imwrite(
            images_output_dir
            / f"{image_path.stem}__mask.png",
            pred_binary * 255,
        )

        gt_path = gt_map.get(
            image_path.stem.lower()
        )

        gt_binary = load_gt_binary(
            gt_path=gt_path,
            original_hw=(image_h, image_w),
        )

        row: dict[str, Any] = {
            "run_name": run_name,
            "epoch": checkpoint.epoch,
            "checkpoint": checkpoint.path.name,
            "image": image_path.name,
            "gt_available": gt_binary is not None,
            "threshold": threshold,
            "patch_height": patch_hw[0],
            "patch_width": patch_hw[1],
            "patch_overlap": PATCH_OVERLAP,
            "tp": "",
            "fp": "",
            "fn": "",
            "tn": "",
            "precision": "",
            "recall": "",
            "dice_f1": "",
            "iou": "",
            "accuracy": "",
            "mean_probability": float(
                probability.mean()
            ),
            "max_probability": float(
                probability.max()
            ),
            "predicted_crack_fraction": float(
                pred_binary.mean()
            ),
            "gt_crack_fraction": "",
        }

        if gt_binary is not None:
            error_map = create_error_map(
                gt_binary=gt_binary,
                pred_binary=pred_binary,
            )

            imwrite(
                images_output_dir
                / f"{image_path.stem}__fp_fn.png",
                error_map,
            )

            tp, fp, fn, tn = confusion_counts(
                gt_binary=gt_binary,
                pred_binary=pred_binary,
            )

            metrics = metrics_from_confusion(
                tp,
                fp,
                fn,
                tn,
            )

            total_tp += tp
            total_fp += fp
            total_fn += fn
            total_tn += tn

            images_with_gt += 1

            row.update(
                {
                    "tp": tp,
                    "fp": fp,
                    "fn": fn,
                    "tn": tn,
                    **metrics,
                    "gt_crack_fraction": float(
                        gt_binary.mean()
                    ),
                }
            )

        per_image_rows.append(
            row
        )

        log(
            f"      [{image_index}/{len(image_paths)}] "
            f"{image_path.name}"
        )

    write_csv(
        epoch_dir / "metrics.csv",
        per_image_rows,
        PER_IMAGE_FIELDS,
    )

    if images_with_gt > 0:
        aggregate_metrics = metrics_from_confusion(
            total_tp,
            total_fp,
            total_fn,
            total_tn,
        )
    else:
        aggregate_metrics = {
            "precision": float("nan"),
            "recall": float("nan"),
            "dice_f1": float("nan"),
            "iou": float("nan"),
            "accuracy": float("nan"),
        }

    summary = {
        "run_name": run_name,
        "epoch": checkpoint.epoch,
        "checkpoint": checkpoint.path.name,
        "images_total": len(image_paths),
        "images_with_gt": images_with_gt,
        "threshold": threshold,
        "patch_height": patch_hw[0],
        "patch_width": patch_hw[1],
        "patch_overlap": PATCH_OVERLAP,
        "tp": total_tp if images_with_gt else "",
        "fp": total_fp if images_with_gt else "",
        "fn": total_fn if images_with_gt else "",
        "tn": total_tn if images_with_gt else "",
        **aggregate_metrics,
    }

    save_json(
        epoch_dir / "epoch_summary.json",
        summary,
    )

    return per_image_rows, summary


# =============================================================================
# 15. GPU
# =============================================================================

def configure_gpu() -> None:
    gpus = tf.config.list_physical_devices(
        "GPU"
    )

    for gpu in gpus:
        try:
            tf.config.experimental.set_memory_growth(
                gpu,
                True,
            )
        except RuntimeError:
            pass

    if gpus:
        log(
            f"[INFO] TensorFlow erkennt {len(gpus)} GPU(s)."
        )
    else:
        log(
            "[WARNUNG] Keine TensorFlow-GPU erkannt."
        )


# =============================================================================
# 16. MAIN
# =============================================================================

def main() -> None:
    register_builtin_custom_objects()
    if INFERENCE_BATCH_SIZE <= 0:
        raise ValueError(
            "INFERENCE_BATCH_SIZE muss > 0 sein."
        )

    configure_gpu()
    register_optional_packages()
    import_custom_modules()

    images_dir = resolve_image_dir()

    image_paths = collect_images(
        images_dir,
        recursive=RECURSIVE_IMAGE_SEARCH,
    )

    if not image_paths:
        raise RuntimeError(
            f"Keine Analysebilder gefunden: {images_dir}"
        )

    gt_dir = auto_detect_gt_dir(
        images_dir
    )

    gt_map = build_gt_map(
        gt_dir
    )

    run_dirs = discover_runs()

    log("=" * 110)
    log("LABEL-NOISE-VERLAUF ÜBER TRAININGS-CHECKPOINTS")
    log("=" * 110)
    log(f"OUTPUTS_ROOT:         {OUTPUTS_ROOT.resolve()}")
    log(f"Run-Modus:            {RUN_SELECTION_MODE}")
    log(f"Gefundene Runs:       {len(run_dirs)}")
    log(f"Analysebilder:        {len(image_paths)}")
    log(f"Bilderordner:         {images_dir}")
    log(f"GT-Ordner:            {gt_dir if gt_dir else 'kein GT'}")
    log(f"GT-Masken:            {len(gt_map)}")
    log(f"Patch-Overlap:         {PATCH_OVERLAP}")
    log(f"Inferenz-Batchgröße:  {INFERENCE_BATCH_SIZE}")
    log("=" * 110)

    global_summary_rows: list[dict[str, Any]] = []

    for run_index, run_dir in enumerate(
        run_dirs,
        start=1,
    ):
        log("")
        log("#" * 110)
        log(
            f"RUN [{run_index}/{len(run_dirs)}]: "
            f"{run_dir.name}"
        )
        log("#" * 110)

        metadata = load_run_metadata(
            run_dir
        )

        policy = metadata.mixed_precision_policy

        tf.keras.mixed_precision.set_global_policy(
            policy
        )

        checkpoints = discover_checkpoints(
            run_dir
        )

        if not checkpoints:
            log(
                "[WARNUNG] Keine passenden Epoch-Checkpoints "
                "nach Filterung. Run wird übersprungen."
            )
            continue

        run_output_root = (
            run_dir / "label_noise_verlauf"
        )

        run_output_root.mkdir(
            parents=True,
            exist_ok=True,
        )

        run_summary_rows: list[dict[str, Any]] = []

        log(
            f"  Run-Name Metadaten: {metadata.run_name}"
        )
        log(
            f"  JSON Patchgröße:     "
            f"{metadata.patch_height}x{metadata.patch_width}"
        )
        log(
            f"  Threshold:           {metadata.threshold:.4f}"
        )
        log(
            f"  Mixed Precision:     {policy}"
        )
        log(
            f"  Checkpoints:         {len(checkpoints)}"
        )

        for checkpoint_index, checkpoint in enumerate(
            checkpoints,
            start=1,
        ):
            log("")
            log(
                f"  EPOCHE [{checkpoint_index}/{len(checkpoints)}] "
                f"{checkpoint.epoch}: {checkpoint.path.name}"
            )

            tf.keras.backend.clear_session()
            gc.collect()

            model = None

            try:
                model = load_model(
                    checkpoint.path
                )

                patch_hw = get_model_input_hw(
                    model=model,
                    metadata_hw=(
                        metadata.patch_height,
                        metadata.patch_width,
                    ),
                )

                input_channels = get_model_input_channels(
                    model
                )

                if PATCH_OVERLAP >= min(patch_hw):
                    raise ValueError(
                        f"PATCH_OVERLAP={PATCH_OVERLAP} ist für "
                        f"Patchgröße {patch_hw} zu groß."
                    )

                log(
                    f"    Patch-Inferenz: "
                    f"{patch_hw[0]}x{patch_hw[1]} "
                    f"| overlap={PATCH_OVERLAP}"
                )

                epoch_dir = (
                    run_output_root
                    / f"epoch_{checkpoint.epoch:03d}"
                )

                _, summary = process_checkpoint(
                    run_name=metadata.run_name,
                    checkpoint=checkpoint,
                    model=model,
                    image_paths=image_paths,
                    gt_map=gt_map,
                    epoch_dir=epoch_dir,
                    patch_hw=patch_hw,
                    input_channels=input_channels,
                    threshold=metadata.threshold,
                )

                run_summary_rows.append(
                    summary
                )

                global_summary_rows.append(
                    summary
                )

                if summary["images_with_gt"] > 0:
                    log(
                        f"    Dice/F1={summary['dice_f1']:.6f} | "
                        f"IoU={summary['iou']:.6f} | "
                        f"Precision={summary['precision']:.6f} | "
                        f"Recall={summary['recall']:.6f}"
                    )

            except Exception as exc:
                log(
                    f"[FEHLER] Run={run_dir.name}, "
                    f"Epoche={checkpoint.epoch}: {exc}"
                )
                traceback.print_exc()
                raise

            finally:
                if model is not None:
                    del model

                tf.keras.backend.clear_session()
                gc.collect()

        write_csv(
            run_output_root
            / "label_noise_summary.csv",
            run_summary_rows,
            SUMMARY_FIELDS,
        )

        save_json(
            run_output_root
            / "label_noise_summary.json",
            {
                "run_directory": run_dir,
                "run_name": metadata.run_name,
                "metadata_path": metadata.metadata_path,
                "threshold": metadata.threshold,
                "mixed_precision_policy": policy,
                "image_directory": images_dir,
                "gt_directory": gt_dir,
                "patch_overlap": PATCH_OVERLAP,
                "epochs": run_summary_rows,
            },
        )

    # Zusätzlich eine Gesamttabelle direkt unter OUTPUTS_ROOT.
    analysis_summary_dir = (
        OUTPUTS_ROOT
        / "_label_noise_verlauf_summary"
    )

    analysis_summary_dir.mkdir(
        parents=True,
        exist_ok=True,
    )

    write_csv(
        analysis_summary_dir
        / "all_runs_label_noise_summary.csv",
        global_summary_rows,
        SUMMARY_FIELDS,
    )

    save_json(
        analysis_summary_dir
        / "analysis_configuration.json",
        {
            "outputs_root": OUTPUTS_ROOT,
            "run_selection_mode": RUN_SELECTION_MODE,
            "requested_run_names": RUN_NAMES,
            "analysed_runs": run_dirs,
            "analyse_bilder_dir": ANALYSE_BILDER_DIR,
            "resolved_images_dir": images_dir,
            "gt_dir": gt_dir,
            "image_count": len(image_paths),
            "gt_mask_count": len(gt_map),
            "patch_overlap": PATCH_OVERLAP,
            "inference_batch_size": INFERENCE_BATCH_SIZE,
            "start_epoch": START_EPOCH,
            "end_epoch": END_EPOCH,
            "global_threshold_override": GLOBAL_THRESHOLD_OVERRIDE,
            "error_map_legend": {
                "TN_black": ERROR_COLOR_TN_BGR,
                "TP_white": ERROR_COLOR_TP_BGR,
                "FP_blue": ERROR_COLOR_FP_BGR,
                "FN_red": ERROR_COLOR_FN_BGR,
            },
        },
    )

    log("")
    log("=" * 110)
    log("ANALYSE ABGESCHLOSSEN")
    log("=" * 110)
    log(
        f"Gesamtübersicht: "
        f"{analysis_summary_dir / 'all_runs_label_noise_summary.csv'}"
    )
    log("=" * 110)


if __name__ == "__main__":
    main()
