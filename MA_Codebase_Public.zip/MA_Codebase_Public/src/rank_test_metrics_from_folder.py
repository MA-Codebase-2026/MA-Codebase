#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Erstellt zwei gerankte TXT-Uebersichten aus bereits vorhandenen Test-Metrics-JSONs.

Erwartete Eingabedateien im INPUT_DIR:
    RUNNAME_test_metrics.json
    RUNNAME_sample_test_metrics.json

Ausgaben:
    all_modells_common_test_metrics.txt
    all_modells_common_sample_test_metrics.txt

Ranking:
    D = sqrt(0.5 * (1 - Dice)^2 + 0.5 * (1 - F2)^2)
    kleiner = besser

Die Ausgabe orientiert sich an:
    all_models_common_test_metrics.txt
    all_modells_common_sample_test_metrics.txt

Es findet KEINE Modellinferenz statt. Das Skript liest ausschliesslich bereits
gespeicherte Metrics-Dateien ein, vereinheitlicht fehlende ableitbare Metriken,
rankt alle Runs und schreibt die beiden Sammeldateien.
"""

from __future__ import annotations

import json
import math
from pathlib import Path
from typing import Any


# =============================================================================
# EINSTELLUNGEN
# =============================================================================

# HIER DEN ORDNER EINTRAGEN, IN DEM DIE EINZELNEN METRICS-JSONS LIEGEN.
INPUT_DIR = Path("/home/mitte/crack_project/modellmetrics_of_best_epoche_on_testdataset")

# Standard: nur direkt in INPUT_DIR suchen.
# True = auch Unterordner durchsuchen.
RECURSIVE = False

# Ausgabeordner. Standardmaessig derselbe Ordner wie INPUT_DIR.
OUTPUT_DIR = INPUT_DIR

COMMON_TEST_FILENAME = "all_modells_common_test_metrics.txt"
COMMON_SAMPLE_FILENAME = "all_modells_common_sample_test_metrics.txt"

# Bei mehrfach vorhandenen Dateien fuer denselben Run gewinnt standardmaessig
# die zuletzt geaenderte Datei.
KEEP_NEWEST_DUPLICATE = True

EPS = 1e-12


# =============================================================================
# HILFSFUNKTIONEN
# =============================================================================

def safe_float(value: Any, default: float = float("nan")) -> float:
    """Konvertiert robust nach float."""
    if value is None:
        return default
    try:
        result = float(value)
    except (TypeError, ValueError):
        return default
    return result


def is_finite(value: Any) -> bool:
    """True fuer endliche numerische Werte."""
    try:
        return math.isfinite(float(value))
    except (TypeError, ValueError):
        return False


def safe_div(num: Any, den: Any) -> float:
    """Division mit Schutz gegen Division durch 0."""
    n = safe_float(num)
    d = safe_float(den)
    if not math.isfinite(n) or not math.isfinite(d):
        return float("nan")
    return n / (d + EPS)


def clean_scalar(value: Any) -> Any:
    """
    Normalisiert einfache JSON-Werte.
    Strings wie "nan" oder leere Strings werden als fehlend behandelt.
    """
    if value is None:
        return None

    if isinstance(value, str):
        stripped = value.strip()
        if not stripped:
            return None
        if stripped.casefold() in {"nan", "none", "null", "na", "n/a"}:
            return None
        return value

    return value


def infer_run_name(data: dict[str, Any], path: Path, sample: bool) -> str:
    """Runname zuerst aus JSON, sonst robust aus dem Dateinamen ableiten."""
    run_name = clean_scalar(data.get("run_name"))
    if run_name is not None:
        return str(run_name)

    suffix = "_sample_test_metrics" if sample else "_test_metrics"
    stem = path.stem
    if stem.endswith(suffix):
        stem = stem[:-len(suffix)]
    return stem


def run_identity(data: dict[str, Any]) -> str:
    """
    Schluessel fuer Deduplizierung.
    Bevorzugt run_name, danach model_id, danach model_name.
    """
    for key in ("run_name", "model_id", "model_name"):
        value = clean_scalar(data.get(key))
        if value is not None:
            return str(value).strip().casefold()
    return ""


def normalize_metrics(
    raw: dict[str, Any],
    source_path: Path,
    *,
    sample: bool,
) -> dict[str, Any]:
    """
    Vereinheitlicht eine einzelne Metrics-Datei und rekonstruiert ableitbare
    Metriken, falls sie in aelteren Dateien fehlen.
    """
    row = dict(raw)
    row["run_name"] = infer_run_name(row, source_path, sample)

    # Manche Dateien benutzen Dice gleichzeitig als F1.
    if not is_finite(row.get("test_f1_fg")) and is_finite(row.get("test_dice_fg")):
        row["test_f1_fg"] = safe_float(row["test_dice_fg"])

    # F2 aus Precision / Recall rekonstruieren.
    if not is_finite(row.get("test_f2")):
        precision = safe_float(row.get("test_precision_fg"))
        recall = safe_float(row.get("test_recall_fg"))
        if math.isfinite(precision) and math.isfinite(recall):
            row["test_f2"] = safe_div(5.0 * precision * recall, 4.0 * precision + recall)

    # FPR / FNR aus Confusion Matrix rekonstruieren.
    if not is_finite(row.get("fpr")):
        fp = safe_float(row.get("fp"))
        tn = safe_float(row.get("tn"))
        if math.isfinite(fp) and math.isfinite(tn):
            row["fpr"] = safe_div(fp, fp + tn)

    if not is_finite(row.get("fnr")):
        fn = safe_float(row.get("fn"))
        tp = safe_float(row.get("tp"))
        if math.isfinite(fn) and math.isfinite(tp):
            row["fnr"] = safe_div(fn, fn + tp)

    # Balanced Error / Accuracy rekonstruieren.
    if not is_finite(row.get("balanced_error")):
        fpr = safe_float(row.get("fpr"))
        fnr = safe_float(row.get("fnr"))
        if math.isfinite(fpr) and math.isfinite(fnr):
            row["balanced_error"] = 0.5 * (fpr + fnr)

    if not is_finite(row.get("balanced_accuracy")):
        bal_err = safe_float(row.get("balanced_error"))
        if math.isfinite(bal_err):
            row["balanced_accuracy"] = 1.0 - bal_err

    # D IMMER neu aus Dice und F2 berechnen, damit das Ranking zwischen
    # verschiedenen Dateiversionen konsistent ist.
    dice = safe_float(row.get("test_dice_fg"))
    f2 = safe_float(row.get("test_f2"))
    if math.isfinite(dice) and math.isfinite(f2):
        row["D"] = math.sqrt(
            0.5 * (1.0 - dice) ** 2
            + 0.5 * (1.0 - f2) ** 2
        )
    else:
        row["D"] = float("inf")

    row["_source_path"] = str(source_path)
    row["_source_mtime"] = source_path.stat().st_mtime

    return row


def load_json_file(path: Path) -> dict[str, Any] | None:
    """Liest eine JSON-Datei; fehlerhafte Dateien werden gemeldet und uebersprungen."""
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as exc:
        print(f"[WARNUNG] JSON konnte nicht gelesen werden: {path}")
        print(f"          Grund: {exc}")
        return None

    if not isinstance(data, dict):
        print(f"[WARNUNG] Erwartet wurde ein JSON-Objekt, uebersprungen: {path}")
        return None

    return data


def discover_metric_files(input_dir: Path) -> tuple[list[Path], list[Path]]:
    """
    Findet:
      - RUNNAME_test_metrics.json
      - RUNNAME_sample_test_metrics.json

    Wichtig: Sample-Dateien matchen technisch ebenfalls auf *_test_metrics.json
    und werden deshalb explizit aus der normalen Testliste entfernt.
    """
    globber = input_dir.rglob if RECURSIVE else input_dir.glob

    all_test_like = sorted(globber("*_test_metrics.json"))
    sample_files = sorted(
        path for path in all_test_like
        if path.name.endswith("_sample_test_metrics.json")
    )
    normal_files = sorted(
        path for path in all_test_like
        if not path.name.endswith("_sample_test_metrics.json")
    )

    # Keine globalen Summary-JSONs als Eingabe verwenden, falls solche spaeter
    # im selben Ordner liegen.
    normal_files = [
        p for p in normal_files
        if not p.name.startswith(("all_models_common_", "all_modells_common_"))
    ]
    sample_files = [
        p for p in sample_files
        if not p.name.startswith(("all_models_common_", "all_modells_common_"))
    ]

    return normal_files, sample_files


def load_and_rank(files: list[Path], *, sample: bool) -> list[dict[str, Any]]:
    """
    Liest alle Dateien, dedupliziert pro Run und sortiert nach D aufsteigend.
    """
    by_run: dict[str, dict[str, Any]] = {}

    for path in files:
        raw = load_json_file(path)
        if raw is None:
            continue

        row = normalize_metrics(raw, path, sample=sample)
        key = run_identity(row)

        if not key:
            print(f"[WARNUNG] Kein Run-/Modellname bestimmbar, uebersprungen: {path}")
            continue

        old = by_run.get(key)
        if old is None:
            by_run[key] = row
        elif KEEP_NEWEST_DUPLICATE:
            if safe_float(row.get("_source_mtime"), 0.0) >= safe_float(old.get("_source_mtime"), 0.0):
                print(
                    f"[DUPLIKAT] {row['run_name']}: neuere Datei wird verwendet:\n"
                    f"           {path}"
                )
                by_run[key] = row
            else:
                print(
                    f"[DUPLIKAT] {row['run_name']}: aeltere Datei wird ignoriert:\n"
                    f"           {path}"
                )
        else:
            print(f"[DUPLIKAT] Run wird nur einmal verwendet: {row['run_name']}")

    results = list(by_run.values())
    results.sort(
        key=lambda r: (
            safe_float(r.get("D"), float("inf")),
            str(r.get("run_name", "")).casefold(),
        )
    )

    for rank, row in enumerate(results, start=1):
        row["rank_d"] = rank

    return results


def fmt_float(value: Any) -> str:
    """Formatierung wie in den vorhandenen Common-Metrics-TXT-Dateien."""
    if not is_finite(value):
        return "nan"
    return f"{float(value):.6f}"


def fmt_int(value: Any) -> str:
    """Ganzzahlformatierung mit robustem Fallback."""
    if value is None or value == "":
        return ""
    try:
        return str(int(round(float(value))))
    except (TypeError, ValueError):
        return str(value)


def fmt_general(value: Any) -> str:
    """Allgemeines Feldformat."""
    value = clean_scalar(value)
    if value is None:
        return "nan"

    if isinstance(value, bool):
        return str(value)

    if isinstance(value, int):
        return str(value)

    if isinstance(value, float):
        if not math.isfinite(value):
            return "nan"
        return f"{value:.6f}"

    return str(value)


# =============================================================================
# TXT-AUSGABE
# =============================================================================

def write_common_test_txt(results: list[dict[str, Any]], output_path: Path) -> None:
    """Schreibt all_modells_common_test_metrics.txt."""
    sep = "=" * 190

    lines = [
        sep,
        "GEMEINSAME TEST-AUSWERTUNG ALLER JEMALS GEPRUEFTEN MODELLE",
        "Ranking: D = sqrt(0.5*(1-Dice)^2 + 0.5*(1-F2)^2) | kleiner = besser",
        f"Anzahl eindeutige Modelle: {len(results)}",
        sep,
        (
            "Rang\tTraining\tBestEpoch\tIMG_SIZE\tThreshold\tValDice\t"
            "TestDice\tTestIoU\tPrecision\tRecall\tF1\tF2\tAP\tAccuracy(%)\t"
            "BalErr\tBalAcc\tFPR\tFNR\tTP\tFP\tFN\tTN\tD"
        ),
    ]

    for r in results:
        values = [
            str(r.get("rank_d", "")),
            str(r.get("run_name", "")),
            fmt_int(r.get("best_epoch")),
            fmt_int(r.get("img_size")),
            fmt_float(r.get("threshold")),
            fmt_float(r.get("best_val_dice_fg")),
            fmt_float(r.get("test_dice_fg")),
            fmt_float(r.get("test_iou_fg")),
            fmt_float(r.get("test_precision_fg")),
            fmt_float(r.get("test_recall_fg")),
            fmt_float(r.get("test_f1_fg")),
            fmt_float(r.get("test_f2")),
            fmt_float(r.get("test_ap")),
            fmt_float(r.get("test_accuracy_pct")),
            fmt_float(r.get("balanced_error")),
            fmt_float(r.get("balanced_accuracy")),
            fmt_float(r.get("fpr")),
            fmt_float(r.get("fnr")),
            fmt_int(r.get("tp")),
            fmt_int(r.get("fp")),
            fmt_int(r.get("fn")),
            fmt_int(r.get("tn")),
            fmt_float(r.get("D")),
        ]
        lines.append("\t".join(values))

    output_path.write_text("\n".join(lines) + "\n", encoding="utf-8")


def write_common_sample_txt(results: list[dict[str, Any]], output_path: Path) -> None:
    """Schreibt all_modells_common_sample_test_metrics.txt."""
    sep = "=" * 190

    lines = [
        sep,
        "GEMEINSAME SAMPLE-TEST-AUSWERTUNG ALLER MODELLE",
        "Bereich: BALANCED CRACK ROI (alle GT-Risspixel + gesampelte Negative)",
        "Ranking: D = sqrt(0.5*(1-Dice)^2 + 0.5*(1-F2)^2) | kleiner = besser",
        f"Anzahl eindeutige Modelle: {len(results)}",
        sep,
        (
            "Rang\tTraining\tBestEpoch\tIMG_SIZE\tThreshold\tValDice\t"
            "SampleTestDice\tSampleTestIoU\tPrecision\tRecall\tF1\tF2\tAP\t"
            "Accuracy(%)\tBalErr\tBalAcc\tFPR\tFNR\tTP\tFP\tFN\tTN\tD\t"
            "SamplePixel\tBilderVerwendet\tBilderOhneRiss"
        ),
    ]

    for r in results:
        values = [
            str(r.get("rank_d", "")),
            str(r.get("run_name", "")),
            fmt_int(r.get("best_epoch")),
            fmt_int(r.get("img_size")),
            fmt_float(r.get("threshold")),
            fmt_float(r.get("best_val_dice_fg")),
            fmt_float(r.get("test_dice_fg")),
            fmt_float(r.get("test_iou_fg")),
            fmt_float(r.get("test_precision_fg")),
            fmt_float(r.get("test_recall_fg")),
            fmt_float(r.get("test_f1_fg")),
            fmt_float(r.get("test_f2")),
            fmt_float(r.get("test_ap")),
            fmt_float(r.get("test_accuracy_pct")),
            fmt_float(r.get("balanced_error")),
            fmt_float(r.get("balanced_accuracy")),
            fmt_float(r.get("fpr")),
            fmt_float(r.get("fnr")),
            fmt_int(r.get("tp")),
            fmt_int(r.get("fp")),
            fmt_int(r.get("fn")),
            fmt_int(r.get("tn")),
            fmt_float(r.get("D")),
            fmt_int(r.get("sampled_pixels_total")),
            fmt_int(r.get("sample_images_used")),
            fmt_int(r.get("sample_images_skipped_no_positive")),
        ]
        lines.append("\t".join(values))

    output_path.write_text("\n".join(lines) + "\n", encoding="utf-8")


# =============================================================================
# MAIN
# =============================================================================

def main() -> None:
    if not INPUT_DIR.is_dir():
        raise FileNotFoundError(
            f"INPUT_DIR existiert nicht oder ist kein Ordner:\n{INPUT_DIR}"
        )

    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)

    normal_files, sample_files = discover_metric_files(INPUT_DIR)

    print("=" * 90)
    print("METRICS-RANKING")
    print("=" * 90)
    print(f"Input:                  {INPUT_DIR}")
    print(f"Output:                 {OUTPUT_DIR}")
    print(f"Normale Test-Dateien:   {len(normal_files)}")
    print(f"Sample-Test-Dateien:    {len(sample_files)}")
    print()

    if not normal_files:
        print("[WARNUNG] Keine Dateien nach Muster RUNNAME_test_metrics.json gefunden.")

    if not sample_files:
        print("[WARNUNG] Keine Dateien nach Muster RUNNAME_sample_test_metrics.json gefunden.")

    common_results = load_and_rank(normal_files, sample=False)
    sample_results = load_and_rank(sample_files, sample=True)

    common_test_path = OUTPUT_DIR / COMMON_TEST_FILENAME
    common_sample_path = OUTPUT_DIR / COMMON_SAMPLE_FILENAME

    write_common_test_txt(common_results, common_test_path)
    write_common_sample_txt(sample_results, common_sample_path)

    print()
    print("Fertig.")
    print(f"Normales Ranking: {common_test_path}")
    print(f"  Runs:           {len(common_results)}")
    print(f"Sample-Ranking:  {common_sample_path}")
    print(f"  Runs:           {len(sample_results)}")

    if common_results:
        best = common_results[0]
        print()
        print(
            f"Bestes normales Test-Ranking: "
            f"{best.get('run_name')} | D={safe_float(best.get('D')):.6f}"
        )

    if sample_results:
        best = sample_results[0]
        print(
            f"Bestes Sample-Test-Ranking:   "
            f"{best.get('run_name')} | D={safe_float(best.get('D')):.6f}"
        )


if __name__ == "__main__":
    main()
