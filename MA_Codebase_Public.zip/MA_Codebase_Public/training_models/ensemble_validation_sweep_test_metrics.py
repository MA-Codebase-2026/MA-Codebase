#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Ensemble-Gewichtssuche auf Validation und finale Auswertung auf Test.

Ziele dieses Skripts
--------------------
1. Keine Prediction-/Overlay-Bilder erzeugen. Es wird nur inferiert und geloggt.
2. Dieselben finalen Pixelmetriken wie im beigefuegten Testdataset-Skript loggen:
   Dice, IoU, Precision, Recall, F1, F2, AP, Accuracy, Balanced Error,
   Balanced Accuracy, FPR, FNR, TP, FP, FN, TN und D.
3. Pro Segmentierungsmodell den Threshold "ROI minimaler Balanced Error" aus
   <RUN>/threshold_results2/<MODELL>_threshold_search_GLOBAL_and_BALANCED_CRACK_ROI_FINE.txt
   laden; falls der exakte Dateiname nicht existiert, wird robust nach einer TXT
   mit genau dieser Empfehlung gesucht.
4. Classifier als Gate verwenden. Unter CLASSIFIER_GATE_THRESHOLD werden die
   Segmentierungsmodelle fuer das Bild nicht ausgefuehrt; Ensemble-Score = 0.
5. Die Segmentierungsmodelle werden jeweils mit ihrem eigenen Threshold binarisiert.
   Anschliessend wird ein gewichteter Vote-Score gebildet und mit
   ENSEMBLE_DECISION_THRESHOLD final binarisiert.
6. Auf immer denselben 200 Validation-Bildern werden alle Gewichtsverteilungen im 0.01er
   Raster getestet. Die beste Verteilung wird danach unveraendert auf dem Testsplit ausgewertet. Erlaubt sind 2 bis maximal 5 wirklich benutzte Modelle
   (Gewicht > 0). Der beste Schritt minimiert wie im Testcode den D-Score.
7. Alle Sweep-Schritte werden streaming als TXT, CSV und JSON gespeichert.
8. Wenn HARD_NEGATIVE_SHARE == 0.0, werden alle vom Classifier negativ
   bewerteten Testbilder als Classifier-FN in TXT und CSV protokolliert.
9. Die Gesamtarchitektur und alle relevanten Variablen werden unter
   outputs/RUN_NAME/architecture als PNG, JSON, Keras-JSON und TXT gespeichert.

WICHTIG ZUM 5-MODELL-SWEEP
--------------------------
Bei 5 konfigurierten Modellen existieren im 0.01-Raster (Summe=1.00,
mindestens zwei positive Gewichte) 4,598,121 gueltige Gewichtskombinationen.
Die Ergebnisdateien koennen daher sehr gross werden. Das ist absichtlich so,
weil hier jeder einzelne Sweep-Step gespeichert wird.
"""

from __future__ import annotations

import csv
import gc
import itertools
import json
import math
import os
import random
import re
from datetime import datetime
from pathlib import Path
from typing import Any, Iterable

# Environment vor TensorFlow konfigurieren.
os.environ.setdefault("PYTHONHASHSEED", "42")
os.environ.setdefault("TF_GPU_ALLOCATOR", "cuda_malloc_async")
os.environ.setdefault("TF_FORCE_GPU_ALLOW_GROWTH", "true")
os.environ.setdefault("KERAS_BACKEND", "tensorflow")

import cv2
import numpy as np
import tensorflow as tf
from keras import mixed_precision
from keras.utils import plot_model

from keras.applications.mobilenet_v2 import preprocess_input as mobilenet_v2_preprocess_input
from keras.applications.resnet50 import preprocess_input as resnet50_preprocess_input
from keras.applications.efficientnet import preprocess_input as efficientnet_preprocess_input
from keras.applications.xception import preprocess_input as xception_preprocess_input
from keras.applications.vgg16 import preprocess_input as vgg16_preprocess_input
from keras.applications.vgg19 import preprocess_input as vgg19_preprocess_input
from keras.applications.densenet import preprocess_input as densenet_preprocess_input


# =============================================================================
# 1. KONFIGURATION - HIER ANPASSEN
# =============================================================================

RUN_NAME = "ensemble_set_threshold_tversky_focalattentionvit_AtoB_Segformer_lowclassifierweight_th050"

# Projekt-/Outputpfade.
CRACK_PROJECT_ROOT = Path("/home/mitte/crack_project")
OUTPUT_ROOT = CRACK_PROJECT_ROOT / "outputs"
RUN_DIR = OUTPUT_ROOT / RUN_NAME

# Diesen Ordner kannst du unabhaengig vom RUN_DIR direkt im Code setzen.
# Standard gemaess Wunsch: /home/mitte/crack_project/ensemblemetrics_on_testdataset
TEST_METRICS_DIR = CRACK_PROJECT_ROOT / "ensemblemetrics_on_testdataset"

# Dataset-Root. Sweep: val_512, finale Metrics: test_512.
# DATASET_DIR/val_512/images + masks
# DATASET_DIR/test_512/images + masks
TEST_DATASET_DIR = CRACK_PROJECT_ROOT / "datasets/better_dataset_evtl"
IMG_SIZE = 512

# Classifier aus dem bisherigen Ensemble.
CLASSIFIER_MODEL_PATH = CRACK_PROJECT_ROOT / "output_classifier/classifier_multi_dataset_optimized/models/classifier_multi_dataset_optimized_best_f1_f2_distance.keras"
CLASSIFIER_GATE_THRESHOLD = 0.000044
CLASSIFIER_POSITIVE_CLASS_INDEX = 1
CLASSIFIER_OUTPUT_IS_LOGITS = False

# 2 bis maximal 5 Segmentierungsmodelle eintragen.
# Der jeweilige Run wird aus <run>/models/<modell>.keras abgeleitet.
SEGMENTATION_MODEL_PATHS = [
    CRACK_PROJECT_ROOT / "outputs/unetpp_512px_f16-256_BetterDataset_tversky/models/unetpp_512px_f16-256_BetterDataset_tversky_Epoche36.keras",
    CRACK_PROJECT_ROOT / "outputs/unetpp_512px_f16-256_BetterDataset_focal_attention_vit/models/unetpp_512px_f16-256_BetterDataset_focal_attention_vit_Epoche28.keras",
    CRACK_PROJECT_ROOT / "outputs/unetpp_A_to_B_finetune_20epochs/models/unetpp_A_to_B_finetune_20epochs_Epoche20.keras",
    CRACK_PROJECT_ROOT / "outputs/unetpp_512px_f16-256_BetterDataset_HN10_DA_040BCE_058Tversky_002Skeleton/models/unetpp_512px_f16-256_BetterDataset_HN10_DA_040BCE_058Tversky_002Skeleton_Epoche33.keras",
    CRACK_PROJECT_ROOT / "outputs/benchmark_segformer_mit_b2_tversky/models/benchmark_segformer_mit_b2_tversky_Epoche40.keras",
]

SEGMENTATION_OUTPUTS_ARE_LOGITS = False

# Individual-Threshold-Dateiname. Zuerst wird exakt
# <model.stem> + dieser Suffix probiert, danach robuste Textsuche.
THRESHOLD_FILENAME_SUFFIX = "_threshold_search_GLOBAL_and_BALANCED_CRACK_ROI_FINE.txt"

# Gewichteter Vote:
# - jedes Segmentierungsmodell wird ZUERST mit seinem individuellen Threshold binarisiert
# - Vote-Score = Summe(weight_i * binary_i)
# - final positiv ab ENSEMBLE_DECISION_THRESHOLD
ENSEMBLE_DECISION_THRESHOLD = 0.50

# Hard-Negative-Anteil im finalen Testset.
# 0.0 = nur regulaere Testbilder. Dann wird jedes Classifier-Negativ als FN geloggt.
# Beispiel 0.20 = HNs werden so gesampelt, dass sie ca. 20 % des finalen Testsets bilden.
HARD_NEGATIVE_SHARE = 0.0
HARD_NEGATIVE_RANDOM_SEED = 42

# Gesampelte BALANCED-CRACK-ROI-Testmetriken:
# alle GT-Risspixel plus gleich viele negative Pixel, bevorzugt aus dem
# rissnahen Ring. Diese Parameter entsprechen dem separaten Sample-Testskript.
ROI_RING_RADIUS_PX = 10
ROI_NEGATIVE_TO_POSITIVE_RATIO = 1.0
ROI_RANDOM_SEED = 42

# Sweep exakt wie gewuenscht.
SWEEP_IMAGE_COUNT = 200
SWEEP_IMAGE_SEED = 42
SWEEP_WEIGHT_STEP = 0.01
SWEEP_MIN_USED_MODELS = 2
SWEEP_MAX_USED_MODELS = 5
SWEEP_RANKING_METRIC = "D"  # kleiner ist besser
SWEEP_CHUNK_SIZE = 10_000
SWEEP_SAVE_ALL_STEPS = True

# Test-/Inferenzoptionen.
BATCH_SIZE = 8
BATCH_SIZE_1024 = 2
SEED = 42
XLA_JIT = True
MIXED_PRECISION_POLICY = "mixed_float16"

# Gleicher AP-Threshold-Raster wie im Testdataset-Skript.
AP_THRESHOLDS = np.linspace(1.0, 0.0, 101, dtype=np.float64)
EPS = 1e-7

# Architektur-Logging wie im U-Net++ Trainingscode.
ARCHITECTURE_EXPAND_NESTED_PNG = True
ARCHITECTURE_DPI = 200

# Ausgabepfade innerhalb des Runordners.
ARCH_DIR = RUN_DIR / "architecture"
MODEL_DIR = RUN_DIR / "models"
SWEEP_DIR = RUN_DIR / "modellverteilung_sweep"
CLASSIFIER_FN_DIR = RUN_DIR / "Classifier_FN"

ARCHITECTURE_TXT_FILE = ARCH_DIR / f"{RUN_NAME}_architecture_detailed.txt"
ARCHITECTURE_JSON_FILE = ARCH_DIR / f"{RUN_NAME}_architecture_config.json"
ARCHITECTURE_KERAS_JSON_FILE = ARCH_DIR / f"{RUN_NAME}_architecture_keras.json"
ARCHITECTURE_PNG_FILE = ARCH_DIR / f"{RUN_NAME}_architecture.png"

FINAL_METRICS_TXT_FILE = TEST_METRICS_DIR / f"{RUN_NAME}_test_metrics.txt"
FINAL_METRICS_CSV_FILE = TEST_METRICS_DIR / f"{RUN_NAME}_test_metrics.csv"
FINAL_METRICS_JSON_FILE = TEST_METRICS_DIR / f"{RUN_NAME}_test_metrics.json"

SAMPLE_METRICS_TXT_FILE = TEST_METRICS_DIR / f"{RUN_NAME}_sample_test_metrics.txt"
SAMPLE_METRICS_CSV_FILE = TEST_METRICS_DIR / f"{RUN_NAME}_sample_test_metrics.csv"
SAMPLE_METRICS_JSON_FILE = TEST_METRICS_DIR / f"{RUN_NAME}_sample_test_metrics.json"

ENSEMBLE_MODEL_PATH = MODEL_DIR / f"{RUN_NAME}_ensemble.keras"

SWEEP_TXT_FILE = SWEEP_DIR / f"{RUN_NAME}_modellverteilung_sweep_steps.txt"
SWEEP_CSV_FILE = SWEEP_DIR / f"{RUN_NAME}_modellverteilung_sweep_steps.csv"
SWEEP_JSON_FILE = SWEEP_DIR / f"{RUN_NAME}_modellverteilung_sweep_steps.json"
SWEEP_BEST_TXT_FILE = SWEEP_DIR / f"{RUN_NAME}_best_modellverteilung.txt"
SWEEP_BEST_CSV_FILE = SWEEP_DIR / f"{RUN_NAME}_best_modellverteilung.csv"
SWEEP_BEST_JSON_FILE = SWEEP_DIR / f"{RUN_NAME}_best_modellverteilung.json"
SWEEP_SELECTION_FILE = SWEEP_DIR / f"{RUN_NAME}_sweep_200_validation_images.json"

CLASSIFIER_FN_TXT_FILE = CLASSIFIER_FN_DIR / f"{RUN_NAME}_classifier_false_negatives.txt"
CLASSIFIER_FN_CSV_FILE = CLASSIFIER_FN_DIR / f"{RUN_NAME}_classifier_false_negatives.csv"


# =============================================================================
# 2. REPRODUZIERBARKEIT / TENSORFLOW
# =============================================================================

random.seed(SEED)
np.random.seed(SEED)
tf.random.set_seed(SEED)

try:
    for gpu in tf.config.list_physical_devices("GPU"):
        tf.config.experimental.set_memory_growth(gpu, True)
except RuntimeError:
    pass

if XLA_JIT:
    tf.config.optimizer.set_jit("autoclustering")
else:
    tf.config.optimizer.set_jit(False)

mixed_precision.set_global_policy(MIXED_PRECISION_POLICY)


# =============================================================================
# 3. CUSTOM OBJECTS FUER ROBUSTES MODELL-LADEN
# =============================================================================

@tf.keras.utils.register_keras_serializable(package="crack_segmentation")
class AddPositionEmbedding(tf.keras.layers.Layer):
    def __init__(self, num_tokens, embed_dim, **kwargs):
        super().__init__(**kwargs)
        self.num_tokens = int(num_tokens)
        self.embed_dim = int(embed_dim)

    def build(self, input_shape):
        self.pos_embedding = self.add_weight(
            name="pos_embedding",
            shape=(1, self.num_tokens, self.embed_dim),
            initializer="random_normal",
            trainable=True,
            dtype=self.dtype,
        )
        super().build(input_shape)

    def call(self, x):
        return x + tf.cast(self.pos_embedding, x.dtype)

    def get_config(self):
        config = super().get_config()
        config.update({"num_tokens": self.num_tokens, "embed_dim": self.embed_dim})
        return config


CUSTOM_OBJECTS = {
    "AddPositionEmbedding": AddPositionEmbedding,
    "crack_segmentation>AddPositionEmbedding": AddPositionEmbedding,
    "preprocess_input": mobilenet_v2_preprocess_input,
    "mobilenetv2_preprocess_input": mobilenet_v2_preprocess_input,
    "mobilenet_v2_preprocess_input": mobilenet_v2_preprocess_input,
    "resnet50_preprocess_input": resnet50_preprocess_input,
    "efficientnet_preprocess_input": efficientnet_preprocess_input,
    "xception_preprocess_input": xception_preprocess_input,
    "vgg16_preprocess_input": vgg16_preprocess_input,
    "vgg19_preprocess_input": vgg19_preprocess_input,
    "densenet_preprocess_input": densenet_preprocess_input,
}


# =============================================================================
# 4. CUSTOM LAYER FUER DIE EXPORTIERTE ENSEMBLE-ARCHITEKTUR
# =============================================================================

@tf.keras.utils.register_keras_serializable(package="crack_ensemble")
class EnsureOneChannel(tf.keras.layers.Layer):
    def call(self, x):
        x = tf.cast(x, tf.float32)
        if x.shape.rank == 3:
            x = x[..., tf.newaxis]
        if x.shape.rank != 4:
            raise ValueError(f"Unerwarteter Segmentierungsoutput: {x.shape}")
        return x[..., :1]


@tf.keras.utils.register_keras_serializable(package="crack_ensemble")
class FixedThreshold(tf.keras.layers.Layer):
    def __init__(self, threshold: float, **kwargs):
        super().__init__(**kwargs)
        self.threshold = float(threshold)

    def call(self, x):
        return tf.cast(tf.cast(x, tf.float32) >= self.threshold, tf.float32)

    def get_config(self):
        config = super().get_config()
        config.update({"threshold": self.threshold})
        return config


@tf.keras.utils.register_keras_serializable(package="crack_ensemble")
class WeightedVote(tf.keras.layers.Layer):
    def __init__(self, weights: list[float], **kwargs):
        super().__init__(**kwargs)
        # WICHTIG: ``Layer.weights`` ist eine von Keras reservierte, schreibgeschuetzte
        # Property. Deshalb duerfen die Ensemble-Gewichte nicht in ``self.weights``
        # gespeichert werden. Der Konfigurationsschluessel bleibt absichtlich
        # ``weights``, damit __init__ und Keras-Deserialisierung zusammenpassen.
        self.vote_weights = tuple(float(w) for w in weights)

    def call(self, inputs):
        if len(inputs) != len(self.vote_weights):
            raise ValueError("Anzahl Inputs passt nicht zu Anzahl Gewichte.")
        terms = [
            tf.cast(x, tf.float32) * w
            for x, w in zip(inputs, self.vote_weights)
        ]
        return tf.add_n(terms)

    def get_config(self):
        config = super().get_config()
        config.update({"weights": list(self.vote_weights)})
        return config


@tf.keras.utils.register_keras_serializable(package="crack_ensemble")
class ClassifierGate(tf.keras.layers.Layer):
    def __init__(
        self,
        threshold: float,
        positive_class_index: int = 1,
        output_is_logits: bool = False,
        **kwargs,
    ):
        super().__init__(**kwargs)
        self.threshold = float(threshold)
        self.positive_class_index = int(positive_class_index)
        self.output_is_logits = bool(output_is_logits)

    def call(self, x):
        x = tf.cast(x, tf.float32)
        if x.shape.rank == 1:
            prob = x
            if self.output_is_logits:
                prob = tf.math.sigmoid(prob)
        elif x.shape.rank == 2:
            last_dim = x.shape[-1]
            if last_dim == 1:
                prob = x[:, 0]
                if self.output_is_logits:
                    prob = tf.math.sigmoid(prob)
            else:
                if self.output_is_logits:
                    x = tf.nn.softmax(x, axis=-1)
                prob = x[:, self.positive_class_index]
        else:
            raise ValueError(f"Classifier-Ausgabe muss Rang 1 oder 2 haben: {x.shape}")

        gate = tf.cast(prob >= self.threshold, tf.float32)
        return tf.reshape(gate, (-1, 1, 1, 1))

    def get_config(self):
        config = super().get_config()
        config.update(
            {
                "threshold": self.threshold,
                "positive_class_index": self.positive_class_index,
                "output_is_logits": self.output_is_logits,
            }
        )
        return config


# =============================================================================
# 5. ALLGEMEINE HILFSFUNKTIONEN
# =============================================================================

def json_safe(value: Any) -> Any:
    if isinstance(value, dict):
        return {str(k): json_safe(v) for k, v in value.items()}
    if isinstance(value, (list, tuple, set)):
        return [json_safe(v) for v in value]
    if isinstance(value, Path):
        return str(value)
    if isinstance(value, np.ndarray):
        return value.tolist()
    if isinstance(value, np.generic):
        return value.item()
    if isinstance(value, datetime):
        return value.isoformat()
    if isinstance(value, float) and not np.isfinite(value):
        return None
    try:
        json.dumps(value)
        return value
    except TypeError:
        return str(value)


def write_json_atomic(path: Path, data: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temp = path.with_suffix(path.suffix + ".tmp")
    with temp.open("w", encoding="utf-8") as f:
        json.dump(json_safe(data), f, indent=2, ensure_ascii=False, allow_nan=False)
    temp.replace(path)


def safe_div(num, den):
    return np.asarray(num, dtype=np.float64) / (np.asarray(den, dtype=np.float64) + EPS)


def round_for_output(value):
    if isinstance(value, (float, np.floating)):
        if not np.isfinite(value):
            return None
        return round(float(value), 6)
    if isinstance(value, (np.integer,)):
        return int(value)
    return value


def sanitize_name(text: str) -> str:
    value = re.sub(r"[^A-Za-z0-9._-]+", "_", str(text)).strip("._")
    return value or "item"


def resolve_run_dir_from_model(model_path: Path) -> Path:
    model_path = model_path.expanduser().resolve()
    if model_path.parent.name.casefold() == "models":
        return model_path.parent.parent
    for parent in model_path.parents:
        if (parent / "threshold_results2").is_dir() or (parent / "metrics").is_dir():
            return parent
    raise ValueError(
        f"Run-Verzeichnis konnte nicht aus Modellpfad ermittelt werden: {model_path}. "
        "Erwartet wird normalerweise <run>/models/<modell>.keras."
    )


def infer_square_input_size(model: tf.keras.Model) -> int:
    shape = model.input_shape
    if isinstance(shape, list):
        if len(shape) != 1:
            raise ValueError(f"Mehrere Modelleingaenge nicht unterstuetzt: {shape}")
        shape = shape[0]
    if len(shape) != 4 or shape[1] is None or shape[2] is None:
        raise ValueError(f"Inputgroesse nicht robust bestimmbar: {shape}")
    if int(shape[1]) != int(shape[2]):
        raise ValueError(f"Nicht-quadratischer Modellinput nicht unterstuetzt: {shape}")
    return int(shape[1])


def load_model_robust(model_path: Path) -> tf.keras.Model:
    model_path = Path(model_path).expanduser().resolve()
    if not model_path.is_file():
        raise FileNotFoundError(f"Modell nicht gefunden: {model_path}")
    try:
        return tf.keras.models.load_model(
            model_path,
            compile=False,
            custom_objects=CUSTOM_OBJECTS,
        )
    except (TypeError, ValueError) as exc:
        text = str(exc)
        safe_mode_issue = (
            "safe_mode" in text
            or "unsafe deserialization" in text.lower()
            or ("Lambda" in text and "lambda" in text.lower())
        )
        if not safe_mode_issue:
            raise
        print(f"[INFO] Safe-Mode-Fallback fuer {model_path.name}: {exc}")
        return tf.keras.models.load_model(
            model_path,
            compile=False,
            safe_mode=False,
            custom_objects=CUSTOM_OBJECTS,
        )


# =============================================================================
# 6. INDIVIDUELLE THRESHOLDS LADEN
# =============================================================================

def find_threshold_txt_for_model(model_path: Path) -> Path:
    run_dir = resolve_run_dir_from_model(model_path)
    threshold_dir = run_dir / "threshold_results2"
    if not threshold_dir.is_dir():
        raise FileNotFoundError(f"Threshold-Ordner fehlt: {threshold_dir}")

    exact = threshold_dir / f"{model_path.stem}{THRESHOLD_FILENAME_SUFFIX}"
    if exact.is_file():
        return exact

    # Fallback 1: Dateiname beginnt mit Modellstem.
    same_model = sorted(threshold_dir.glob(f"{model_path.stem}*.txt"))
    # Fallback 2: beliebige TXT im Ordner.
    candidates = same_model + [p for p in sorted(threshold_dir.glob("*.txt")) if p not in same_model]

    pattern = re.compile(
        r"ROI\s+minimaler\s+Balanced\s+Error\s*:\s*Threshold\s*=\s*([0-9.eE+-]+)",
        re.IGNORECASE,
    )
    for path in candidates:
        try:
            text = path.read_text(encoding="utf-8", errors="replace")
        except OSError:
            continue
        if pattern.search(text):
            return path

    raise FileNotFoundError(
        f"Keine Threshold-TXT mit 'ROI minimaler Balanced Error' fuer {model_path.name} "
        f"in {threshold_dir} gefunden."
    )


def read_individual_threshold(model_path: Path) -> dict[str, Any]:
    txt_path = find_threshold_txt_for_model(model_path)
    text = txt_path.read_text(encoding="utf-8", errors="replace")

    # Bevorzugt explizit im Abschnitt "FINALE THRESHOLD-EMPFEHLUNGEN" suchen.
    # Falls ein aelteres Logger-Format die Ueberschrift nicht enthaelt, wird
    # aus Kompatibilitaetsgruenden im gesamten Text gesucht.
    final_section = text
    section_match = re.search(
        r"FINALE\s+THRESHOLD-EMPFEHLUNGEN",
        text,
        re.IGNORECASE,
    )
    if section_match is not None:
        final_section = text[section_match.end():]

    match = re.search(
        r"ROI\s+minimaler\s+Balanced\s+Error\s*:\s*"
        r"Threshold\s*=\s*([0-9.eE+-]+)",
        final_section,
        re.IGNORECASE,
    )
    if match is None:
        raise ValueError(f"Threshold nicht lesbar: {txt_path}")

    threshold = float(match.group(1))
    if not 0.0 <= threshold <= 1.0:
        raise ValueError(f"Ungueltiger Threshold {threshold} in {txt_path}")

    return {
        "threshold": threshold,
        "threshold_file": txt_path,
    }


# =============================================================================
# 7. DATENSPLITS: VALIDATION FUER SWEEP, TEST FUER FINALE METRIKEN
# =============================================================================

def get_valid_pairs(images_dir: Path, masks_dir: Path) -> list[dict[str, Any]]:
    if not images_dir.is_dir() or not masks_dir.is_dir():
        return []

    images = sorted(
        p for p in images_dir.iterdir()
        if p.is_file() and not p.name.startswith(".")
    )
    masks_by_stem = {
        p.stem.casefold(): p
        for p in masks_dir.iterdir()
        if p.is_file() and not p.name.startswith(".")
    }

    records = []
    for image in images:
        mask = masks_by_stem.get(image.stem.casefold())
        if mask is not None:
            records.append({"image_path": image, "mask_path": mask})
    return records


def build_validation_records() -> list[dict[str, Any]]:
    """Validation wird ausschliesslich fuer die Gewichtssuche verwendet."""
    split = TEST_DATASET_DIR / f"val_{IMG_SIZE}"
    records = get_valid_pairs(split / "images", split / "masks")
    if not records:
        raise RuntimeError(f"Keine Validation-Paare in {split} gefunden.")
    for row in records:
        row["is_hard_negative"] = False
    return records


def build_test_records() -> list[dict[str, Any]]:
    """Test wird erst nach dem Sweep fuer die finalen Metriken verwendet."""
    split = TEST_DATASET_DIR / f"test_{IMG_SIZE}"
    regular = get_valid_pairs(split / "images", split / "masks")
    for row in regular:
        row["is_hard_negative"] = False

    if not regular:
        raise RuntimeError(f"Keine regulaeren Testpaare in {split} gefunden.")

    if HARD_NEGATIVE_SHARE <= 0.0:
        return regular

    hn = get_valid_pairs(
        split / f"images_{IMG_SIZE}px_hard_negatives",
        split / f"masks_{IMG_SIZE}px_hard_negatives",
    )
    for row in hn:
        row["is_hard_negative"] = True

    if not hn:
        raise RuntimeError(
            f"HARD_NEGATIVE_SHARE={HARD_NEGATIVE_SHARE}, aber keine Hard-Negatives in {split} gefunden."
        )

    share = float(HARD_NEGATIVE_SHARE)
    if not 0.0 <= share <= 1.0:
        raise ValueError("HARD_NEGATIVE_SHARE muss zwischen 0 und 1 liegen.")

    if share >= 1.0:
        chosen_hn = hn
        regular = []
    else:
        target_hn = int(round(len(regular) * share / max(1.0 - share, EPS)))
        target_hn = min(target_hn, len(hn))
        rng = np.random.default_rng(HARD_NEGATIVE_RANDOM_SEED)
        indices = np.sort(rng.choice(len(hn), size=target_hn, replace=False)) if target_hn else []
        chosen_hn = [hn[int(i)] for i in indices]

    records = regular + chosen_hn
    records.sort(key=lambda r: str(r["image_path"]).casefold())
    return records


def load_and_preprocess(img_path, mask_path, sample_index):
    img = tf.io.read_file(img_path)
    img = tf.image.decode_image(img, channels=3, expand_animations=False)
    img = tf.image.convert_image_dtype(img, tf.float32)
    img = tf.image.resize(img, [IMG_SIZE, IMG_SIZE], method="bilinear", antialias=True)
    img.set_shape([IMG_SIZE, IMG_SIZE, 3])

    mask = tf.io.read_file(mask_path)
    mask = tf.image.decode_image(mask, channels=1, expand_animations=False)
    mask = tf.image.resize(mask, [IMG_SIZE, IMG_SIZE], method="nearest")
    mask = tf.cast(mask > 127, tf.float32) if mask.dtype.is_integer else tf.cast(mask > 0.5, tf.float32)
    mask.set_shape([IMG_SIZE, IMG_SIZE, 1])

    return img, mask, sample_index


def make_dataset(records: list[dict[str, Any]]):
    image_paths = [str(r["image_path"]) for r in records]
    mask_paths = [str(r["mask_path"]) for r in records]
    indices = np.arange(len(records), dtype=np.int64)

    ds = tf.data.Dataset.from_tensor_slices((image_paths, mask_paths, indices))
    options = tf.data.Options()
    options.experimental_deterministic = True
    ds = ds.with_options(options)
    ds = ds.map(load_and_preprocess, num_parallel_calls=tf.data.AUTOTUNE)
    batch = BATCH_SIZE_1024 if IMG_SIZE == 1024 else BATCH_SIZE
    ds = ds.batch(batch, drop_remainder=False)
    ds = ds.prefetch(tf.data.AUTOTUNE)
    return ds


def get_or_create_sweep_indices(records: list[dict[str, Any]]) -> np.ndarray:
    """Waehlt reproduzierbar dieselben 200 Bilder ausschliesslich aus val_<IMG_SIZE>."""
    SWEEP_DIR.mkdir(parents=True, exist_ok=True)

    if len(records) < SWEEP_IMAGE_COUNT:
        raise RuntimeError(
            f"Fuer den Sweep werden exakt {SWEEP_IMAGE_COUNT} Validation-Bilder verlangt, "
            f"der Validation-Split enthaelt aber nur {len(records)}."
        )

    current_paths = [str(Path(r["image_path"]).resolve()) for r in records]
    path_to_index = {p: i for i, p in enumerate(current_paths)}

    if SWEEP_SELECTION_FILE.is_file():
        data = json.loads(SWEEP_SELECTION_FILE.read_text(encoding="utf-8"))
        if data.get("split") not in (None, f"val_{IMG_SIZE}"):
            raise RuntimeError(
                f"Bestehende Sweep-Auswahl stammt nicht aus val_{IMG_SIZE}: {SWEEP_SELECTION_FILE}. "
                "Datei bewusst loeschen, wenn eine neue Validation-Auswahl erzeugt werden soll."
            )
        saved_paths = data.get("image_paths", [])
        if len(saved_paths) != SWEEP_IMAGE_COUNT:
            raise RuntimeError(
                f"Bestehende Sweep-Auswahl {SWEEP_SELECTION_FILE} enthaelt nicht exakt "
                f"{SWEEP_IMAGE_COUNT} Bilder."
            )
        missing = [p for p in saved_paths if p not in path_to_index]
        if missing:
            raise RuntimeError(
                "Die bestehende 200-Bilder-Sweep-Auswahl passt nicht mehr zum Validation-Split. "
                f"Fehlende Dateien, erste Beispiele: {missing[:5]}"
            )
        return np.asarray([path_to_index[p] for p in saved_paths], dtype=np.int64)

    rng = np.random.default_rng(SWEEP_IMAGE_SEED)
    chosen = np.sort(rng.choice(len(records), size=SWEEP_IMAGE_COUNT, replace=False))
    selected_paths = [current_paths[int(i)] for i in chosen]

    write_json_atomic(
        SWEEP_SELECTION_FILE,
        {
            "created_at": datetime.now().isoformat(timespec="seconds"),
            "run_name": RUN_NAME,
            "dataset": str(TEST_DATASET_DIR),
            "split": f"val_{IMG_SIZE}",
            "purpose": "model_weight_sweep_only",
            "img_size": IMG_SIZE,
            "seed": SWEEP_IMAGE_SEED,
            "count": SWEEP_IMAGE_COUNT,
            "image_paths": selected_paths,
        },
    )
    return chosen.astype(np.int64)


# =============================================================================
# 8. MODELLRUNNER / INFERENZ
# =============================================================================

def build_inference_function(model: tf.keras.Model, jit_compile: bool):
    @tf.function(jit_compile=jit_compile, reduce_retracing=True)
    def infer(images):
        return model(images, training=False)
    return infer


def make_runner(model: tf.keras.Model, name: str) -> dict[str, Any]:
    return {
        "model": model,
        "name": name,
        "fn": build_inference_function(model, XLA_JIT),
        "xla_failed": False,
    }


def run_runner(runner: dict[str, Any], images: tf.Tensor):
    try:
        return runner["fn"](images)
    except Exception as exc:
        if XLA_JIT and not runner["xla_failed"]:
            print(
                f"\n[WARNUNG] XLA fuer {runner['name']} fehlgeschlagen; "
                f"tf.function ohne XLA wird verwendet: {exc}"
            )
            runner["fn"] = build_inference_function(runner["model"], False)
            runner["xla_failed"] = True
            return runner["fn"](images)
        raise


def first_output(preds):
    if isinstance(preds, (list, tuple)):
        if not preds:
            raise ValueError("Leere Modellausgabe.")
        return preds[0]
    return preds


def ensure_segmentation_prediction(preds, target_size: int) -> tf.Tensor:
    preds = first_output(preds)
    preds = tf.cast(preds, tf.float32)
    if preds.shape.rank == 3:
        preds = preds[..., tf.newaxis]
    if preds.shape.rank != 4:
        raise ValueError(f"Unerwartete Prediction-Shape: {preds.shape}")
    if preds.shape[-1] != 1:
        preds = preds[..., :1]
    if SEGMENTATION_OUTPUTS_ARE_LOGITS:
        preds = tf.math.sigmoid(preds)
    if preds.shape[1] != target_size or preds.shape[2] != target_size:
        preds = tf.image.resize(preds, [target_size, target_size], method="bilinear")
    return preds


def classifier_probabilities(preds) -> np.ndarray:
    preds = first_output(preds)
    arr = np.asarray(tf.cast(preds, tf.float32).numpy())

    if arr.ndim == 1:
        values = arr
        if CLASSIFIER_OUTPUT_IS_LOGITS:
            values = 1.0 / (1.0 + np.exp(-values))
    elif arr.ndim == 2:
        if arr.shape[1] == 1:
            values = arr[:, 0]
            if CLASSIFIER_OUTPUT_IS_LOGITS:
                values = 1.0 / (1.0 + np.exp(-values))
        else:
            if CLASSIFIER_OUTPUT_IS_LOGITS:
                shifted = arr - np.max(arr, axis=1, keepdims=True)
                exp = np.exp(shifted)
                arr = exp / np.sum(exp, axis=1, keepdims=True)
            if not 0 <= CLASSIFIER_POSITIVE_CLASS_INDEX < arr.shape[1]:
                raise ValueError(
                    f"CLASSIFIER_POSITIVE_CLASS_INDEX={CLASSIFIER_POSITIVE_CLASS_INDEX} "
                    f"passt nicht zu Classifier-Shape {arr.shape}."
                )
            values = arr[:, CLASSIFIER_POSITIVE_CLASS_INDEX]
    else:
        raise ValueError(f"Unerwartete Classifier-Ausgabe: {arr.shape}")

    return np.asarray(values, dtype=np.float32).reshape(-1)


def pattern_bit_matrix(n_models: int) -> np.ndarray:
    codes = np.arange(2 ** n_models, dtype=np.int16)[:, None]
    shifts = np.arange(n_models, dtype=np.int16)[None, :]
    return ((codes >> shifts) & 1).astype(np.int16)


def accumulate_pattern_counts(
    pattern_code: np.ndarray,
    y_true: np.ndarray,
    n_patterns: int,
) -> tuple[np.ndarray, np.ndarray]:
    flat_code = np.asarray(pattern_code, dtype=np.int64).reshape(-1)
    flat_true = np.asarray(y_true, dtype=bool).reshape(-1)
    pos = np.bincount(flat_code[flat_true], minlength=n_patterns).astype(np.int64)
    neg = np.bincount(flat_code[~flat_true], minlength=n_patterns).astype(np.int64)
    return pos, neg


def make_empty_roi_sampling_stats() -> dict[str, int]:
    return {
        "images_total": 0,
        "images_used": 0,
        "images_skipped_no_positive": 0,
        "images_ring_downsampled": 0,
        "positive_pixels": 0,
        "negative_pixels_sampled": 0,
        "ring_pixels_available": 0,
        "ring_pixels_sampled": 0,
        "far_background_available": 0,
        "far_background_sampled": 0,
        "negative_shortfall": 0,
    }


def accumulate_roi_sampling_stats(total: dict[str, int], sample: dict[str, Any]) -> None:
    total["images_total"] += 1
    if sample["skipped_no_positive"]:
        total["images_skipped_no_positive"] += 1
        return
    total["images_used"] += 1
    if sample["ring_was_downsampled"]:
        total["images_ring_downsampled"] += 1
    for key in (
        "positive_pixels",
        "negative_pixels_sampled",
        "ring_pixels_available",
        "ring_pixels_sampled",
        "far_background_available",
        "far_background_sampled",
        "negative_shortfall",
    ):
        total[key] += int(sample[key])


def build_balanced_crack_roi_indices(
    y_true_2d: np.ndarray,
    rng: np.random.Generator,
    ring_radius_px: int,
    negative_to_positive_ratio: float,
) -> tuple[np.ndarray, np.ndarray, dict[str, Any]]:
    """Waehlt exakt die BALANCED-CRACK-ROI-Pixelpositionen.

    Alle positiven GT-Pixel werden benutzt. Negative Pixel werden zuerst aus einem
    rissnahen morphologischen Ring und bei Bedarf aus weiter entferntem Hintergrund
    gezogen. Bilder ohne positive GT-Pixel werden fuer die Sample-Auswertung
    uebersprungen.
    """
    y_true_bool = np.asarray(y_true_2d).astype(bool)
    positive_flat = np.flatnonzero(y_true_bool.reshape(-1))
    n_pos = int(positive_flat.size)
    stats = {
        "positive_pixels": n_pos,
        "ring_pixels_available": 0,
        "ring_pixels_sampled": 0,
        "far_background_available": 0,
        "far_background_sampled": 0,
        "negative_pixels_sampled": 0,
        "ring_was_downsampled": False,
        "skipped_no_positive": False,
        "negative_shortfall": 0,
    }

    if n_pos == 0:
        stats["skipped_no_positive"] = True
        return (
            np.empty(0, dtype=np.int64),
            np.empty(0, dtype=np.int64),
            stats,
        )

    radius = int(ring_radius_px)
    if radius < 0:
        raise ValueError("ROI_RING_RADIUS_PX darf nicht negativ sein.")

    if radius == 0:
        dilated = y_true_bool.copy()
    else:
        kernel_size = 2 * radius + 1
        kernel = cv2.getStructuringElement(
            cv2.MORPH_ELLIPSE,
            (kernel_size, kernel_size),
        )
        dilated = cv2.dilate(
            y_true_bool.astype(np.uint8),
            kernel,
            iterations=1,
        ).astype(bool)

    ring_flat = np.flatnonzero(np.logical_and(dilated, ~y_true_bool).reshape(-1))
    far_flat = np.flatnonzero((~dilated).reshape(-1))
    stats["ring_pixels_available"] = int(ring_flat.size)
    stats["far_background_available"] = int(far_flat.size)

    target_neg = max(
        0,
        int(round(n_pos * float(negative_to_positive_ratio))),
    )

    sampled_ring = np.empty(0, dtype=np.int64)
    sampled_far = np.empty(0, dtype=np.int64)

    if target_neg > 0 and ring_flat.size >= target_neg:
        if ring_flat.size == target_neg:
            sampled_ring = ring_flat
        else:
            sampled_ring = rng.choice(
                ring_flat,
                size=target_neg,
                replace=False,
            )
            stats["ring_was_downsampled"] = True
    elif target_neg > 0:
        sampled_ring = ring_flat
        remaining = target_neg - int(ring_flat.size)
        if remaining > 0 and far_flat.size > 0:
            n_far = min(remaining, int(far_flat.size))
            sampled_far = (
                far_flat
                if n_far == far_flat.size
                else rng.choice(far_flat, size=n_far, replace=False)
            )

    negative_flat = np.concatenate(
        [
            np.asarray(sampled_ring, dtype=np.int64),
            np.asarray(sampled_far, dtype=np.int64),
        ]
    )
    stats["ring_pixels_sampled"] = int(sampled_ring.size)
    stats["far_background_sampled"] = int(sampled_far.size)
    stats["negative_pixels_sampled"] = int(negative_flat.size)
    stats["negative_shortfall"] = max(
        0,
        target_neg - int(negative_flat.size),
    )

    return (
        np.asarray(positive_flat, dtype=np.int64),
        negative_flat,
        stats,
    )


def collect_pattern_counts(
    dataset,
    records: list[dict[str, Any]],
    classifier_info: dict[str, Any],
    segmentation_infos: list[dict[str, Any]],
    *,
    log_classifier_fn: bool = False,
    collect_sample_patterns: bool = False,
    phase_name: str = "dataset",
):
    """Sammelt Abstimmungsmuster fuer genau einen Split/Subset.

    Validation und Test werden absichtlich in getrennten Aufrufen verarbeitet, damit
    die Gewichtsauswahl niemals Testpixel sieht.

    Wenn ``collect_sample_patterns`` aktiv ist, werden zusaetzlich auf denselben
    Testbildern BALANCED-CRACK-ROI-Pattern-Counts gesammelt. Die Modellinferenz wird
    dafuer nicht wiederholt.
    """
    n_models = len(segmentation_infos)
    n_patterns = 2 ** n_models
    positive_counts = np.zeros(n_patterns, dtype=np.int64)
    negative_counts = np.zeros(n_patterns, dtype=np.int64)
    classifier_fn_rows: list[dict[str, Any]] = []

    sampled_positive_counts = np.zeros(n_patterns, dtype=np.int64)
    sampled_negative_counts = np.zeros(n_patterns, dtype=np.int64)
    sampling_stats = make_empty_roi_sampling_stats()
    sample_rng = np.random.default_rng(int(ROI_RANDOM_SEED))

    classifier_runner = make_runner(classifier_info["model"], "classifier")
    seg_runners = [
        make_runner(info["model"], info["model_name"])
        for info in segmentation_infos
    ]
    classifier_input_size = classifier_info["input_size"]

    processed = 0
    for batch_index, (images, masks, sample_indices) in enumerate(dataset, start=1):
        batch_size = int(tf.shape(images)[0].numpy())

        cls_images = images
        if classifier_input_size != IMG_SIZE:
            cls_images = tf.image.resize(
                images,
                [classifier_input_size, classifier_input_size],
                method="bilinear",
                antialias=True,
            )

        cls_preds = run_runner(classifier_runner, cls_images)
        cls_probs = classifier_probabilities(cls_preds)
        active_mask = cls_probs >= CLASSIFIER_GATE_THRESHOLD
        active_indices = np.flatnonzero(active_mask)

        mask_np = masks.numpy()[..., 0] >= 0.5
        batch_sample_indices = sample_indices.numpy().astype(np.int64)

        # Classifier-FNs nur im finalen Testlauf loggen.
        if log_classifier_fn and float(HARD_NEGATIVE_SHARE) == 0.0:
            gt_pos_per_image = mask_np.reshape(batch_size, -1).sum(axis=1)
            for local_idx in np.flatnonzero(~active_mask):
                dataset_idx = int(batch_sample_indices[local_idx])
                rec = records[dataset_idx]
                classifier_fn_rows.append(
                    {
                        "sample_index": dataset_idx,
                        "image_name": Path(rec["image_path"]).name,
                        "image_path": str(Path(rec["image_path"]).resolve()),
                        "mask_path": str(Path(rec["mask_path"]).resolve()),
                        "classifier_probability": float(cls_probs[local_idx]),
                        "classifier_gate_threshold": float(CLASSIFIER_GATE_THRESHOLD),
                        "gt_positive_pixels": int(gt_pos_per_image[local_idx]),
                        "decision": "negative -> FN (final test; HARD_NEGATIVE_SHARE=0)",
                    }
                )

        # Pattern 0 bedeutet: kein Segmentierungsmodell stimmt fuer diesen Pixel positiv.
        # Bei inaktivem Classifier bleibt das komplette Bild Pattern 0, wodurch Gate=0
        # mathematisch exakt in den Pattern-Counts enthalten ist.
        pattern_code = np.zeros(
            (batch_size, IMG_SIZE, IMG_SIZE),
            dtype=np.uint8,
        )

        if active_indices.size > 0:
            active_images = tf.gather(images, active_indices)

            for model_index, (info, runner) in enumerate(
                zip(segmentation_infos, seg_runners)
            ):
                model_input_size = info["input_size"]
                model_images = active_images
                if model_input_size != IMG_SIZE:
                    model_images = tf.image.resize(
                        active_images,
                        [model_input_size, model_input_size],
                        method="bilinear",
                        antialias=True,
                    )

                preds = run_runner(runner, model_images)
                probs = ensure_segmentation_prediction(preds, IMG_SIZE)
                bits = probs.numpy()[..., 0] >= float(info["threshold"])

                current = pattern_code[active_indices]
                current = current | (
                    bits.astype(np.uint8) << np.uint8(model_index)
                )
                pattern_code[active_indices] = current
                del probs, preds, bits

        # Vollbild-Pixelmetriken.
        bpos, bneg = accumulate_pattern_counts(
            pattern_code,
            mask_np,
            n_patterns,
        )
        positive_counts += bpos
        negative_counts += bneg

        # Zusaetzliche BALANCED-CRACK-ROI-Auswertung ohne zweite Inferenz.
        if collect_sample_patterns:
            for image_index in range(batch_size):
                positive_flat, negative_flat, sample_stats = (
                    build_balanced_crack_roi_indices(
                        mask_np[image_index],
                        sample_rng,
                        ROI_RING_RADIUS_PX,
                        ROI_NEGATIVE_TO_POSITIVE_RATIO,
                    )
                )
                accumulate_roi_sampling_stats(sampling_stats, sample_stats)

                if positive_flat.size == 0:
                    continue

                flat_codes = pattern_code[image_index].reshape(-1)
                sampled_positive_counts += np.bincount(
                    flat_codes[positive_flat].astype(np.int64),
                    minlength=n_patterns,
                ).astype(np.int64)
                sampled_negative_counts += np.bincount(
                    flat_codes[negative_flat].astype(np.int64),
                    minlength=n_patterns,
                ).astype(np.int64)

        processed += batch_size
        print(
            f"\r{phase_name} Inferenz Batch {batch_index} | "
            f"Bilder {processed}/{len(records)} | "
            f"Classifier aktiv {int(active_mask.sum())}/{batch_size}",
            end="",
            flush=True,
        )
        del images, masks, pattern_code

    print()

    if int(positive_counts.sum() + negative_counts.sum()) == 0:
        raise RuntimeError(f"Keine Pixel fuer {phase_name} gesammelt.")

    if collect_sample_patterns:
        sampled_total = int(
            sampled_positive_counts.sum() + sampled_negative_counts.sum()
        )
        if sampled_total == 0:
            raise RuntimeError(
                f"Keine BALANCED-CRACK-ROI-Pixel fuer {phase_name} gesammelt."
            )

    return {
        "positive_pattern_counts": positive_counts,
        "negative_pattern_counts": negative_counts,
        "sample_positive_pattern_counts": sampled_positive_counts,
        "sample_negative_pattern_counts": sampled_negative_counts,
        "sample_sampling_stats": sampling_stats,
        "classifier_fn_rows": classifier_fn_rows,
    }


# =============================================================================
# 9. METRIKEN - GLEICHE DEFINITIONEN WIE TESTDATASET-SKRIPT
# =============================================================================

def compute_ap_batch_from_score_bins(
    score_int: np.ndarray,
    positive_pattern_counts: np.ndarray,
    negative_pattern_counts: np.ndarray,
) -> np.ndarray:
    """
    Exakte AP-Berechnung fuer das 0.01-Raster.

    score_int liegt wegen der 0.01-Gewichte immer in 0..100. Damit entsprechen
    die 101 Score-Bins exakt AP_THRESHOLDS = 1.00, 0.99, ..., 0.00.
    """
    score_int = np.asarray(score_int, dtype=np.int16)
    n_candidates, n_patterns = score_int.shape
    total_pos = int(np.sum(positive_pattern_counts))
    if total_pos <= 0:
        return np.full(n_candidates, np.nan, dtype=np.float64)

    pos_hist = np.zeros((n_candidates, 101), dtype=np.int64)
    neg_hist = np.zeros((n_candidates, 101), dtype=np.int64)

    rows = np.repeat(np.arange(n_candidates, dtype=np.int64), n_patterns)
    bins = score_int.reshape(-1).astype(np.int64)
    pos_values = np.broadcast_to(
        positive_pattern_counts[None, :], (n_candidates, n_patterns)
    ).reshape(-1)
    neg_values = np.broadcast_to(
        negative_pattern_counts[None, :], (n_candidates, n_patterns)
    ).reshape(-1)

    np.add.at(pos_hist, (rows, bins), pos_values)
    np.add.at(neg_hist, (rows, bins), neg_values)

    # Schwellenfolge 1.00 -> 0.00 entspricht Bins 100 -> 0.
    tp = np.cumsum(pos_hist[:, ::-1], axis=1, dtype=np.int64)
    fp = np.cumsum(neg_hist[:, ::-1], axis=1, dtype=np.int64)

    pred_pos = tp + fp
    precision = np.divide(
        tp,
        pred_pos,
        out=np.ones_like(tp, dtype=np.float64),
        where=pred_pos > 0,
    )
    recall = tp.astype(np.float64) / float(total_pos)

    # Exakt analog compute_ap_from_threshold_confusions aus dem Testcode.
    precision_ext = np.concatenate(
        [precision[:, :1], precision, np.zeros((n_candidates, 1), dtype=np.float64)],
        axis=1,
    )
    recall_ext = np.concatenate(
        [np.zeros((n_candidates, 1), dtype=np.float64), recall, np.ones((n_candidates, 1), dtype=np.float64)],
        axis=1,
    )
    precision_ext = np.maximum.accumulate(precision_ext[:, ::-1], axis=1)[:, ::-1]
    ap = np.sum(
        (recall_ext[:, 1:] - recall_ext[:, :-1]) * precision_ext[:, 1:],
        axis=1,
    )
    return ap.astype(np.float64)


def compute_metrics_for_weight_chunk(
    weights_int: np.ndarray,
    pattern_bits: np.ndarray,
    positive_pattern_counts: np.ndarray,
    negative_pattern_counts: np.ndarray,
) -> dict[str, np.ndarray]:
    weights_int = np.asarray(weights_int, dtype=np.int16)
    score_int = weights_int @ pattern_bits.T  # 0..100

    decision = (score_int.astype(np.float64) / 100.0) >= float(ENSEMBLE_DECISION_THRESHOLD)

    pos_counts = np.asarray(positive_pattern_counts, dtype=np.int64)
    neg_counts = np.asarray(negative_pattern_counts, dtype=np.int64)
    total_pos = int(pos_counts.sum())
    total_neg = int(neg_counts.sum())

    tp = decision.astype(np.int64) @ pos_counts
    fp = decision.astype(np.int64) @ neg_counts
    fn = total_pos - tp
    tn = total_neg - fp

    precision = safe_div(tp, tp + fp)
    recall = safe_div(tp, tp + fn)
    dice = safe_div(2 * tp, 2 * tp + fp + fn)
    iou = safe_div(tp, tp + fp + fn)
    f1 = safe_div(2 * precision * recall, precision + recall)
    beta2 = 4.0
    f2 = safe_div((1.0 + beta2) * precision * recall, beta2 * precision + recall)
    accuracy_pct = safe_div(tp + tn, tp + tn + fp + fn) * 100.0
    fpr = safe_div(fp, fp + tn)
    fnr = safe_div(fn, fn + tp)
    balanced_error = 0.5 * (fpr + fnr)
    balanced_accuracy = 1.0 - balanced_error
    test_ap = compute_ap_batch_from_score_bins(score_int, pos_counts, neg_counts)
    d_score = np.sqrt(0.5 * (1.0 - dice) ** 2 + 0.5 * (1.0 - f2) ** 2)

    return {
        "test_dice_fg": dice,
        "test_iou_fg": iou,
        "test_precision_fg": precision,
        "test_recall_fg": recall,
        "test_f1_fg": f1,
        "test_f2": f2,
        "test_ap": test_ap,
        "test_accuracy_pct": accuracy_pct,
        "balanced_error": balanced_error,
        "balanced_accuracy": balanced_accuracy,
        "fpr": fpr,
        "fnr": fnr,
        "tp": tp.astype(np.int64),
        "fp": fp.astype(np.int64),
        "fn": fn.astype(np.int64),
        "tn": tn.astype(np.int64),
        "D": d_score,
    }


def metrics_for_single_weights(
    weights: list[float],
    pattern_bits: np.ndarray,
    positive_pattern_counts: np.ndarray,
    negative_pattern_counts: np.ndarray,
) -> dict[str, Any]:
    weights_int = np.rint(np.asarray(weights, dtype=np.float64) * 100.0).astype(np.int16)[None, :]
    metrics = compute_metrics_for_weight_chunk(
        weights_int,
        pattern_bits,
        positive_pattern_counts,
        negative_pattern_counts,
    )
    return {key: value[0].item() for key, value in metrics.items()}


# =============================================================================
# 10. EXAKTER 0.01-GEWICHTSSWEEP
# =============================================================================

SWEEP_METRIC_FIELDS = [
    "test_dice_fg",
    "test_iou_fg",
    "test_precision_fg",
    "test_recall_fg",
    "test_f1_fg",
    "test_f2",
    "test_ap",
    "test_accuracy_pct",
    "balanced_error",
    "balanced_accuracy",
    "fpr",
    "fnr",
    "tp",
    "fp",
    "fn",
    "tn",
    "D",
]


def expected_weight_combination_count(n_models: int) -> int:
    total_units = int(round(1.0 / SWEEP_WEIGHT_STEP))
    min_used = max(1, int(SWEEP_MIN_USED_MODELS))
    max_used = min(int(SWEEP_MAX_USED_MODELS), n_models, total_units)

    # Fuer genau k benutzte Modelle:
    # - C(n_models, k) Auswahl der Modelle
    # - C(total_units - 1, k - 1) positive ganzzahlige Gewichte, Summe=total_units
    count = 0
    for k in range(min_used, max_used + 1):
        count += math.comb(n_models, k) * math.comb(total_units - 1, k - 1)
    return count


def iter_weight_chunks(n_models: int) -> Iterable[np.ndarray]:
    if abs(SWEEP_WEIGHT_STEP - 0.01) > 1e-12:
        raise ValueError("Dieses Skript ist fuer den explizit gewuenschten 0.01-Sweep gebaut.")

    total_units = 100
    bars_range = range(total_units + n_models - 1)
    chunk: list[tuple[int, ...]] = []

    for bars in itertools.combinations(bars_range, n_models - 1):
        positions = (-1,) + bars + (total_units + n_models - 1,)
        weights = tuple(
            positions[i + 1] - positions[i] - 1
            for i in range(n_models)
        )
        used = sum(w > 0 for w in weights)
        if not (SWEEP_MIN_USED_MODELS <= used <= min(SWEEP_MAX_USED_MODELS, n_models)):
            continue

        chunk.append(weights)
        if len(chunk) >= SWEEP_CHUNK_SIZE:
            yield np.asarray(chunk, dtype=np.int16)
            chunk.clear()

    if chunk:
        yield np.asarray(chunk, dtype=np.int16)


def row_from_chunk(
    step: int,
    weights_int_row: np.ndarray,
    metrics: dict[str, np.ndarray],
    row_index: int,
) -> dict[str, Any]:
    weights = [int(v) / 100.0 for v in weights_int_row.tolist()]
    row: dict[str, Any] = {
        "step": int(step),
        "used_models": int(np.count_nonzero(weights_int_row)),
    }
    for i, weight in enumerate(weights, start=1):
        row[f"weight_{i}"] = weight
    for field in SWEEP_METRIC_FIELDS:
        value = metrics[field][row_index]
        if field in {"tp", "fp", "fn", "tn"}:
            row[field] = int(value)
        else:
            row[field] = float(value)
    return row


def better_sweep_row(candidate: dict[str, Any], current: dict[str, Any] | None) -> bool:
    if current is None:
        return True
    candidate_key = (
        float(candidate["D"]),
        -float(candidate["test_dice_fg"]),
        -float(candidate["test_f2"]),
        -float(candidate["test_ap"]),
        tuple(float(candidate[k]) for k in sorted(candidate) if k.startswith("weight_")),
    )
    current_key = (
        float(current["D"]),
        -float(current["test_dice_fg"]),
        -float(current["test_f2"]),
        -float(current["test_ap"]),
        tuple(float(current[k]) for k in sorted(current) if k.startswith("weight_")),
    )
    return candidate_key < current_key


def run_weight_sweep(
    segmentation_infos: list[dict[str, Any]],
    pattern_bits: np.ndarray,
    positive_pattern_counts: np.ndarray,
    negative_pattern_counts: np.ndarray,
) -> dict[str, Any]:
    SWEEP_DIR.mkdir(parents=True, exist_ok=True)

    n_models = len(segmentation_infos)
    weight_fields = [f"weight_{i}" for i in range(1, n_models + 1)]
    fieldnames = ["step", "used_models", *weight_fields, *SWEEP_METRIC_FIELDS]

    model_map = [
        {
            "index": i + 1,
            "model_name": info["model_name"],
            "run_name": info["run_name"],
            "model_path": str(info["model_path"]),
            "individual_threshold": float(info["threshold"]),
            "threshold_file": str(info["threshold_file"]),
        }
        for i, info in enumerate(segmentation_infos)
    ]

    expected_steps = expected_weight_combination_count(n_models)
    metadata = {
        "run_name": RUN_NAME,
        "created_at": datetime.now().isoformat(timespec="seconds"),
        "sweep_split": f"val_{IMG_SIZE}",
        "sweep_dataset_dir": str(TEST_DATASET_DIR / f"val_{IMG_SIZE}"),
        "sweep_image_count": SWEEP_IMAGE_COUNT,
        "weight_step": SWEEP_WEIGHT_STEP,
        "min_used_models": SWEEP_MIN_USED_MODELS,
        "max_used_models": min(SWEEP_MAX_USED_MODELS, n_models),
        "ensemble_decision_threshold": ENSEMBLE_DECISION_THRESHOLD,
        "ranking_metric": "D = sqrt(0.5*(1-Dice)^2 + 0.5*(1-F2)^2); lower is better",
        "expected_steps": expected_steps,
        "models": model_map,
    }

    best_row = None
    step_counter = 0

    txt_file = SWEEP_TXT_FILE.open("w", encoding="utf-8") if SWEEP_SAVE_ALL_STEPS else None
    csv_handle = SWEEP_CSV_FILE.open("w", encoding="utf-8", newline="") if SWEEP_SAVE_ALL_STEPS else None
    json_file = SWEEP_JSON_FILE.open("w", encoding="utf-8") if SWEEP_SAVE_ALL_STEPS else None

    try:
        csv_writer = csv.DictWriter(csv_handle, fieldnames=fieldnames) if csv_handle else None
        if csv_writer:
            csv_writer.writeheader()

        if txt_file:
            txt_file.write("=" * 180 + "\n")
            txt_file.write("MODELLVERTEILUNG-SWEEP AUF FESTEN 200 VALIDATION-BILDERN\n")
            txt_file.write(json.dumps(json_safe(metadata), indent=2, ensure_ascii=False) + "\n")
            txt_file.write("=" * 180 + "\n")
            txt_file.write("\t".join(fieldnames) + "\n")

        if json_file:
            json_file.write("{\n  \"metadata\": ")
            json_file.write(json.dumps(json_safe(metadata), ensure_ascii=False, indent=2))
            json_file.write(",\n  \"steps\": [\n")
            json_first = True
        else:
            json_first = False

        for chunk_index, weights_int in enumerate(iter_weight_chunks(n_models), start=1):
            metrics = compute_metrics_for_weight_chunk(
                weights_int,
                pattern_bits,
                positive_pattern_counts,
                negative_pattern_counts,
            )

            # Lokales Optimum effizient bestimmen.
            order = np.lexsort(
                (
                    np.arange(len(weights_int)),
                    -metrics["test_ap"],
                    -metrics["test_f2"],
                    -metrics["test_dice_fg"],
                    metrics["D"],
                )
            )
            local_best_index = int(order[0])
            local_best_step = step_counter + local_best_index + 1
            local_best = row_from_chunk(
                local_best_step,
                weights_int[local_best_index],
                metrics,
                local_best_index,
            )
            if better_sweep_row(local_best, best_row):
                best_row = local_best

            if SWEEP_SAVE_ALL_STEPS:
                rows = []
                txt_lines = []
                json_lines = []

                for row_index in range(len(weights_int)):
                    step = step_counter + row_index + 1
                    row = row_from_chunk(step, weights_int[row_index], metrics, row_index)
                    rows.append(row)

                    if txt_file:
                        values = []
                        for key in fieldnames:
                            value = row[key]
                            if isinstance(value, float):
                                values.append(f"{value:.6f}")
                            else:
                                values.append(str(value))
                        txt_lines.append("\t".join(values) + "\n")

                    if json_file:
                        prefix = "" if json_first and row_index == 0 else ",\n"
                        json_lines.append(
                            prefix + "    " + json.dumps(json_safe(row), ensure_ascii=False, separators=(",", ":"))
                        )

                if csv_writer:
                    csv_writer.writerows(rows)
                if txt_file:
                    txt_file.writelines(txt_lines)
                if json_file:
                    json_file.write("".join(json_lines))
                    json_first = False

            step_counter += len(weights_int)
            print(
                f"\rSweep: {step_counter:,}/{expected_steps:,} Steps | "
                f"aktuelles bestes D={best_row['D']:.6f}",
                end="",
                flush=True,
            )

            del metrics, weights_int
            if chunk_index % 20 == 0:
                gc.collect()
        print()

        if best_row is None:
            raise RuntimeError("Sweep hat keine gueltige Gewichtsverteilung erzeugt.")

        if json_file:
            json_file.write("\n  ],\n  \"best\": ")
            json_file.write(json.dumps(json_safe(best_row), ensure_ascii=False, indent=2))
            json_file.write("\n}\n")

    finally:
        if txt_file:
            txt_file.close()
        if csv_handle:
            csv_handle.close()
        if json_file:
            json_file.close()

    best_payload = {
        "metadata": metadata,
        "best": best_row,
        "steps_evaluated": step_counter,
    }
    write_json_atomic(SWEEP_BEST_JSON_FILE, best_payload)

    with SWEEP_BEST_TXT_FILE.open("w", encoding="utf-8") as f:
        f.write("=" * 140 + "\n")
        f.write("BESTE MODELLVERTEILUNG DES 200-VALIDATION-BILDER-SWEEPS\n")
        f.write("=" * 140 + "\n")
        f.write(f"Steps ausgewertet: {step_counter:,}\n")
        f.write(f"Best Step: {best_row['step']}\n")
        f.write(f"Benutzte Modelle: {best_row['used_models']}\n")
        for i, info in enumerate(segmentation_infos, start=1):
            f.write(
                f"Modell {i}: weight={best_row[f'weight_{i}']:.2f} | "
                f"{info['model_name']} | individual_threshold={info['threshold']:.10g}\n"
            )
        f.write("\n")
        for field in SWEEP_METRIC_FIELDS:
            value = best_row[field]
            if isinstance(value, float):
                f.write(f"{field}: {value:.6f}\n")
            else:
                f.write(f"{field}: {value}\n")

    with SWEEP_BEST_CSV_FILE.open("w", encoding="utf-8", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerow({k: best_row.get(k, "") for k in fieldnames})

    return best_row


# =============================================================================
# 11. CLASSIFIER-FN LOGGING
# =============================================================================

def save_classifier_false_negatives(rows: list[dict[str, Any]]) -> None:
    if float(HARD_NEGATIVE_SHARE) != 0.0:
        return

    CLASSIFIER_FN_DIR.mkdir(parents=True, exist_ok=True)
    fieldnames = [
        "sample_index",
        "image_name",
        "image_path",
        "mask_path",
        "classifier_probability",
        "classifier_gate_threshold",
        "gt_positive_pixels",
        "decision",
    ]

    with CLASSIFIER_FN_CSV_FILE.open("w", encoding="utf-8", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()
        for row in rows:
            writer.writerow(row)

    with CLASSIFIER_FN_TXT_FILE.open("w", encoding="utf-8") as f:
        f.write("=" * 140 + "\n")
        f.write("CLASSIFIER FALSE NEGATIVES\n")
        f.write("Definition hier: HARD_NEGATIVE_SHARE=0.0, daher gilt jedes vom Classifier "
                "negativ bewertete Testbild gemaess Konfiguration als FN.\n")
        f.write(f"Classifier Gate Threshold: {CLASSIFIER_GATE_THRESHOLD}\n")
        f.write(f"Anzahl FN: {len(rows)}\n")
        f.write("=" * 140 + "\n")
        f.write("\t".join(fieldnames) + "\n")
        for row in rows:
            values = []
            for key in fieldnames:
                value = row[key]
                if isinstance(value, float):
                    values.append(f"{value:.8f}")
                else:
                    values.append(str(value))
            f.write("\t".join(values) + "\n")


# =============================================================================
# 12. FINALE TESTMETRIKEN LOGGEN
# =============================================================================

SUMMARY_FIELDS = [
    "rank_d",
    "run_name",
    "model_name",
    "model_id",
    "best_epoch",
    "img_size",
    "threshold",
    "best_val_dice_fg",
    "test_dice_fg",
    "test_iou_fg",
    "test_precision_fg",
    "test_recall_fg",
    "test_f1_fg",
    "test_f2",
    "test_ap",
    "test_accuracy_pct",
    "balanced_error",
    "balanced_accuracy",
    "fpr",
    "fnr",
    "tp",
    "fp",
    "fn",
    "tn",
    "D",
]

SAMPLE_STAT_FIELDS = [
    "sampled_pixels_total",
    "sample_images_total",
    "sample_images_used",
    "sample_images_skipped_no_positive",
    "sample_images_ring_downsampled",
    "sample_positive_pixels",
    "sample_negative_pixels",
    "sample_ring_pixels_available",
    "sample_ring_pixels_sampled",
    "sample_far_background_available",
    "sample_far_background_sampled",
    "sample_negative_shortfall",
]

SAMPLE_SUMMARY_FIELDS = [*SUMMARY_FIELDS, *SAMPLE_STAT_FIELDS]


def _table_value(value: Any) -> str:
    if value is None:
        return "n/a"
    if isinstance(value, (float, np.floating)):
        if not np.isfinite(float(value)):
            return "n/a"
        return f"{float(value):.6f}"
    return str(value)


def write_horizontal_metrics_txt(
    path: Path,
    title: str,
    result: dict[str, Any],
    fields: list[str],
    metadata_title: str,
    metadata: dict[str, Any],
) -> None:
    """Schreibt Metriken als echte horizontale Tabelle: Header + genau eine Datenzeile."""
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8") as f:
        f.write("=" * 180 + "\n")
        f.write(title + "\n")
        f.write("=" * 180 + "\n")
        f.write("\t".join(fields) + "\n")
        f.write("\t".join(_table_value(result.get(field)) for field in fields) + "\n")

        f.write("\n" + "=" * 180 + "\n")
        f.write(metadata_title + "\n")
        f.write("=" * 180 + "\n")
        f.write(json.dumps(json_safe(metadata), indent=2, ensure_ascii=False) + "\n")


def build_ensemble_metadata(
    selected_weights: list[float],
    segmentation_infos: list[dict[str, Any]],
    records: list[dict[str, Any]],
    classifier_fn_count: int,
) -> dict[str, Any]:
    return {
        "evaluated_at": datetime.now().isoformat(timespec="seconds"),
        "test_dataset_dir": str(TEST_DATASET_DIR),
        "test_split": f"test_{IMG_SIZE}",
        "test_image_count": len(records),
        "hard_negative_share_configured": HARD_NEGATIVE_SHARE,
        "hard_negative_count": sum(bool(r["is_hard_negative"]) for r in records),
        "classifier_model_path": str(CLASSIFIER_MODEL_PATH),
        "classifier_gate_threshold": CLASSIFIER_GATE_THRESHOLD,
        "classifier_false_negative_count": (
            classifier_fn_count if HARD_NEGATIVE_SHARE == 0.0 else None
        ),
        "ensemble_decision_threshold": ENSEMBLE_DECISION_THRESHOLD,
        "selected_weights": selected_weights,
        "saved_ensemble_model": str(ENSEMBLE_MODEL_PATH),
        "segmentation_models": [
            {
                "index": i + 1,
                "run_name": info["run_name"],
                "model_name": info["model_name"],
                "model_path": str(info["model_path"]),
                "input_size": info["input_size"],
                "weight": selected_weights[i],
                "individual_threshold": info["threshold"],
                "threshold_file": str(info["threshold_file"]),
            }
            for i, info in enumerate(segmentation_infos)
        ],
        "sweep": {
            "source_split": f"val_{IMG_SIZE}",
            "source_dataset_dir": str(TEST_DATASET_DIR / f"val_{IMG_SIZE}"),
            "image_count": SWEEP_IMAGE_COUNT,
            "selection_file": str(SWEEP_SELECTION_FILE),
            "weight_step": SWEEP_WEIGHT_STEP,
            "ranking_metric": SWEEP_RANKING_METRIC,
            "steps_txt": str(SWEEP_TXT_FILE),
            "steps_csv": str(SWEEP_CSV_FILE),
            "steps_json": str(SWEEP_JSON_FILE),
        },
    }


def save_final_metrics(
    metrics: dict[str, Any],
    selected_weights: list[float],
    segmentation_infos: list[dict[str, Any]],
    records: list[dict[str, Any]],
    classifier_fn_count: int,
) -> dict[str, Any]:
    TEST_METRICS_DIR.mkdir(parents=True, exist_ok=True)

    result = {
        "rank_d": 1,
        "run_name": RUN_NAME,
        "model_name": f"{RUN_NAME}_ensemble",
        "model_id": sanitize_name(RUN_NAME).casefold(),
        "best_epoch": None,
        "img_size": IMG_SIZE,
        "threshold": float(ENSEMBLE_DECISION_THRESHOLD),
        "best_val_dice_fg": None,
        **metrics,
    }

    ensemble_metadata = build_ensemble_metadata(
        selected_weights,
        segmentation_infos,
        records,
        classifier_fn_count,
    )

    write_horizontal_metrics_txt(
        FINAL_METRICS_TXT_FILE,
        f"FINALE VOLLBILD-TESTMETRIKEN: {RUN_NAME}",
        result,
        SUMMARY_FIELDS,
        "ENSEMBLE-METADATEN",
        ensemble_metadata,
    )

    with FINAL_METRICS_CSV_FILE.open("w", encoding="utf-8", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=SUMMARY_FIELDS)
        writer.writeheader()
        writer.writerow({
            key: round_for_output(result.get(key))
            for key in SUMMARY_FIELDS
        })

    payload = {
        key: round_for_output(result.get(key))
        for key in SUMMARY_FIELDS
    }
    payload["ensemble_metadata"] = ensemble_metadata
    write_json_atomic(FINAL_METRICS_JSON_FILE, payload)
    return payload


def save_sample_metrics(
    metrics: dict[str, Any],
    selected_weights: list[float],
    segmentation_infos: list[dict[str, Any]],
    records: list[dict[str, Any]],
    classifier_fn_count: int,
    sampling_stats: dict[str, Any],
) -> dict[str, Any]:
    """Speichert die BALANCED-CRACK-ROI-Testmetriken getrennt von den Vollbildmetriken."""
    TEST_METRICS_DIR.mkdir(parents=True, exist_ok=True)

    sampled_pixels_total = int(
        sampling_stats["positive_pixels"]
        + sampling_stats["negative_pixels_sampled"]
    )
    result = {
        "rank_d": 1,
        "run_name": RUN_NAME,
        "model_name": f"{RUN_NAME}_ensemble",
        "model_id": sanitize_name(RUN_NAME).casefold(),
        "best_epoch": None,
        "img_size": IMG_SIZE,
        "threshold": float(ENSEMBLE_DECISION_THRESHOLD),
        "best_val_dice_fg": None,
        **metrics,
        "sampled_pixels_total": sampled_pixels_total,
        "sample_images_total": int(sampling_stats["images_total"]),
        "sample_images_used": int(sampling_stats["images_used"]),
        "sample_images_skipped_no_positive": int(
            sampling_stats["images_skipped_no_positive"]
        ),
        "sample_images_ring_downsampled": int(
            sampling_stats["images_ring_downsampled"]
        ),
        "sample_positive_pixels": int(sampling_stats["positive_pixels"]),
        "sample_negative_pixels": int(
            sampling_stats["negative_pixels_sampled"]
        ),
        "sample_ring_pixels_available": int(
            sampling_stats["ring_pixels_available"]
        ),
        "sample_ring_pixels_sampled": int(
            sampling_stats["ring_pixels_sampled"]
        ),
        "sample_far_background_available": int(
            sampling_stats["far_background_available"]
        ),
        "sample_far_background_sampled": int(
            sampling_stats["far_background_sampled"]
        ),
        "sample_negative_shortfall": int(
            sampling_stats["negative_shortfall"]
        ),
    }

    ensemble_metadata = build_ensemble_metadata(
        selected_weights,
        segmentation_infos,
        records,
        classifier_fn_count,
    )
    sample_metadata = {
        **ensemble_metadata,
        "evaluation_scope": "BALANCED_CRACK_ROI_SAMPLE",
        "sampling": {
            "ring_radius_px": ROI_RING_RADIUS_PX,
            "negative_to_positive_ratio": ROI_NEGATIVE_TO_POSITIVE_RATIO,
            "random_seed": ROI_RANDOM_SEED,
            "semantics": (
                "Alle GT-Risspixel plus gesampelte negative Pixel. Negative Pixel "
                "werden bevorzugt aus dem rissnahen morphologischen Ring gezogen; "
                "Bilder ohne positive GT-Pixel werden fuer die Sample-Metriken "
                "uebersprungen."
            ),
            "statistics": sampling_stats,
        },
    }

    write_horizontal_metrics_txt(
        SAMPLE_METRICS_TXT_FILE,
        f"GESAMPELTE BALANCED-CRACK-ROI-TESTMETRIKEN: {RUN_NAME}",
        result,
        SAMPLE_SUMMARY_FIELDS,
        "SAMPLE-/ENSEMBLE-METADATEN",
        sample_metadata,
    )

    with SAMPLE_METRICS_CSV_FILE.open("w", encoding="utf-8", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=SAMPLE_SUMMARY_FIELDS)
        writer.writeheader()
        writer.writerow({
            key: round_for_output(result.get(key))
            for key in SAMPLE_SUMMARY_FIELDS
        })

    payload = {
        key: round_for_output(result.get(key))
        for key in SAMPLE_SUMMARY_FIELDS
    }
    payload["sample_metadata"] = sample_metadata
    write_json_atomic(SAMPLE_METRICS_JSON_FILE, payload)
    return payload


# =============================================================================
# 13. ARCHITEKTUR-EXPORT
# =============================================================================

def clone_model_shell(model: tf.keras.Model, name: str) -> tf.keras.Model:
    """Erzeugt einen eindeutig benannten Wrapper, teilt aber dieselben Layer/Gewichte."""
    return tf.keras.Model(inputs=model.inputs, outputs=model.outputs, name=name)


def build_architecture_model(
    classifier_info: dict[str, Any],
    segmentation_infos: list[dict[str, Any]],
    selected_weights: list[float],
) -> tf.keras.Model:
    ensemble_input = tf.keras.Input(
        shape=(IMG_SIZE, IMG_SIZE, 3),
        dtype=tf.float32,
        name="test_image",
    )

    binary_outputs = []
    for i, (info, weight) in enumerate(zip(segmentation_infos, selected_weights), start=1):
        x = ensemble_input
        if info["input_size"] != IMG_SIZE:
            x = tf.keras.layers.Resizing(
                info["input_size"],
                info["input_size"],
                interpolation="bilinear",
                name=f"seg_{i}_input_resize",
            )(x)

        branch_model = clone_model_shell(
            info["model"],
            name=f"segmentation_model_{i}_{sanitize_name(info['run_name'])}",
        )
        pred = branch_model(x)
        if isinstance(pred, (list, tuple)):
            pred = pred[0]
        pred = EnsureOneChannel(name=f"seg_{i}_one_channel")(pred)
        if SEGMENTATION_OUTPUTS_ARE_LOGITS:
            pred = tf.keras.layers.Activation(
                "sigmoid",
                dtype="float32",
                name=f"seg_{i}_logits_to_probability",
            )(pred)
        if info["input_size"] != IMG_SIZE:
            pred = tf.keras.layers.Resizing(
                IMG_SIZE,
                IMG_SIZE,
                interpolation="bilinear",
                name=f"seg_{i}_output_resize",
            )(pred)
        binary = FixedThreshold(
            info["threshold"],
            name=f"seg_{i}_individual_threshold",
        )(pred)
        binary_outputs.append(binary)

    vote_score = WeightedVote(
        selected_weights,
        name="weighted_binary_vote_score",
    )(binary_outputs)

    cls_x = ensemble_input
    if classifier_info["input_size"] != IMG_SIZE:
        cls_x = tf.keras.layers.Resizing(
            classifier_info["input_size"],
            classifier_info["input_size"],
            interpolation="bilinear",
            name="classifier_input_resize",
        )(cls_x)

    classifier_branch = clone_model_shell(
        classifier_info["model"],
        name="classifier_model",
    )
    cls_pred = classifier_branch(cls_x)
    if isinstance(cls_pred, (list, tuple)):
        cls_pred = cls_pred[0]

    gate = ClassifierGate(
        threshold=CLASSIFIER_GATE_THRESHOLD,
        positive_class_index=CLASSIFIER_POSITIVE_CLASS_INDEX,
        output_is_logits=CLASSIFIER_OUTPUT_IS_LOGITS,
        name="classifier_gate",
    )(cls_pred)

    gated_score = tf.keras.layers.Multiply(name="classifier_gated_vote_score")(
        [vote_score, gate]
    )
    final_mask = FixedThreshold(
        ENSEMBLE_DECISION_THRESHOLD,
        name="ensemble_decision_threshold",
    )(gated_score)

    return tf.keras.Model(
        inputs=ensemble_input,
        outputs={"ensemble_score": gated_score, "binary_mask": final_mask},
        name=f"{sanitize_name(RUN_NAME)}_ensemble",
    )


def save_ensemble_model(
    classifier_info: dict[str, Any],
    segmentation_infos: list[dict[str, Any]],
    selected_weights: list[float],
) -> dict[str, Any]:
    """Speichert das komplette, nach Validation eingefrorene Ensemble als .keras."""
    MODEL_DIR.mkdir(parents=True, exist_ok=True)
    ensemble_model = build_architecture_model(
        classifier_info,
        segmentation_infos,
        selected_weights,
    )
    ensemble_model.save(ENSEMBLE_MODEL_PATH)

    # Direkt im selben Prozess wieder laden: prueft die Keras-Serialisierung inklusive
    # der registrierten Custom-Layer, ohne Testdaten zur Auswahl zu verwenden.
    try:
        reloaded = tf.keras.models.load_model(
            ENSEMBLE_MODEL_PATH,
            compile=False,
            custom_objects=CUSTOM_OBJECTS,
            safe_mode=False,
        )
    except TypeError:
        reloaded = tf.keras.models.load_model(
            ENSEMBLE_MODEL_PATH,
            compile=False,
            custom_objects=CUSTOM_OBJECTS,
        )
    info = {
        "model_path": str(ENSEMBLE_MODEL_PATH),
        "model_name": ENSEMBLE_MODEL_PATH.name,
        "input_shape": ensemble_model.input_shape,
        "output_names": list(ensemble_model.output_names),
        "parameters": int(ensemble_model.count_params()),
        "reload_verified": True,
        "reload_input_shape": reloaded.input_shape,
        "selected_weights": [float(v) for v in selected_weights],
        "ensemble_decision_threshold": float(ENSEMBLE_DECISION_THRESHOLD),
        "classifier_gate_threshold": float(CLASSIFIER_GATE_THRESHOLD),
    }
    del reloaded, ensemble_model
    return info


def iter_layers_recursive(model: tf.keras.Model, prefix: str = ""):
    for index, layer in enumerate(model.layers):
        path = f"{prefix}{index:03d}:{layer.name}"
        yield path, layer
        if isinstance(layer, tf.keras.Model):
            yield from iter_layers_recursive(layer, prefix=path + "/")


def write_model_summary(file, model: tf.keras.Model, title: str) -> None:
    file.write("=" * 200 + "\n")
    file.write(title + "\n")
    file.write("=" * 200 + "\n\n")
    model.summary(
        expand_nested=True,
        line_length=200,
        print_fn=lambda line: file.write(line + "\n"),
    )
    file.write("\n\n")


def architecture_variables(
    selected_weights: list[float],
    classifier_info: dict[str, Any],
    segmentation_infos: list[dict[str, Any]],
) -> dict[str, Any]:
    return {
        "RUN_NAME": RUN_NAME,
        "CRACK_PROJECT_ROOT": CRACK_PROJECT_ROOT,
        "OUTPUT_ROOT": OUTPUT_ROOT,
        "RUN_DIR": RUN_DIR,
        "TEST_METRICS_DIR": TEST_METRICS_DIR,
        "TEST_DATASET_DIR": TEST_DATASET_DIR,
        "IMG_SIZE": IMG_SIZE,
        "CLASSIFIER_MODEL_PATH": CLASSIFIER_MODEL_PATH,
        "CLASSIFIER_GATE_THRESHOLD": CLASSIFIER_GATE_THRESHOLD,
        "CLASSIFIER_POSITIVE_CLASS_INDEX": CLASSIFIER_POSITIVE_CLASS_INDEX,
        "CLASSIFIER_OUTPUT_IS_LOGITS": CLASSIFIER_OUTPUT_IS_LOGITS,
        "SEGMENTATION_MODEL_PATHS": SEGMENTATION_MODEL_PATHS,
        "SEGMENTATION_OUTPUTS_ARE_LOGITS": SEGMENTATION_OUTPUTS_ARE_LOGITS,
        "THRESHOLD_FILENAME_SUFFIX": THRESHOLD_FILENAME_SUFFIX,
        "ENSEMBLE_DECISION_THRESHOLD": ENSEMBLE_DECISION_THRESHOLD,
        "HARD_NEGATIVE_SHARE": HARD_NEGATIVE_SHARE,
        "HARD_NEGATIVE_RANDOM_SEED": HARD_NEGATIVE_RANDOM_SEED,
        "SWEEP_SOURCE_SPLIT": f"val_{IMG_SIZE}",
        "FINAL_METRICS_SPLIT": f"test_{IMG_SIZE}",
        "SWEEP_IMAGE_COUNT": SWEEP_IMAGE_COUNT,
        "SWEEP_IMAGE_SEED": SWEEP_IMAGE_SEED,
        "SWEEP_WEIGHT_STEP": SWEEP_WEIGHT_STEP,
        "SWEEP_MIN_USED_MODELS": SWEEP_MIN_USED_MODELS,
        "SWEEP_MAX_USED_MODELS": SWEEP_MAX_USED_MODELS,
        "SWEEP_RANKING_METRIC": SWEEP_RANKING_METRIC,
        "SWEEP_CHUNK_SIZE": SWEEP_CHUNK_SIZE,
        "SWEEP_SAVE_ALL_STEPS": SWEEP_SAVE_ALL_STEPS,
        "BATCH_SIZE": BATCH_SIZE,
        "BATCH_SIZE_1024": BATCH_SIZE_1024,
        "SEED": SEED,
        "XLA_JIT": XLA_JIT,
        "MIXED_PRECISION_POLICY": MIXED_PRECISION_POLICY,
        "AP_THRESHOLDS": AP_THRESHOLDS,
        "ARCHITECTURE_EXPAND_NESTED_PNG": ARCHITECTURE_EXPAND_NESTED_PNG,
        "selected_weights": selected_weights,
        "classifier": {
            "model_path": classifier_info["model_path"],
            "input_size": classifier_info["input_size"],
        },
        "segmentation_models": [
            {
                "index": i + 1,
                "run_name": info["run_name"],
                "model_name": info["model_name"],
                "model_path": info["model_path"],
                "input_size": info["input_size"],
                "individual_threshold": info["threshold"],
                "threshold_file": info["threshold_file"],
                "selected_weight": selected_weights[i],
            }
            for i, info in enumerate(segmentation_infos)
        ],
        "runtime_gate_semantics": (
            "Classifier wird zuerst ausgefuehrt. Bei probability < CLASSIFIER_GATE_THRESHOLD "
            "werden die Segmentierungsmodelle fuer dieses Bild nicht ausgefuehrt und der "
            "Ensemble-Score wird auf 0 gesetzt."
        ),
        "fusion_semantics": (
            "Jedes Segmentierungsmodell wird mit seinem individuellen ROI-minimal-Balanced-Error-"
            "Threshold binarisiert. Danach gewichtete Summe der binaeren Outputs; finale Entscheidung "
            "bei ENSEMBLE_DECISION_THRESHOLD."
        ),
    }


def export_architecture(
    classifier_info: dict[str, Any],
    segmentation_infos: list[dict[str, Any]],
    selected_weights: list[float],
) -> dict[str, Any]:
    ARCH_DIR.mkdir(parents=True, exist_ok=True)
    wrapper = build_architecture_model(classifier_info, segmentation_infos, selected_weights)
    variables = architecture_variables(selected_weights, classifier_info, segmentation_infos)

    architecture_payload = {
        "variables": variables,
        "ensemble_keras_config": wrapper.get_config(),
        "classifier_config": classifier_info["model"].get_config(),
        "segmentation_model_configs": [info["model"].get_config() for info in segmentation_infos],
    }
    write_json_atomic(ARCHITECTURE_JSON_FILE, architecture_payload)

    try:
        ARCHITECTURE_KERAS_JSON_FILE.write_text(wrapper.to_json(), encoding="utf-8")
    except Exception as exc:
        ARCHITECTURE_KERAS_JSON_FILE.write_text(
            json.dumps({"error": str(exc)}, indent=2, ensure_ascii=False),
            encoding="utf-8",
        )

    all_layers = list(iter_layers_recursive(wrapper))

    with ARCHITECTURE_TXT_FILE.open("w", encoding="utf-8") as f:
        f.write(f"Run: {RUN_NAME}\n")
        f.write("Architecture: Classifier-Gate + 2..5 individuell thresholded Segmentierungsmodelle + weighted vote\n")
        f.write(f"Input: ({IMG_SIZE}, {IMG_SIZE}, 3)\n")
        f.write("Output 1: ensemble_score in [0,1]\n")
        f.write("Output 2: binary_mask nach ENSEMBLE_DECISION_THRESHOLD\n")
        f.write(f"Classifier gate threshold: {CLASSIFIER_GATE_THRESHOLD}\n")
        f.write(f"Ensemble decision threshold: {ENSEMBLE_DECISION_THRESHOLD}\n")
        f.write(f"Selected weights: {selected_weights}\n")
        f.write(f"Mixed precision: {mixed_precision.global_policy().name}\n")
        f.write(f"Gesamtparameter Wrapper: {wrapper.count_params():,}\n")
        f.write(f"Rekursiv gefundene Layer: {len(all_layers)}\n\n")

        f.write("=" * 200 + "\n")
        f.write("0. VOLLSTAENDIGE ENSEMBLE-VARIABLEN\n")
        f.write("=" * 200 + "\n\n")
        f.write(json.dumps(json_safe(variables), indent=2, ensure_ascii=False) + "\n\n")

        write_model_summary(f, wrapper, "1. VOLLSTAENDIGE ENSEMBLE-MODELLZUSAMMENFASSUNG")
        write_model_summary(f, classifier_info["model"], "2. CLASSIFIER-MODELLZUSAMMENFASSUNG")
        for i, info in enumerate(segmentation_infos, start=1):
            write_model_summary(
                f,
                info["model"],
                f"3.{i} SEGMENTIERUNGSMODELL: {info['model_name']}",
            )

        f.write("=" * 200 + "\n")
        f.write("4. REKURSIVE LAYERLISTE\n")
        f.write("=" * 200 + "\n\n")
        for path, layer in all_layers:
            try:
                params = int(layer.count_params())
            except Exception:
                params = -1
            f.write(f"Pfad: {path}\n")
            f.write(f"  Klasse: {layer.__class__.__name__}\n")
            f.write(f"  Trainable: {layer.trainable}\n")
            f.write(f"  dtype: {getattr(layer, 'dtype', 'n/a')}\n")
            f.write(f"  Parameter: {params}\n")
            try:
                f.write(
                    "  Konfiguration: "
                    + json.dumps(json_safe(layer.get_config()), ensure_ascii=False, sort_keys=True)
                    + "\n"
                )
            except Exception as exc:
                f.write(f"  Konfiguration nicht verfuegbar: {exc}\n")
            f.write("\n")

        f.write("=" * 200 + "\n")
        f.write("5. VOLLSTAENDIGE ENSEMBLE-KONFIGURATION ALS JSON\n")
        f.write("=" * 200 + "\n\n")
        json.dump(json_safe(architecture_payload), f, indent=2, ensure_ascii=False)
        f.write("\n")

    plot_error = None
    try:
        plot_model(
            wrapper,
            to_file=str(ARCHITECTURE_PNG_FILE),
            show_shapes=True,
            show_layer_names=True,
            expand_nested=ARCHITECTURE_EXPAND_NESTED_PNG,
            dpi=ARCHITECTURE_DPI,
            rankdir="TB",
        )
    except Exception as exc:
        plot_error = str(exc)
        (ARCH_DIR / f"{RUN_NAME}_architecture_plot_error.txt").write_text(
            "Die PNG-Architektur konnte nicht erstellt werden.\n"
            f"Fehler: {exc}\n"
            "Pruefe insbesondere pydot und Graphviz.\n",
            encoding="utf-8",
        )

    return {
        "architecture_txt": str(ARCHITECTURE_TXT_FILE),
        "architecture_json": str(ARCHITECTURE_JSON_FILE),
        "architecture_keras_json": str(ARCHITECTURE_KERAS_JSON_FILE),
        "architecture_png": str(ARCHITECTURE_PNG_FILE),
        "plot_error": plot_error,
        "total_parameters": int(wrapper.count_params()),
        "recursive_layer_count": len(all_layers),
    }


# =============================================================================
# 14. KONFIGURATION VALIDIEREN / MODELLE LADEN
# =============================================================================

def validate_configuration() -> None:
    n_models = len(SEGMENTATION_MODEL_PATHS)
    if not 2 <= n_models <= 5:
        raise ValueError(
            f"SEGMENTATION_MODEL_PATHS muss 2 bis 5 Modelle enthalten, aktuell: {n_models}."
        )
    if SWEEP_MIN_USED_MODELS < 2:
        raise ValueError("SWEEP_MIN_USED_MODELS muss mindestens 2 sein.")
    if SWEEP_MAX_USED_MODELS > 5:
        raise ValueError("SWEEP_MAX_USED_MODELS darf maximal 5 sein.")
    if SWEEP_MIN_USED_MODELS > min(SWEEP_MAX_USED_MODELS, n_models):
        raise ValueError("Ungueltige Min/Max-Konfiguration fuer benutzte Sweep-Modelle.")
    if abs(SWEEP_WEIGHT_STEP - 0.01) > 1e-12:
        raise ValueError("SWEEP_WEIGHT_STEP muss gemaess Anforderung exakt 0.01 sein.")
    if str(SWEEP_RANKING_METRIC).strip().upper() != "D":
        raise ValueError(
            "SWEEP_RANKING_METRIC muss fuer die gleiche Ranking-Logik wie im Testcode 'D' sein."
        )
    if not 0.0 <= ENSEMBLE_DECISION_THRESHOLD <= 1.0:
        raise ValueError("ENSEMBLE_DECISION_THRESHOLD muss in [0,1] liegen.")
    if not 0.0 <= CLASSIFIER_GATE_THRESHOLD <= 1.0:
        raise ValueError("CLASSIFIER_GATE_THRESHOLD muss in [0,1] liegen.")


def load_all_models():
    print("Lade Classifier ...")
    classifier_model = load_model_robust(CLASSIFIER_MODEL_PATH)
    classifier_info = {
        "model": classifier_model,
        "model_path": Path(CLASSIFIER_MODEL_PATH).expanduser().resolve(),
        "input_size": infer_square_input_size(classifier_model),
    }

    segmentation_infos = []
    for index, raw_path in enumerate(SEGMENTATION_MODEL_PATHS, start=1):
        model_path = Path(raw_path).expanduser().resolve()
        print(f"Lade Segmentierungsmodell {index}/{len(SEGMENTATION_MODEL_PATHS)}: {model_path.name}")
        threshold_info = read_individual_threshold(model_path)
        model = load_model_robust(model_path)
        run_dir = resolve_run_dir_from_model(model_path)
        info = {
            "model": model,
            "model_path": model_path,
            "model_name": model_path.name,
            "run_dir": run_dir,
            "run_name": run_dir.name,
            "input_size": infer_square_input_size(model),
            **threshold_info,
        }
        segmentation_infos.append(info)
        print(
            f"  Run={info['run_name']} | Input={info['input_size']} | "
            f"Threshold={info['threshold']:.10g} | Quelle={info['threshold_file']}"
        )

    return classifier_info, segmentation_infos


# =============================================================================
# 15. MAIN
# =============================================================================

def main():
    validate_configuration()
    RUN_DIR.mkdir(parents=True, exist_ok=True)
    ARCH_DIR.mkdir(parents=True, exist_ok=True)
    MODEL_DIR.mkdir(parents=True, exist_ok=True)
    SWEEP_DIR.mkdir(parents=True, exist_ok=True)
    TEST_METRICS_DIR.mkdir(parents=True, exist_ok=True)

    print("=" * 110)
    print(f"ENSEMBLE VALIDATION-SWEEP + TESTRUN: {RUN_NAME}")
    print(f"Run-Ordner:         {RUN_DIR}")
    print(f"Testmetrics-Ordner: {TEST_METRICS_DIR}")
    print(f"Dataset-Root:        {TEST_DATASET_DIR}")
    print(f"Sweep-Split:         val_{IMG_SIZE}")
    print(f"Finaler Metricsplit: test_{IMG_SIZE}")
    print("=" * 110)

    classifier_info, segmentation_infos = load_all_models()
    pattern_bits = pattern_bit_matrix(len(segmentation_infos))

    # -------------------------------------------------------------------------
    # 1) VALIDATION: nur hier werden die Ensemble-Gewichte optimiert.
    # -------------------------------------------------------------------------
    validation_records = build_validation_records()
    sweep_indices = get_or_create_sweep_indices(validation_records)
    sweep_records = [validation_records[int(i)] for i in sweep_indices]
    print(
        f"Validation gesamt: {len(validation_records)} | "
        f"feste Sweep-Auswahl: {len(sweep_records)} Bilder | {SWEEP_SELECTION_FILE}"
    )

    validation_sweep_ds = make_dataset(sweep_records)
    validation_counts = collect_pattern_counts(
        validation_sweep_ds,
        sweep_records,
        classifier_info,
        segmentation_infos,
        log_classifier_fn=False,
        phase_name="Validation-Sweep",
    )

    print("\nStarte exakten Modellverteilung-Sweep ausschliesslich auf Validation ...")
    print(
        f"Konfigurierte Modelle: {len(segmentation_infos)} | "
        f"erwartete gueltige Steps: {expected_weight_combination_count(len(segmentation_infos)):,}"
    )
    best_sweep = run_weight_sweep(
        segmentation_infos,
        pattern_bits,
        validation_counts["positive_pattern_counts"],
        validation_counts["negative_pattern_counts"],
    )

    selected_weights = [
        float(best_sweep[f"weight_{i}"])
        for i in range(1, len(segmentation_infos) + 1)
    ]
    print(f"Beste Validation-Gewichte: {selected_weights} | Validation-D={best_sweep['D']:.6f}")

    # Ensemble sofort nach der Validation-Auswahl speichern. So wird der
    # Testsplit weder fuer die Gewichtsbestimmung noch fuer den Modell-Export
    # benoetigt, und Serialisierungsfehler treten vor der langen Testinferenz auf.
    print("\nSpeichere komplettes Ensemble als .keras ...")
    ensemble_model_info = save_ensemble_model(
        classifier_info,
        segmentation_infos,
        selected_weights,
    )
    print(
        f"Ensemble-Modell: {ensemble_model_info['model_path']} | "
        f"Reload-Verifikation={ensemble_model_info['reload_verified']}"
    )

    # -------------------------------------------------------------------------
    # 2) TEST: Gewichte sind jetzt eingefroren. Keine Optimierung auf Testdaten.
    # -------------------------------------------------------------------------
    print("\nStarte getrennte finale Inferenz auf test-Split mit eingefrorenen Gewichten ...")
    test_records = build_test_records()
    hard_negative_count = sum(bool(r["is_hard_negative"]) for r in test_records)
    print(
        f"Testbilder gesamt: {len(test_records)} | Hard-Negatives: {hard_negative_count} | "
        f"HN-Anteil effektiv: {hard_negative_count / max(len(test_records), 1):.4f}"
    )

    test_ds = make_dataset(test_records)
    test_counts = collect_pattern_counts(
        test_ds,
        test_records,
        classifier_info,
        segmentation_infos,
        log_classifier_fn=(float(HARD_NEGATIVE_SHARE) == 0.0),
        collect_sample_patterns=True,
        phase_name="Final-Test",
    )

    if HARD_NEGATIVE_SHARE == 0.0:
        save_classifier_false_negatives(test_counts["classifier_fn_rows"])
        print(
            f"Classifier-FN (nur Testsplit): {len(test_counts['classifier_fn_rows'])} | "
            f"{CLASSIFIER_FN_DIR}"
        )

    final_metrics = metrics_for_single_weights(
        selected_weights,
        pattern_bits,
        test_counts["positive_pattern_counts"],
        test_counts["negative_pattern_counts"],
    )
    save_final_metrics(
        final_metrics,
        selected_weights,
        segmentation_infos,
        test_records,
        classifier_fn_count=len(test_counts["classifier_fn_rows"]),
    )

    sample_metrics = metrics_for_single_weights(
        selected_weights,
        pattern_bits,
        test_counts["sample_positive_pattern_counts"],
        test_counts["sample_negative_pattern_counts"],
    )
    save_sample_metrics(
        sample_metrics,
        selected_weights,
        segmentation_infos,
        test_records,
        classifier_fn_count=len(test_counts["classifier_fn_rows"]),
        sampling_stats=test_counts["sample_sampling_stats"],
    )

    print("\nExportiere Gesamtarchitektur ...")
    architecture_info = export_architecture(
        classifier_info,
        segmentation_infos,
        selected_weights,
    )

    print("\n" + "=" * 110)
    print("ENSEMBLE VALIDATION-SWEEP + TEST ABGESCHLOSSEN")
    print(f"Gewichte aus: val_{IMG_SIZE} (feste {SWEEP_IMAGE_COUNT} Bilder)")
    print(f"Metrics aus:  test_{IMG_SIZE} (kompletter konfigurierte Testsplit)")
    print(f"Dice: {final_metrics['test_dice_fg']:.6f}")
    print(f"F2:   {final_metrics['test_f2']:.6f}")
    print(f"AP:   {final_metrics['test_ap']:.6f}")
    print(f"D:    {final_metrics['D']:.6f}")
    print(f"Metrics TXT:         {FINAL_METRICS_TXT_FILE}")
    print(f"Metrics CSV:         {FINAL_METRICS_CSV_FILE}")
    print(f"Metrics JSON:        {FINAL_METRICS_JSON_FILE}")
    print(f"Sample Metrics TXT:  {SAMPLE_METRICS_TXT_FILE}")
    print(f"Sample Metrics CSV:  {SAMPLE_METRICS_CSV_FILE}")
    print(f"Sample Metrics JSON: {SAMPLE_METRICS_JSON_FILE}")
    print(f"Ensemble .keras:     {ENSEMBLE_MODEL_PATH}")
    print(f"Sweep:               {SWEEP_DIR}")
    print(f"Architecture: {ARCH_DIR}")
    if HARD_NEGATIVE_SHARE == 0.0:
        print(f"Classifier-FN:{CLASSIFIER_FN_DIR}")
    if architecture_info.get("plot_error"):
        print(f"[WARNUNG] Architektur-PNG fehlgeschlagen: {architecture_info['plot_error']}")
    print("=" * 110)


if __name__ == "__main__":
    main()
