#!/usr/bin/env python3
from pathlib import Path
import cv2
from reportlab.pdfgen import canvas
from reportlab.lib.pagesizes import A4
from reportlab.lib.units import mm
from reportlab.lib.utils import ImageReader

# ---- HIER ANPASSEN ----
DICTIONARY_NAME = "DICT_5X5_50"
MARKER_ID = 1
MARKER_SIZE_MM = 50.0
OUTPUT_PDF = Path("aruco_marker.pdf")
OUTPUT_PNG = Path("aruco_marker.png")
# -----------------------

aruco = cv2.aruco
if not hasattr(aruco, DICTIONARY_NAME):
    raise ValueError(f"Unbekanntes Dictionary: {DICTIONARY_NAME}")

dictionary = aruco.getPredefinedDictionary(getattr(aruco, DICTIONARY_NAME))
# Hohe Aufloesung; 1400 px passt bei 5x5 + 1 Randbit je Seite exakt auf 7 Module.
marker = aruco.generateImageMarker(dictionary, MARKER_ID, 1400, borderBits=1)
cv2.imwrite(str(OUTPUT_PNG), marker)

page_w, page_h = A4
c = canvas.Canvas(str(OUTPUT_PDF), pagesize=A4)
size_pt = MARKER_SIZE_MM * mm
x = (page_w - size_pt) / 2
y = page_h - 70*mm - size_pt

# 10-mm-Quiet-Zone; nicht Teil der MARKER_SIZE_MM.
quiet = 10*mm
c.setFillColorRGB(1, 1, 1)
c.rect(x-quiet, y-quiet, size_pt+2*quiet, size_pt+2*quiet, stroke=0, fill=1)
c.drawImage(ImageReader(str(OUTPUT_PNG)), x, y, width=size_pt, height=size_pt,
            preserveAspectRatio=False, mask="auto")

c.setFillColorRGB(0, 0, 0)
c.setFont("Helvetica-Bold", 13)
c.drawCentredString(page_w/2, page_h-25*mm,
                    f"ArUco {DICTIONARY_NAME} - ID {MARKER_ID}")
c.setFont("Helvetica", 10)
c.drawCentredString(page_w/2, page_h-32*mm,
                    f"Schwarze Aussenkante: {MARKER_SIZE_MM:.2f} mm")
c.drawCentredString(page_w/2, page_h-38*mm,
                    "Drucken mit 100 % / Tatsaechliche Groesse")
c.save()

print(f"Erzeugt: {OUTPUT_PDF}")
print(f"Erzeugt: {OUTPUT_PNG}")
