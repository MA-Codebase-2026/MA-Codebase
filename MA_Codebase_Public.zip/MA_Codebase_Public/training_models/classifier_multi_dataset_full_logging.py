#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Binärer Bildklassifikator für Betonrisse mit mehreren Datensätzen.

Erweiterungen gegenüber classifier_multi_dataset_optimized:
- Run-Struktur unter /home/mitte/crack_project/output_classifier/RUN_NAME
- schnelles Training-/Validation-Logging in metrics/ als TXT, CSV und JSON
- Architektur-Export in architecture/ als PNG, JSON, Keras-JSON und ausführliche TXT
- Epochen-Validation nur 250 Steps x Batch 8; Threshold-Sweep erst am Ende vollständig auf val_512
- Empfehlungen für bestes F1 ("optimal"), F2, Recall, minimalen Balanced Error
  und zusätzlich U-Net++-artige F1/F2-Idealpunkt-Distanz
- genau ein finaler Testlauf auf test_512 mit dem primären, ausschließlich auf Validation bestimmten Threshold
- Testmetriken in metrics/ als TXT, CSV und JSON

WICHTIG:
Der Testsplit wird niemals zur Threshold-Auswahl benutzt. Alle Testmetriken werden erst
nach Abschluss des Validation-Threshold-Sweeps mit fest eingefrorenen Thresholds berechnet.
"""

from __future__ import annotations

import csv
import json
import os
import platform
import random
import sys
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path
from typing import Any, Iterable, Sequence

# Muss vor TensorFlow gesetzt werden.
os.environ.setdefault("TF_CPP_MIN_LOG_LEVEL", "2")
os.environ.setdefault("TF_GPU_ALLOCATOR", "cuda_malloc_async")
os.environ.setdefault("TF_FORCE_GPU_ALLOW_GROWTH", "true")
os.environ.setdefault("KERAS_BACKEND", "tensorflow")

import matplotlib.pyplot as plt
import numpy as np
import tensorflow as tf
from keras import layers, mixed_precision
from keras.utils import plot_model


# =============================================================================
# 0. REPRODUZIERBARKEIT / HARDWARE
# =============================================================================
SEED = 42
os.environ["PYTHONHASHSEED"] = str(SEED)
random.seed(SEED)
np.random.seed(SEED)
tf.random.set_seed(SEED)

print("TensorFlow:", tf.__version__)
gpus = tf.config.list_physical_devices("GPU")
print("Verfügbare GPUs:", gpus)
if gpus:
    try:
        for gpu in gpus:
            tf.config.experimental.set_memory_growth(gpu, True)
        print("GPU wird verwendet.")
    except RuntimeError as exc:
        print("Konnte Memory Growth nicht setzen:", exc)
else:
    print("WARNUNG: Keine GPU gefunden. TensorFlow läuft auf CPU.")


# =============================================================================
# 1. KONFIGURATION – HIER ANPASSEN
# =============================================================================
@dataclass(frozen=True)
class DatasetConfig:
    root: Path
    positive_dir: str = "images"
    negative_dir: str = "images_512px_hard_negatives"
    weight: float = 1.0


RUN_NAME = "classifier_multi_dataset_optimized"
CRACK_PROJECT_ROOT = Path("/home/mitte/crack_project")
OUTPUT_ROOT = CRACK_PROJECT_ROOT / "output_classifier"
RUN_DIR = OUTPUT_ROOT / RUN_NAME
MODEL_DIR = RUN_DIR / "models"
METRICS_DIR = RUN_DIR / "metrics"
PLOT_DIR = METRICS_DIR / "plots"
ARCH_DIR = RUN_DIR / "architecture"
THRESHOLD_DIR = RUN_DIR / "threshold_results2"

DATASETS: list[DatasetConfig] = [
    DatasetConfig(
        root=CRACK_PROJECT_ROOT / "datasets/better_dataset_evtl",
        positive_dir="images",
        negative_dir="images_512px_hard_negatives",
        weight=1.0,
    ),
    DatasetConfig(
        root=CRACK_PROJECT_ROOT / "datasets/baseline_dataset/uncolored_set",
        positive_dir="images",
        negative_dir="images_512px_hard_negatives",
        weight=1.0,
    ),
]

IMG_SIZE = (512, 512)
BATCH_SIZE = 8

# Schnelle Epochen-Validation: exakt 250 Batches à 8 Bilder (= 2000 Samples).
# Der vollständige Validation-Split wird erst nach dem Training EINMAL für den
# Threshold-Sweep auf dem besten Epochenmodell ausgewertet.
VALIDATION_BATCH_SIZE = 8
VALIDATION_STEPS = 250

# Compute-Speed-Optionen, analog zu den separaten Threshold-/Testskripten.
XLA_JIT = True
MIXED_PRECISION_POLICY = "mixed_float16"
STEPS_PER_EXECUTION = 32
EPOCH_AUC_THRESHOLDS = 101
SAVE_PLOTS_EACH_EPOCH = False
SAVE_EVERY_EPOCH_MODEL = False

PHASE1_EPOCHS = 20
PHASE2_EPOCHS = 20
EPOCHS_TOTAL = PHASE1_EPOCHS + PHASE2_EPOCHS
STEPS_PER_EPOCH = 1000

LR = 1e-4
FINE_TUNE_LR = 1e-5
UNFREEZE_LAST_N = 60
TRAIN_POSITIVE_FRACTION = 0.50

# Fixer Threshold für die Epochenmetriken und die U-Net++-artige Best-Epoch-Auswahl.
TRAINING_METRIC_THRESHOLD = 0.5

# Threshold-Sweep auf Validation. Das Raster ist absichtlich auch im sehr kleinen
# Bereich fein genug und nicht auf 0.05..0.95 beschränkt.
THRESHOLD_LOG_MIN = 1e-6
THRESHOLD_LOG_MAX = 1e-2
THRESHOLD_LOG_POINTS = 1201
THRESHOLD_LOW_FINE_MIN = 1e-6
THRESHOLD_LOW_FINE_MAX = 5e-4
THRESHOLD_LOW_FINE_STEP = 1e-7
THRESHOLD_LINEAR_MIN = 0.001
THRESHOLD_LINEAR_MAX = 0.999
THRESHOLD_LINEAR_STEP = 0.001
THRESHOLD_EXTRA = [0.0, 1.0, 0.9995, 0.9999, 0.99999]
THRESHOLD_ROUND_DECIMALS = 10

# Welcher Validation-Threshold wird als "primär" markiert? Nur dieser eine, auf
# Validation bestimmte Threshold wird am Ende auf dem Testsplit ausgewertet.
PRIMARY_THRESHOLD_SELECTION = "best_f1"

SUPPORTED_SUFFIXES = {".jpg", ".jpeg", ".png", ".bmp", ".tif", ".tiff", ".webp"}
AUTOTUNE = tf.data.AUTOTUNE
EPS = 1e-12

# Globaler Compute-Pfad. Mixed Precision wird vor dem Modellbau gesetzt; der
# finale Sigmoid-Output bleibt im Modell explizit float32.
tf.config.optimizer.set_jit("autoclustering" if XLA_JIT else False)
mixed_precision.set_global_policy(MIXED_PRECISION_POLICY)

# Training-/Run-Dateien
TRAIN_METRICS_TXT_FILE = METRICS_DIR / f"{RUN_NAME}_epoch_metrics.txt"
TRAIN_METRICS_CSV_FILE = METRICS_DIR / f"{RUN_NAME}_epoch_metrics.csv"
TRAIN_METRICS_JSON_FILE = METRICS_DIR / f"{RUN_NAME}_epoch_metrics.json"
RUN_CONFIG_FILE = METRICS_DIR / f"{RUN_NAME}_run_configuration.txt"
DATASET_REPORT_PATH = METRICS_DIR / f"{RUN_NAME}_dataset_report.json"

# Architektur-Dateien wie beim U-Net++ Training.
ARCHITECTURE_TXT_FILE = ARCH_DIR / f"{RUN_NAME}_architecture_detailed.txt"
ARCHITECTURE_JSON_FILE = ARCH_DIR / f"{RUN_NAME}_architecture_config.json"
ARCHITECTURE_KERAS_JSON_FILE = ARCH_DIR / f"{RUN_NAME}_architecture_keras.json"
ARCHITECTURE_PNG_FILE = ARCH_DIR / f"{RUN_NAME}_architecture.png"

# Modelle
BEST_DISTANCE_MODEL_PATH = MODEL_DIR / f"{RUN_NAME}_best_f1_f2_distance.keras"
BEST_PR_AUC_MODEL_PATH = MODEL_DIR / f"{RUN_NAME}_best_pr_auc.keras"
FINAL_MODEL_PATH = MODEL_DIR / f"{RUN_NAME}_final.keras"

# Threshold-Sweep-Dateien
THRESHOLD_TXT_FILE = THRESHOLD_DIR / f"{RUN_NAME}_threshold_search_validation.txt"
THRESHOLD_CSV_FILE = THRESHOLD_DIR / f"{RUN_NAME}_threshold_search_validation.csv"
THRESHOLD_JSON_FILE = THRESHOLD_DIR / f"{RUN_NAME}_threshold_search_validation.json"
THRESHOLD_SELECTED_CSV_FILE = THRESHOLD_DIR / f"{RUN_NAME}_selected_thresholds_validation.csv"

# Testmetriken
TEST_METRICS_TXT_FILE = METRICS_DIR / f"{RUN_NAME}_test_metrics.txt"
TEST_METRICS_CSV_FILE = METRICS_DIR / f"{RUN_NAME}_test_metrics.csv"
TEST_METRICS_JSON_FILE = METRICS_DIR / f"{RUN_NAME}_test_metrics.json"
TEST_FN_TXT_FILE = METRICS_DIR / f"{RUN_NAME}_test_false_negatives.txt"
TEST_FN_CSV_FILE = METRICS_DIR / f"{RUN_NAME}_test_false_negatives.csv"


# =============================================================================
# 2. ALLGEMEINE HILFSFUNKTIONEN
# =============================================================================
def json_safe(value: Any) -> Any:
    if isinstance(value, dict):
        return {str(k): json_safe(v) for k, v in value.items()}
    if isinstance(value, (list, tuple, set)):
        return [json_safe(v) for v in value]
    if isinstance(value, Path):
        return str(value)
    if isinstance(value, np.ndarray):
        return value.tolist()
    if isinstance(value, np.generic):
        return value.item()
    if isinstance(value, datetime):
        return value.isoformat()
    if isinstance(value, float) and not np.isfinite(value):
        return None
    try:
        json.dumps(value)
        return value
    except TypeError:
        return str(value)


def write_json_atomic(path: Path, data: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temp_path = path.with_suffix(path.suffix + ".tmp")
    with temp_path.open("w", encoding="utf-8") as file:
        json.dump(json_safe(data), file, indent=2, ensure_ascii=False, allow_nan=False)
    temp_path.replace(path)


def safe_div(numerator: Any, denominator: Any) -> Any:
    return np.asarray(numerator, dtype=np.float64) / (
        np.asarray(denominator, dtype=np.float64) + EPS
    )


def get_current_learning_rate(model: tf.keras.Model) -> float:
    try:
        lr = model.optimizer.learning_rate
        if callable(lr):
            lr = lr(model.optimizer.iterations)
        return float(tf.keras.backend.get_value(lr))
    except Exception:
        return float("nan")


def create_output_dirs() -> None:
    for directory in (RUN_DIR, MODEL_DIR, METRICS_DIR, PLOT_DIR, ARCH_DIR, THRESHOLD_DIR):
        directory.mkdir(parents=True, exist_ok=True)


# =============================================================================
# 3. DATEIEN UND DATENSATZ
# =============================================================================
def list_image_files(folder: Path) -> list[str]:
    if not folder.exists():
        return []
    return sorted(
        str(path)
        for path in folder.rglob("*")
        if path.is_file() and path.suffix.lower() in SUPPORTED_SUFFIXES
    )


def collect_split_files(
    config: DatasetConfig,
    split: str,
) -> tuple[list[str], list[str]]:
    split_folder_names = {
        "train": "train_512",
        "val": "val_512",
        "test": "test_512",
    }
    if split not in split_folder_names:
        raise ValueError(f"Unbekannter Split '{split}'. Erlaubt: {list(split_folder_names)}")

    split_dir = config.root / split_folder_names[split]
    positive_files = list_image_files(split_dir / config.positive_dir)
    negative_files = list_image_files(split_dir / config.negative_dir)
    return positive_files, negative_files


def validate_dataset_configs(configs: Sequence[DatasetConfig]) -> dict[str, Any]:
    if not configs:
        raise ValueError("DATASETS ist leer. Mindestens ein Datensatz muss angegeben werden.")

    physical_names = {"train": "train_512", "val": "val_512", "test": "test_512"}
    report: dict[str, Any] = {}
    totals = {split: {"positive": 0, "negative": 0} for split in physical_names}

    for cfg in configs:
        if cfg.weight <= 0:
            raise ValueError(f"Dataset-Gewicht muss > 0 sein: {cfg.root}")
        if not cfg.root.exists():
            raise FileNotFoundError(f"Dataset-Pfad nicht gefunden: {cfg.root}")

        root_key = str(cfg.root)
        report[root_key] = {
            "weight": cfg.weight,
            "positive_dir": cfg.positive_dir,
            "negative_dir": cfg.negative_dir,
        }

        for split, physical in physical_names.items():
            pos, neg = collect_split_files(cfg, split)
            report[root_key][physical] = {
                "positive": len(pos),
                "negative": len(neg),
                "total": len(pos) + len(neg),
            }
            totals[split]["positive"] += len(pos)
            totals[split]["negative"] += len(neg)

    for split, physical in physical_names.items():
        pos = totals[split]["positive"]
        neg = totals[split]["negative"]
        if pos == 0 or neg == 0:
            raise ValueError(
                f"Im globalen Split '{physical}' müssen beide Klassen vorhanden sein. "
                f"Gefunden: positiv={pos}, negativ={neg}"
            )

    report["global_totals"] = {
        physical_names[split]: {
            **values,
            "total": values["positive"] + values["negative"],
        }
        for split, values in totals.items()
    }
    write_json_atomic(DATASET_REPORT_PATH, report)

    print("\nGefundene Bilder:")
    for split, values in report["global_totals"].items():
        print(
            f"  {split:10s}: {values['total']:6d} "
            f"(positiv={values['positive']:6d}, negativ={values['negative']:6d})"
        )
    return report


def decode_image(path: tf.Tensor, label: tf.Tensor) -> tuple[tf.Tensor, tf.Tensor]:
    raw = tf.io.read_file(path)
    image = tf.io.decode_image(raw, channels=3, expand_animations=False)
    image.set_shape([None, None, 3])
    image = tf.image.resize(image, IMG_SIZE, method="bilinear", antialias=True)
    image = tf.cast(image, tf.float32) / 255.0
    label = tf.cast(tf.reshape(label, [1]), tf.float32)
    return image, label


def augment(image: tf.Tensor, label: tf.Tensor) -> tuple[tf.Tensor, tf.Tensor]:
    image = tf.image.random_flip_left_right(image)
    image = tf.image.random_flip_up_down(image)
    k = tf.random.uniform([], minval=0, maxval=4, dtype=tf.int32)
    image = tf.image.rot90(image, k=k)
    image = tf.image.random_brightness(image, max_delta=0.10)
    image = tf.image.random_contrast(image, lower=0.80, upper=1.20)
    image = tf.image.random_saturation(image, lower=0.80, upper=1.20)
    image = tf.image.random_hue(image, max_delta=0.02)

    def grayscale() -> tf.Tensor:
        return tf.image.grayscale_to_rgb(tf.image.rgb_to_grayscale(image))

    image = tf.cond(tf.random.uniform([]) < 0.15, grayscale, lambda: image)
    image = tf.cond(
        tf.random.uniform([]) < 0.20,
        lambda: image + tf.random.normal(tf.shape(image), stddev=0.015),
        lambda: image,
    )
    image = tf.clip_by_value(image, 0.0, 1.0)
    return image, label


def make_class_stream(files: Sequence[str], label: float, training: bool) -> tf.data.Dataset:
    if not files:
        raise ValueError(f"Leere Dateiliste für Klasse {label}.")
    labels = np.full(len(files), label, dtype=np.float32)
    ds = tf.data.Dataset.from_tensor_slices((list(files), labels))
    if training:
        ds = ds.shuffle(
            buffer_size=min(max(len(files), 256), 8192),
            seed=SEED,
            reshuffle_each_iteration=True,
        ).repeat()
    ds = ds.map(decode_image, num_parallel_calls=AUTOTUNE, deterministic=not training)
    if training:
        ds = ds.map(augment, num_parallel_calls=AUTOTUNE, deterministic=False)
    return ds


def make_train_dataset(configs: Sequence[DatasetConfig]) -> tf.data.Dataset:
    all_positive: list[str] = []
    all_negative: list[str] = []

    for cfg in configs:
        positive_files, negative_files = collect_split_files(cfg, "train")
        print(
            f"Trainingsquelle {cfg.root}:\n"
            f"  positiv: {len(positive_files)}\n"
            f"  negativ: {len(negative_files)}"
        )
        all_positive.extend(positive_files)
        all_negative.extend(negative_files)

    if not all_positive or not all_negative:
        raise ValueError("Im globalen Trainingspool müssen positive und negative Bilder vorhanden sein.")

    positive_ds = make_class_stream(all_positive, 1.0, training=True)
    negative_ds = make_class_stream(all_negative, 0.0, training=True)
    ds = tf.data.Dataset.sample_from_datasets(
        [positive_ds, negative_ds],
        weights=[TRAIN_POSITIVE_FRACTION, 1.0 - TRAIN_POSITIVE_FRACTION],
        seed=SEED,
        stop_on_empty_dataset=False,
    )
    options = tf.data.Options()
    options.experimental_deterministic = False
    ds = ds.with_options(options)
    return ds.batch(BATCH_SIZE, drop_remainder=True).prefetch(AUTOTUNE)


def make_eval_dataset(
    configs: Sequence[DatasetConfig],
    split: str,
    *,
    batch_size: int = BATCH_SIZE,
    shuffle: bool = False,
    repeat: bool = False,
    deterministic: bool = True,
) -> tuple[tf.data.Dataset, int]:
    """
    Baut einen schnellen Eval-Datensatz.

    Für die Epochen-Validation wird vor dem Decode einmal deterministisch auf
    Dateipfad-Ebene gemischt und anschließend repeat() verwendet. Dadurch kann
    model.fit mit VALIDATION_STEPS exakt 250 Batches auswerten, ohne jedes Mal
    den kompletten Validation-Split zu traversieren.

    Für finalen Threshold-Sweep/Test bleiben shuffle=False, repeat=False und
    deterministic=True, damit jeder Sample exakt einmal und reproduzierbar läuft.
    """
    all_files: list[str] = []
    all_labels: list[float] = []
    for cfg in configs:
        positive, negative = collect_split_files(cfg, split)
        all_files.extend(positive)
        all_labels.extend([1.0] * len(positive))
        all_files.extend(negative)
        all_labels.extend([0.0] * len(negative))

    if not all_files:
        raise ValueError(f"Keine Bilder für Split '{split}' gefunden.")

    labels_array = np.asarray(all_labels, dtype=np.float32)
    if shuffle:
        # Vollständige, einmalige Permutation auf Pfad-Ebene. Das ist günstiger als
        # ein großer tf.data-Shuffle-Buffer und verhindert bei klassenweise
        # angeordneten Dateilisten einen verzerrten 2000-Sample-Ausschnitt.
        order = np.random.default_rng(SEED).permutation(len(all_files))
        all_files = [all_files[int(i)] for i in order]
        labels_array = labels_array[order]

    ds = tf.data.Dataset.from_tensor_slices((all_files, labels_array))
    if repeat:
        ds = ds.repeat()

    options = tf.data.Options()
    options.experimental_deterministic = deterministic
    ds = ds.with_options(options)
    ds = ds.map(
        decode_image,
        num_parallel_calls=AUTOTUNE,
        deterministic=deterministic,
    )
    ds = ds.batch(int(batch_size), drop_remainder=False)
    ds = ds.prefetch(AUTOTUNE)
    return ds, len(all_files)


def collect_eval_file_records(configs: Sequence[DatasetConfig], split: str) -> list[dict[str, Any]]:
    """Liefert exakt dieselbe Dateireihenfolge wie make_eval_dataset, inkl. Label und Datasetquelle."""
    records: list[dict[str, Any]] = []
    for cfg in configs:
        positive, negative = collect_split_files(cfg, split)
        records.extend({
            "image_path": path,
            "label": 1,
            "class_name": "positive",
            "dataset_root": str(cfg.root),
        } for path in positive)
        records.extend({
            "image_path": path,
            "label": 0,
            "class_name": "negative",
            "dataset_root": str(cfg.root),
        } for path in negative)
    return records


# =============================================================================
# 4. METRIKEN FÜR MODEL.FIT
# =============================================================================
@tf.keras.utils.register_keras_serializable(package="CrackClassifier")
class BinaryF1Score(tf.keras.metrics.Metric):
    def __init__(self, name: str = "f1", threshold: float = 0.5, **kwargs):
        super().__init__(name=name, **kwargs)
        self.threshold = float(threshold)
        self.tp = self.add_weight(name="tp", initializer="zeros")
        self.fp = self.add_weight(name="fp", initializer="zeros")
        self.fn = self.add_weight(name="fn", initializer="zeros")

    def update_state(self, y_true, y_pred, sample_weight=None):
        y_true = tf.cast(tf.reshape(y_true, [-1]) >= 0.5, tf.float32)
        y_pred = tf.cast(tf.reshape(y_pred, [-1]) >= self.threshold, tf.float32)
        tp = y_true * y_pred
        fp = (1.0 - y_true) * y_pred
        fn = y_true * (1.0 - y_pred)
        if sample_weight is not None:
            sample_weight = tf.cast(tf.reshape(sample_weight, [-1]), tf.float32)
            tp *= sample_weight
            fp *= sample_weight
            fn *= sample_weight
        self.tp.assign_add(tf.reduce_sum(tp))
        self.fp.assign_add(tf.reduce_sum(fp))
        self.fn.assign_add(tf.reduce_sum(fn))

    def result(self):
        precision = self.tp / (self.tp + self.fp + tf.keras.backend.epsilon())
        recall = self.tp / (self.tp + self.fn + tf.keras.backend.epsilon())
        return 2.0 * precision * recall / (precision + recall + tf.keras.backend.epsilon())

    def reset_state(self):
        self.tp.assign(0.0)
        self.fp.assign(0.0)
        self.fn.assign(0.0)

    def get_config(self):
        config = super().get_config()
        config.update({"threshold": self.threshold})
        return config


@tf.keras.utils.register_keras_serializable(package="CrackClassifier")
class BinaryF2Score(BinaryF1Score):
    def __init__(self, name: str = "f2", threshold: float = 0.5, **kwargs):
        super().__init__(name=name, threshold=threshold, **kwargs)

    def result(self):
        precision = self.tp / (self.tp + self.fp + tf.keras.backend.epsilon())
        recall = self.tp / (self.tp + self.fn + tf.keras.backend.epsilon())
        beta2 = 4.0
        return (1.0 + beta2) * precision * recall / (
            beta2 * precision + recall + tf.keras.backend.epsilon()
        )


# =============================================================================
# 5. MODELL
# =============================================================================
def build_model() -> tuple[tf.keras.Model, tf.keras.Model]:
    backbone = tf.keras.applications.EfficientNetB0(
        include_top=False,
        weights="imagenet",
        input_shape=(*IMG_SIZE, 3),
    )
    backbone.trainable = False

    inputs = tf.keras.Input(shape=(*IMG_SIZE, 3), name="image")
    x = layers.Rescaling(255.0, name="to_efficientnet_range")(inputs)
    x = backbone(x, training=False)
    x = layers.GlobalAveragePooling2D(name="global_average_pooling")(x)
    x = layers.BatchNormalization(name="classifier_batch_norm")(x)
    x = layers.Dropout(0.35, name="dropout_1")(x)
    x = layers.Dense(256, activation="swish", name="classifier_dense")(x)
    x = layers.Dropout(0.25, name="dropout_2")(x)
    outputs = layers.Dense(1, activation="sigmoid", name="crack_probability", dtype="float32")(x)

    model = tf.keras.Model(inputs, outputs, name="EfficientNetB0_CrackClassifier")
    return model, backbone


def compile_model(model: tf.keras.Model, learning_rate: float) -> None:
    model.compile(
        optimizer=tf.keras.optimizers.AdamW(
            learning_rate=learning_rate,
            weight_decay=1e-5,
            clipnorm=1.0,
        ),
        loss=tf.keras.losses.BinaryCrossentropy(label_smoothing=0.02),
        metrics=[
            tf.keras.metrics.BinaryAccuracy(name="accuracy", threshold=TRAINING_METRIC_THRESHOLD),
            tf.keras.metrics.AUC(name="roc_auc", curve="ROC", num_thresholds=EPOCH_AUC_THRESHOLDS),
            tf.keras.metrics.AUC(name="pr_auc", curve="PR", num_thresholds=EPOCH_AUC_THRESHOLDS),
            tf.keras.metrics.Precision(name="precision", thresholds=TRAINING_METRIC_THRESHOLD),
            tf.keras.metrics.Recall(name="recall", thresholds=TRAINING_METRIC_THRESHOLD),
            BinaryF1Score(name="f1", threshold=TRAINING_METRIC_THRESHOLD),
            BinaryF2Score(name="f2", threshold=TRAINING_METRIC_THRESHOLD),
            tf.keras.metrics.TruePositives(name="tp", thresholds=TRAINING_METRIC_THRESHOLD),
            tf.keras.metrics.FalsePositives(name="fp", thresholds=TRAINING_METRIC_THRESHOLD),
            tf.keras.metrics.FalseNegatives(name="fn", thresholds=TRAINING_METRIC_THRESHOLD),
            tf.keras.metrics.TrueNegatives(name="tn", thresholds=TRAINING_METRIC_THRESHOLD),
        ],
        steps_per_execution=STEPS_PER_EXECUTION,
        jit_compile=XLA_JIT,
    )


def configure_fine_tuning(backbone: tf.keras.Model, unfreeze_last_n: int) -> None:
    backbone.trainable = True
    cutoff = max(0, len(backbone.layers) - unfreeze_last_n)
    for index, layer in enumerate(backbone.layers):
        layer.trainable = index >= cutoff and not isinstance(layer, layers.BatchNormalization)
    trainable_count = sum(layer.trainable for layer in backbone.layers)
    print(
        f"Fine-Tuning: {trainable_count}/{len(backbone.layers)} Backbone-Layer trainierbar "
        "(BatchNormalization bleibt eingefroren)."
    )


# =============================================================================
# 6. ARCHITEKTUR-LOGGING WIE IM U-NET++ TRAINING
# =============================================================================
def tensor_shape_string(tensor_or_tensors: Any) -> str:
    try:
        if isinstance(tensor_or_tensors, (list, tuple)):
            return "[" + ", ".join(str(t.shape) for t in tensor_or_tensors) + "]"
        return str(tensor_or_tensors.shape)
    except Exception:
        return "nicht verfügbar"


def flatten_tensors(tensors: Any) -> list[Any]:
    if isinstance(tensors, (list, tuple)):
        result: list[Any] = []
        for item in tensors:
            result.extend(flatten_tensors(item))
        return result
    return [tensors]


def keras_tensor_source(tensor: Any) -> str:
    try:
        history = getattr(tensor, "_keras_history", None)
        if history is None:
            return "unbekannt"
        operation = getattr(history, "operation", None)
        node_index = getattr(history, "node_index", None)
        tensor_index = getattr(history, "tensor_index", None)
        if operation is None and isinstance(history, (tuple, list)) and history:
            operation = history[0]
            node_index = history[1] if len(history) > 1 else None
            tensor_index = history[2] if len(history) > 2 else None
        return f"{getattr(operation, 'name', str(operation))}[node={node_index}, tensor={tensor_index}]"
    except Exception as exc:
        return f"unbekannt ({exc})"


def iter_layers_recursive(
    model: tf.keras.Model,
    prefix: str = "",
) -> Iterable[tuple[str, tf.keras.layers.Layer]]:
    for index, layer in enumerate(model.layers):
        path = f"{prefix}{index:03d}:{layer.name}"
        yield path, layer
        if isinstance(layer, tf.keras.Model):
            yield from iter_layers_recursive(layer, prefix=path + "/")


def write_model_summary(file, model: tf.keras.Model, title: str) -> None:
    file.write("=" * 200 + "\n")
    file.write(title + "\n")
    file.write("=" * 200 + "\n\n")
    model.summary(
        expand_nested=True,
        line_length=200,
        print_fn=lambda line: file.write(line + "\n"),
    )
    file.write("\n\n")


def export_architecture(model: tf.keras.Model) -> dict[str, Any]:
    ARCH_DIR.mkdir(parents=True, exist_ok=True)
    write_json_atomic(ARCHITECTURE_JSON_FILE, model.get_config())
    ARCHITECTURE_KERAS_JSON_FILE.write_text(model.to_json(), encoding="utf-8")

    all_layers = list(iter_layers_recursive(model))
    nested_models = [
        (path, layer)
        for path, layer in all_layers
        if isinstance(layer, tf.keras.Model) and layer is not model
    ]

    with ARCHITECTURE_TXT_FILE.open("w", encoding="utf-8") as file:
        file.write(f"Run: {RUN_NAME}\n")
        file.write("Architecture: EfficientNetB0 Crack Classifier\n")
        file.write(f"Input: ({IMG_SIZE[0]}, {IMG_SIZE[1]}, 3)\n")
        file.write("Output: binäre Risswahrscheinlichkeit, Sigmoid, 1 Wert pro Bild\n")
        file.write("Backbone: EfficientNetB0, ImageNet pre-trained\n")
        file.write("Classifier head: GAP -> BatchNorm -> Dropout(0.35) -> Dense(256, swish) -> Dropout(0.25) -> Dense(1, sigmoid)\n")
        file.write(f"Phase 1 epochs: {PHASE1_EPOCHS}\n")
        file.write(f"Phase 2 epochs: {PHASE2_EPOCHS}\n")
        file.write(f"Unfreeze last N backbone layers: {UNFREEZE_LAST_N}\n")
        file.write(f"Training positive fraction: {TRAIN_POSITIVE_FRACTION}\n")
        file.write(f"Gesamtparameter: {model.count_params():,}\n")
        file.write(f"Rekursiv gefundene Layer: {len(all_layers)}\n")
        file.write(f"Nested models: {len(nested_models)}\n\n")

        write_model_summary(file, model, "1. VOLLSTÄNDIGE MODELLZUSAMMENFASSUNG")
        for nested_index, (path, nested_model) in enumerate(nested_models, start=1):
            write_model_summary(
                file,
                nested_model,
                f"2.{nested_index} DETAILLIERTE SUMMARY DES INNEREN MODELLS: {path}",
            )

        file.write("=" * 200 + "\n")
        file.write("3. REKURSIVE LAYERLISTE MIT INPUT-/OUTPUTQUELLEN\n")
        file.write("=" * 200 + "\n\n")
        for path, layer in all_layers:
            try:
                layer_input = layer.input
            except Exception:
                layer_input = None
            try:
                layer_output = layer.output
            except Exception:
                layer_output = None
            input_tensors = flatten_tensors(layer_input) if layer_input is not None else []
            input_sources = [keras_tensor_source(tensor) for tensor in input_tensors]
            try:
                parameters = int(layer.count_params())
            except Exception:
                parameters = -1
            file.write(f"Pfad: {path}\n")
            file.write(f"  Klasse: {layer.__class__.__name__}\n")
            file.write(f"  Trainable: {layer.trainable}\n")
            file.write(f"  dtype: {getattr(layer, 'dtype', 'nicht verfügbar')}\n")
            file.write(f"  Parameter: {parameters}\n")
            file.write(f"  Input shape: {tensor_shape_string(layer_input)}\n")
            file.write(f"  Output shape: {tensor_shape_string(layer_output)}\n")
            file.write(f"  Input-Quellen: {input_sources}\n")
            try:
                file.write(
                    "  Konfiguration: "
                    + json.dumps(json_safe(layer.get_config()), ensure_ascii=False, sort_keys=True)
                    + "\n"
                )
            except Exception as exc:
                file.write(f"  Konfiguration nicht verfügbar: {exc}\n")
            file.write("\n")

        file.write("=" * 200 + "\n")
        file.write("4. VOLLSTÄNDIGE MODELLKONFIGURATION ALS JSON\n")
        file.write("=" * 200 + "\n\n")
        json.dump(json_safe(model.get_config()), file, indent=2, ensure_ascii=False)
        file.write("\n")

    plot_error = None
    try:
        plot_model(
            model,
            to_file=str(ARCHITECTURE_PNG_FILE),
            show_shapes=True,
            show_layer_names=True,
            expand_nested=True,
            dpi=200,
            rankdir="TB",
        )
    except Exception as exc:
        plot_error = str(exc)
        (ARCH_DIR / f"{RUN_NAME}_architecture_plot_error.txt").write_text(
            "Die PNG-Architektur konnte nicht erstellt werden.\n"
            f"Fehler: {exc}\n"
            "Prüfe insbesondere pydot und Graphviz.\n",
            encoding="utf-8",
        )

    return {
        "total_parameters": int(model.count_params()),
        "recursive_layer_count": len(all_layers),
        "nested_model_count": len(nested_models),
        "architecture_txt": str(ARCHITECTURE_TXT_FILE),
        "architecture_json": str(ARCHITECTURE_JSON_FILE),
        "architecture_keras_json": str(ARCHITECTURE_KERAS_JSON_FILE),
        "architecture_png": str(ARCHITECTURE_PNG_FILE),
        "plot_error": plot_error,
    }


# =============================================================================
# 7. INFERENZ UND METRIKEN
# =============================================================================
def build_inference_function(model: tf.keras.Model, jit_compile: bool = XLA_JIT):
    """Direkter, optional XLA-kompilierter Inferenzpfad für finale Val/Test-Läufe."""

    @tf.function(jit_compile=jit_compile, reduce_retracing=True)
    def infer(images: tf.Tensor) -> tf.Tensor:
        return model(images, training=False)

    return infer


def collect_predictions(
    model: tf.keras.Model,
    dataset: tf.data.Dataset,
) -> tuple[np.ndarray, np.ndarray]:
    labels: list[np.ndarray] = []
    predictions: list[np.ndarray] = []
    inference_fn = build_inference_function(model, jit_compile=XLA_JIT)
    xla_failed = False

    for images, batch_labels in dataset:
        try:
            batch_predictions = inference_fn(images)
        except Exception as exc:
            if XLA_JIT and not xla_failed:
                print(
                    "\n[WARNUNG] XLA-Inferenz fehlgeschlagen; "
                    f"Fallback auf tf.function ohne XLA: {exc}"
                )
                inference_fn = build_inference_function(model, jit_compile=False)
                xla_failed = True
                batch_predictions = inference_fn(images)
            else:
                raise

        batch_predictions = tf.cast(batch_predictions, tf.float32)
        predictions.append(batch_predictions.numpy().reshape(-1))
        labels.append(batch_labels.numpy().reshape(-1))

    y_true = np.concatenate(labels).astype(np.int32, copy=False)
    probabilities = np.concatenate(predictions).astype(np.float32, copy=False)
    probabilities = np.clip(probabilities, 0.0, 1.0)
    return y_true, probabilities


def confusion_metrics(
    tp: Any,
    fp: Any,
    fn: Any,
    tn: Any,
) -> dict[str, Any]:
    precision = safe_div(tp, np.asarray(tp) + np.asarray(fp))
    recall = safe_div(tp, np.asarray(tp) + np.asarray(fn))
    specificity = safe_div(tn, np.asarray(tn) + np.asarray(fp))
    f1 = safe_div(2.0 * precision * recall, precision + recall)
    # Bei binärer Bildklassifikation ist Dice der positiven Klasse identisch zu F1.
    dice = safe_div(2.0 * np.asarray(tp), 2.0 * np.asarray(tp) + np.asarray(fp) + np.asarray(fn))
    iou = safe_div(np.asarray(tp), np.asarray(tp) + np.asarray(fp) + np.asarray(fn))
    beta2 = 4.0
    f2 = safe_div((1.0 + beta2) * precision * recall, beta2 * precision + recall)
    accuracy = safe_div(np.asarray(tp) + np.asarray(tn), np.asarray(tp) + np.asarray(tn) + np.asarray(fp) + np.asarray(fn))
    fpr = safe_div(fp, np.asarray(fp) + np.asarray(tn))
    fnr = safe_div(fn, np.asarray(fn) + np.asarray(tp))
    balanced_error = 0.5 * (fpr + fnr)
    balanced_accuracy = 1.0 - balanced_error
    selection_distance = np.sqrt(0.5 * (1.0 - f1) ** 2 + 0.5 * (1.0 - f2) ** 2)
    return {
        "accuracy": accuracy,
        "precision": precision,
        "recall": recall,
        "specificity": specificity,
        "dice": dice,
        "iou": iou,
        "f1": f1,
        "f2": f2,
        "fpr": fpr,
        "fnr": fnr,
        "balanced_error": balanced_error,
        "balanced_accuracy": balanced_accuracy,
        "selection_distance": selection_distance,
    }


def binary_metrics(y_true: np.ndarray, probabilities: np.ndarray, threshold: float) -> dict[str, Any]:
    y_true = np.asarray(y_true, dtype=np.int32).reshape(-1)
    probabilities = np.asarray(probabilities, dtype=np.float64).reshape(-1)
    y_pred = probabilities >= float(threshold)
    true = y_true == 1
    tp = int(np.sum(true & y_pred))
    fp = int(np.sum((~true) & y_pred))
    fn = int(np.sum(true & (~y_pred)))
    tn = int(np.sum((~true) & (~y_pred)))
    derived = confusion_metrics(tp, fp, fn, tn)
    result = {
        "threshold": float(threshold),
        "tp": tp,
        "fp": fp,
        "fn": fn,
        "tn": tn,
    }
    result.update({key: float(value) for key, value in derived.items()})
    return result


def compute_average_precision(y_true: np.ndarray, probabilities: np.ndarray) -> float:
    y_true = np.asarray(y_true, dtype=np.int32).reshape(-1)
    probabilities = np.asarray(probabilities, dtype=np.float64).reshape(-1)
    total_pos = int(np.sum(y_true == 1))
    if total_pos == 0:
        return float("nan")

    order = np.argsort(-probabilities, kind="stable")
    labels = (y_true[order] == 1).astype(np.int64)
    tp = np.cumsum(labels)
    fp = np.cumsum(1 - labels)
    precision = tp / np.maximum(tp + fp, 1)
    recall = tp / total_pos

    # AP mit monotoner Precision-Hülle analog zum U-Net++/Testcode.
    recall_ext = np.concatenate(([0.0], recall, [1.0]))
    precision_ext = np.concatenate(([1.0], precision, [0.0]))
    for i in range(len(precision_ext) - 2, -1, -1):
        precision_ext[i] = max(precision_ext[i], precision_ext[i + 1])
    changes = np.where(recall_ext[1:] != recall_ext[:-1])[0]
    return float(np.sum(
        (recall_ext[changes + 1] - recall_ext[changes]) * precision_ext[changes + 1]
    ))


def compute_curve_aucs(y_true: np.ndarray, probabilities: np.ndarray) -> tuple[float, float]:
    y_true = np.asarray(y_true, dtype=np.int32).reshape(-1)
    probabilities = np.asarray(probabilities, dtype=np.float64).reshape(-1)
    total_pos = int(np.sum(y_true == 1))
    total_neg = int(np.sum(y_true == 0))
    if total_pos == 0 or total_neg == 0:
        return float("nan"), float("nan")

    order = np.argsort(-probabilities, kind="stable")
    labels = (y_true[order] == 1).astype(np.int64)
    tp = np.cumsum(labels).astype(np.float64)
    fp = np.cumsum(1 - labels).astype(np.float64)
    tpr = tp / total_pos
    fpr = fp / total_neg
    roc_auc = float(np.trapezoid(np.concatenate(([0.0], tpr, [1.0])), np.concatenate(([0.0], fpr, [1.0]))))

    precision = tp / np.maximum(tp + fp, 1.0)
    recall = tpr
    pr_auc = float(np.trapezoid(np.concatenate(([1.0], precision, [0.0])), np.concatenate(([0.0], recall, [1.0]))))
    return roc_auc, pr_auc


def probability_metrics(y_true: np.ndarray, probabilities: np.ndarray) -> dict[str, float]:
    y_true = np.asarray(y_true, dtype=np.float32).reshape(-1, 1)
    probabilities = np.asarray(probabilities, dtype=np.float32).reshape(-1, 1)
    loss_fn = tf.keras.losses.BinaryCrossentropy(label_smoothing=0.02)
    loss = float(loss_fn(y_true, probabilities).numpy())
    ap = compute_average_precision(y_true.reshape(-1), probabilities.reshape(-1))
    roc_auc, pr_auc = compute_curve_aucs(y_true.reshape(-1), probabilities.reshape(-1))
    return {
        "loss": loss,
        "ap": ap,
        "roc_auc": roc_auc,
        "pr_auc": pr_auc,
    }


def evaluate_at_threshold(y_true: np.ndarray, probabilities: np.ndarray, threshold: float) -> dict[str, Any]:
    result = binary_metrics(y_true, probabilities, threshold)
    result.update(probability_metrics(y_true, probabilities))
    return result


# =============================================================================
# 8. TRAINING-/VALIDATION-LOGGER IM STIL DES U-NET++ TRAININGS
# =============================================================================
TRAIN_FIELDNAMES = [
    "epoch",
    "phase",
    "learning_rate",
    "train_loss",
    "val_loss",
    "train_accuracy",
    "train_precision",
    "train_recall",
    "train_f1",
    "train_f2",
    "train_roc_auc",
    "train_pr_auc",
    "val_accuracy",
    "val_dice",
    "val_iou",
    "val_precision",
    "val_recall",
    "val_f1",
    "val_f2",
    "val_balanced_error",
    "val_balanced_accuracy",
    "val_fpr",
    "val_fnr",
    "val_ap",
    "val_roc_auc",
    "val_pr_auc",
    "val_tp",
    "val_fp",
    "val_fn",
    "val_tn",
    "val_selection_distance",
]


def save_training_plots(history_rows: list[dict[str, Any]]) -> None:
    if not history_rows:
        return
    PLOT_DIR.mkdir(parents=True, exist_ok=True)
    epochs = [int(row["epoch"]) for row in history_rows]

    def plot_fields(fields: list[str], filename: str, ylabel: str) -> None:
        plt.figure(figsize=(10, 6))
        for field in fields:
            values = [row.get(field, np.nan) for row in history_rows]
            plt.plot(epochs, values, label=field)
        plt.xlabel("Epoch")
        plt.ylabel(ylabel)
        plt.grid(True, alpha=0.3)
        plt.legend()
        plt.tight_layout()
        plt.savefig(PLOT_DIR / filename, dpi=160)
        plt.close()

    plot_fields(["train_loss", "val_loss"], "loss_curve.png", "Loss")
    plot_fields(["val_accuracy", "val_dice", "val_iou", "val_precision", "val_recall", "val_f1", "val_f2"], "classification_metrics_curve.png", "Metric")
    plot_fields(["val_balanced_accuracy", "val_balanced_error", "val_fpr", "val_fnr"], "balanced_error_accuracy_fpr_fnr_curve.png", "Metric")
    plot_fields(["val_ap", "val_roc_auc", "val_pr_auc"], "ap_auc_curve.png", "Metric")
    plot_fields(["val_selection_distance"], "selection_distance_curve.png", "D (lower is better)")


class ValidationMetricsLogger(tf.keras.callbacks.Callback):
    """Logging/Best-Epoch-Auswahl ohne zusätzliche Validation-Inferenz."""

    def __init__(self, run_metadata: dict[str, Any]):
        super().__init__()
        self.run_metadata = run_metadata
        self.epoch_history: list[dict[str, Any]] = []
        self.best_epoch: int | None = None
        self.best_selection_distance = float("inf")
        self.initialized = False

    def on_train_begin(self, logs=None):
        if self.initialized:
            return
        self.initialized = True
        METRICS_DIR.mkdir(parents=True, exist_ok=True)
        with TRAIN_METRICS_CSV_FILE.open("w", encoding="utf-8", newline="") as file:
            csv.DictWriter(file, fieldnames=TRAIN_FIELDNAMES).writeheader()
        with TRAIN_METRICS_TXT_FILE.open("w", encoding="utf-8") as file:
            file.write(f"Run: {RUN_NAME}\n")
            file.write(f"Output: {RUN_DIR}\n")
            file.write(f"Training metric threshold: {TRAINING_METRIC_THRESHOLD}\n")
            file.write(
                f"Epoch validation: {VALIDATION_STEPS} steps x batch {VALIDATION_BATCH_SIZE} = "
                f"{VALIDATION_STEPS * VALIDATION_BATCH_SIZE} samples.\n"
            )
            file.write(
                "Best-epoch selection: D = sqrt(0.5*(1-F1)^2 + 0.5*(1-F2)^2), lower is better.\n"
            )
            file.write(
                "Kein zweiter Validation-Inferenzlauf im Callback; alle val_* Epochenmetriken "
                "stammen direkt aus model.fit.\n"
            )
            file.write(
                "val_ap wird pro Epoche aus Speed-Gründen nicht separat berechnet (NaN); "
                "im finalen vollständigen Validation-Lauf wird AP exakt aus den Predictions berechnet.\n"
            )
            file.write("=" * 180 + "\n")
            file.write("\t".join(TRAIN_FIELDNAMES) + "\n")
        self._write_json("initialized")

    def _write_json(self, status: str) -> None:
        payload = {
            "status": status,
            "run_name": RUN_NAME,
            "training_metric_threshold": TRAINING_METRIC_THRESHOLD,
            "epoch_validation_steps": VALIDATION_STEPS,
            "epoch_validation_batch_size": VALIDATION_BATCH_SIZE,
            "best_epoch": self.best_epoch,
            "best_selection_distance": None if not np.isfinite(self.best_selection_distance) else self.best_selection_distance,
            "best_model": str(BEST_DISTANCE_MODEL_PATH),
            "metadata": self.run_metadata,
            "history": self.epoch_history,
        }
        write_json_atomic(TRAIN_METRICS_JSON_FILE, payload)

    @staticmethod
    def _log_float(logs: dict[str, Any], key: str, default: float = float("nan")) -> float:
        value = logs.get(key, default)
        try:
            return float(value)
        except (TypeError, ValueError):
            return float(default)

    def on_epoch_end(self, epoch, logs=None):
        logs = logs or {}
        tp = int(round(self._log_float(logs, "val_tp", 0.0)))
        fp = int(round(self._log_float(logs, "val_fp", 0.0)))
        fn = int(round(self._log_float(logs, "val_fn", 0.0)))
        tn = int(round(self._log_float(logs, "val_tn", 0.0)))
        derived = confusion_metrics(tp, fp, fn, tn)

        val_f1 = self._log_float(logs, "val_f1", float(derived["f1"]))
        val_f2 = self._log_float(logs, "val_f2", float(derived["f2"]))
        selection_distance = float(
            np.sqrt(0.5 * (1.0 - val_f1) ** 2 + 0.5 * (1.0 - val_f2) ** 2)
        )
        val_pr_auc = self._log_float(logs, "val_pr_auc")

        row = {
            "epoch": int(epoch + 1),
            "phase": 1 if int(epoch + 1) <= PHASE1_EPOCHS else 2,
            "learning_rate": get_current_learning_rate(self.model),
            "train_loss": self._log_float(logs, "loss"),
            "val_loss": self._log_float(logs, "val_loss"),
            "train_accuracy": self._log_float(logs, "accuracy"),
            "train_precision": self._log_float(logs, "precision"),
            "train_recall": self._log_float(logs, "recall"),
            "train_f1": self._log_float(logs, "f1"),
            "train_f2": self._log_float(logs, "f2"),
            "train_roc_auc": self._log_float(logs, "roc_auc"),
            "train_pr_auc": self._log_float(logs, "pr_auc"),
            "val_accuracy": self._log_float(logs, "val_accuracy", float(derived["accuracy"])),
            "val_dice": val_f1,
            "val_iou": float(derived["iou"]),
            "val_precision": self._log_float(logs, "val_precision", float(derived["precision"])),
            "val_recall": self._log_float(logs, "val_recall", float(derived["recall"])),
            "val_f1": val_f1,
            "val_f2": val_f2,
            "val_balanced_error": float(derived["balanced_error"]),
            "val_balanced_accuracy": float(derived["balanced_accuracy"]),
            "val_fpr": float(derived["fpr"]),
            "val_fnr": float(derived["fnr"]),
            "val_ap": float("nan"),
            "val_roc_auc": self._log_float(logs, "val_roc_auc"),
            "val_pr_auc": val_pr_auc,
            "val_tp": tp,
            "val_fp": fp,
            "val_fn": fn,
            "val_tn": tn,
            "val_selection_distance": selection_distance,
        }
        self.epoch_history.append(row)

        logs["val_f1_full"] = row["val_f1"]
        logs["val_f2_full"] = row["val_f2"]
        logs["val_balanced_error_full"] = row["val_balanced_error"]
        logs["val_selection_distance"] = row["val_selection_distance"]

        if row["val_selection_distance"] < self.best_selection_distance:
            self.best_selection_distance = row["val_selection_distance"]
            self.best_epoch = row["epoch"]
            self.model.save(BEST_DISTANCE_MODEL_PATH)

        with TRAIN_METRICS_CSV_FILE.open("a", encoding="utf-8", newline="") as file:
            csv.DictWriter(file, fieldnames=TRAIN_FIELDNAMES).writerow(row)
        with TRAIN_METRICS_TXT_FILE.open("a", encoding="utf-8") as file:
            values = []
            for field in TRAIN_FIELDNAMES:
                value = row[field]
                values.append(f"{value:.8f}" if isinstance(value, float) else str(value))
            file.write("\t".join(values) + "\n")

        self._write_json("training")
        if SAVE_PLOTS_EACH_EPOCH:
            save_training_plots(self.epoch_history)

        print(
            "\n[Fast Validation] "
            f"{VALIDATION_STEPS}x{VALIDATION_BATCH_SIZE} | "
            f"F1={row['val_f1']:.6f} | IoU={row['val_iou']:.6f} | "
            f"F2={row['val_f2']:.6f} | Recall={row['val_recall']:.6f} | "
            f"BalErr={row['val_balanced_error']:.6f} | "
            f"PR-AUC={row['val_pr_auc']:.6f} | D={row['val_selection_distance']:.6f}"
        )

    def finalize(self) -> None:
        self._write_json("completed")
        with TRAIN_METRICS_TXT_FILE.open("a", encoding="utf-8") as file:
            file.write("\n" + "=" * 180 + "\n")
            file.write(f"Best epoch: {self.best_epoch}\n")
            file.write(f"Best val selection distance: {self.best_selection_distance:.8f}\n")
            file.write(f"Best model: {BEST_DISTANCE_MODEL_PATH}\n")
        save_training_plots(self.epoch_history)


# =============================================================================
# 9. THRESHOLD-SWEEP AUF VALIDATION
# =============================================================================
def build_threshold_grid() -> np.ndarray:
    log_grid = np.geomspace(THRESHOLD_LOG_MIN, THRESHOLD_LOG_MAX, THRESHOLD_LOG_POINTS)
    low_fine_grid = np.arange(
        THRESHOLD_LOW_FINE_MIN,
        THRESHOLD_LOW_FINE_MAX + THRESHOLD_LOW_FINE_STEP / 2.0,
        THRESHOLD_LOW_FINE_STEP,
        dtype=np.float64,
    )
    linear_grid = np.arange(
        THRESHOLD_LINEAR_MIN,
        THRESHOLD_LINEAR_MAX + THRESHOLD_LINEAR_STEP / 2.0,
        THRESHOLD_LINEAR_STEP,
        dtype=np.float64,
    )
    thresholds = np.concatenate((log_grid, low_fine_grid, linear_grid, np.asarray(THRESHOLD_EXTRA, dtype=np.float64)))
    thresholds = np.clip(thresholds, 0.0, 1.0)
    thresholds = np.unique(np.round(thresholds, THRESHOLD_ROUND_DECIMALS))
    return thresholds.astype(np.float64)


def threshold_metrics_vectorized(
    y_true: np.ndarray,
    probabilities: np.ndarray,
    thresholds: np.ndarray,
) -> dict[str, np.ndarray]:
    y_true = np.asarray(y_true, dtype=np.int32).reshape(-1)
    probabilities = np.asarray(probabilities, dtype=np.float64).reshape(-1)
    thresholds = np.asarray(thresholds, dtype=np.float64)

    order = np.argsort(probabilities, kind="stable")
    probs_sorted = probabilities[order]
    labels_sorted = (y_true[order] == 1).astype(np.int64)
    pos_prefix = np.concatenate(([0], np.cumsum(labels_sorted, dtype=np.int64)))
    neg_prefix = np.concatenate(([0], np.cumsum(1 - labels_sorted, dtype=np.int64)))

    idx = np.searchsorted(probs_sorted, thresholds, side="left")
    fn = pos_prefix[idx]
    tn = neg_prefix[idx]
    total_pos = int(pos_prefix[-1])
    total_neg = int(neg_prefix[-1])
    tp = total_pos - fn
    fp = total_neg - tn
    derived = confusion_metrics(tp, fp, fn, tn)

    return {
        "threshold": thresholds,
        "tp": tp,
        "fp": fp,
        "fn": fn,
        "tn": tn,
        **derived,
    }


def threshold_row(metrics: dict[str, np.ndarray], index: int) -> dict[str, Any]:
    row: dict[str, Any] = {}
    for key, values in metrics.items():
        value = values[index]
        if key in {"tp", "fp", "fn", "tn"}:
            row[key] = int(value)
        else:
            row[key] = float(value)
    return row


def select_threshold_recommendations(metrics: dict[str, np.ndarray]) -> dict[str, dict[str, Any]]:
    n = len(metrics["threshold"])
    indices = np.arange(n)

    # "Optimal" = bestes F1. Zusätzliche Empfehlungen bleiben separat erhalten.
    best_f1_idx = int(np.lexsort((
        -metrics["threshold"],
        -metrics["precision"],
        -metrics["recall"],
        -metrics["f2"],
        -metrics["f1"],
    ))[0])

    best_f2_idx = int(np.lexsort((
        -metrics["threshold"],
        -metrics["precision"],
        -metrics["recall"],
        -metrics["f2"],
    ))[0])

    # Maximaler Recall; bei Gleichstand wird die praktisch sinnvollere Variante
    # mit höherer Precision/F2 und danach höherem Threshold genommen.
    best_recall_idx = int(np.lexsort((
        -metrics["threshold"],
        -metrics["f2"],
        -metrics["precision"],
        -metrics["recall"],
    ))[0])

    best_balerr_idx = int(np.lexsort((
        np.abs(metrics["fpr"] - metrics["fnr"]),
        -metrics["f1"],
        -metrics["f2"],
        metrics["balanced_error"],
    ))[0])

    best_distance_idx = int(np.lexsort((
        -metrics["f2"],
        -metrics["f1"],
        metrics["selection_distance"],
    ))[0])

    _ = indices  # explizit: n wird für Validierung berechnet; lexsort liefert gültige Indizes.
    return {
        "best_f1": threshold_row(metrics, best_f1_idx),
        "best_f2": threshold_row(metrics, best_f2_idx),
        "best_recall": threshold_row(metrics, best_recall_idx),
        "best_balanced_error": threshold_row(metrics, best_balerr_idx),
        "best_f1_f2_distance": threshold_row(metrics, best_distance_idx),
    }


def save_threshold_sweep(
    y_val: np.ndarray,
    p_val: np.ndarray,
) -> dict[str, dict[str, Any]]:
    THRESHOLD_DIR.mkdir(parents=True, exist_ok=True)
    thresholds = build_threshold_grid()
    metrics = threshold_metrics_vectorized(y_val, p_val, thresholds)
    recommendations = select_threshold_recommendations(metrics)
    probability_info = probability_metrics(y_val, p_val)

    fields = [
        "threshold", "tp", "fp", "fn", "tn", "accuracy", "dice", "iou", "precision", "recall",
        "specificity", "f1", "f2", "fpr", "fnr", "balanced_error",
        "balanced_accuracy", "selection_distance",
    ]

    with THRESHOLD_CSV_FILE.open("w", encoding="utf-8", newline="") as file:
        writer = csv.DictWriter(file, fieldnames=fields)
        writer.writeheader()
        for i in range(len(thresholds)):
            writer.writerow({k: threshold_row(metrics, i)[k] for k in fields})

    selected_rows = []
    for selection_name, row in recommendations.items():
        selected_rows.append({"selection": selection_name, **row})
    with THRESHOLD_SELECTED_CSV_FILE.open("w", encoding="utf-8", newline="") as file:
        writer = csv.DictWriter(file, fieldnames=["selection", *fields])
        writer.writeheader()
        writer.writerows(selected_rows)

    payload = {
        "run_name": RUN_NAME,
        "created_at": datetime.now().astimezone().isoformat(),
        "selection_split": "validation",
        "validation_image_count": int(len(y_val)),
        "threshold_grid": {
            "count": int(len(thresholds)),
            "min": float(thresholds.min()),
            "max": float(thresholds.max()),
            "log_min": THRESHOLD_LOG_MIN,
            "log_max": THRESHOLD_LOG_MAX,
            "log_points": THRESHOLD_LOG_POINTS,
            "low_fine_min": THRESHOLD_LOW_FINE_MIN,
            "low_fine_max": THRESHOLD_LOW_FINE_MAX,
            "low_fine_step": THRESHOLD_LOW_FINE_STEP,
            "linear_step": THRESHOLD_LINEAR_STEP,
        },
        "threshold_independent_validation_metrics": probability_info,
        "primary_selection": PRIMARY_THRESHOLD_SELECTION,
        "recommendations": recommendations,
        "all_thresholds": [threshold_row(metrics, i) for i in range(len(thresholds))],
    }
    write_json_atomic(THRESHOLD_JSON_FILE, payload)

    with THRESHOLD_TXT_FILE.open("w", encoding="utf-8") as file:
        file.write("=" * 140 + "\n")
        file.write("CLASSIFIER THRESHOLD-SWEEP AUF VALIDATION\n")
        file.write("=" * 140 + "\n")
        file.write("WICHTIG: Der Testsplit wurde nicht zur Threshold-Auswahl verwendet.\n")
        file.write(f"Run: {RUN_NAME}\n")
        file.write(f"Validation images: {len(y_val)}\n")
        file.write(f"Thresholds getestet: {len(thresholds)}\n")
        file.write(f"Validation AP: {probability_info['ap']:.8f}\n")
        file.write(f"Validation ROC AUC: {probability_info['roc_auc']:.8f}\n")
        file.write(f"Validation PR AUC: {probability_info['pr_auc']:.8f}\n\n")

        file.write("=" * 140 + "\n")
        file.write("FINALE THRESHOLD-EMPFEHLUNGEN\n")
        file.write("=" * 140 + "\n")

        labels = [
            ("best_f1", "1. Optimaler Threshold (max F1)"),
            ("best_f2", "2. Optimaler Threshold nach F2"),
            ("best_recall", "3. Optimaler Threshold nach Recall"),
            ("best_balanced_error", "4. Optimaler Threshold nach minimalem Balanced Error"),
            ("best_f1_f2_distance", "5. Optimaler Threshold nach F1/F2-Idealpunkt-Distanz D"),
        ]
        for key, label in labels:
            row = recommendations[key]
            file.write(
                f"{label}: Threshold = {row['threshold']:.10g} "
                f"(F1={row['f1']:.6f}, F2={row['f2']:.6f}, Recall={row['recall']:.6f}, "
                f"Precision={row['precision']:.6f}, BalError={row['balanced_error']:.6f}, "
                f"FPR={row['fpr']:.6f}, FNR={row['fnr']:.6f}, D={row['selection_distance']:.6f})\n"
            )

        file.write(f"\nPrimäre Auswahl für den Run: {PRIMARY_THRESHOLD_SELECTION}\n")
        file.write(
            f"Primärer Threshold: {recommendations[PRIMARY_THRESHOLD_SELECTION]['threshold']:.10g}\n\n"
        )
        file.write("=" * 140 + "\n")
        file.write("ALLE THRESHOLD-STEPS\n")
        file.write("=" * 140 + "\n")
        file.write("\t".join(fields) + "\n")
        for i in range(len(thresholds)):
            row = threshold_row(metrics, i)
            values = []
            for field_name in fields:
                value = row[field_name]
                if isinstance(value, float):
                    values.append(f"{value:.10g}" if field_name == "threshold" else f"{value:.8f}")
                else:
                    values.append(str(value))
            file.write("\t".join(values) + "\n")

    return recommendations


# =============================================================================
# 10. TESTAUSWERTUNG MIT EINEM FESTEN VALIDATION-THRESHOLD
# =============================================================================
TEST_FIELDS = [
    "selection", "threshold", "is_primary", "loss", "accuracy", "dice", "iou", "precision", "recall",
    "specificity", "f1", "f2", "balanced_error", "balanced_accuracy", "fpr", "fnr",
    "ap", "roc_auc", "pr_auc", "tp", "fp", "fn", "tn", "selection_distance",
]


def save_test_metrics(
    y_test: np.ndarray,
    p_test: np.ndarray,
    recommendations: dict[str, dict[str, Any]],
) -> list[dict[str, Any]]:
    METRICS_DIR.mkdir(parents=True, exist_ok=True)
    evaluations: list[dict[str, Any]] = []

    # Test wird genau EINMAL mit dem auf Validation festgelegten primären Threshold ausgewertet.
    threshold_specs: list[tuple[str, float]] = [
        (PRIMARY_THRESHOLD_SELECTION, float(recommendations[PRIMARY_THRESHOLD_SELECTION]["threshold"]))
    ]

    for selection, threshold in threshold_specs:
        metrics = evaluate_at_threshold(y_test, p_test, threshold)
        evaluations.append({
            "selection": selection,
            "threshold": float(threshold),
            "is_primary": selection == PRIMARY_THRESHOLD_SELECTION,
            **metrics,
        })

    with TEST_METRICS_CSV_FILE.open("w", encoding="utf-8", newline="") as file:
        writer = csv.DictWriter(file, fieldnames=TEST_FIELDS)
        writer.writeheader()
        for row in evaluations:
            writer.writerow({key: row.get(key) for key in TEST_FIELDS})

    payload = {
        "run_name": RUN_NAME,
        "created_at": datetime.now().astimezone().isoformat(),
        "split": "test",
        "test_image_count": int(len(y_test)),
        "threshold_selection_source": "validation only",
        "primary_selection": PRIMARY_THRESHOLD_SELECTION,
        "primary_threshold": float(recommendations[PRIMARY_THRESHOLD_SELECTION]["threshold"]),
        "evaluations": evaluations,
    }
    write_json_atomic(TEST_METRICS_JSON_FILE, payload)

    with TEST_METRICS_TXT_FILE.open("w", encoding="utf-8") as file:
        file.write("=" * 140 + "\n")
        file.write("FINALE CLASSIFIER-TESTAUSWERTUNG\n")
        file.write("=" * 140 + "\n")
        file.write("Der verwendete Threshold wurde ausschließlich auf Validation bestimmt.\n")
        file.write("Der Testsplit hat keinen Threshold ausgewählt oder verändert.\n")
        file.write(f"Run: {RUN_NAME}\n")
        file.write(f"Test images: {len(y_test)}\n")
        file.write(f"Primary selection: {PRIMARY_THRESHOLD_SELECTION}\n")
        file.write(f"Primary threshold: {recommendations[PRIMARY_THRESHOLD_SELECTION]['threshold']:.10g}\n\n")

        for row in evaluations:
            file.write("-" * 140 + "\n")
            file.write(f"Selection: {row['selection']}\n")
            file.write(f"Threshold: {row['threshold']:.10g}\n")
            file.write(f"Primary: {row['is_primary']}\n")
            for key in TEST_FIELDS:
                if key in {"selection", "threshold", "is_primary"}:
                    continue
                value = row[key]
                if isinstance(value, float):
                    file.write(f"{key}: {value:.8f}\n")
                else:
                    file.write(f"{key}: {value}\n")
            file.write("\n")

    return evaluations


def save_test_false_negatives(
    y_test: np.ndarray,
    p_test: np.ndarray,
    test_records: list[dict[str, Any]],
    recommendations: dict[str, dict[str, Any]],
) -> list[dict[str, Any]]:
    """Loggt jedes konkrete positive Testbild, das bei einem festen Validation-Threshold negativ wird."""
    y_test = np.asarray(y_test, dtype=np.int32).reshape(-1)
    p_test = np.asarray(p_test, dtype=np.float64).reshape(-1)
    if len(test_records) != len(y_test):
        raise ValueError(
            f"Test-Dateiliste ({len(test_records)}) und Predictions ({len(y_test)}) haben unterschiedliche Laenge."
        )

    # Test wird genau EINMAL mit dem auf Validation festgelegten primären Threshold ausgewertet.
    threshold_specs: list[tuple[str, float]] = [
        (PRIMARY_THRESHOLD_SELECTION, float(recommendations[PRIMARY_THRESHOLD_SELECTION]["threshold"]))
    ]

    rows: list[dict[str, Any]] = []
    for selection, threshold in threshold_specs:
        fn_indices = np.flatnonzero((y_test == 1) & (p_test < float(threshold)))
        for idx in fn_indices:
            rec = test_records[int(idx)]
            rows.append({
                "selection": selection,
                "is_primary": selection == PRIMARY_THRESHOLD_SELECTION,
                "threshold": float(threshold),
                "sample_index": int(idx),
                "image_name": Path(rec["image_path"]).name,
                "image_path": str(Path(rec["image_path"]).resolve()),
                "dataset_root": rec["dataset_root"],
                "ground_truth": 1,
                "classifier_probability": float(p_test[int(idx)]),
                "margin_to_threshold": float(p_test[int(idx)] - threshold),
                "decision": "false_negative",
            })

    fields = [
        "selection", "is_primary", "threshold", "sample_index", "image_name",
        "image_path", "dataset_root", "ground_truth", "classifier_probability",
        "margin_to_threshold", "decision",
    ]

    with TEST_FN_CSV_FILE.open("w", encoding="utf-8", newline="") as file:
        writer = csv.DictWriter(file, fieldnames=fields)
        writer.writeheader()
        writer.writerows(rows)

    with TEST_FN_TXT_FILE.open("w", encoding="utf-8") as file:
        file.write("=" * 140 + "\n")
        file.write("CLASSIFIER FALSE NEGATIVES AUF DEM FINALEN TESTSPLIT\n")
        file.write("=" * 140 + "\n")
        file.write("Der verwendete Threshold wurde zuvor ausschließlich auf Validation bestimmt.\n")
        file.write(f"Run: {RUN_NAME}\n")
        file.write(f"Testbilder: {len(y_test)}\n")
        file.write(f"Positive Testbilder: {int(np.sum(y_test == 1))}\n")
        file.write(f"False-Negative-Zeilen beim finalen Threshold: {len(rows)}\n\n")
        for selection, threshold in threshold_specs:
            subset = [row for row in rows if row["selection"] == selection]
            file.write("-" * 140 + "\n")
            file.write(f"Selection: {selection}\n")
            file.write(f"Threshold: {threshold:.10g}\n")
            file.write(f"Primary: {selection == PRIMARY_THRESHOLD_SELECTION}\n")
            file.write(f"False Negatives: {len(subset)}\n")
            for row in subset:
                file.write(
                    f"[{row['sample_index']}] {row['image_name']} | "
                    f"p={row['classifier_probability']:.10g} | "
                    f"margin={row['margin_to_threshold']:.10g} | "
                    f"dataset={row['dataset_root']} | {row['image_path']}\n"
                )
            file.write("\n")

    return rows


# =============================================================================
# 11. RUN-KONFIGURATION
# =============================================================================
def save_run_configuration(dataset_report: dict[str, Any], architecture_info: dict[str, Any]) -> None:
    config = {
        "run_name": RUN_NAME,
        "run_dir": RUN_DIR,
        "datasets": [
            {
                "root": cfg.root,
                "positive_dir": cfg.positive_dir,
                "negative_dir": cfg.negative_dir,
                "weight": cfg.weight,
            }
            for cfg in DATASETS
        ],
        "img_size": IMG_SIZE,
        "batch_size": BATCH_SIZE,
        "validation_batch_size": VALIDATION_BATCH_SIZE,
        "validation_steps": VALIDATION_STEPS,
        "validation_samples_per_epoch": VALIDATION_BATCH_SIZE * VALIDATION_STEPS,
        "xla_jit": XLA_JIT,
        "mixed_precision_policy": MIXED_PRECISION_POLICY,
        "steps_per_execution": STEPS_PER_EXECUTION,
        "epoch_auc_thresholds": EPOCH_AUC_THRESHOLDS,
        "phase1_epochs": PHASE1_EPOCHS,
        "phase2_epochs": PHASE2_EPOCHS,
        "steps_per_epoch": STEPS_PER_EPOCH,
        "lr": LR,
        "fine_tune_lr": FINE_TUNE_LR,
        "unfreeze_last_n": UNFREEZE_LAST_N,
        "train_positive_fraction": TRAIN_POSITIVE_FRACTION,
        "training_metric_threshold": TRAINING_METRIC_THRESHOLD,
        "primary_threshold_selection": PRIMARY_THRESHOLD_SELECTION,
        "threshold_grid_count": len(build_threshold_grid()),
        "dataset_report": dataset_report,
        "architecture": architecture_info,
        "environment": {
            "timestamp": datetime.now().astimezone().isoformat(),
            "python": sys.version.replace("\n", " "),
            "platform": platform.platform(),
            "tensorflow": tf.__version__,
            "visible_gpus": [gpu.name for gpu in tf.config.list_physical_devices("GPU")],
        },
    }
    with RUN_CONFIG_FILE.open("w", encoding="utf-8") as file:
        for key, value in config.items():
            if isinstance(value, (dict, list, tuple)):
                file.write(f"{key}: {json.dumps(json_safe(value), ensure_ascii=False)}\n")
            else:
                file.write(f"{key}: {value}\n")


# =============================================================================
# 12. MAIN
# =============================================================================
def main() -> None:
    if PRIMARY_THRESHOLD_SELECTION not in {
        "best_f1", "best_f2", "best_recall", "best_balanced_error", "best_f1_f2_distance"
    }:
        raise ValueError(f"Unbekannte PRIMARY_THRESHOLD_SELECTION: {PRIMARY_THRESHOLD_SELECTION}")
    create_output_dirs()
    dataset_report = validate_dataset_configs(DATASETS)

    train_ds = make_train_dataset(DATASETS)
    val_fit_ds, val_count = make_eval_dataset(
        DATASETS,
        "val",
        batch_size=VALIDATION_BATCH_SIZE,
        shuffle=True,
        repeat=True,
        deterministic=False,
    )
    print(f"\nValidierungsbilder physisch: {val_count}")
    print(
        f"Epochen-Validation:          {VALIDATION_STEPS} Steps x "
        f"Batch {VALIDATION_BATCH_SIZE} = {VALIDATION_STEPS * VALIDATION_BATCH_SIZE} Samples"
    )

    model, backbone = build_model()
    model.summary()
    architecture_info = export_architecture(model)
    save_run_configuration(dataset_report, architecture_info)

    metrics_logger = ValidationMetricsLogger(
        run_metadata={
            "run_name": RUN_NAME,
            "dataset_report": dataset_report,
            "architecture": architecture_info,
        },
    )

    callbacks = [
        metrics_logger,  # muss vor monitorenden Callbacks stehen
        tf.keras.callbacks.ReduceLROnPlateau(
            monitor="val_pr_auc",
            mode="max",
            factor=0.5,
            patience=3,
            min_lr=1e-7,
            verbose=1,
        ),
        tf.keras.callbacks.EarlyStopping(
            monitor="val_pr_auc",
            mode="max",
            patience=8,
            restore_best_weights=False,
            verbose=1,
        ),
        tf.keras.callbacks.TerminateOnNaN(),
    ]
    if SAVE_EVERY_EPOCH_MODEL:
        callbacks.insert(
            1,
            tf.keras.callbacks.ModelCheckpoint(
                filepath=str(MODEL_DIR / f"{RUN_NAME}_epoch_{{epoch:02d}}.keras"),
                save_best_only=False,
                save_freq="epoch",
                verbose=1,
            ),
        )

    print(f"\nStarte Phase 1: {PHASE1_EPOCHS} Epochen mit eingefrorenem Backbone ...")
    compile_model(model, LR)
    model.fit(
        train_ds,
        validation_data=val_fit_ds,
        validation_steps=VALIDATION_STEPS,
        epochs=PHASE1_EPOCHS,
        steps_per_epoch=STEPS_PER_EPOCH,
        callbacks=callbacks,
        verbose=1,
    )

    print(f"\nStarte Phase 2: bis Epoche {EPOCHS_TOTAL} mit Fine-Tuning ...")
    configure_fine_tuning(backbone, UNFREEZE_LAST_N)
    compile_model(model, FINE_TUNE_LR)
    model.fit(
        train_ds,
        validation_data=val_fit_ds,
        validation_steps=VALIDATION_STEPS,
        initial_epoch=PHASE1_EPOCHS,
        epochs=EPOCHS_TOTAL,
        steps_per_epoch=STEPS_PER_EPOCH,
        callbacks=callbacks,
        verbose=1,
    )
    metrics_logger.finalize()

    # Threshold-Sweep genau einmal auf dem nach F1/F2-Distanz besten Epochenmodell.
    if not BEST_DISTANCE_MODEL_PATH.is_file():
        raise FileNotFoundError(
            f"Bestes Distanz-Modell wurde nicht gespeichert: {BEST_DISTANCE_MODEL_PATH}"
        )

    print(f"\nLade bestes Modell für Threshold-Sweep: {BEST_DISTANCE_MODEL_PATH}")
    best_model = tf.keras.models.load_model(
        BEST_DISTANCE_MODEL_PATH,
        compile=False,
        custom_objects={
            "BinaryF1Score": BinaryF1Score,
            "BinaryF2Score": BinaryF2Score,
            "CrackClassifier>BinaryF1Score": BinaryF1Score,
            "CrackClassifier>BinaryF2Score": BinaryF2Score,
        },
    )

    print("\nThreshold-Sweep EINMAL auf dem vollständigen Validation-Split ...")
    val_full_ds, val_full_count = make_eval_dataset(
        DATASETS,
        "val",
        batch_size=VALIDATION_BATCH_SIZE,
        shuffle=False,
        repeat=False,
        deterministic=True,
    )
    print(f"Vollständige Validation für Sweep: {val_full_count} Bilder")
    y_val, p_val = collect_predictions(best_model, val_full_ds)
    recommendations = save_threshold_sweep(y_val, p_val)

    print("\nFINALE THRESHOLD-EMPFEHLUNGEN (Validation):")
    for name, row in recommendations.items():
        print(
            f"  {name:24s}: t={row['threshold']:.10g} | F1={row['f1']:.6f} | "
            f"F2={row['f2']:.6f} | Recall={row['recall']:.6f} | "
            f"BalErr={row['balanced_error']:.6f}"
        )

    # Testsplit wird erst jetzt erzeugt und genau einmal inferiert. Keine Threshold-Optimierung auf Test.
    primary_threshold = float(recommendations[PRIMARY_THRESHOLD_SELECTION]["threshold"])
    print(
        "\nFinale Test-Auswertung EINMAL mit eingefrorenem Validation-Threshold "
        f"{primary_threshold:.10g} ({PRIMARY_THRESHOLD_SELECTION}) ..."
    )
    test_ds, test_count = make_eval_dataset(
        DATASETS,
        "test",
        batch_size=BATCH_SIZE,
        shuffle=False,
        repeat=False,
        deterministic=True,
    )
    test_records = collect_eval_file_records(DATASETS, "test")
    print(f"Testbilder gesamt: {test_count}")
    y_test, p_test = collect_predictions(best_model, test_ds)
    test_results = save_test_metrics(y_test, p_test, recommendations)
    test_fn_rows = save_test_false_negatives(y_test, p_test, test_records, recommendations)

    best_model.save(FINAL_MODEL_PATH)

    primary_result = next(row for row in test_results if row["selection"] == PRIMARY_THRESHOLD_SELECTION)
    print("\nFertig.")
    print(f"Run-Ordner:                    {RUN_DIR}")
    print(f"Architecture:                  {ARCH_DIR}")
    print(f"Training-/Validation-Metrics: {METRICS_DIR}")
    print(f"Threshold-Sweep:               {THRESHOLD_DIR}")
    print(f"Finales Modell:                {FINAL_MODEL_PATH}")
    print(f"Best epoch:                    {metrics_logger.best_epoch}")
    print(f"Primary threshold:             {primary_result['threshold']:.10g} ({PRIMARY_THRESHOLD_SELECTION})")
    print(f"Primary Test F1:               {primary_result['f1']:.6f}")
    print(f"Primary Test F2:               {primary_result['f2']:.6f}")
    print(f"Primary Test Recall:           {primary_result['recall']:.6f}")
    print(f"Primary Test Balanced Error:   {primary_result['balanced_error']:.6f}")
    primary_fn_count = sum(1 for row in test_fn_rows if row["selection"] == PRIMARY_THRESHOLD_SELECTION)
    print(f"Primary Test False Negatives:  {primary_fn_count}")
    print(f"Test-FN TXT:                   {TEST_FN_TXT_FILE}")
    print(f"Test-FN CSV:                   {TEST_FN_CSV_FILE}")


if __name__ == "__main__":
    main()
