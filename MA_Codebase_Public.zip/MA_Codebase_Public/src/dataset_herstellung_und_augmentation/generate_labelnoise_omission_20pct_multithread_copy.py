#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Erzeugt eine kontrollierte Label-Noise-Variante des Better Datasets.

Experimentelles Prinzip:
- NUR train_512/masks wird veraendert.
- train_512/images wird unveraendert physisch in den neuen Datensatz kopiert.
- val_512 und test_512 werden ebenfalls unveraendert kopiert.
- Die Originaldaten werden niemals ueberschrieben.
- Jede Transformation wird pro Datei in CSV/JSON protokolliert.

Damit kann dieselbe Trainingsarchitektur fuer Referenz- und Noise-Datensaetze
verwendet werden, ohne dass Validation/Test durch Label-Noise kontaminiert werden.
"""

from __future__ import annotations

import csv
import hashlib
import json
import os
import random
import shutil
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path

import cv2
import numpy as np


# =============================================================================
# KONFIGURATION
# =============================================================================

SOURCE_DATASET = Path("/home/mitte/crack_project/datasets/better_dataset_evtl")
SEED = 42
MAX_WORKERS = min(16, os.cpu_count() or 1)
OVERWRITE_EXISTING_MASKS = True

MASK_EXTENSIONS = {".png"}

TRAIN_SPLIT = "train_512"
VAL_SPLIT = "val_512"
TEST_SPLIT = "test_512"


def deterministic_rng(path: Path) -> random.Random:
    """Dateispezifischer RNG, damit Ergebnisse unabhaengig von Dateireihenfolge reproduzierbar sind."""
    key = f"{SEED}|{path.name}".encode("utf-8")
    digest = hashlib.sha256(key).digest()
    local_seed = int.from_bytes(digest[:8], "little", signed=False)
    return random.Random(local_seed)


def read_binary_mask(path: Path) -> np.ndarray:
    mask = cv2.imread(str(path), cv2.IMREAD_GRAYSCALE)
    if mask is None:
        raise ValueError(f"Maske konnte nicht gelesen werden: {path}")
    return (mask > 127).astype(np.uint8)


def write_binary_mask(path: Path, mask: np.ndarray) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    data = (np.asarray(mask) > 0).astype(np.uint8) * 255
    if not cv2.imwrite(str(path), data):
        raise IOError(f"Maske konnte nicht gespeichert werden: {path}")


def copy_tree_contents(source_dir: Path, target_dir: Path) -> None:
    """Kopiert einen Verzeichnisbaum, ohne Quelldaten zu veraendern."""
    if not source_dir.is_dir():
        raise FileNotFoundError(f"Quellordner fehlt: {source_dir}")
    target_dir.mkdir(parents=True, exist_ok=True)
    shutil.copytree(
        source_dir,
        target_dir,
        dirs_exist_ok=True,
        copy_function=shutil.copy2,
    )


def prepare_output_dataset(output_dataset: Path) -> Path:
    """Erzeugt eine vollstaendig eigenstaendige Dataset-Struktur per Kopie."""
    source_train_images = SOURCE_DATASET / TRAIN_SPLIT / "images"
    source_train_masks = SOURCE_DATASET / TRAIN_SPLIT / "masks"
    source_val = SOURCE_DATASET / VAL_SPLIT
    source_test = SOURCE_DATASET / TEST_SPLIT

    for required in (source_train_images, source_train_masks, source_val, source_test):
        if not required.exists():
            raise FileNotFoundError(f"Erforderlicher Quellpfad fehlt: {required}")

    output_dataset.mkdir(parents=True, exist_ok=True)
    train_out = output_dataset / TRAIN_SPLIT
    train_images_out = train_out / "images"
    masks_out = train_out / "masks"

    # Trainingsbilder werden physisch kopiert.
    copy_tree_contents(source_train_images, train_images_out)

    # Validation und Test werden ebenfalls physisch kopiert und bleiben unveraendert.
    copy_tree_contents(source_val, output_dataset / VAL_SPLIT)
    copy_tree_contents(source_test, output_dataset / TEST_SPLIT)

    masks_out.mkdir(parents=True, exist_ok=True)
    return masks_out



def source_masks() -> list[Path]:
    mask_dir = SOURCE_DATASET / TRAIN_SPLIT / "masks"
    paths = sorted(
        p for p in mask_dir.iterdir()
        if p.is_file()
        and not p.name.startswith(".")
        and p.suffix.lower() in MASK_EXTENSIONS
    )
    if not paths:
        raise RuntimeError(f"Keine PNG-Masken gefunden in: {mask_dir}")
    return paths


def save_logs(
    output_dataset: Path,
    transformation_name: str,
    transformation_config: dict,
    rows: list[dict],
) -> None:
    manifest_path = output_dataset / "label_noise_manifest.csv"
    summary_path = output_dataset / "label_noise_summary.json"

    if not rows:
        raise RuntimeError("Keine Masken verarbeitet.")

    with manifest_path.open("w", encoding="utf-8", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
        writer.writeheader()
        writer.writerows(rows)

    before = sum(int(r["positive_pixels_before"]) for r in rows)
    after = sum(int(r["positive_pixels_after"]) for r in rows)

    summary = {
        "transformation": transformation_name,
        "seed": SEED,
        "source_dataset": str(SOURCE_DATASET),
        "output_dataset": str(output_dataset),
        "train_masks_modified": True,
        "train_images_modified": False,
        "validation_modified": False,
        "test_modified": False,
        "configuration": transformation_config,
        "number_of_masks": len(rows),
        "positive_pixels_before_total": before,
        "positive_pixels_after_total": after,
        "delta_positive_pixels_total": after - before,
    }

    with summary_path.open("w", encoding="utf-8") as f:
        json.dump(summary, f, indent=2, ensure_ascii=False)

    print(f"\nFertig: {len(rows)} Masken verarbeitet.")
    print(f"Output:   {output_dataset}")
    print(f"Manifest: {manifest_path}")
    print(f"Summary:  {summary_path}")

OUTPUT_DATASET = Path("/home/mitte/crack_project/datasets/better_dataset_labelnoise_omission_20pct")

OMISSION_FRACTION = 0.20
MIN_COMPONENT_PIXELS = 2


def omit_contiguous_axis_segment(
    component_mask: np.ndarray,
    rng: random.Random,
    fraction: float,
) -> tuple[np.ndarray, int]:
    """
    Entfernt einen zusammenhaengenden Abschnitt entlang der Hauptachse einer
    zusammenhaengenden Risskomponente.

    Die Hauptachse wird ueber PCA der Komponentenpixel bestimmt. Danach wird ein
    zufaelliger, zusammenhaengender Projektionsbereich von 20 % der Achsenlaenge
    entfernt. Bei sehr kleinen/degenerierten Komponenten wird mindestens ein
    Komponentenpixel entfernt.
    """
    ys, xs = np.where(component_mask > 0)
    n = len(xs)
    if n == 0:
        return component_mask.copy(), 0

    if n == 1:
        out = component_mask.copy()
        out[ys[0], xs[0]] = 0
        return out, 1

    xy = np.column_stack((xs, ys)).astype(np.float64)
    center = xy.mean(axis=0, keepdims=True)
    centered = xy - center

    covariance = centered.T @ centered
    eigenvalues, eigenvectors = np.linalg.eigh(covariance)
    axis = eigenvectors[:, int(np.argmax(eigenvalues))]
    projection = centered @ axis

    p_min = float(projection.min())
    p_max = float(projection.max())
    axis_length = p_max - p_min

    remove_selector = np.zeros(n, dtype=bool)

    if axis_length > 1e-9:
        segment_length = max(axis_length * fraction, 1e-9)
        max_start = p_max - segment_length
        start = rng.uniform(p_min, max_start) if max_start > p_min else p_min
        end = start + segment_length
        remove_selector = (projection >= start) & (projection <= end)

    # Diskretisierung kann bei sehr duennen/kurzen Komponenten 0 Treffer ergeben.
    # Dann entfernen wir eine zusammenhaengende 20%-Scheibe nach sortierter Achsenposition.
    desired_min = max(1, int(round(n * fraction)))
    if int(remove_selector.sum()) == 0:
        order = np.argsort(projection)
        if n <= desired_min:
            chosen = order
        else:
            start_idx = rng.randint(0, n - desired_min)
            chosen = order[start_idx:start_idx + desired_min]
        remove_selector[chosen] = True

    out = component_mask.copy()
    out[ys[remove_selector], xs[remove_selector]] = 0
    return out, int(remove_selector.sum())


def transform_mask(mask: np.ndarray, source_path: Path) -> tuple[np.ndarray, int, int]:
    rng = deterministic_rng(source_path)

    num_labels, labels, stats, _centroids = cv2.connectedComponentsWithStats(
        mask.astype(np.uint8),
        connectivity=8,
    )

    output = mask.copy()
    total_removed = 0
    processed_components = 0

    for label_id in range(1, num_labels):
        area = int(stats[label_id, cv2.CC_STAT_AREA])
        if area < MIN_COMPONENT_PIXELS:
            continue

        component = (labels == label_id).astype(np.uint8)
        modified_component, removed = omit_contiguous_axis_segment(
            component,
            rng=rng,
            fraction=OMISSION_FRACTION,
        )

        # Nur Pixel dieser Komponente ersetzen.
        output[component > 0] = modified_component[component > 0]
        total_removed += removed
        processed_components += 1

    return output, total_removed, processed_components


def process_one_mask(source_path: Path, masks_out: Path) -> dict:
    mask = read_binary_mask(source_path)
    noisy, removed, components = transform_mask(mask, source_path)

    output_path = masks_out / source_path.name
    if output_path.exists() and not OVERWRITE_EXISTING_MASKS:
        raise FileExistsError(output_path)
    write_binary_mask(output_path, noisy)

    before = int(mask.sum())
    after = int(noisy.sum())
    return {
        "filename": source_path.name,
        "source_mask": str(source_path),
        "output_mask": str(output_path),
        "height": int(mask.shape[0]),
        "width": int(mask.shape[1]),
        "positive_pixels_before": before,
        "positive_pixels_after": after,
        "removed_positive_pixels": before - after,
        "requested_omission_fraction_axis": OMISSION_FRACTION,
        "processed_connected_components": components,
        "seed": SEED,
    }



def main() -> None:
    masks_out = prepare_output_dataset(OUTPUT_DATASET)
    rows = []

    paths = source_masks()
    with ThreadPoolExecutor(max_workers=MAX_WORKERS) as executor:
        futures = {
            executor.submit(process_one_mask, source_path, masks_out): source_path
            for source_path in paths
        }
        for index, future in enumerate(as_completed(futures), start=1):
            rows.append(future.result())
            if index % 500 == 0 or index == len(paths):
                print(f"Omission: {index}/{len(paths)} | Threads={MAX_WORKERS}", flush=True)

    rows.sort(key=lambda row: row["filename"])

    save_logs(
        OUTPUT_DATASET,
        transformation_name="structural_omission",
        transformation_config={
            "omission_fraction_of_component_axis": OMISSION_FRACTION,
            "component_connectivity": 8,
            "axis_estimation": "PCA principal axis",
            "random_segment": True,
            "seed": SEED,
        },
        rows=rows,
    )


if __name__ == "__main__":
    main()
