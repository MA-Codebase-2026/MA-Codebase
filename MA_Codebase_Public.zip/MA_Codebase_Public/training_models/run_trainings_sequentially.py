#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Startet mehrere Trainingsskripte nacheinander.

Das nächste Training startet erst, wenn das vorherige vollständig beendet wurde.
Standardmäßig wird bei einem Fehler abgebrochen.

Anwendung:
    1. TRAINING_SCRIPTS unten anpassen.
    2. Dieses Skript im selben Ordner wie die Trainingsskripte ablegen
       oder absolute Pfade verwenden.
    3. Starten mit:
           python run_trainings_sequentially.py
"""

from __future__ import annotations

import subprocess
import sys
import time
from datetime import datetime
from pathlib import Path


# =============================================================================
# KONFIGURATION
# =============================================================================

BASE_DIR = Path(__file__).resolve().parent

TRAINING_SCRIPTS = [
    "self_training_iterative_online_teacher_wsl_ultrastable.py",
    "deeplabv3plus_better_dataset_dice_loss_logging_wie_unetpp.py",
    "Rissbreite_in_px_batch_auto.py",
]
    

STOP_ON_ERROR = False
PAUSE_BETWEEN_RUNS_SECONDS = 5


# =============================================================================
# HILFSFUNKTIONEN
# =============================================================================

def timestamp() -> str:
    return datetime.now().astimezone().strftime("%Y-%m-%d %H:%M:%S %Z")


def resolve_script(script_name: str) -> Path:
    path = Path(script_name)
    if not path.is_absolute():
        path = BASE_DIR / path
    return path.resolve()


def check_scripts() -> list[Path]:
    resolved_scripts: list[Path] = []
    missing_scripts: list[Path] = []

    for script_name in TRAINING_SCRIPTS:
        script_path = resolve_script(script_name)
        if script_path.is_file():
            resolved_scripts.append(script_path)
        else:
            missing_scripts.append(script_path)

    if missing_scripts:
        print("\nFEHLER: Folgende Trainingsskripte wurden nicht gefunden:")
        for path in missing_scripts:
            print(f"  - {path}")
        print("\nPasse TRAINING_SCRIPTS oder BASE_DIR an.")
        sys.exit(1)

    return resolved_scripts


def run_training(script_path: Path, index: int, total: int) -> int:
    separator = "=" * 100

    print(f"\n{separator}")
    print(f"[{timestamp()}] Training {index}/{total}")
    print(f"Datei: {script_path.name}")
    print(f"Pfad : {script_path}")
    print(separator)
    print()

    start_time = time.perf_counter()

    try:
        process = subprocess.run(
            [sys.executable, "-u", str(script_path)],
            cwd=str(script_path.parent),
            check=False,
        )
        return_code = int(process.returncode)

    except KeyboardInterrupt:
        print(f"\n[{timestamp()}] Abbruch durch Benutzer.")
        raise

    except Exception as exc:
        print(f"\n[{timestamp()}] Fehler beim Starten von {script_path.name}:")
        print(exc)
        return_code = -1

    elapsed = time.perf_counter() - start_time
    hours, remainder = divmod(int(elapsed), 3600)
    minutes, seconds = divmod(remainder, 60)

    status = (
        "ERFOLGREICH BEENDET"
        if return_code == 0
        else f"FEHLER / RETURNCODE {return_code}"
    )

    print()
    print(separator)
    print(f"[{timestamp()}] {script_path.name}: {status}")
    print(f"Laufzeit: {hours:02d}:{minutes:02d}:{seconds:02d}")
    print(separator)

    return return_code


# =============================================================================
# MAIN
# =============================================================================

def main() -> None:
    scripts = check_scripts()

    print("=" * 100)
    print("SEQUENTIELLER TRAININGS-LAUNCHER")
    print("=" * 100)
    print(f"Python: {sys.executable}")
    print(f"Basisordner: {BASE_DIR}")
    print(f"Anzahl Trainings: {len(scripts)}")
    print(f"Stop bei Fehler: {STOP_ON_ERROR}")
    print()

    for index, script in enumerate(scripts, start=1):
        print(f"{index:2d}. {script.name}")

    overall_start = time.perf_counter()
    completed = 0

    try:
        for index, script_path in enumerate(scripts, start=1):
            return_code = run_training(
                script_path=script_path,
                index=index,
                total=len(scripts),
            )

            if return_code != 0:
                if STOP_ON_ERROR:
                    print(
                        f"\nSequenz wird abgebrochen, weil "
                        f"'{script_path.name}' mit Fehler beendet wurde."
                    )
                    sys.exit(return_code if return_code > 0 else 1)

                print(
                    f"\nWARNUNG: '{script_path.name}' ist fehlgeschlagen. "
                    "Das nächste Training wird trotzdem gestartet."
                )
            else:
                completed += 1

            if index < len(scripts) and PAUSE_BETWEEN_RUNS_SECONDS > 0:
                print(
                    f"\nPause von {PAUSE_BETWEEN_RUNS_SECONDS} Sekunden "
                    "vor dem nächsten Training ..."
                )
                time.sleep(PAUSE_BETWEEN_RUNS_SECONDS)

    except KeyboardInterrupt:
        print("\nLauncher wurde manuell beendet.")
        sys.exit(130)

    overall_elapsed = time.perf_counter() - overall_start
    hours, remainder = divmod(int(overall_elapsed), 3600)
    minutes, seconds = divmod(remainder, 60)

    print("\n" + "=" * 100)
    print("ALLE TRAININGS ABGEARBEITET")
    print("=" * 100)
    print(f"Erfolgreich beendet: {completed}/{len(scripts)}")
    print(f"Gesamtlaufzeit: {hours:02d}:{minutes:02d}:{seconds:02d}")
    print(f"Ende: {timestamp()}")
    print("=" * 100)


if __name__ == "__main__":
    main()
