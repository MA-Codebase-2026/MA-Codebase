from pathlib import Path
import csv
import json
import shutil
from datetime import datetime

import numpy as np
import tensorflow as tf


# ============================================================
# KONFIGURATION
# ============================================================

# Pfad zum vollständig gespeicherten .keras-Modell
MODEL_PATH = Path("/home/mitte/crack_project/output_classifier/classifier_multi_dataset_optimized/classifier_best.keras")

# test_512/
# ├── images_512px_hard_negatives/   -> nur NEGATIVE Bilder
# └── images/                        -> nur POSITIVE Bilder
TEST_ROOT = Path("/home/mitte/crack_project/datasets/better_dataset_evtl/test_512")

NEGATIVE_DIR = TEST_ROOT / "images_512px_hard_negatives"
POSITIVE_DIR = TEST_ROOT / "images"

# Die beiden Thresholds, die getestet werden sollen
THRESHOLDS = [0.094, 0.000044]

# Batchgröße für model.predict()
BATCH_SIZE = 16

# Falls das Modell eine feste Eingabegröße hat, wird diese automatisch
# aus model.input_shape gelesen.
# Falls dort None steht, wird 512x512 verwendet.
FALLBACK_IMAGE_SIZE = (512, 512)

# WICHTIG:
# Muss zu deinem Training passen.
#
# "0_1"      -> Pixelwerte / 255.0
# "minus1_1" -> Pixelwerte von [-1, 1]
# "none"     -> Pixelwerte bleiben [0, 255]
PREPROCESS_MODE = "0_1"

# Bei True werden falsch klassifizierte Bilder zusätzlich
# in Ordner neben dem Modell kopiert.
COPY_MISCLASSIFIED_IMAGES = True

# Bei einem 2-Klassen-Softmax:
# Index der POSITIVEN Klasse.
POSITIVE_CLASS_INDEX = 1

IMAGE_EXTENSIONS = {
    ".jpg",
    ".jpeg",
    ".png",
    ".bmp",
    ".tif",
    ".tiff",
    ".webp",
}


# ============================================================
# HILFSFUNKTIONEN
# ============================================================

def get_image_files(folder: Path):
    """Sucht rekursiv nach Bilddateien."""
    if not folder.exists():
        raise FileNotFoundError(f"Ordner nicht gefunden: {folder}")

    files = [
        p for p in folder.rglob("*")
        if p.is_file() and p.suffix.lower() in IMAGE_EXTENSIONS
    ]

    return sorted(files)


def preprocess_image_array(image_array):
    """
    WICHTIG:
    Dieses Preprocessing muss genauso sein wie beim Training.
    """
    image_array = image_array.astype(np.float32)

    if PREPROCESS_MODE == "0_1":
        image_array = image_array / 255.0

    elif PREPROCESS_MODE == "minus1_1":
        image_array = (image_array / 127.5) - 1.0

    elif PREPROCESS_MODE == "none":
        pass

    else:
        raise ValueError(
            f"Unbekannter PREPROCESS_MODE: {PREPROCESS_MODE}"
        )

    return image_array


def unwrap_model_output(prediction):
    """
    Macht verschiedene mögliche Keras-Ausgaben handhabbar.
    """
    if isinstance(prediction, dict):
        if len(prediction) != 1:
            raise ValueError(
                "Das Modell liefert mehrere Outputs als Dictionary. "
                "Bitte den gewünschten Output explizit auswählen."
            )
        prediction = next(iter(prediction.values()))

    if isinstance(prediction, (list, tuple)):
        if len(prediction) != 1:
            raise ValueError(
                "Das Modell liefert mehrere Outputs. "
                "Bitte den gewünschten Output explizit auswählen."
            )
        prediction = prediction[0]

    return np.asarray(prediction)


def sigmoid(x):
    return 1.0 / (1.0 + np.exp(-x))


def softmax(x):
    x = x - np.max(x, axis=-1, keepdims=True)
    exp_x = np.exp(x)
    return exp_x / np.sum(exp_x, axis=-1, keepdims=True)


def prediction_to_positive_score(prediction):
    """
    Konvertiert den Modelloutput in eine Wahrscheinlichkeit / einen Score
    für die POSITIVE Klasse.

    Unterstützt:
        - sigmoid mit Shape (batch, 1)
        - sigmoid mit Shape (batch,)
        - Softmax mit Shape (batch, 2)
        - Logits
    """
    prediction = unwrap_model_output(prediction)

    if prediction.ndim == 1:
        scores = prediction.astype(np.float32)

        if np.any(scores < 0.0) or np.any(scores > 1.0):
            scores = sigmoid(scores)

        return scores

    if prediction.ndim == 2 and prediction.shape[1] == 1:
        scores = prediction[:, 0].astype(np.float32)

        if np.any(scores < 0.0) or np.any(scores > 1.0):
            scores = sigmoid(scores)

        return scores

    if prediction.ndim == 2 and prediction.shape[1] == 2:

        probs = prediction.astype(np.float32)

        looks_like_probabilities = (
            np.all(probs >= 0.0)
            and np.all(probs <= 1.0)
            and np.allclose(
                np.sum(probs, axis=1),
                1.0,
                atol=1e-3,
            )
        )

        if not looks_like_probabilities:
            probs = softmax(probs)

        return probs[:, POSITIVE_CLASS_INDEX]

    raise ValueError(
        f"Nicht unterstützter Modelloutput: Shape {prediction.shape}"
    )


def determine_input_size(model):
    """
    Liest die Bildgröße aus dem Modell.
    Erwartet normalerweise:
        (None, height, width, channels)
    """
    input_shape = model.input_shape

    if isinstance(input_shape, list):
        input_shape = input_shape[0]

    print(f"Model input shape: {input_shape}")

    if len(input_shape) != 4:
        print(
            "Input-Shape konnte nicht eindeutig als Bildinput "
            "interpretiert werden."
        )
        return (
            FALLBACK_IMAGE_SIZE[0],
            FALLBACK_IMAGE_SIZE[1],
            3,
        )

    height = input_shape[1]
    width = input_shape[2]
    channels = input_shape[3]

    if height is None:
        height = FALLBACK_IMAGE_SIZE[0]

    if width is None:
        width = FALLBACK_IMAGE_SIZE[1]

    if channels is None:
        channels = 3

    return int(height), int(width), int(channels)


def load_image(path, height, width, channels):
    """Lädt ein einzelnes Bild passend für das Modell."""

    if channels == 1:
        color_mode = "grayscale"
    else:
        color_mode = "rgb"

    img = tf.keras.utils.load_img(
        path,
        target_size=(height, width),
        color_mode=color_mode,
    )

    img = tf.keras.utils.img_to_array(img)
    img = preprocess_image_array(img)

    return img


def predict_files(
    model,
    image_files,
    true_label,
    height,
    width,
    channels,
):
    """
    Führt die Vorhersage für eine Liste von Bildern durch.

    true_label:
        0 = negativ
        1 = positiv
    """

    results = []
    failed_files = []

    total = len(image_files)

    for start in range(0, total, BATCH_SIZE):
        batch_files = image_files[start:start + BATCH_SIZE]

        batch_images = []
        valid_files = []

        for image_path in batch_files:
            try:
                image = load_image(
                    image_path,
                    height,
                    width,
                    channels,
                )

                batch_images.append(image)
                valid_files.append(image_path)

            except Exception as exc:
                print(
                    f"[WARNUNG] Bild konnte nicht geladen werden: "
                    f"{image_path}\n{exc}"
                )

                failed_files.append({
                    "path": str(image_path),
                    "error": str(exc),
                })

        if not batch_images:
            continue

        batch_array = np.stack(batch_images, axis=0)

        raw_prediction = model.predict_on_batch(batch_array)
        scores = prediction_to_positive_score(raw_prediction)

        for image_path, score in zip(valid_files, scores):
            results.append({
                "path": image_path,
                "filename": image_path.name,
                "true_label": int(true_label),
                "score": float(score),
            })

        processed = min(start + BATCH_SIZE, total)

        print(
            f"\rVerarbeitet: {processed}/{total}",
            end="",
            flush=True,
        )

    print()

    return results, failed_files


def calculate_metrics(all_results, threshold):
    """Berechnet Confusion-Matrix und wichtige Kennzahlen."""

    tp = 0
    tn = 0
    fp = 0
    fn = 0

    false_positives = []
    false_negatives = []

    for result in all_results:

        true_label = result["true_label"]
        score = result["score"]

        predicted_label = int(score >= threshold)

        if true_label == 1 and predicted_label == 1:
            tp += 1

        elif true_label == 0 and predicted_label == 0:
            tn += 1

        elif true_label == 0 and predicted_label == 1:
            fp += 1
            false_positives.append(result)

        elif true_label == 1 and predicted_label == 0:
            fn += 1
            false_negatives.append(result)

    total = tp + tn + fp + fn

    accuracy = (
        (tp + tn) / total
        if total > 0
        else 0.0
    )

    precision = (
        tp / (tp + fp)
        if (tp + fp) > 0
        else 0.0
    )

    recall = (
        tp / (tp + fn)
        if (tp + fn) > 0
        else 0.0
    )

    specificity = (
        tn / (tn + fp)
        if (tn + fp) > 0
        else 0.0
    )

    return {
        "threshold": float(threshold),

        "total": total,

        "true_positives": tp,
        "true_negatives": tn,

        "false_positives": fp,
        "false_negatives": fn,

        "total_misclassified": fp + fn,

        "accuracy": accuracy,
        "precision": precision,
        "recall_sensitivity": recall,
        "specificity": specificity,

        "false_positive_files": false_positives,
        "false_negative_files": false_negatives,
    }


def threshold_string(threshold):
    return f"{threshold:.4f}".replace(".", "p")


def save_prediction_csv(
    results,
    thresholds,
    output_path,
):
    """
    Speichert alle Bilder, Scores und die Entscheidung für
    jeden Threshold.
    """

    threshold_columns = [
        f"predicted_label_threshold_{threshold}"
        for threshold in thresholds
    ]

    fieldnames = [
        "filename",
        "path",
        "true_label",
        "score",
        *threshold_columns,
    ]

    with open(
        output_path,
        "w",
        newline="",
        encoding="utf-8",
    ) as file:

        writer = csv.DictWriter(
            file,
            fieldnames=fieldnames,
        )

        writer.writeheader()

        for result in results:

            row = {
                "filename": result["filename"],
                "path": str(result["path"]),
                "true_label": result["true_label"],
                "score": result["score"],
            }

            for threshold in thresholds:
                row[
                    f"predicted_label_threshold_{threshold}"
                ] = int(
                    result["score"] >= threshold
                )

            writer.writerow(row)


def save_misclassified_csv(
    items,
    output_path,
    threshold,
    error_type,
):
    fieldnames = [
        "filename",
        "path",
        "true_label",
        "score",
        "threshold",
        "error_type",
    ]

    with open(
        output_path,
        "w",
        newline="",
        encoding="utf-8",
    ) as file:

        writer = csv.DictWriter(
            file,
            fieldnames=fieldnames,
        )

        writer.writeheader()

        for result in items:
            writer.writerow({
                "filename": result["filename"],
                "path": str(result["path"]),
                "true_label": result["true_label"],
                "score": result["score"],
                "threshold": threshold,
                "error_type": error_type,
            })


def copy_misclassified_images(
    metrics,
    model_directory,
):
    """
    Kopiert falsch klassifizierte Bilder in:

    Modellordner/
        misclassified_threshold_0p5000/
            false_positives/
            false_negatives/
    """

    threshold = metrics["threshold"]
    threshold_name = threshold_string(threshold)

    error_root = (
        model_directory
        / f"misclassified_threshold_{threshold_name}"
    )

    fp_dir = error_root / "false_positives"
    fn_dir = error_root / "false_negatives"

    fp_dir.mkdir(parents=True, exist_ok=True)
    fn_dir.mkdir(parents=True, exist_ok=True)

    for result in metrics["false_positive_files"]:
        source = result["path"]

        target_name = (
            f"score_{result['score']:.6f}_"
            f"{source.name}"
        )

        shutil.copy2(
            source,
            fp_dir / target_name,
        )

    for result in metrics["false_negative_files"]:
        source = result["path"]

        target_name = (
            f"score_{result['score']:.6f}_"
            f"{source.name}"
        )

        shutil.copy2(
            source,
            fn_dir / target_name,
        )


def save_summary(
    metrics_per_threshold,
    model_path,
    negative_count,
    positive_count,
    failed_count,
):
    """
    Speichert eine gut lesbare Zusammenfassung direkt
    neben dem Modell.
    """

    output_path = (
        model_path.parent
        / "classifier_test_summary.txt"
    )

    lines = []

    lines.append("=" * 70)
    lines.append("CLASSIFIER TEST RESULTS")
    lines.append("=" * 70)
    lines.append("")

    lines.append(f"Modell: {model_path}")
    lines.append(
        f"Auswertung: {datetime.now().isoformat(timespec='seconds')}"
    )
    lines.append("")

    lines.append(
        f"Negative Testbilder: {negative_count}"
    )
    lines.append(
        f"Positive Testbilder: {positive_count}"
    )
    lines.append(
        f"Nicht lesbare Bilder: {failed_count}"
    )

    lines.append("")
    lines.append("=" * 70)

    for metrics in metrics_per_threshold:

        threshold = metrics["threshold"]

        lines.append("")
        lines.append(
            f"THRESHOLD = {threshold:.4f}"
        )
        lines.append("-" * 70)

        lines.append(
            f"True Positives  (TP): {metrics['true_positives']}"
        )

        lines.append(
            f"True Negatives  (TN): {metrics['true_negatives']}"
        )

        lines.append("")

        lines.append(
            f"FALSE POSITIVES (FP): "
            f"{metrics['false_positives']}"
        )

        lines.append(
            f"FALSE NEGATIVES (FN): "
            f"{metrics['false_negatives']}"
        )

        lines.append("")

        lines.append(
            f"GESAMT FALSCH GELABELT: "
            f"{metrics['total_misclassified']}"
        )

        lines.append("")

        lines.append(
            f"Accuracy:    "
            f"{metrics['accuracy']:.6f}"
        )

        lines.append(
            f"Precision:   "
            f"{metrics['precision']:.6f}"
        )

        lines.append(
            f"Recall:      "
            f"{metrics['recall_sensitivity']:.6f}"
        )

        lines.append(
            f"Specificity: "
            f"{metrics['specificity']:.6f}"
        )

        lines.append("")
        lines.append("=" * 70)

    with open(
        output_path,
        "w",
        encoding="utf-8",
    ) as file:
        file.write("\n".join(lines))

    return output_path


# ============================================================
# MAIN
# ============================================================

def main():

    print("=" * 70)
    print("CLASSIFIER TEST")
    print("=" * 70)

    if not MODEL_PATH.exists():
        raise FileNotFoundError(
            f"Modell nicht gefunden:\n{MODEL_PATH}"
        )

    if not NEGATIVE_DIR.exists():
        raise FileNotFoundError(
            f"Negativ-Ordner nicht gefunden:\n{NEGATIVE_DIR}"
        )

    if not POSITIVE_DIR.exists():
        raise FileNotFoundError(
            f"Positiv-Ordner nicht gefunden:\n{POSITIVE_DIR}"
        )

    output_dir = MODEL_PATH.parent

    print(f"\nModell:\n{MODEL_PATH}")
    print(f"\nErgebnisordner:\n{output_dir}")

    print("\nLade Modell ...")

    model = tf.keras.models.load_model(
        MODEL_PATH,
        compile=False,
    )

    print("Modell geladen.")

    height, width, channels = determine_input_size(model)

    print(
        f"Verwendete Bildgröße: "
        f"{width}x{height}, Channels={channels}"
    )

    print(
        f"Preprocessing: {PREPROCESS_MODE}"
    )

    negative_files = get_image_files(NEGATIVE_DIR)
    positive_files = get_image_files(POSITIVE_DIR)

    print("\nGefundene Bilder:")
    print(
        f"  Negative: {len(negative_files)}"
    )
    print(
        f"  Positive: {len(positive_files)}"
    )

    if len(negative_files) == 0:
        print(
            "WARNUNG: Keine negativen Bilder gefunden."
        )

    if len(positive_files) == 0:
        print(
            "WARNUNG: Keine positiven Bilder gefunden."
        )

    print("\n" + "=" * 70)
    print("NEGATIVE BILDER")
    print("=" * 70)

    negative_results, negative_failed = predict_files(
        model=model,
        image_files=negative_files,
        true_label=0,
        height=height,
        width=width,
        channels=channels,
    )

    print("\n" + "=" * 70)
    print("POSITIVE BILDER")
    print("=" * 70)

    positive_results, positive_failed = predict_files(
        model=model,
        image_files=positive_files,
        true_label=1,
        height=height,
        width=width,
        channels=channels,
    )

    all_results = (
        negative_results
        + positive_results
    )

    failed_files = (
        negative_failed
        + positive_failed
    )

    prediction_csv = (
        output_dir
        / "classifier_all_predictions.csv"
    )

    save_prediction_csv(
        all_results,
        THRESHOLDS,
        prediction_csv,
    )

    all_metrics = []

    print("\n" + "=" * 70)
    print("ERGEBNISSE")
    print("=" * 70)

    for threshold in THRESHOLDS:

        metrics = calculate_metrics(
            all_results,
            threshold,
        )

        all_metrics.append(metrics)

        threshold_name = threshold_string(
            threshold
        )

        fp_csv = (
            output_dir
            / f"false_positives_threshold_{threshold_name}.csv"
        )

        save_misclassified_csv(
            metrics["false_positive_files"],
            fp_csv,
            threshold,
            "false_positive",
        )

        fn_csv = (
            output_dir
            / f"false_negatives_threshold_{threshold_name}.csv"
        )

        save_misclassified_csv(
            metrics["false_negative_files"],
            fn_csv,
            threshold,
            "false_negative",
        )

        if COPY_MISCLASSIFIED_IMAGES:
            copy_misclassified_images(
                metrics,
                output_dir,
            )

        print()
        print("-" * 70)
        print(
            f"THRESHOLD: {threshold:.4f}"
        )
        print("-" * 70)

        print(
            f"True Positives:      "
            f"{metrics['true_positives']}"
        )

        print(
            f"True Negatives:      "
            f"{metrics['true_negatives']}"
        )

        print()
        print(
            f"FALSE POSITIVES:     "
            f"{metrics['false_positives']}"
        )

        print(
            f"FALSE NEGATIVES:     "
            f"{metrics['false_negatives']}"
        )

        print(
            f"GESAMT FALSCH:       "
            f"{metrics['total_misclassified']}"
        )

        print()
        print(
            f"Accuracy:            "
            f"{metrics['accuracy']:.4%}"
        )

        print(
            f"Precision:           "
            f"{metrics['precision']:.4%}"
        )

        print(
            f"Recall / Sensitivity:"
            f" {metrics['recall_sensitivity']:.4%}"
        )

        print(
            f"Specificity:         "
            f"{metrics['specificity']:.4%}"
        )

    summary_path = save_summary(
        metrics_per_threshold=all_metrics,
        model_path=MODEL_PATH,
        negative_count=len(negative_results),
        positive_count=len(positive_results),
        failed_count=len(failed_files),
    )

    json_metrics = []

    for metrics in all_metrics:
        json_metrics.append({
            key: value
            for key, value in metrics.items()
            if key not in {
                "false_positive_files",
                "false_negative_files",
            }
        })

    json_path = (
        output_dir
        / "classifier_test_results.json"
    )

    with open(
        json_path,
        "w",
        encoding="utf-8",
    ) as file:

        json.dump(
            {
                "model": str(MODEL_PATH),
                "negative_directory": str(NEGATIVE_DIR),
                "positive_directory": str(POSITIVE_DIR),
                "thresholds": THRESHOLDS,
                "negative_images": len(negative_results),
                "positive_images": len(positive_results),
                "failed_images": failed_files,
                "results": json_metrics,
            },
            file,
            indent=4,
            ensure_ascii=False,
        )

    print("\n" + "=" * 70)
    print("AUSWERTUNG ABGESCHLOSSEN")
    print("=" * 70)

    print(
        f"\nZusammenfassung:\n{summary_path}"
    )

    print(
        f"\nAlle Einzelvorhersagen:\n{prediction_csv}"
    )

    print(
        f"\nJSON-Ergebnisse:\n{json_path}"
    )


if __name__ == "__main__":
    main()
