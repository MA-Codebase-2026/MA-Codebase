#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Lokale Pixel-zu-mm-Skalierung mit drei ArUco-Markern.

Für jedes Bild im Eingabeordner werden die ArUco-Marker 0, 1 und 2 gesucht.
Aus der bekannten realen Kantenlänge jedes Markers und der gemessenen
Marker-Kantenlänge in Pixeln wird lokal berechnet:

    mm_per_px = reale_marker_kantenlaenge_mm / mittlere_marker_kantenlaenge_px

Standard-Zuordnung:
    Marker 0 -> Bildmitte
    Marker 1 -> Bild links oben
    Marker 2 -> Bildmitte links

Ausgabe:
    - aruco_scale_report.json
    - aruco_scale_report.txt

Benötigte Pakete:
    pip install opencv-contrib-python numpy
"""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any

import cv2
import numpy as np


# =============================================================================
# 1. BENUTZERKONFIGURATION
# =============================================================================

IMAGE_DIR = Path("/home/mitte/crack_project/test_images/Bildverzeichnung_aruco_150cm/s24")
OUTPUT_DIR = Path("/home/mitte/crack_project/test_images/Bildverzeichnung_aruco_150cm/s24")

IMAGE_EXTENSIONS = (
    ".png", ".jpg", ".jpeg", ".bmp", ".tif", ".tiff",
)

# Muss zu den gedruckten Markern passen.
ARUCO_DICTIONARY_NAME = "DICT_5X5_50"

# Marker-ID -> Position + reale Außenkantenlänge des schwarzen Markers in mm
MARKERS = {
    0: {"position_name": "bildmitte", "size_mm": 48.7},
    1: {"position_name": "bild_links_oben", "size_mm": 48.7},
    2: {"position_name": "bildmitte_links", "size_mm": 48.7},
    
}

USE_SUBPIXEL_REFINEMENT = True


def validate_marker_configuration() -> None:
    """Prüft, ob die erwarteten drei Positionen eindeutig konfiguriert sind."""
    expected = {"bildmitte", "bildmitte_links", "bild_links_oben"}
    configured = [str(cfg["position_name"]) for cfg in MARKERS.values()]

    if set(configured) != expected or len(configured) != len(set(configured)):
        raise ValueError(
            "MARKERS muss genau diese drei eindeutigen position_name-Werte enthalten: "
            "'bildmitte', 'bildmitte_links', 'bild_links_oben'. "
            f"Aktuell: {configured}"
        )

    if 0 not in MARKERS or MARKERS[0]["position_name"] != "bildmitte":
        raise ValueError(
            "Marker ID 0 muss als Referenz in der Bildmitte konfiguriert sein."
        )


# =============================================================================
# 2. ARUCO
# =============================================================================

def get_aruco_dictionary():
    if not hasattr(cv2, "aruco"):
        raise RuntimeError(
            "cv2.aruco ist nicht verfügbar. Installiere:\n"
            "pip install opencv-contrib-python"
        )

    if not hasattr(cv2.aruco, ARUCO_DICTIONARY_NAME):
        raise ValueError(f"Unbekanntes Dictionary: {ARUCO_DICTIONARY_NAME}")

    dict_id = getattr(cv2.aruco, ARUCO_DICTIONARY_NAME)
    return cv2.aruco.getPredefinedDictionary(dict_id)


def create_detector():
    dictionary = get_aruco_dictionary()

    if hasattr(cv2.aruco, "DetectorParameters"):
        params = cv2.aruco.DetectorParameters()
    else:
        params = cv2.aruco.DetectorParameters_create()

    if USE_SUBPIXEL_REFINEMENT:
        params.cornerRefinementMethod = cv2.aruco.CORNER_REFINE_SUBPIX

    if hasattr(cv2.aruco, "ArucoDetector"):
        return cv2.aruco.ArucoDetector(dictionary, params), dictionary, params

    return None, dictionary, params


def detect_markers(gray, detector, dictionary, params):
    if detector is not None:
        return detector.detectMarkers(gray)

    return cv2.aruco.detectMarkers(gray, dictionary, parameters=params)


# =============================================================================
# 3. GEOMETRIE
# =============================================================================

def edge_lengths_px(corners_xy: np.ndarray) -> list[float]:
    pts = np.asarray(corners_xy, dtype=np.float64).reshape(4, 2)
    return [
        float(np.linalg.norm(pts[(i + 1) % 4] - pts[i]))
        for i in range(4)
    ]


def marker_center_px(corners_xy: np.ndarray) -> tuple[float, float]:
    pts = np.asarray(corners_xy, dtype=np.float64).reshape(4, 2)
    center = np.mean(pts, axis=0)
    return float(center[0]), float(center[1])


def interior_angles_deg(corners_xy: np.ndarray) -> list[float]:
    """Berechnet die vier Innenwinkel des erkannten Marker-Vierecks in Grad."""
    pts = np.asarray(corners_xy, dtype=np.float64).reshape(4, 2)
    angles: list[float] = []

    for i in range(4):
        p_prev = pts[(i - 1) % 4]
        p = pts[i]
        p_next = pts[(i + 1) % 4]

        v1 = p_prev - p
        v2 = p_next - p

        n1 = np.linalg.norm(v1)
        n2 = np.linalg.norm(v2)

        if n1 <= 0 or n2 <= 0:
            angles.append(float("nan"))
            continue

        cos_angle = float(np.dot(v1, v2) / (n1 * n2))
        cos_angle = float(np.clip(cos_angle, -1.0, 1.0))
        angles.append(float(np.degrees(np.arccos(cos_angle))))

    return angles


def calculate_local_scale(corners_xy: np.ndarray, marker_size_mm: float) -> dict[str, Any]:
    lengths = edge_lengths_px(corners_xy)
    mean_edge_px = float(np.mean(lengths))

    if mean_edge_px <= 0:
        raise ValueError("Ungültige mittlere Marker-Kantenlänge.")

    mm_per_px = float(marker_size_mm / mean_edge_px)
    px_per_mm = float(mean_edge_px / marker_size_mm)
    min_edge_px = float(np.min(lengths))
    max_edge_px = float(np.max(lengths))
    center_x, center_y = marker_center_px(corners_xy)

    angles = interior_angles_deg(corners_xy)
    angle_deviations = [
        float(angle - 90.0) if np.isfinite(angle) else None
        for angle in angles
    ]
    valid_abs_deviations = [
        abs(v) for v in angle_deviations if v is not None
    ]

    mean_abs_angle_deviation_deg = (
        float(np.mean(valid_abs_deviations))
        if valid_abs_deviations else None
    )
    max_abs_angle_deviation_deg = (
        float(np.max(valid_abs_deviations))
        if valid_abs_deviations else None
    )

    max_abs_angle_deviation_percent = (
        float(max_abs_angle_deviation_deg / 90.0 * 100.0)
        if max_abs_angle_deviation_deg is not None
        else None
    )

    return {
        "marker_size_mm": float(marker_size_mm),
        "mm_per_px": mm_per_px,
        "px_per_mm": px_per_mm,
        "mean_edge_px": mean_edge_px,
        "edge_lengths_px": lengths,
        "edge_spread_percent": float(
            100.0 * (max_edge_px - min_edge_px) / mean_edge_px
        ),
        "interior_angles_deg": angles,
        "angle_deviation_from_90_deg": angle_deviations,
        "mean_abs_angle_deviation_deg": mean_abs_angle_deviation_deg,
        "max_abs_angle_deviation_deg": max_abs_angle_deviation_deg,
        "max_abs_angle_deviation_percent": max_abs_angle_deviation_percent,
        "center_px": [center_x, center_y],
    }


# =============================================================================
# 4. BILDER
# =============================================================================

def find_images() -> list[Path]:
    image_dir = IMAGE_DIR.expanduser().resolve()

    if not image_dir.is_dir():
        raise FileNotFoundError(f"IMAGE_DIR nicht gefunden: {image_dir}")

    valid_ext = {e.lower() for e in IMAGE_EXTENSIONS}
    images = sorted(
        p for p in image_dir.iterdir()
        if p.is_file() and p.suffix.lower() in valid_ext
    )

    if not images:
        raise FileNotFoundError(f"Keine Bilder in {image_dir} gefunden.")

    return images


def analyze_image(image_path: Path, detector, dictionary, params) -> dict[str, Any]:
    image = cv2.imread(str(image_path), cv2.IMREAD_COLOR)

    if image is None:
        return {
            "image_name": image_path.name,
            "status": "image_read_error",
            "scales": {},
        }

    gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
    corners, ids, _ = detect_markers(gray, detector, dictionary, params)

    result = {
        "image_name": image_path.name,
        "image_path": str(image_path),
        "image_width_px": int(image.shape[1]),
        "image_height_px": int(image.shape[0]),
        "status": "ok",
        "scales": {},
    }

    if ids is None or len(ids) == 0:
        result["status"] = "no_markers_found"
        for marker_id, cfg in MARKERS.items():
            result["scales"][cfg["position_name"]] = {
                "marker_id": marker_id,
                "status": "not_found",
                "marker_size_mm": float(cfg["size_mm"]),
                "mm_per_px": None,
            }
        return result

    ids_flat = ids.flatten().astype(int)
    detected = {
        int(marker_id): corners[i][0]
        for i, marker_id in enumerate(ids_flat)
    }

    partial = False

    for marker_id, cfg in MARKERS.items():
        pos = str(cfg["position_name"])
        size_mm = float(cfg["size_mm"])

        if marker_id not in detected:
            partial = True
            result["scales"][pos] = {
                "marker_id": marker_id,
                "status": "not_found",
                "marker_size_mm": size_mm,
                "mm_per_px": None,
            }
            continue

        try:
            data = calculate_local_scale(detected[marker_id], size_mm)
            result["scales"][pos] = {
                "marker_id": marker_id,
                "status": "ok",
                **data,
            }
        except Exception as exc:
            partial = True
            result["scales"][pos] = {
                "marker_id": marker_id,
                "status": "calculation_error",
                "marker_size_mm": size_mm,
                "mm_per_px": None,
                "error": str(exc),
            }

    # Prozentuale Abweichung des lokalen Maßstabs relativ zum Marker 0
    # (Bildmitte). Marker 0 erhält definitionsgemäß 0 %.
    center_position = str(MARKERS[0]["position_name"])
    center_mm_per_px = result["scales"].get(center_position, {}).get("mm_per_px")
    center_px_per_mm = result["scales"].get(center_position, {}).get("px_per_mm")

    for marker_id, cfg in MARKERS.items():
        pos = str(cfg["position_name"])
        current_mm_per_px = result["scales"].get(pos, {}).get("mm_per_px")
        current_px_per_mm = result["scales"].get(pos, {}).get("px_per_mm")

        mm_per_px_deviation_percent = None
        if (
            center_mm_per_px is not None
            and current_mm_per_px is not None
            and float(center_mm_per_px) != 0.0
        ):
            mm_per_px_deviation_percent = float(
                100.0
                * (float(current_mm_per_px) - float(center_mm_per_px))
                / float(center_mm_per_px)
            )

        px_per_mm_deviation_percent = None
        if (
            center_px_per_mm is not None
            and current_px_per_mm is not None
            and float(center_px_per_mm) != 0.0
        ):
            px_per_mm_deviation_percent = float(
                100.0
                * (float(current_px_per_mm) - float(center_px_per_mm))
                / float(center_px_per_mm)
            )

        if pos in result["scales"]:
            result["scales"][pos][
                "mm_per_px_deviation_vs_center_percent"
            ] = mm_per_px_deviation_percent
            result["scales"][pos][
                "px_per_mm_deviation_vs_center_percent"
            ] = px_per_mm_deviation_percent

            # Rückwärtskompatibler Alias:
            result["scales"][pos][
                "scale_deviation_vs_center_percent"
            ] = mm_per_px_deviation_percent

    if partial:
        result["status"] = "partial"

    return result


# =============================================================================
# 5. AUSGABE
# =============================================================================

def json_safe(value: Any) -> Any:
    if value is None or isinstance(value, (str, int, float, bool)):
        return value
    if isinstance(value, Path):
        return str(value)
    if isinstance(value, np.generic):
        return value.item()
    if isinstance(value, np.ndarray):
        return value.tolist()
    if isinstance(value, dict):
        return {str(k): json_safe(v) for k, v in value.items()}
    if isinstance(value, (list, tuple)):
        return [json_safe(v) for v in value]
    return str(value)


def write_json_report(path: Path, results: list[dict[str, Any]]) -> None:
    payload = {
        "configuration": {
            "image_dir": str(IMAGE_DIR.expanduser().resolve()),
            "output_dir": str(OUTPUT_DIR.expanduser().resolve()),
            "aruco_dictionary": ARUCO_DICTIONARY_NAME,
            "subpixel_refinement": USE_SUBPIXEL_REFINEMENT,
            "markers": {str(k): v for k, v in MARKERS.items()},
            "formula": (
                "mm_per_px = marker_size_mm / mean_of_4_marker_edges_px"
            ),
            "angle_definition": (
                "max_abs_angle_deviation_deg = maximale absolute Abweichung "
                "der 4 Marker-Innenwinkel von 90 Grad; "
                "max_abs_angle_deviation_percent = diese Abweichung / 90 * 100"
            ),
            "percentage_definition": (
                "mm_per_px_deviation_vs_center_percent = prozentuale Änderung "
                "von mm/px relativ zu Marker 0; "
                "px_per_mm_deviation_vs_center_percent = prozentuale Änderung "
                "von px/mm relativ zu Marker 0"
            ),
        },
        "images": results,
    }

    path.write_text(
        json.dumps(json_safe(payload), indent=2, ensure_ascii=False),
        encoding="utf-8",
    )


def fmt(value: Any) -> str:
    if value is None:
        return "-"
    return f"{float(value):.8f}"


def write_txt_report(path: Path, results: list[dict[str, Any]]) -> None:
    headers = [
        "Bild",
        "Mitte [mm/px]",
        "Mitte Winkelabw. [°]",
        "Links-Mitte [mm/px]",
        "Links-Mitte Winkelabw. [°]",
        "Links-Mitte mm/px Abw. [%]",
        "Links-Mitte Winkelabw. [%]",
        "Links-Oben [mm/px]",
        "Links-Oben Winkelabw. [°]",
        "Links-Oben mm/px Abw. [%]",
        "Links-Oben Winkelabw. [%]",
        "Status",
    ]

    # Explizite Positionsnamen für die Tabellenspalten.
    # Dadurch bleibt die Ausgabe korrekt, auch wenn Marker-IDs getauscht werden.
    center_position = "bildmitte"
    left_mid_position = "bildmitte_links"
    left_top_position = "bild_links_oben"

    def fmt_angle(value: Any) -> str:
        if value is None:
            return "-"
        return f"{float(value):.4f}"

    def fmt_percent(value: Any) -> str:
        if value is None:
            return "-"
        return f"{float(value):+.4f}"

    rows = []
    for result in results:
        scales = result.get("scales", {})

        center = scales.get(center_position, {})
        left_mid = scales.get(left_mid_position, {})
        left_top = scales.get(left_top_position, {})

        rows.append([
            result["image_name"],

            fmt(center.get("mm_per_px")),
            fmt_angle(center.get("max_abs_angle_deviation_deg")),

            fmt(left_mid.get("mm_per_px")),
            fmt_angle(left_mid.get("max_abs_angle_deviation_deg")),
            fmt_percent(left_mid.get("mm_per_px_deviation_vs_center_percent")),
            fmt_percent(left_mid.get("max_abs_angle_deviation_percent")),

            fmt(left_top.get("mm_per_px")),
            fmt_angle(left_top.get("max_abs_angle_deviation_deg")),
            fmt_percent(left_top.get("mm_per_px_deviation_vs_center_percent")),
            fmt_percent(left_top.get("max_abs_angle_deviation_percent")),

            result["status"],
        ])

    widths = [
        max(len(headers[i]), max((len(r[i]) for r in rows), default=0))
        for i in range(len(headers))
    ]

    def row_to_str(row):
        return " | ".join(str(v).ljust(widths[i]) for i, v in enumerate(row))

    separator = "-+-".join("-" * w for w in widths)

    lines = [
        "ARUCO - LOKALE SKALIERUNG",
        "=" * 80,
        "",
        f"Dictionary: {ARUCO_DICTIONARY_NAME}",
        "",
        "Marker:",
        f"  ID 0 -> Bildmitte       | {MARKERS[0]['size_mm']} mm",
        f"  ID 1 -> Bild links oben | {MARKERS[1]['size_mm']} mm",
        f"  ID 2 -> Bildmitte links | {MARKERS[2]['size_mm']} mm",
        "",
        "Formel:",
        "  mm/px = reale Marker-Kantenlänge [mm] / mittlere der 4 Marker-Kanten [px]",
        "",
        row_to_str(headers),
        separator,
    ]

    lines.extend(row_to_str(r) for r in rows)

    lines += [
        "",
        "Hinweis:",
        "Winkelabw. [°] = maximale absolute Abweichung eines der vier",
        "Marker-Innenwinkel von idealen 90 Grad.",
        "",
        "mm/px Abw. [%] = prozentuale Änderung der Umrechnung von Pixel zu",
        "Millimeter relativ zu Marker 0 in der Bildmitte.",
        "",
        "Winkelabw. [%] = maximale absolute Abweichung eines Marker-Innenwinkels",
        "von 90 Grad, relativ zu 90 Grad:",
        "  Winkelabw. [%] = max(|alpha - 90 Grad|) / 90 Grad * 100",
        "",
        "Die mm/px-Prozentabweichung bezieht sich weiterhin auf Marker 0",
        "in der Bildmitte als 0-%-Referenz.",
        "",
        "Beispiel: +5 % bei mm/px bedeutet, dass 1 Pixel an dieser Position",
        "5 % mehr Millimeter repräsentiert als in der Bildmitte.",
        "",
        "Unterschiedliche mm/px-Werte und Winkelabweichungen an den drei",
        "Positionen weisen auf perspektivische bzw. optische Verzerrungen hin.",
        "",
    ]

    path.write_text("\n".join(lines), encoding="utf-8")


# =============================================================================
# 6. MAIN
# =============================================================================

def main() -> None:
    validate_marker_configuration()
    images = find_images()
    out_dir = OUTPUT_DIR.expanduser().resolve()
    out_dir.mkdir(parents=True, exist_ok=True)

    detector, dictionary, params = create_detector()

    results = []

    print(f"Gefundene Bilder: {len(images)}")
    print(f"Dictionary: {ARUCO_DICTIONARY_NAME}")
    print()

    for i, image_path in enumerate(images, start=1):
        print(f"[{i}/{len(images)}] {image_path.name}")

        result = analyze_image(
            image_path,
            detector,
            dictionary,
            params,
        )
        results.append(result)

        for marker_id, cfg in MARKERS.items():
            data = result["scales"].get(cfg["position_name"], {})
            value = data.get("mm_per_px")

            if value is None:
                print(f"  ID {marker_id}: nicht erkannt")
            else:
                print(
                    f"  ID {marker_id} ({cfg['position_name']}): "
                    f"{value:.8f} mm/px"
                )

    json_path = out_dir / "aruco_scale_report.json"
    txt_path = out_dir / "aruco_scale_report.txt"

    write_json_report(json_path, results)
    write_txt_report(txt_path, results)

    print()
    print("Fertig.")
    print(f"JSON: {json_path}")
    print(f"TXT : {txt_path}")


if __name__ == "__main__":
    main()
