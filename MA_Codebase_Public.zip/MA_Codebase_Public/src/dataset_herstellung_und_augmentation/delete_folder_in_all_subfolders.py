#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Loescht in allen direkten RUNNAME-Ordnern unter ``outputs`` den direkten
Unterordner mit dem exakten Namen ``XXX``.

Alle Einstellungen werden direkt im Konfigurationsblock gesetzt. Mit
``DRY_RUN = False`` werden die gefundenen Ordner beim normalen Start ohne
Terminalabfrage geloescht:

    python delete_folder.py
"""

from __future__ import annotations

import shutil
from pathlib import Path


OUTPUTS_DIR = Path("/home/mitte/crack_project/outputs")
TARGET_FOLDER_NAME = "perfect_labels_test"

# False = beim Start sofort und ohne Terminalabfrage loeschen.
# True  = nur anzeigen, welche Ordner geloescht wuerden.
DRY_RUN = False


def validate_folder_name(folder_name: str) -> str:
    """Erlaubt nur einen einzelnen, nicht leeren Ordnernamen."""
    value = folder_name.strip()
    if not value or value in {".", ".."}:
        raise ValueError("Der Ordnername darf nicht leer, '.' oder '..' sein.")
    if Path(value).name != value or "/" in value or "\\" in value:
        raise ValueError(
            "--folder-name darf nur einen einzelnen Ordnernamen enthalten, keinen Pfad."
        )
    return value


def find_targets(outputs_dir: Path, folder_name: str) -> tuple[list[Path], list[Path]]:
    """
    Sucht ausschliesslich direkte Pfade ``outputs/RUNNAME/folder_name``.

    Symbolische Links werden aus Sicherheitsgruenden nicht verfolgt und separat
    zur Warnung zurueckgegeben.
    """
    targets: list[Path] = []
    skipped_symlinks: list[Path] = []

    for run_dir in sorted(outputs_dir.iterdir(), key=lambda path: path.name.casefold()):
        if not run_dir.is_dir() or run_dir.is_symlink():
            continue

        candidate = run_dir / folder_name
        if candidate.is_symlink():
            skipped_symlinks.append(candidate)
        elif candidate.is_dir():
            targets.append(candidate)

    return targets, skipped_symlinks


def validate_target(target: Path, outputs_dir: Path, folder_name: str) -> None:
    """Letzte Schutzpruefung unmittelbar vor ``shutil.rmtree``."""
    if target.name != folder_name:
        raise RuntimeError(f"Unerwarteter Zielname: {target}")
    if target.parent.parent != outputs_dir:
        raise RuntimeError(f"Ziel liegt nicht direkt in einem RUNNAME-Ordner: {target}")
    if target.is_symlink():
        raise RuntimeError(f"Symbolischer Link wird nicht geloescht: {target}")
    if not target.is_dir():
        raise RuntimeError(f"Ziel ist kein vorhandener Ordner: {target}")


def main() -> int:
    folder_name = validate_folder_name(TARGET_FOLDER_NAME)
    outputs_dir = OUTPUTS_DIR.expanduser().resolve()

    if not outputs_dir.is_dir():
        print(f"FEHLER: outputs-Ordner existiert nicht: {outputs_dir}")
        return 2

    targets, skipped_symlinks = find_targets(outputs_dir, folder_name)

    print(f"Outputs-Ordner: {outputs_dir}")
    print(f"Gesuchter Unterordner: {folder_name!r}")
    print(f"Gefundene echte Ordner: {len(targets)}")
    for target in targets:
        print(f"  - {target}")

    if skipped_symlinks:
        print("\nWARNUNG: Folgende symbolische Links werden nicht geloescht:")
        for path in skipped_symlinks:
            print(f"  - {path}")

    if not targets:
        print("\nNichts zu loeschen.")
        return 0

    if DRY_RUN:
        print("\nDRY-RUN: Es wurde nichts geloescht.")
        print("Zum Loeschen DRY_RUN oben im Code auf False setzen.")
        return 0

    deleted = 0
    errors: list[tuple[Path, Exception]] = []
    for target in targets:
        try:
            validate_target(target, outputs_dir, folder_name)
            shutil.rmtree(target)
            deleted += 1
            print(f"[GELOESCHT] {target}")
        except Exception as exc:
            errors.append((target, exc))
            print(f"[FEHLER] {target}: {exc}")

    print(f"\nFertig: {deleted}/{len(targets)} Ordner geloescht.")
    if errors:
        print(f"Fehler: {len(errors)}")
        return 1
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
