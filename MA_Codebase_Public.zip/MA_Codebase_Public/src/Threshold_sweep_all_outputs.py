#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Threshold-Suche fuer binaere Risssegmentierung mit Keras/TensorFlow.

Es werden ZWEI Auswertungen parallel in EINEM Inferenzlauf berechnet:

A) GLOBAL
   Alle Validierungspixel werden ausgewertet.

B) BALANCED CRACK ROI
   Pro Bild:
   1. Alle Ground-Truth-Risspixel werden verwendet.
   2. Negative Pixel werden bevorzugt aus einem konfigurierbaren Ring um den
      Ground-Truth-Riss gezogen (Standard: 10 px).
   3. Falls der Ring nicht genug negative Pixel liefert, wird die Restmenge
      zufaellig aus dem weiter entfernten Hintergrund aufgefuellt.
   4. Die Anzahl der negativen ROI-Pixel wird auf die Anzahl der positiven
      Risspixel begrenzt:
          N_neg = N_pos
      Damit ist die betrachtete ROI-Pixelmenge ungefaehr 50/50 balanciert.
   5. Ist der Ring selbst groesser als N_pos, wird deterministisch zufaellig
      aus dem Ring auf N_pos heruntergesampelt.

Primaere Threshold-Auswahl:
- Der finale Threshold wird standardmaessig aus der BALANCED CRACK ROI ueber
  minimalen Balanced Error bestimmt:
      FPR = FP / (FP + TN)
      FNR = FN / (FN + TP)
      Balanced Error = 0.5 * (FPR + FNR)
- Zusaetzlich werden best Dice/F1, best IoU, best F2 und der
  Equal-Error-aehnliche Punkt min |FPR-FNR| fuer GLOBAL und ROI geloggt.

Zusaetzliche Diagnose:
- Wahrscheinlichkeitsverteilung p(y=1 | GT=1) und p(y=1 | GT=0)
  ueber ALLE Validierungspixel
- Quantile 1 %, 5 %, 25 %, Median, 75 %, 95 %, 99 %
- Histogramm beider Verteilungen
- ROI-Sampling-Statistik

WICHTIG:
Die ROI-Metriken beantworten eine andere Frage als die globalen Metriken.
Precision/Dice/IoU der ROI sind nur innerhalb dieser bewusst gesampelten,
rissnahen und 50/50-balancierten Evaluationsmenge zu interpretieren.
Die globale Auswertung bleibt deshalb parallel erhalten.
"""

from __future__ import annotations

# ============================================================
# WICHTIG: Environment VOR TensorFlow setzen
# ============================================================

import os

# Weniger TensorFlow-Logspam
os.environ["TF_CPP_MIN_LOG_LEVEL"] = "2"

# TensorFlow soll nicht direkt den ganzen GPU-Speicher reservieren
os.environ["TF_FORCE_GPU_ALLOW_GROWTH"] = "true"

# XLA wird weiter unten kontrolliert ueber XLA_JIT aktiviert/deaktiviert.
os.environ["XLA_FLAGS"] = "--xla_gpu_cuda_data_dir=/usr/local/cuda"

# Falls du komplett auf CPU testen willst, setze das auf True.
# Achtung: Muss vor import tensorflow passieren.
FORCE_CPU = False
if FORCE_CPU:
    os.environ["CUDA_VISIBLE_DEVICES"] = "-1"

from pathlib import Path
import csv
import gc
import json
import re
import shutil
import traceback
import cv2
import matplotlib.pyplot as plt
import numpy as np
import tensorflow as tf
from keras import mixed_precision
from tqdm import tqdm

# GPU Memory Growth aktivieren
try:
    gpus = tf.config.list_physical_devices("GPU")
    if gpus:
        for gpu in gpus:
            tf.config.experimental.set_memory_growth(gpu, True)
except RuntimeError as e:
    print("Warnung: GPU memory_growth konnte nicht gesetzt werden.")
    print("Grund:", e)


# ============================================================
# EINSTELLUNGEN
# ============================================================

# EINZIGER PFAD, DEN DU ANPASSEN MUSST:
OUTPUTS_ROOT = Path("/home/mitte/crack_project/outputs")

# Alle Runs verwenden 512 x 512 px. Dieser Wert wird zusaetzlich gegen den
# tatsaechlichen Modellinput validiert.
IMG_SIZE = 512

# Name des Ergebnisordners in jedem Run-Verzeichnis. Existiert er bereits,
# wird der Run vollstaendig uebersprungen.
THRESHOLD_RESULTS_DIRNAME = "threshold_results2"

# Temporaerer Ordner waehrend eines Sweeps. Erst nach erfolgreichem Abschluss
# wird er atomar (soweit vom Dateisystem unterstuetzt) in threshold_results2
# umbenannt. So gilt: threshold_results2 vorhanden == Sweep abgeschlossen.
THRESHOLD_RESULTS_TMP_DIRNAME = "threshold_results2_in_progress"

# Standardwert. Bei 1024 px kann Batch 8 je nach Modell/VRAM zu gross sein.
BATCH_SIZE = 8

# Geschwindigkeitsoptionen analog zum Trainingscode.
XLA_JIT = True
MIXED_PRECISION_POLICY = "mixed_float16"
# Hinweis: STEPS_PER_EXECUTION wirkt nur bei model.fit/evaluate/predict.
# Die Threshold-Suche nutzt einen direkten tf.function-Inferenzpfad; der Wert
# wird deshalb nur dokumentiert und nicht kuenstlich auf die Schleife angewendet.
STEPS_PER_EXECUTION = 16

if XLA_JIT:
    tf.config.optimizer.set_jit("autoclustering")
else:
    tf.config.optimizer.set_jit(False)

mixed_precision.set_global_policy(MIXED_PRECISION_POLICY)

# Falls deine Masken 0/255 sind, True lassen.
# Falls deine Masken bereits 0/1 sind, funktioniert True meistens ebenfalls.
NORMALIZE_MASK_TO_01 = True

# False, wenn dein Modell am Ende bereits Sigmoid hat.
# True, wenn dein Modell rohe Logits ausgibt.
APPLY_SIGMOID = False

# Falls dein Modellausgang groesser/kleiner als die Maske ist, wird die Prediction
# automatisch auf Maskengroesse resized.
AUTO_RESIZE_PRED_TO_MASK = True

# GC nach jedem Batch kostet deutlich Zeit. Normalerweise ist False schneller
# und durch Streaming/GPU-Memory-Growth weiterhin speicherschonend.
GC_EVERY_BATCH = False

EPS = 1e-7

# Toleranz fuer minimale numerische Ueberschreitungen bei bereits sigmoidierten
# Wahrscheinlichkeiten. Groessere Abweichungen werden NICHT mehr durch clip()
# versteckt, sondern als wahrscheinlicher Logit-/Output-Konfigurationsfehler gemeldet.
PROBABILITY_RANGE_TOLERANCE = 1e-6

# ============================================================
# THRESHOLD-SUCHRASTER
# ============================================================
#
# Der bisherige Lauf hat gezeigt, dass der relevante Arbeitspunkt fuer dieses
# Modell im sehr kleinen Wahrscheinlichkeitsbereich liegt. Deshalb wird dort
# NICHT mehr nur 1e-5 -> 1e-4 getestet, sondern sehr fein gesucht.
#
# A) Extrembereich logarithmisch:
#    1e-10 bis 1e-3 mit vielen logarithmisch verteilten Punkten.
#
# B) Kritischer Bereich linear sehr fein:
#    1e-6 bis 5e-4 in Schritten von 1e-7.
#    Damit kann z.B. zwischen 0.0000100 und 0.0001000 sehr fein unterschieden
#    werden. Die absolute Rasteraufloesung betraegt dort 0.0000001.
#
# C) Uebergangsbereich:
#    0.001 bis 0.009 in 0.001-Schritten, damit relevante Arbeitspunkte in
#    diesem Bereich (z.B. ein F2-Optimum) nicht verloren gehen.
#
# D) Restlicher Bereich:
#    0.01 bis 0.99 in 0.01-Schritten.
#    Der sehr kleine Bereich bleibt separat fein aufgeloest; groessere
#    Wahrscheinlichkeiten werden bewusst nur noch grob als Referenz geprueft.
#
# D) Sehr hohe Randwerte als Absicherung.
#
# Alle Raster werden vereinigt und Duplikate entfernt. Die komplette Menge
# wird im selben Inferenzlauf ausgewertet.

LOG_THRESHOLD_MIN = 1e-10
LOG_THRESHOLD_MAX = 1e-3
LOG_THRESHOLD_POINTS = 2501

LOW_FINE_MIN = 1e-6
LOW_FINE_MAX = 5e-4
LOW_FINE_STEP = 1e-7

MID_THRESHOLD_STEP = 0.001
REGULAR_THRESHOLD_STEP = 0.01

EXTRA_HIGH_THRESHOLDS = [
    0.9995,
    0.9999,
    0.99999,
    0.999999,
    0.9999999,
]

# Thresholds werden intern auf 10 Nachkommastellen normalisiert.
THRESHOLD_ROUND_DECIMALS = 10

# Fuer die dritte finale Entscheidung: niedrigste FNR unter einer maximalen FPR.
FPR_CONSTRAINT_MAX = 0.02

# Streaming-Histogramm fuer p(y=1|GT). 100001 Bins => Aufloesung ca. 1e-5.
# Die Quantile werden daraus approximiert, ohne Milliarden Pixelwerte im RAM zu halten.
PROBABILITY_HIST_BINS = 100001
PROBABILITY_QUANTILES = [0.01, 0.05, 0.25, 0.50, 0.75, 0.95, 0.99]

# ============================================================
# BALANCED CRACK ROI SAMPLING
# ============================================================

# Radius des rissnahen Hintergrundbereichs in Pixeln.
# Ein Wert von 10 bedeutet: negative Pixel bis etwa 10 px um den GT-Riss
# werden bevorzugt fuer die ROI-Auswertung verwendet.
ROI_RING_RADIUS_PX = 10

# Zielverhaeltnis negative : positive Pixel in der ROI.
# 1.0 => N_neg = N_pos => ca. 50/50.
ROI_NEGATIVE_TO_POSITIVE_RATIO = 1.0

# Reproduzierbares Sampling der Hintergrundpixel.
ROI_RANDOM_SEED = 42

# Falls eine Maske keine positiven Risspixel besitzt, kann keine 50/50-ROI
# gebildet werden. Solche Bilder bleiben in GLOBAL enthalten, werden fuer ROI
# aber uebersprungen.
ROI_SKIP_EMPTY_POSITIVE_MASKS = True




# ============================================================
# CUSTOM LAYER FUER ViT-BLOCK
# ============================================================

@tf.keras.utils.register_keras_serializable(package="crack_segmentation")
class AddPositionEmbedding(tf.keras.layers.Layer):
    """Custom Position-Embedding-Layer fuer ViT-Bloecke."""

    def __init__(self, num_tokens, embed_dim, **kwargs):
        super().__init__(**kwargs)
        self.num_tokens = int(num_tokens)
        self.embed_dim = int(embed_dim)

    def build(self, input_shape):
        self.pos_embedding = self.add_weight(
            name="pos_embedding",
            shape=(1, self.num_tokens, self.embed_dim),
            initializer="random_normal",
            trainable=True,
            dtype=self.dtype,
        )
        super().build(input_shape)

    def call(self, x):
        pos_embedding = tf.cast(self.pos_embedding, x.dtype)
        return x + pos_embedding

    def get_config(self):
        config = super().get_config()
        config.update({
            "num_tokens": self.num_tokens,
            "embed_dim": self.embed_dim,
        })
        return config


# Bekannte Keras-Preprocessing-Funktionen explizit registrieren.
# Manche ältere/anders gespeicherte Lambda-Layer referenzieren die Funktion
# nur unter dem generischen Namen "preprocess_input". Keras kann diese Referenz
# beim Laden sonst nicht eindeutig auflösen.
from keras.applications.mobilenet_v2 import preprocess_input as mobilenet_v2_preprocess_input
from keras.applications.resnet50 import preprocess_input as resnet50_preprocess_input
from keras.applications.efficientnet import preprocess_input as efficientnet_preprocess_input
from keras.applications.xception import preprocess_input as xception_preprocess_input
from keras.applications.vgg16 import preprocess_input as vgg16_preprocess_input
from keras.applications.vgg19 import preprocess_input as vgg19_preprocess_input
from keras.applications.densenet import preprocess_input as densenet_preprocess_input


CUSTOM_OBJECTS = {
    "AddPositionEmbedding": AddPositionEmbedding,
    "crack_segmentation>AddPositionEmbedding": AddPositionEmbedding,

    # Der konkrete Fehler in deinem Traceback betrifft MobileNetV2.
    "preprocess_input": mobilenet_v2_preprocess_input,
    "mobilenetv2_preprocess_input": mobilenet_v2_preprocess_input,
    "mobilenet_v2_preprocess_input": mobilenet_v2_preprocess_input,

    # Zusätzliche Aliase für andere Backbones, falls weitere Runs
    # mit ähnlich gespeicherten Lambda-Preprocessing-Layern auftauchen.
    "resnet50_preprocess_input": resnet50_preprocess_input,
    "efficientnet_preprocess_input": efficientnet_preprocess_input,
    "xception_preprocess_input": xception_preprocess_input,
    "vgg16_preprocess_input": vgg16_preprocess_input,
    "vgg19_preprocess_input": vgg19_preprocess_input,
    "densenet_preprocess_input": densenet_preprocess_input,
}


def resolve_model_image_size(model, configured_img_size=None) -> int:
    """Ermittelt die quadratische Eingabegroesse robust aus dem Modell."""
    input_shape = model.input_shape

    if isinstance(input_shape, list):
        if len(input_shape) != 1:
            raise ValueError(
                f"Mehrere Modelleingaenge werden nicht unterstuetzt: {input_shape}"
            )
        input_shape = input_shape[0]

    if len(input_shape) != 4:
        raise ValueError(f"Unerwartete Modell-Input-Shape: {input_shape}")

    model_h, model_w, model_c = input_shape[1], input_shape[2], input_shape[3]

    if model_c not in (3, None):
        raise ValueError(
            f"Das Modell erwartet {model_c} Eingangskanaele statt RGB mit 3 Kanaelen."
        )

    if configured_img_size is not None:
        configured_img_size = int(configured_img_size)
        if model_h is not None and model_w is not None:
            if (configured_img_size, configured_img_size) != (model_h, model_w):
                raise ValueError(
                    f"IMG_SIZE={configured_img_size} passt nicht zum Modellinput "
                    f"{input_shape}. Setze IMG_SIZE=None fuer automatische Erkennung."
                )
        return configured_img_size

    if model_h is None or model_w is None:
        raise ValueError(
            "Das Modell besitzt eine dynamische raeumliche Eingabegroesse. "
            "Bitte IMG_SIZE explizit setzen."
        )

    if model_h != model_w:
        raise ValueError(
            f"Der Threshold-Test erwartet quadratische Eingaben, Modellinput ist {input_shape}."
        )

    return int(model_h)


# ============================================================
# HILFSFUNKTIONEN
# ============================================================

def load_model_with_custom_objects(model_path: Path):
    """
    Laedt ein Keras-Modell robust mit Custom Objects.

    Hintergrund:
    Neuere Keras-Versionen blockieren standardmaessig die Deserialisierung von
    Lambda-Layern, wenn deren Funktion als Python-Lambda gespeichert wurde.
    Fuer eigene/vertraute Modellartefakte kann safe_mode=False verwendet werden.

    Strategie:
    1. Zuerst normal mit safe_mode=True/default laden.
    2. Falls die Deserialisierung wegen eines Lambda-Layers fehlschlaegt,
       gezielt mit safe_mode=False erneut laden.
    3. Andere Fehler werden NICHT still verschluckt.
    """
    try:
        return tf.keras.models.load_model(
            model_path,
            compile=False,
            custom_objects=CUSTOM_OBJECTS,
        )

    except (TypeError, ValueError) as e:
        error_text = str(e)

        lambda_safe_mode_error = (
            "Lambda" in error_text
            and (
                "safe_mode" in error_text
                or "unsafe deserialization" in error_text.lower()
                or "Python lambda" in error_text
            )
        )

        # Manche Keras-Versionen werfen fuer safe_mode-bezogene Probleme
        # TypeError, andere ValueError.
        safe_mode_argument_issue = "safe_mode" in error_text

        if lambda_safe_mode_error or safe_mode_argument_issue:
            print()
            print("Normales Modell-Laden wurde von Keras Safe-Mode blockiert.")
            print(f"Modell: {model_path}")
            print(f"Grund:  {e}")
            print("Neuer Versuch mit safe_mode=False ...")

            return tf.keras.models.load_model(
                model_path,
                compile=False,
                safe_mode=False,
                custom_objects=CUSTOM_OBJECTS,
            )

        # Kein Lambda-/Safe-Mode-Problem -> echten Fehler weiterreichen.
        raise


def load_image(path: Path, img_size: int) -> np.ndarray:
    img = cv2.imread(str(path), cv2.IMREAD_COLOR)
    if img is None:
        raise ValueError(f"Bild konnte nicht gelesen werden: {path}")

    img = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
    img = cv2.resize(img, (img_size, img_size), interpolation=cv2.INTER_AREA)
    img = img.astype(np.float32) / 255.0
    return img


def load_mask(path: Path, img_size: int) -> np.ndarray:
    mask = cv2.imread(str(path), cv2.IMREAD_GRAYSCALE)
    if mask is None:
        raise ValueError(f"Maske konnte nicht gelesen werden: {path}")

    mask = cv2.resize(mask, (img_size, img_size), interpolation=cv2.INTER_NEAREST)

    if NORMALIZE_MASK_TO_01:
        mask = (mask > 127).astype(np.uint8)
    else:
        mask = mask.astype(np.uint8)

    mask = np.expand_dims(mask, axis=-1)
    return mask


def find_image_mask_pairs(image_dir: Path, mask_dir: Path):
    image_extensions = [".png", ".jpg", ".jpeg", ".tif", ".tiff", ".bmp"]

    image_paths = []
    for ext in image_extensions:
        image_paths.extend(image_dir.glob(f"*{ext}"))
        image_paths.extend(image_dir.glob(f"*{ext.upper()}"))

    image_paths = sorted(set(image_paths))
    pairs = []

    for img_path in image_paths:
        stem = img_path.stem
        possible_masks = []
        for ext in image_extensions:
            possible_masks.append(mask_dir / f"{stem}{ext}")
            possible_masks.append(mask_dir / f"{stem}{ext.upper()}")

        mask_path = next((p for p in possible_masks if p.exists()), None)

        if mask_path is not None:
            pairs.append((img_path, mask_path))
        else:
            print(f"Keine Maske gefunden fuer: {img_path.name}")

    if len(pairs) == 0:
        raise RuntimeError("Keine passenden Bild-Masken-Paare gefunden.")

    return pairs


def ensure_prediction_shape(preds: np.ndarray, masks: np.ndarray) -> np.ndarray:
    """Stellt sicher, dass preds die Form (B, H, W, 1) haben und zur Maskengroesse passen."""

    if isinstance(preds, (list, tuple)):
        preds = preds[0]

    preds = np.asarray(preds)

    if preds.ndim == 3:
        preds = np.expand_dims(preds, axis=-1)

    if preds.ndim != 4:
        raise ValueError(f"Unerwartete Prediction-Shape: {preds.shape}")

    if preds.shape[-1] != 1:
        print(f"Warnung: Prediction hat {preds.shape[-1]} Kanaele. Es wird Kanal 0 verwendet.")
        preds = preds[..., :1]

    if preds.shape[1:3] != masks.shape[1:3]:
        if not AUTO_RESIZE_PRED_TO_MASK:
            raise ValueError(
                f"Prediction-Shape {preds.shape} passt nicht zu Mask-Shape {masks.shape}. "
                f"Setze AUTO_RESIZE_PRED_TO_MASK=True oder pruefe dein Modell."
            )

        resized = []
        target_h, target_w = masks.shape[1], masks.shape[2]
        for i in range(preds.shape[0]):
            p = preds[i, ..., 0]
            p = cv2.resize(p, (target_w, target_h), interpolation=cv2.INTER_LINEAR)
            p = np.expand_dims(p, axis=-1)
            resized.append(p)
        preds = np.stack(resized, axis=0)

    return preds


def prepare_predictions_for_thresholding(preds: np.ndarray) -> np.ndarray:
    """Validiert den Modelloutput und wandelt ihn sicher in Wahrscheinlichkeiten um.

    APPLY_SIGMOID=True: Der Modelloutput wird als Logits interpretiert und sigmoidiert.
    APPLY_SIGMOID=False: Der Modelloutput MUSS bereits eine Wahrscheinlichkeit in [0, 1]
    sein. Werte deutlich ausserhalb dieses Bereichs fuehren zu einem Fehler statt zu
    stillem Abschneiden per np.clip(). Nur minimale numerische Ueberschreitungen innerhalb
    PROBABILITY_RANGE_TOLERANCE werden am Ende auf [0, 1] begrenzt.
    """
    preds = np.asarray(preds, dtype=np.float32)

    if not np.all(np.isfinite(preds)):
        raise RuntimeError("Modelloutput enthaelt NaN oder Inf. Threshold-Suche abgebrochen.")

    raw_min = float(np.min(preds))
    raw_max = float(np.max(preds))

    if APPLY_SIGMOID:
        preds = tf.nn.sigmoid(preds).numpy().astype(np.float32)
    else:
        tol = float(PROBABILITY_RANGE_TOLERANCE)
        if raw_min < -tol or raw_max > 1.0 + tol:
            raise RuntimeError(
                "Modelloutput liegt nicht im Wahrscheinlichkeitsbereich [0,1], "
                f"obwohl APPLY_SIGMOID=False ist: min={raw_min:.9g}, max={raw_max:.9g}. "
                "Das Modell gibt wahrscheinlich rohe Logits aus. Setze APPLY_SIGMOID=True "
                "oder pruefe die letzte Modellschicht. Die Werte werden absichtlich NICHT "
                "durch np.clip() versteckt."
            )

    # Nur gegen winzige numerische Rundungsueberschreitungen absichern.
    return np.clip(preds, 0.0, 1.0).astype(np.float32, copy=False)


def make_empty_accumulators(thresholds):
    thresholds = [float(np.round(t, THRESHOLD_ROUND_DECIMALS)) for t in thresholds]
    return {
        t: {
            "threshold": t,
            "tp": 0,
            "fp": 0,
            "fn": 0,
            "tn": 0,
        }
        for t in thresholds
    }


def update_accumulators(
    accumulators: dict,
    y_true: np.ndarray,
    y_prob: np.ndarray,
    positive_hist: np.ndarray | None = None,
    negative_hist: np.ndarray | None = None,
):
    """
    Aktualisiert TP/FP/FN/TN fuer alle Thresholds und optional die
    GT-getrennten Wahrscheinlichkeits-Histogramme.
    """
    y_true_flat = y_true.reshape(-1).astype(bool)
    y_prob_flat = y_prob.reshape(-1).astype(np.float32)

    threshold_keys = sorted(accumulators.keys())
    threshold_values = np.asarray(threshold_keys, dtype=np.float64)

    positive_scores = np.sort(y_prob_flat[y_true_flat])
    negative_scores = np.sort(y_prob_flat[~y_true_flat])

    total_positive = positive_scores.size
    total_negative = negative_scores.size

    tp_counts = total_positive - np.searchsorted(positive_scores, threshold_values, side="left")
    fp_counts = total_negative - np.searchsorted(negative_scores, threshold_values, side="left")
    fn_counts = total_positive - tp_counts
    tn_counts = total_negative - fp_counts

    for key, tp, fp, fn, tn in zip(
        threshold_keys, tp_counts, fp_counts, fn_counts, tn_counts
    ):
        acc = accumulators[key]
        acc["tp"] += int(tp)
        acc["fp"] += int(fp)
        acc["fn"] += int(fn)
        acc["tn"] += int(tn)

    # Streaming-Histogramm: jeder Pixel geht genau einmal in seine GT-Klasse ein.
    # Binning ueber [0,1] mit fester, sehr feiner Aufloesung.
    if positive_hist is not None and positive_scores.size:
        pos_idx = np.minimum(
            (positive_scores * (PROBABILITY_HIST_BINS - 1)).astype(np.int64),
            PROBABILITY_HIST_BINS - 1,
        )
        positive_hist += np.bincount(pos_idx, minlength=PROBABILITY_HIST_BINS).astype(np.int64)

    if negative_hist is not None and negative_scores.size:
        neg_idx = np.minimum(
            (negative_scores * (PROBABILITY_HIST_BINS - 1)).astype(np.int64),
            PROBABILITY_HIST_BINS - 1,
        )
        negative_hist += np.bincount(neg_idx, minlength=PROBABILITY_HIST_BINS).astype(np.int64)



def build_balanced_crack_roi_sample(
    y_true_2d: np.ndarray,
    y_prob_2d: np.ndarray,
    rng: np.random.Generator,
) -> tuple[np.ndarray, np.ndarray, dict]:
    """
    Erzeugt eine 50/50-balancierte Crack-ROI fuer EIN Bild.

    Positive Klasse:
        alle GT-Risspixel.

    Negative Klasse:
        bevorzugt Pixel aus dem ROI_RING_RADIUS_PX breiten Ring um den Riss.
        Falls Ringpixel fehlen, wird aus dem entfernten Hintergrund aufgefuellt.
        Falls der Ring bereits groesser als das Negativ-Ziel ist, wird nur aus
        dem Ring auf die Zielgroesse heruntergesampelt.

    Rueckgabe:
        sampled_true, sampled_prob, stats
    """
    y_true_bool = np.asarray(y_true_2d).astype(bool)
    y_prob = np.asarray(y_prob_2d, dtype=np.float32)

    if y_true_bool.shape != y_prob.shape:
        raise ValueError(
            f"ROI: GT-Shape {y_true_bool.shape} passt nicht zu Prediction-Shape {y_prob.shape}."
        )

    positive_flat = np.flatnonzero(y_true_bool.reshape(-1))
    n_pos = int(positive_flat.size)

    stats = {
        "positive_pixels": n_pos,
        "ring_pixels_available": 0,
        "ring_pixels_sampled": 0,
        "far_background_available": 0,
        "far_background_sampled": 0,
        "negative_pixels_sampled": 0,
        "ring_was_downsampled": False,
        "skipped_no_positive": False,
        "negative_shortfall": 0,
    }

    if n_pos == 0:
        stats["skipped_no_positive"] = True
        return (
            np.empty(0, dtype=np.uint8),
            np.empty(0, dtype=np.float32),
            stats,
        )

    radius = int(ROI_RING_RADIUS_PX)
    if radius < 0:
        raise ValueError("ROI_RING_RADIUS_PX darf nicht negativ sein.")

    if radius == 0:
        dilated = y_true_bool.copy()
    else:
        kernel_size = 2 * radius + 1
        kernel = cv2.getStructuringElement(
            cv2.MORPH_ELLIPSE,
            (kernel_size, kernel_size),
        )
        dilated = cv2.dilate(
            y_true_bool.astype(np.uint8),
            kernel,
            iterations=1,
        ).astype(bool)

    ring_mask = np.logical_and(dilated, ~y_true_bool)
    far_mask = ~dilated

    ring_flat = np.flatnonzero(ring_mask.reshape(-1))
    far_flat = np.flatnonzero(far_mask.reshape(-1))

    stats["ring_pixels_available"] = int(ring_flat.size)
    stats["far_background_available"] = int(far_flat.size)

    target_neg = int(round(n_pos * float(ROI_NEGATIVE_TO_POSITIVE_RATIO)))
    target_neg = max(0, target_neg)

    if target_neg == 0:
        negative_flat = np.empty(0, dtype=np.int64)

    elif ring_flat.size >= target_neg:
        # Der Ring allein ist bereits gross genug. Um die 50/50-Balance zu
        # erhalten, werden nur target_neg Ringpixel gezogen.
        if ring_flat.size == target_neg:
            sampled_ring = ring_flat
        else:
            sampled_ring = rng.choice(ring_flat, size=target_neg, replace=False)
            stats["ring_was_downsampled"] = True

        sampled_far = np.empty(0, dtype=np.int64)
        negative_flat = np.asarray(sampled_ring, dtype=np.int64)

    else:
        # Alle Ringpixel verwenden und nur die fehlende Zahl aus dem weiter
        # entfernten Hintergrund auffuellen.
        sampled_ring = ring_flat
        remaining = target_neg - int(ring_flat.size)

        if remaining > 0 and far_flat.size > 0:
            n_far = min(remaining, int(far_flat.size))
            if n_far == far_flat.size:
                sampled_far = far_flat
            else:
                sampled_far = rng.choice(far_flat, size=n_far, replace=False)
        else:
            sampled_far = np.empty(0, dtype=np.int64)

        negative_flat = np.concatenate(
            [
                np.asarray(sampled_ring, dtype=np.int64),
                np.asarray(sampled_far, dtype=np.int64),
            ]
        )

    stats["ring_pixels_sampled"] = int(len(sampled_ring)) if target_neg else 0
    stats["far_background_sampled"] = int(len(sampled_far)) if target_neg else 0
    stats["negative_pixels_sampled"] = int(negative_flat.size)
    stats["negative_shortfall"] = max(0, target_neg - int(negative_flat.size))

    flat_prob = y_prob.reshape(-1)

    sampled_true = np.concatenate(
        [
            np.ones(n_pos, dtype=np.uint8),
            np.zeros(negative_flat.size, dtype=np.uint8),
        ]
    )
    sampled_prob = np.concatenate(
        [
            flat_prob[positive_flat],
            flat_prob[negative_flat],
        ]
    ).astype(np.float32, copy=False)

    return sampled_true, sampled_prob, stats


def make_empty_roi_sampling_stats() -> dict:
    return {
        "images_total": 0,
        "images_used": 0,
        "images_skipped_no_positive": 0,
        "images_ring_downsampled": 0,
        "positive_pixels": 0,
        "negative_pixels_sampled": 0,
        "ring_pixels_available": 0,
        "ring_pixels_sampled": 0,
        "far_background_available": 0,
        "far_background_sampled": 0,
        "negative_shortfall": 0,
    }


def accumulate_roi_sampling_stats(total: dict, sample: dict) -> None:
    total["images_total"] += 1

    if sample["skipped_no_positive"]:
        total["images_skipped_no_positive"] += 1
        return

    total["images_used"] += 1
    if sample["ring_was_downsampled"]:
        total["images_ring_downsampled"] += 1

    for key in (
        "positive_pixels",
        "negative_pixels_sampled",
        "ring_pixels_available",
        "ring_pixels_sampled",
        "far_background_available",
        "far_background_sampled",
        "negative_shortfall",
    ):
        total[key] += int(sample[key])


def quantiles_from_histogram(hist: np.ndarray, quantiles: list[float]) -> dict[str, float]:
    """Approximiert Quantile aus dem vollstaendig akkumulierten Streaming-Histogramm."""
    total = int(hist.sum())
    if total == 0:
        return {f"q{int(q * 100):02d}": float("nan") for q in quantiles}

    cdf = np.cumsum(hist, dtype=np.int64)
    result = {}
    for q in quantiles:
        target = max(1, int(np.ceil(q * total)))
        idx = int(np.searchsorted(cdf, target, side="left"))
        value = idx / float(PROBABILITY_HIST_BINS - 1)
        result[f"q{int(q * 100):02d}"] = float(value)
    return result


def probability_diagnostics_from_histograms(positive_hist: np.ndarray, negative_hist: np.ndarray) -> dict:
    return {
        "hist_bins": int(PROBABILITY_HIST_BINS),
        "hist_bin_width": 1.0 / float(PROBABILITY_HIST_BINS - 1),
        "positive_pixel_count": int(positive_hist.sum()),
        "negative_pixel_count": int(negative_hist.sum()),
        "gt_positive": quantiles_from_histogram(positive_hist, PROBABILITY_QUANTILES),
        "gt_negative": quantiles_from_histogram(negative_hist, PROBABILITY_QUANTILES),
        "positive_hist": positive_hist,
        "negative_hist": negative_hist,
    }

def metrics_from_accumulator(acc: dict) -> dict:
    tp = acc["tp"]
    fp = acc["fp"]
    fn = acc["fn"]
    tn = acc["tn"]

    precision = tp / (tp + fp + EPS)
    recall = tp / (tp + fn + EPS)
    dice = (2 * tp) / (2 * tp + fp + fn + EPS)
    iou = tp / (tp + fp + fn + EPS)
    f1 = dice

    beta = 2.0
    beta_sq = beta ** 2
    f2 = ((1.0 + beta_sq) * precision * recall) / (
        beta_sq * precision + recall + EPS
    )

    accuracy = (tp + tn) / (tp + tn + fp + fn + EPS)

    # Klassenbalancierte Fehleranteile:
    # FPR bewertet FP relativ zu allen tatsaechlich negativen Pixeln.
    # FNR bewertet FN relativ zu allen tatsaechlich positiven Pixeln.
    # Durch den Mittelwert gehen beide Klassen mit exakt gleichem Gewicht ein,
    # unabhaengig davon, wie stark Hintergrund- und Risspixel unausgeglichen sind.
    negative_pixels = fp + tn
    positive_pixels = tp + fn
    false_positive_rate = fp / (negative_pixels + EPS)
    false_negative_rate = fn / (positive_pixels + EPS)
    balanced_error = 0.5 * (false_positive_rate + false_negative_rate)
    balanced_accuracy = 1.0 - balanced_error

    return {
        "threshold": float(acc["threshold"]),
        "balanced_error": float(balanced_error),
        "balanced_accuracy": float(balanced_accuracy),
        "false_positive_rate": float(false_positive_rate),
        "false_negative_rate": float(false_negative_rate),
        "f2": float(f2),
        "dice": float(dice),
        "f1": float(f1),
        "iou": float(iou),
        "precision": float(precision),
        "recall": float(recall),
        "accuracy": float(accuracy),
        "tp": int(tp),
        "fp": int(fp),
        "fn": int(fn),
        "tn": int(tn),
    }


def build_inference_function(model):
    """Erzeugt einen kompakten, optional XLA-kompilierten Inferenzpfad."""

    @tf.function(jit_compile=XLA_JIT, reduce_retracing=True)
    def infer(images):
        return model(images, training=False)

    return infer


def evaluate_thresholds_streaming(
    model,
    inference_fn,
    pairs,
    thresholds,
    img_size: int,
    batch_size: int,
    desc: str,
):
    """
    Ein Inferenzdurchlauf ueber das komplette Validierungsset; es gibt kein 1600-Bilder-Limit.

    Parallel werden berechnet:
    A) GLOBAL: alle Pixel
    B) BALANCED CRACK ROI: alle GT-Risspixel + gleich viele gesampelte
       Hintergrundpixel, bevorzugt aus dem rissnahen Ring.

    Die GT-getrennten Wahrscheinlichkeits-Histogramme bleiben GLOBAL.
    """
    thresholds = sorted(set(float(np.round(t, THRESHOLD_ROUND_DECIMALS)) for t in thresholds))

    global_accumulators = make_empty_accumulators(thresholds)
    roi_accumulators = make_empty_accumulators(thresholds)

    positive_hist = np.zeros(PROBABILITY_HIST_BINS, dtype=np.int64)
    negative_hist = np.zeros(PROBABILITY_HIST_BINS, dtype=np.int64)

    roi_sampling_stats = make_empty_roi_sampling_stats()
    rng = np.random.default_rng(ROI_RANDOM_SEED)

    for start in tqdm(range(0, len(pairs), batch_size), desc=desc):
        batch_pairs = pairs[start:start + batch_size]
        imgs = []
        masks = []

        for img_path, mask_path in batch_pairs:
            imgs.append(load_image(img_path, img_size))
            masks.append(load_mask(mask_path, img_size))

        imgs = np.stack(imgs, axis=0).astype(np.float32)
        masks = np.stack(masks, axis=0).astype(np.uint8)

        preds = inference_fn(tf.convert_to_tensor(imgs, dtype=tf.float32))

        if isinstance(preds, tf.Tensor):
            preds = preds.numpy()
        elif isinstance(preds, (list, tuple)) and isinstance(preds[0], tf.Tensor):
            preds = preds[0].numpy()

        preds = ensure_prediction_shape(preds, masks)
        preds = prepare_predictions_for_thresholding(preds)

        # A) GLOBAL
        update_accumulators(
            global_accumulators,
            masks,
            preds,
            positive_hist=positive_hist,
            negative_hist=negative_hist,
        )

        # B) BALANCED CRACK ROI – pro Bild, damit Ring und Sampling immer zur
        # jeweiligen Ground-Truth-Geometrie gehoeren.
        for i in range(masks.shape[0]):
            gt_2d = masks[i, ..., 0]
            prob_2d = preds[i, ..., 0]

            roi_true, roi_prob, sample_stats = build_balanced_crack_roi_sample(
                gt_2d,
                prob_2d,
                rng,
            )
            accumulate_roi_sampling_stats(roi_sampling_stats, sample_stats)

            if roi_true.size == 0:
                continue

            update_accumulators(
                roi_accumulators,
                roi_true,
                roi_prob,
            )

        del imgs, masks, preds
        if GC_EVERY_BATCH:
            gc.collect()

    global_results = [
        metrics_from_accumulator(acc)
        for acc in global_accumulators.values()
    ]
    global_results = sorted(global_results, key=lambda x: x["threshold"])

    roi_results = [
        metrics_from_accumulator(acc)
        for acc in roi_accumulators.values()
    ]
    roi_results = sorted(roi_results, key=lambda x: x["threshold"])

    diagnostics = probability_diagnostics_from_histograms(
        positive_hist,
        negative_hist,
    )

    return global_results, roi_results, diagnostics, roi_sampling_stats


def merge_results_unique(*result_lists):
    """Fuehrt Ergebnislisten zusammen, ohne Thresholds doppelt zu speichern."""
    merged = {}
    for result_list in result_lists:
        for row in result_list:
            merged[round(float(row["threshold"]), 4)] = row
    return sorted(merged.values(), key=lambda x: x["threshold"])


def _threshold_range_001(lower: float, upper: float) -> list[float]:
    """Erzeugt inklusive Grenzen saubere 0.01-Schritte ohne Float-Artefakte."""
    lower_cent = int(round(min(lower, upper) * 100))
    upper_cent = int(round(max(lower, upper) * 100))
    return [cent / 100.0 for cent in range(lower_cent, upper_cent + 1)]


def _get_result_at_threshold(results: list[dict], threshold: float) -> dict:
    """Liefert den Ergebnisdatensatz eines exakt getesteten Thresholds."""
    threshold = round(float(threshold), 4)
    for row in results:
        if round(float(row["threshold"]), 4) == threshold:
            return row
    raise KeyError(f"Threshold {threshold:.4f} wurde nicht gefunden.")


def _find_bracketing_thresholds(
    coarse_results: list[dict],
    metric_name: str,
    target_value: float,
) -> tuple[float, float]:
    """
    Findet zwei benachbarte Grobsuch-Thresholds, zwischen deren Metrikwerten
    der Zielwert liegt. FP ist mit steigendem Threshold monoton fallend,
    FN monoton steigend; die Implementierung funktioniert fuer beide Richtungen.
    """
    rows = sorted(coarse_results, key=lambda x: x["threshold"])

    # Exakter Treffer: keine echte Intervallsuche noetig.
    for row in rows:
        if float(row[metric_name]) == float(target_value):
            t = float(row["threshold"])
            return t, t

    for left, right in zip(rows[:-1], rows[1:]):
        a = float(left[metric_name])
        b = float(right[metric_name])
        low_value = min(a, b)
        high_value = max(a, b)
        if low_value <= target_value <= high_value:
            return float(left["threshold"]), float(right["threshold"])

    # Sollte bei monotonen FP/FN-Verlaeufen und Zielwerten zwischen den
    # Randwerten nicht auftreten. Als robuste Rueckfalle wird um den naechsten
    # Grobsuchpunkt herum ein benachbartes Intervall gewaehlt.
    closest_index = min(
        range(len(rows)),
        key=lambda i: abs(float(rows[i][metric_name]) - target_value),
    )
    if closest_index == 0:
        return float(rows[0]["threshold"]), float(rows[1]["threshold"])
    if closest_index == len(rows) - 1:
        return float(rows[-2]["threshold"]), float(rows[-1]["threshold"])
    return float(rows[closest_index - 1]["threshold"]), float(rows[closest_index + 1]["threshold"])


def _closest_to_target(
    results: list[dict],
    metric_name: str,
    target_value: float,
) -> dict:
    """
    Waehlt den Threshold mit minimalem absolutem Abstand zum Zielwert.
    Bei exakt gleichem Abstand wird der kleinere Threshold bevorzugt,
    damit die Auswahl deterministisch bleibt.
    """
    return min(
        results,
        key=lambda row: (
            abs(float(row[metric_name]) - float(target_value)),
            float(row["threshold"]),
        ),
    )


def build_threshold_grid() -> list[float]:
    """
    Erstellt ein kombiniertes Threshold-Raster mit sehr hoher Aufloesung im
    fuer dieses Modell kritischen Low-Probability-Bereich.

    Die Suche bleibt ein einziger Inferenzdurchlauf: np.searchsorted wertet
    alle Thresholds aus denselben sortierten Score-Arrays aus.
    """
    # A) Logarithmische Absicherung fuer extrem kleine Scores.
    logarithmic = np.logspace(
        np.log10(LOG_THRESHOLD_MIN),
        np.log10(LOG_THRESHOLD_MAX),
        LOG_THRESHOLD_POINTS,
        dtype=np.float64,
    )

    # B) Sehr feines lineares Raster im aktuell relevanten Bereich.
    # +0.5*step stellt sicher, dass LOW_FINE_MAX trotz Float-Rundung enthalten ist.
    low_fine = np.arange(
        LOW_FINE_MIN,
        LOW_FINE_MAX + 0.5 * LOW_FINE_STEP,
        LOW_FINE_STEP,
        dtype=np.float64,
    )

    # C) Kleiner Uebergangsbereich: 0.001..0.009 in 0.001-Schritten.
    mid = np.arange(
        0.001,
        0.010,
        MID_THRESHOLD_STEP,
        dtype=np.float64,
    )

    # D) Grober Referenzbereich fuer groessere Thresholds: exakt 0.01..0.99.
    regular = np.arange(
        0.01,
        1.0,
        REGULAR_THRESHOLD_STEP,
        dtype=np.float64,
    )

    # E) Sehr hohe Randwerte.
    high_tail = np.asarray(EXTRA_HIGH_THRESHOLDS, dtype=np.float64)

    values = np.concatenate([logarithmic, low_fine, mid, regular, high_tail])

    # Nur echte Thresholds in (0, 1), sauber runden und Duplikate entfernen.
    thresholds = sorted(
        set(
            float(np.round(t, THRESHOLD_ROUND_DECIMALS))
            for t in values
            if 0.0 < float(t) < 1.0
        )
    )

    return thresholds


def select_thresholds(results: list[dict]) -> dict:
    """Bestimmt die wichtigsten Arbeitspunkte fuer eine Ergebnisliste."""
    best_balanced = min(
        results,
        key=lambda r: (
            float(r["balanced_error"]),
            abs(float(r["false_positive_rate"]) - float(r["false_negative_rate"])),
            -float(r["dice"]),
            float(r["threshold"]),
        ),
    )

    equal_error = min(
        results,
        key=lambda r: (
            abs(float(r["false_positive_rate"]) - float(r["false_negative_rate"])),
            float(r["balanced_error"]),
            float(r["threshold"]),
        ),
    )

    best_dice = max(
        results,
        key=lambda r: (float(r["dice"]), -float(r["threshold"])),
    )
    best_f2 = max(
        results,
        key=lambda r: (float(r["f2"]), -float(r["threshold"])),
    )
    best_iou = max(
        results,
        key=lambda r: (float(r["iou"]), -float(r["threshold"])),
    )

    # Niedrigste FNR unter expliziter FPR-Grenze. Bei gleicher FNR wird die
    # kleinere FPR und danach der groessere Threshold bevorzugt.
    eligible_fpr = [
        r for r in results
        if float(r["false_positive_rate"]) <= float(FPR_CONSTRAINT_MAX)
    ]
    best_fnr_under_fpr = None
    if eligible_fpr:
        best_fnr_under_fpr = min(
            eligible_fpr,
            key=lambda r: (
                float(r["false_negative_rate"]),
                float(r["false_positive_rate"]),
                -float(r["threshold"]),
            ),
        )

    return {
        "threshold_final_balanced_error": best_balanced,
        "threshold_equal_error": equal_error,
        "threshold_best_dice": best_dice,
        "threshold_best_f2": best_f2,
        "threshold_best_iou": best_iou,
        "threshold_best_fnr_under_fpr": best_fnr_under_fpr,
    }


def run_threshold_search_streaming(model, pairs, img_size: int):
    """
    Berechnet GLOBAL und BALANCED CRACK ROI parallel.

    Der primaere finale Threshold wird aus der BALANCED CRACK ROI durch
    Minimierung des Balanced Error gewaehlt.
    """
    thresholds = build_threshold_grid()
    inference_fn = build_inference_function(model)

    warmup_img, _ = pairs[0]
    warmup = np.expand_dims(
        load_image(warmup_img, img_size),
        axis=0,
    ).astype(np.float32)
    _ = inference_fn(tf.convert_to_tensor(warmup, dtype=tf.float32))
    del warmup

    (
        global_results,
        roi_results,
        diagnostics,
        roi_sampling_stats,
    ) = evaluate_thresholds_streaming(
        model=model,
        inference_fn=inference_fn,
        pairs=pairs,
        thresholds=thresholds,
        img_size=img_size,
        batch_size=BATCH_SIZE,
        desc=(
            f"Threshold-Auswertung GLOBAL + Balanced Crack ROI "
            f"({len(thresholds)} Schwellen)"
        ),
    )

    global_selection = select_thresholds(global_results)
    roi_selection = select_thresholds(roi_results)

    final_roi = roi_selection["threshold_final_balanced_error"]

    print("\nFINALE AUSWAHL: BALANCED CRACK ROI / minimaler Balanced Error")
    print(f"Threshold:          {final_roi['threshold']:.10f}  ({final_roi['threshold']:.6e})")
    print(f"Balanced Error:     {final_roi['balanced_error']:.6f}")
    print(f"Balanced Accuracy:  {final_roi['balanced_accuracy']:.6f}")
    print(f"FPR:                {final_roi['false_positive_rate']:.6f}")
    print(f"FNR:                {final_roi['false_negative_rate']:.6f}")
    print(f"Dice/F1:            {final_roi['dice']:.6f}")
    print(f"Precision:          {final_roi['precision']:.6f}")
    print(f"Recall:             {final_roi['recall']:.6f}")

    return {
        "global_results": global_results,
        "roi_results": roi_results,
        "global_selection": global_selection,
        "roi_selection": roi_selection,
        "threshold_final_balanced_error": final_roi,
        "dense_threshold_count": len(thresholds),
        "probability_diagnostics": diagnostics,
        "roi_sampling_stats": roi_sampling_stats,
    }


def _nearest_result(results: list[dict], target_threshold: float) -> dict:
    return min(
        results,
        key=lambda r: (
            abs(float(r["threshold"]) - float(target_threshold)),
            float(r["threshold"]),
        ),
    )


def build_compact_report_results(
    results: list[dict],
    selection: dict,
    extra_thresholds: list[float] | None = None,
) -> list[dict]:
    """
    Reduziert die gespeicherte Tabelle bewusst auf relevante Thresholds:
      - alle automatisch ausgewaehlten Arbeitspunkte,
      - optionale zusaetzliche Arbeitspunkte,
      - 0.01 bis 0.99 in 0.01-Schritten.

    Die eigentliche Optimierung arbeitet weiterhin auf dem vollen feinen
    Suchraster; nur die gespeicherte/reportete Tabelle wird komprimiert.
    """
    selected_rows = []
    for key in (
        "threshold_final_balanced_error",
        "threshold_equal_error",
        "threshold_best_dice",
        "threshold_best_f2",
        "threshold_best_iou",
        "threshold_best_fnr_under_fpr",
    ):
        row = selection.get(key)
        if row is not None:
            selected_rows.append(row)

    targets = [i / 100.0 for i in range(1, 100)]
    if extra_thresholds:
        targets.extend(float(t) for t in extra_thresholds)

    selected_rows.extend(_nearest_result(results, t) for t in targets)

    # Deduplizieren anhand der intern konsistent gerundeten Thresholds.
    unique = {}
    for row in selected_rows:
        key = round(float(row["threshold"]), THRESHOLD_ROUND_DECIMALS)
        unique[key] = row

    return [unique[k] for k in sorted(unique)]


def save_csv(results, csv_path: Path):
    csv_path.parent.mkdir(parents=True, exist_ok=True)

    fieldnames = [
        "threshold",
        "balanced_error",
        "balanced_accuracy",
        "false_positive_rate",
        "false_negative_rate",
        "f2",
        "dice",
        "f1",
        "iou",
        "precision",
        "recall",
        "accuracy",
        "tp",
        "fp",
        "fn",
        "tn",
    ]

    with open(csv_path, mode="w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()
        for row in results:
            writer.writerow(row)


def save_selected_thresholds(summary: dict, csv_path: Path):
    """
    Speichert GLOBAL und ROI jeweils in genau einer Zeile. Die fuenf
    geforderten Auswahlkriterien stehen nebeneinander als Spalten.
    """
    csv_path.parent.mkdir(parents=True, exist_ok=True)

    fieldnames = [
        "evaluation",
        "min_bal_error_threshold", "min_bal_error",
        "equal_error_threshold", "abs_fpr_minus_fnr",
        "max_dice_f1_threshold", "max_dice_f1",
        "max_f2_threshold", "max_f2",
        "max_iou_threshold", "max_iou",
    ]

    rows = []
    for evaluation, selection in (
        ("GLOBAL", summary["global_selection"]),
        ("BALANCED_CRACK_ROI", summary["roi_selection"]),
    ):
        be = selection["threshold_final_balanced_error"]
        ee = selection["threshold_equal_error"]
        dice = selection["threshold_best_dice"]
        f05 = selection["threshold_best_f2"]
        iou = selection["threshold_best_iou"]
        rows.append({
            "evaluation": evaluation,
            "min_bal_error_threshold": be["threshold"],
            "min_bal_error": be["balanced_error"],
            "equal_error_threshold": ee["threshold"],
            "abs_fpr_minus_fnr": abs(
                float(ee["false_positive_rate"]) - float(ee["false_negative_rate"])
            ),
            "max_dice_f1_threshold": dice["threshold"],
            "max_dice_f1": dice["dice"],
            "max_f2_threshold": f05["threshold"],
            "max_f2": f05["f2"],
            "max_iou_threshold": iou["threshold"],
            "max_iou": iou["iou"],
        })

    with open(csv_path, mode="w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(rows)


def save_probability_quantiles(diagnostics: dict, csv_path: Path):
    csv_path.parent.mkdir(parents=True, exist_ok=True)
    fieldnames = ["class", "pixel_count", "q01", "q05", "q25", "q50", "q75", "q95", "q99"]
    rows = [
        {"class": "GT=1 echte Risspixel", "pixel_count": diagnostics["positive_pixel_count"], **diagnostics["gt_positive"]},
        {"class": "GT=0 Hintergrundpixel", "pixel_count": diagnostics["negative_pixel_count"], **diagnostics["gt_negative"]},
    ]
    with open(csv_path, mode="w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(rows)


def save_probability_histogram(diagnostics: dict, png_path: Path):
    """Speichert ein speichersicheres Histogramm beider GT-Klassen."""
    png_path.parent.mkdir(parents=True, exist_ok=True)
    pos = diagnostics["positive_hist"].astype(np.float64)
    neg = diagnostics["negative_hist"].astype(np.float64)
    x = np.linspace(0.0, 1.0, len(pos), dtype=np.float64)

    # Fuer die Darstellung auf 1000 Punkte aggregieren; die Quantile nutzen weiterhin alle Bins.
    display_bins = 1000
    edges = np.linspace(0, len(pos), display_bins + 1, dtype=int)
    x_plot = np.empty(display_bins, dtype=np.float64)
    pos_plot = np.empty(display_bins, dtype=np.float64)
    neg_plot = np.empty(display_bins, dtype=np.float64)
    for i in range(display_bins):
        a, b = edges[i], edges[i + 1]
        x_plot[i] = x[a:b].mean() if b > a else x[min(a, len(x)-1)]
        pos_plot[i] = pos[a:b].sum()
        neg_plot[i] = neg[a:b].sum()

    # Relative Verteilungen machen die stark unterschiedlichen Klassengroessen vergleichbar.
    if pos_plot.sum() > 0:
        pos_plot /= pos_plot.sum()
    if neg_plot.sum() > 0:
        neg_plot /= neg_plot.sum()

    plt.figure(figsize=(11, 6))
    plt.plot(x_plot, pos_plot, label="GT=1 echte Risspixel")
    plt.plot(x_plot, neg_plot, label="GT=0 Hintergrundpixel")
    plt.yscale("log")
    plt.xlabel("Vorhergesagte Wahrscheinlichkeit p(y=1)")
    plt.ylabel("Relativer Pixelanteil pro Bin (log)")
    plt.title("Wahrscheinlichkeitsverteilung getrennt nach Ground Truth")
    plt.xlim(0.0, 1.0)
    plt.grid(True, alpha=0.25)
    plt.legend()
    plt.tight_layout()
    plt.savefig(png_path, dpi=200)
    plt.close()


def save_probability_histogram_csv(diagnostics: dict, csv_path: Path):
    csv_path.parent.mkdir(parents=True, exist_ok=True)
    pos = diagnostics["positive_hist"]
    neg = diagnostics["negative_hist"]
    denom = float(PROBABILITY_HIST_BINS - 1)
    with open(csv_path, mode="w", newline="", encoding="utf-8") as f:
        writer = csv.writer(f)
        writer.writerow(["probability", "gt_positive_count", "gt_negative_count"])
        for i, (p_count, n_count) in enumerate(zip(pos, neg)):
            if p_count or n_count:
                writer.writerow([i / denom, int(p_count), int(n_count)])



def save_roi_sampling_stats(stats: dict, csv_path: Path):
    csv_path.parent.mkdir(parents=True, exist_ok=True)
    with open(csv_path, mode="w", newline="", encoding="utf-8") as f:
        writer = csv.writer(f)
        writer.writerow(["metric", "value"])
        writer.writerow(["ring_radius_px", ROI_RING_RADIUS_PX])
        writer.writerow(["negative_to_positive_ratio", ROI_NEGATIVE_TO_POSITIVE_RATIO])
        writer.writerow(["random_seed", ROI_RANDOM_SEED])
        for key, value in stats.items():
            writer.writerow([key, value])


def format_metric_block(title: str, result: dict) -> str:
    return (
        f"{title}\n"
        f"{'-' * len(title)}\n"
        f"Threshold:          {result['threshold']:.10f}  ({result['threshold']:.6e})\n"
        f"Balanced Error:     {result['balanced_error']:.6f}\n"
        f"Balanced Accuracy:  {result['balanced_accuracy']:.6f}\n"
        f"FP-Rate (FP/Neg):   {result['false_positive_rate']:.6f}\n"
        f"FN-Rate (FN/Pos):   {result['false_negative_rate']:.6f}\n"
        f"F2:               {result['f2']:.6f}\n"
        f"Dice/F1:            {result['dice']:.6f}\n"
        f"IoU:                {result['iou']:.6f}\n"
        f"Precision:          {result['precision']:.6f}\n"
        f"Recall:             {result['recall']:.6f}\n"
        f"Accuracy:           {result['accuracy']:.6f}\n"
        f"TP:                 {result['tp']}\n"
        f"FP:                 {result['fp']}\n"
        f"FN:                 {result['fn']}\n"
        f"TN:                 {result['tn']}\n"
    )


def append_selection_horizontal_table(
    lines: list[str],
    title: str,
    selection: dict,
) -> None:
    """Fuenf Auswahlpunkte horizontal statt als vertikale Einzelbloecke."""
    items = [
        ("Min Bal Error", selection["threshold_final_balanced_error"], "balanced_error"),
        ("Equal-Error", selection["threshold_equal_error"], None),
        ("Max Dice/F1", selection["threshold_best_dice"], "dice"),
        ("Max F2", selection["threshold_best_f2"], "f2"),
        ("Max IoU", selection["threshold_best_iou"], "iou"),
    ]

    lines.append("=" * 138)
    lines.append(title)
    lines.append("=" * 138)
    lines.append(
        f"{'':<20} | " + " | ".join(f"{label:^20}" for label, _, _ in items)
    )
    lines.append("-" * 138)
    lines.append(
        f"{'Threshold':<20} | "
        + " | ".join(f"{float(row['threshold']):20.10g}" for _, row, _ in items)
    )

    criterion_values = []
    for _, row, metric in items:
        if metric is None:
            value = abs(
                float(row["false_positive_rate"]) - float(row["false_negative_rate"])
            )
        else:
            value = float(row[metric])
        criterion_values.append(value)
    lines.append(
        f"{'Kriterium-Wert':<20} | "
        + " | ".join(f"{v:20.6f}" for v in criterion_values)
    )
    lines.append(
        f"{'FPR':<20} | "
        + " | ".join(f"{float(row['false_positive_rate']):20.6f}" for _, row, _ in items)
    )
    lines.append(
        f"{'FNR':<20} | "
        + " | ".join(f"{float(row['false_negative_rate']):20.6f}" for _, row, _ in items)
    )
    lines.append(
        f"{'Dice/F1':<20} | "
        + " | ".join(f"{float(row['dice']):20.6f}" for _, row, _ in items)
    )
    lines.append(
        f"{'F2':<20} | "
        + " | ".join(f"{float(row['f2']):20.6f}" for _, row, _ in items)
    )
    lines.append(
        f"{'IoU':<20} | "
        + " | ".join(f"{float(row['iou']):20.6f}" for _, row, _ in items)
    )
    lines.append("")


def append_threshold_result_table(lines: list[str], title: str, results: list[dict]) -> None:
    lines.append("=" * 170)
    lines.append(title)
    lines.append("=" * 170)

    header = (
        f"{'Threshold':>14} | {'BalErr':>10} | {'BalAcc':>10} | {'FPR':>10} | {'FNR':>10} | "
        f"{'F2':>10} | {'Dice/F1':>10} | {'IoU':>10} | {'Precision':>10} | {'Recall':>10} | "
        f"{'Accuracy':>10} | {'TP':>12} | {'FP':>12} | {'FN':>12} | {'TN':>12}"
    )
    lines.append(header)
    lines.append("-" * len(header))

    for r in results:
        lines.append(
            f"{r['threshold']:14.10f} | {r['balanced_error']:10.6f} | "
            f"{r['balanced_accuracy']:10.6f} | {r['false_positive_rate']:10.6f} | "
            f"{r['false_negative_rate']:10.6f} | {r['f2']:10.6f} | "
            f"{r['dice']:10.6f} | {r['iou']:10.6f} | "
            f"{r['precision']:10.6f} | {r['recall']:10.6f} | "
            f"{r['accuracy']:10.6f} | {r['tp']:12d} | {r['fp']:12d} | "
            f"{r['fn']:12d} | {r['tn']:12d}"
        )
    lines.append("")


def save_txt(
    summary: dict,
    txt_path: Path,
    model_path: Path,
    image_dir: Path,
    mask_dir: Path,
    pair_count: int,
    img_size: int,
):
    txt_path.parent.mkdir(parents=True, exist_ok=True)

    diagnostics = summary["probability_diagnostics"]
    roi_stats = summary["roi_sampling_stats"]

    lines = []
    lines.append("=" * 120)
    lines.append("THRESHOLD-SUCHE: GLOBAL + BALANCED CRACK ROI")
    lines.append("=" * 120)
    lines.append(f"Model:       {model_path}")
    lines.append(f"Images:      {image_dir}")
    lines.append(f"Masks:       {mask_dir}")
    lines.append(f"Paare:       {pair_count}")
    lines.append(f"IMG_SIZE:    {img_size}")
    lines.append(f"BATCH:       {BATCH_SIZE}")
    lines.append(f"Thresholds:  {summary['dense_threshold_count']}")
    lines.append(
        f"Low-Fine-Raster: {LOW_FINE_MIN:.1e} bis {LOW_FINE_MAX:.1e} "
        f"in Schritten von {LOW_FINE_STEP:.1e}"
    )
    lines.append(
        f"Log-Raster: {LOG_THRESHOLD_MIN:.1e} bis {LOG_THRESHOLD_MAX:.1e} "
        f"mit {LOG_THRESHOLD_POINTS} Punkten"
    )
    lines.append("")
    lines.append("BALANCED CRACK ROI:")
    lines.append(f"- Ringradius: {ROI_RING_RADIUS_PX} px")
    lines.append(
        f"- Ziel N_neg/N_pos: {ROI_NEGATIVE_TO_POSITIVE_RATIO:.4f}"
    )
    lines.append(
        "- Alle GT-Risspixel werden verwendet. Negative Pixel kommen bevorzugt "
        "aus dem Ring; fehlende Negative werden zufaellig aus fernem Hintergrund aufgefuellt."
    )
    lines.append(
        "- Ist der Ring groesser als das Negativ-Ziel, wird der Ring auf das Ziel "
        "heruntergesampelt, damit die Klassenbalance erhalten bleibt."
    )
    lines.append(
        "- Primaerer finaler Threshold = Minimum Balanced Error der BALANCED CRACK ROI."
    )
    lines.append("")

    append_selection_horizontal_table(
        lines,
        "AUSWAHLPUNKTE GLOBAL - Kriterien nebeneinander",
        summary["global_selection"],
    )
    append_selection_horizontal_table(
        lines,
        "AUSWAHLPUNKTE BALANCED CRACK ROI - Kriterien nebeneinander",
        summary["roi_selection"],
    )

    lines.append("=" * 120)
    lines.append("ROI-SAMPLING-STATISTIK")
    lines.append("=" * 120)
    lines.append(f"Bilder gesamt:                     {roi_stats['images_total']}")
    lines.append(f"Bilder in ROI verwendet:           {roi_stats['images_used']}")
    lines.append(f"Bilder ohne Riss uebersprungen:    {roi_stats['images_skipped_no_positive']}")
    lines.append(f"Bilder mit Ring-Downsampling:      {roi_stats['images_ring_downsampled']}")
    lines.append(f"Positive ROI-Pixel:                {roi_stats['positive_pixels']}")
    lines.append(f"Negative ROI-Pixel:                {roi_stats['negative_pixels_sampled']}")
    lines.append(f"Ringpixel verfuegbar:              {roi_stats['ring_pixels_available']}")
    lines.append(f"Ringpixel gesampelt:               {roi_stats['ring_pixels_sampled']}")
    lines.append(f"Ferner Hintergrund verfuegbar:     {roi_stats['far_background_available']}")
    lines.append(f"Ferner Hintergrund gesampelt:      {roi_stats['far_background_sampled']}")
    lines.append(f"Negativpixel-Shortfall:            {roi_stats['negative_shortfall']}")
    if roi_stats["positive_pixels"] > 0:
        ratio = roi_stats["negative_pixels_sampled"] / roi_stats["positive_pixels"]
        lines.append(f"Tatsaechliches N_neg/N_pos:        {ratio:.6f}")
    lines.append("")

    lines.append("=" * 120)
    lines.append("WAHRSCHEINLICHKEITSDIAGNOSE p(y=1 | Ground Truth) - GLOBAL")
    lines.append("=" * 120)
    lines.append(f"GT=1 Pixel: {diagnostics['positive_pixel_count']}")
    lines.append(f"GT=0 Pixel: {diagnostics['negative_pixel_count']}")
    total_px = diagnostics["positive_pixel_count"] + diagnostics["negative_pixel_count"]
    if total_px:
        pos_share = diagnostics["positive_pixel_count"] / total_px
        lines.append(
            f"Risspixelanteil: {pos_share:.8f} ({100.0 * pos_share:.4f} %)"
        )
    lines.append(
        f"Histogramm-Bins: {diagnostics['hist_bins']} "
        f"(Binbreite ca. {diagnostics['hist_bin_width']:.8f})"
    )
    lines.append("")

    qheader = (
        f"{'Klasse':<28} | {'1 %':>9} | {'5 %':>9} | {'25 %':>9} | "
        f"{'Median':>9} | {'75 %':>9} | {'95 %':>9} | {'99 %':>9}"
    )
    lines.append(qheader)
    lines.append("-" * len(qheader))
    for label, q in (
        ("echte Risspixel (GT=1)", diagnostics["gt_positive"]),
        ("Hintergrundpixel (GT=0)", diagnostics["gt_negative"]),
    ):
        lines.append(
            f"{label:<28} | {q['q01']:9.6f} | {q['q05']:9.6f} | "
            f"{q['q25']:9.6f} | {q['q50']:9.6f} | {q['q75']:9.6f} | "
            f"{q['q95']:9.6f} | {q['q99']:9.6f}"
        )
    lines.append("")

    global_compact = build_compact_report_results(
        summary["global_results"],
        summary["global_selection"],
    )
    roi_compact = build_compact_report_results(
        summary["roi_results"],
        summary["roi_selection"],
    )

    append_threshold_result_table(
        lines,
        "KOMPAKTE THRESHOLD-TABELLE - GLOBAL (relevante Arbeitspunkte + 0.01..0.99)",
        global_compact,
    )
    append_threshold_result_table(
        lines,
        "KOMPAKTE THRESHOLD-TABELLE - BALANCED CRACK ROI (relevante Arbeitspunkte + 0.01..0.99)",
        roi_compact,
    )

    roi_be = summary["roi_selection"]["threshold_final_balanced_error"]
    roi_f05 = summary["roi_selection"]["threshold_best_f2"]
    global_f05 = summary["global_selection"]["threshold_best_f2"]
    global_fnr_constraint = summary["global_selection"]["threshold_best_fnr_under_fpr"]

    lines.append("=" * 120)
    lines.append("FINALE THRESHOLD-EMPFEHLUNGEN")
    lines.append("=" * 120)
    lines.append(
        "1. ROI minimaler Balanced Error: "
        f"Threshold = {roi_be['threshold']:.10g} "
        f"(BalError={roi_be['balanced_error']:.6f}, FPR={roi_be['false_positive_rate']:.6f}, "
        f"FNR={roi_be['false_negative_rate']:.6f})"
    )
    lines.append(
        "2. ROI maximaler F2:            "
        f"Threshold = {roi_f05['threshold']:.10g} "
        f"(F2={roi_f05['f2']:.6f}, Precision={roi_f05['precision']:.6f}, "
        f"Recall={roi_f05['recall']:.6f})"
    )
    if global_fnr_constraint is None:
        lines.append(
            f"3. GLOBAL min FNR bei FPR <= {100*FPR_CONSTRAINT_MAX:.1f}%: kein Threshold erfuellt die Bedingung"
        )
    else:
        lines.append(
            f"3. GLOBAL min FNR bei FPR <= {100*FPR_CONSTRAINT_MAX:.1f}%: "
            f"Threshold = {global_fnr_constraint['threshold']:.10g} "
            f"(FPR={global_fnr_constraint['false_positive_rate']:.6f}, "
            f"FNR={global_fnr_constraint['false_negative_rate']:.6f}, "
            f"Dice={global_fnr_constraint['dice']:.6f})"
        )

    lines.append(
        "GLOBAL maximaler F2:             "
        f"Threshold = {global_f05['threshold']:.10g} "
        f"(F2={global_f05['f2']:.6f}, Precision={global_f05['precision']:.6f}, "
        f"Recall={global_f05['recall']:.6f})"
    )

    txt_path.write_text("\n".join(lines), encoding="utf-8")


# ============================================================
# AUTOMATISCHE RUN-/PFAD-ERKENNUNG
# ============================================================

def _load_json(path: Path) -> dict:
    with path.open("r", encoding="utf-8") as f:
        data = json.load(f)
    if not isinstance(data, dict):
        raise ValueError(f"JSON-Wurzel ist kein Objekt: {path}")
    return data


def _best_epoch_from_metrics(metrics: dict, metrics_path: Path) -> int:
    """Liest die beste Epoche aus der Metrics-Datei, mit robustem Fallback."""
    best_epoch = metrics.get("best_epoch")
    if best_epoch is not None:
        return int(best_epoch)

    history = metrics.get("history") or []
    valid = [
        row for row in history
        if isinstance(row, dict)
        and row.get("epoch") is not None
        and row.get("val_selection_distance") is not None
    ]
    if valid:
        best = min(valid, key=lambda row: float(row["val_selection_distance"]))
        return int(best["epoch"])

    valid = [
        row for row in history
        if isinstance(row, dict)
        and row.get("epoch") is not None
        and row.get("val_dice_fg") is not None
    ]
    if valid:
        best = max(valid, key=lambda row: float(row["val_dice_fg"]))
        return int(best["epoch"])

    raise ValueError(
        f"Keine best_epoch und keine auswertbare History in {metrics_path} gefunden."
    )


def _resolve_validation_dirs(metrics: dict, metrics_path: Path) -> tuple[Path, Path]:
    """
    Ermittelt val_512/images und val_512/masks aus den Metrics.

    Reihenfolge:
    1) Gespeicherter validation-Pfad aus der Metrics-Datei.
    2) Gespeicherter dataset_root + val_512.
    3) Relokativer Fallback neben OUTPUTS_ROOT:
       <OUTPUTS_ROOT.parent>/datasets/<dataset-name>/val_512

    Dadurch muss auch nach einem Verschieben des Projektordners normalerweise
    nur OUTPUTS_ROOT angepasst werden.
    """
    meta = metrics.get("run_metadata") or {}
    dataset_splits = meta.get("dataset_splits") or {}
    validation = dataset_splits.get("validation") or dataset_splits.get("val")
    dataset_root_raw = meta.get("dataset_root")

    candidates: list[Path] = []

    if validation:
        val_dir = Path(validation).expanduser()
        if val_dir.name.lower() in {"images", "masks"}:
            val_dir = val_dir.parent
        candidates.append(val_dir)

    if dataset_root_raw:
        dataset_root = Path(dataset_root_raw).expanduser()
        candidates.append(dataset_root / "val_512")

    # Falls absolute Pfade in alten Metrics nicht mehr stimmen, den Dataset-Namen
    # beibehalten und relativ zum aktuellen Projekt (Geschwisterordner von outputs)
    # neu aufbauen.
    dataset_name = None
    if dataset_root_raw:
        dataset_name = Path(dataset_root_raw).name
    elif validation:
        v = Path(validation)
        if v.name.lower() in {"images", "masks"}:
            v = v.parent
        if v.name.lower() == "val_512":
            dataset_name = v.parent.name

    if dataset_name:
        candidates.append(OUTPUTS_ROOT.expanduser().resolve().parent / "datasets" / dataset_name / "val_512")

    # Duplikate entfernen, Reihenfolge erhalten.
    unique_candidates = []
    seen = set()
    for candidate in candidates:
        key = str(candidate)
        if key not in seen:
            seen.add(key)
            unique_candidates.append(candidate)

    for val_dir in unique_candidates:
        image_dir = val_dir / "images"
        mask_dir = val_dir / "masks"
        if image_dir.is_dir() and mask_dir.is_dir():
            return image_dir, mask_dir

    tried = "\n  - ".join(str(p) for p in unique_candidates) or "<keine Kandidaten>"
    raise FileNotFoundError(
        "Validierungsdaten konnten aus den Metrics nicht aufgeloest werden. "
        f"Metrics: {metrics_path}\nVersuchte val_512-Pfade:\n  - {tried}"
    )


def _model_candidate_score(path: Path, run_name: str, best_epoch: int) -> tuple:
    """Kleinere Tupel sind besser; dient nur zur eindeutigen Kandidatenwahl."""
    stem = path.stem.lower()
    run_lower = run_name.lower()
    exact_stems = {
        f"{run_lower}_epoche{best_epoch}",
        f"{run_lower}_epoch{best_epoch}",
        f"{run_lower}_epoche_{best_epoch}",
        f"{run_lower}_epoch_{best_epoch}",
    }
    return (
        0 if stem in exact_stems else 1,
        0 if stem.startswith(run_lower) else 1,
        0 if path.suffix.lower() == ".keras" else 1,
        len(path.name),
        path.name.lower(),
    )


def _resolve_best_model(run_dir: Path, metrics: dict, metrics_path: Path, best_epoch: int) -> Path:
    """Findet im models-Ordner das Modell der in den Metrics markierten besten Epoche."""
    models_dir = run_dir / "models"
    if not models_dir.is_dir():
        raise FileNotFoundError(f"models-Ordner fehlt: {models_dir}")

    meta = metrics.get("run_metadata") or {}
    run_name = str(meta.get("run") or run_dir.name)

    # Zuerst die bei deinen Trainingslaeufen erwarteten exakten Namen testen.
    exact_names = [
        f"{run_name}_Epoche{best_epoch}.keras",
        f"{run_name}_Epoch{best_epoch}.keras",
        f"{run_name}_Epoche_{best_epoch}.keras",
        f"{run_name}_Epoch_{best_epoch}.keras",
        f"{run_dir.name}_Epoche{best_epoch}.keras",
        f"{run_dir.name}_Epoch{best_epoch}.keras",
    ]
    for name in exact_names:
        candidate = models_dir / name
        if candidate.is_file():
            return candidate

    # Robust gegen leicht abweichende Dateinamen: Epoche16, epoch_16, epoch-016, ...
    epoch_pattern = re.compile(
        rf"(?:epoche|epoch)[ _-]*0*{best_epoch}(?!\d)",
        flags=re.IGNORECASE,
    )
    all_models = [
        p for p in models_dir.rglob("*")
        if p.is_file() and p.suffix.lower() in {".keras", ".h5", ".hdf5"}
    ]
    epoch_models = [p for p in all_models if epoch_pattern.search(p.stem)]

    if epoch_models:
        epoch_models.sort(key=lambda p: _model_candidate_score(p, run_name, best_epoch))
        return epoch_models[0]

    # Letzter sinnvoller Fallback: explizit als "best" benanntes Modell.
    # Das wird nur verwendet, wenn kein Modell mit der best_epoch im Namen existiert.
    best_named = [p for p in all_models if "best" in p.stem.lower()]
    if len(best_named) == 1:
        print(
            f"WARNUNG: Kein Epoch-Modell fuer Epoche {best_epoch} gefunden. "
            f"Verwende einziges 'best'-Modell: {best_named[0].name}"
        )
        return best_named[0]

    available = ", ".join(sorted(p.name for p in all_models)[:20]) or "<keine>"
    raise FileNotFoundError(
        f"Kein Modell fuer best_epoch={best_epoch} in {models_dir} gefunden. "
        f"Vorhandene Modelldateien (max. 20): {available}"
    )


def _select_metrics_file(metrics_files: list[Path], run_dir: Path) -> Path:
    """Waehlt bei mehreren *_epoch_metrics.json die am besten zum Run passende Datei."""
    if len(metrics_files) == 1:
        return metrics_files[0]

    exact = run_dir / "metrics" / f"{run_dir.name}_epoch_metrics.json"
    if exact in metrics_files:
        return exact

    matching = [
        p for p in metrics_files
        if p.name == f"{run_dir.name}_epoch_metrics.json"
        or p.stem.startswith(run_dir.name)
    ]
    if len(matching) == 1:
        return matching[0]

    names = ", ".join(p.name for p in metrics_files)
    raise RuntimeError(
        f"Mehrere Metrics-Dateien in {run_dir / 'metrics'} gefunden und nicht eindeutig: {names}"
    )


def discover_runs(outputs_root: Path) -> list[dict]:
    """
    Sucht rekursiv nach <run>/metrics/*_epoch_metrics.json.
    Damit funktionieren sowohl direkte Unterordner von outputs als auch tiefer
    verschachtelte Run-Verzeichnisse.
    """
    outputs_root = outputs_root.expanduser().resolve()
    if not outputs_root.is_dir():
        raise FileNotFoundError(f"OUTPUTS_ROOT existiert nicht oder ist kein Ordner: {outputs_root}")

    grouped: dict[Path, list[Path]] = {}
    for metrics_path in outputs_root.rglob("*_epoch_metrics.json"):
        if metrics_path.parent.name != "metrics":
            continue
        run_dir = metrics_path.parent.parent
        grouped.setdefault(run_dir, []).append(metrics_path)

    runs = []
    for run_dir in sorted(grouped, key=lambda p: str(p).lower()):
        metrics_files = sorted(grouped[run_dir], key=lambda p: p.name.lower())
        metrics_path = _select_metrics_file(metrics_files, run_dir)
        runs.append({"run_dir": run_dir, "metrics_path": metrics_path})
    return runs


def resolve_run_configuration(run_dir: Path, metrics_path: Path) -> dict:
    metrics = _load_json(metrics_path)
    best_epoch = _best_epoch_from_metrics(metrics, metrics_path)
    image_dir, mask_dir = _resolve_validation_dirs(metrics, metrics_path)
    model_path = _resolve_best_model(run_dir, metrics, metrics_path, best_epoch)

    return {
        "run_dir": run_dir,
        "metrics_path": metrics_path,
        "metrics": metrics,
        "best_epoch": best_epoch,
        "model_path": model_path,
        "image_dir": image_dir,
        "mask_dir": mask_dir,
        "output_dir": run_dir / THRESHOLD_RESULTS_DIRNAME,
        "tmp_output_dir": run_dir / THRESHOLD_RESULTS_TMP_DIRNAME,
    }


# ============================================================
# EINZELNEN RUN AUSWERTEN
# ============================================================

def run_threshold_sweep_for_run(config: dict) -> None:
    run_dir = config["run_dir"]
    model_path = config["model_path"]
    image_dir = config["image_dir"]
    mask_dir = config["mask_dir"]
    output_dir = config["output_dir"]
    tmp_output_dir = config["tmp_output_dir"]
    best_epoch = config["best_epoch"]
    metrics_path = config["metrics_path"]

    model_name = model_path.stem

    # Stale Temp-Ergebnisse eines abgebrochenen vorherigen Laufs entfernen.
    if tmp_output_dir.exists():
        print(f"Entferne alten Temp-Ordner: {tmp_output_dir}")
        shutil.rmtree(tmp_output_dir)
    tmp_output_dir.mkdir(parents=True, exist_ok=False)

    global_csv_path = tmp_output_dir / f"{model_name}_threshold_search_GLOBAL_FINE.csv"
    roi_csv_path = tmp_output_dir / f"{model_name}_threshold_search_BALANCED_CRACK_ROI_FINE.csv"
    txt_path = tmp_output_dir / f"{model_name}_threshold_search_GLOBAL_and_BALANCED_CRACK_ROI_FINE.txt"
    selected_csv_path = tmp_output_dir / f"{model_name}_selected_thresholds_GLOBAL_and_ROI_FINE.csv"

    quantile_csv_path = tmp_output_dir / f"{model_name}_probability_quantiles_GLOBAL.csv"
    histogram_csv_path = tmp_output_dir / f"{model_name}_probability_histogram_GLOBAL.csv"
    histogram_png_path = tmp_output_dir / f"{model_name}_probability_histogram_GLOBAL.png"
    roi_stats_csv_path = tmp_output_dir / f"{model_name}_balanced_crack_roi_sampling_stats.csv"

    print("=" * 90)
    print(f"RUN: {run_dir.name}")
    print("=" * 90)
    print(f"Metrics:      {metrics_path}")
    print(f"Beste Epoche: {best_epoch}")
    print(f"Modell:       {model_path}")
    print(f"Images:       {image_dir}")
    print(f"Masks:        {mask_dir}")
    print(f"IMG_SIZE:     {IMG_SIZE}")
    print(f"BATCH_SIZE:   {BATCH_SIZE}")
    print(f"ROI-Ringradius: {ROI_RING_RADIUS_PX} px")
    print(f"ROI Ziel N_neg/N_pos: {ROI_NEGATIVE_TO_POSITIVE_RATIO}")
    print(f"ROI Random Seed: {ROI_RANDOM_SEED}")
    print(
        f"Low-Fine-Threshold-Raster: {LOW_FINE_MIN:.1e} bis {LOW_FINE_MAX:.1e} "
        f"mit Schritt {LOW_FINE_STEP:.1e}"
    )
    print(
        f"Log-Threshold-Raster: {LOG_THRESHOLD_MIN:.1e} bis {LOG_THRESHOLD_MAX:.1e} "
        f"({LOG_THRESHOLD_POINTS} Punkte)"
    )
    print("Primaere Threshold-Auswahl: min Balanced Error der BALANCED CRACK ROI")
    print("=" * 90)

    model = None
    try:
        print("\nLade Modell...")
        model = load_model_with_custom_objects(model_path)
        img_size = resolve_model_image_size(model, IMG_SIZE)
        print(f"Erkannte/validierte Modell-Eingabegroesse: {img_size} x {img_size} px")
        print(f"Modell-Input-Shape:  {model.input_shape}")
        print(f"Modell-Output-Shape: {model.output_shape}")

        print("\nSuche Bild-Masken-Paare...")
        pairs = find_image_mask_pairs(image_dir, mask_dir)
        print(f"Gefundene Paare: {len(pairs)} (alle werden ausgewertet)")

        summary = run_threshold_search_streaming(
            model=model,
            pairs=pairs,
            img_size=img_size,
        )

        global_compact = build_compact_report_results(
            summary["global_results"],
            summary["global_selection"],
        )
        roi_compact = build_compact_report_results(
            summary["roi_results"],
            summary["roi_selection"],
        )
        save_csv(global_compact, global_csv_path)
        save_csv(roi_compact, roi_csv_path)
        save_selected_thresholds(summary, selected_csv_path)

        save_probability_quantiles(
            summary["probability_diagnostics"],
            quantile_csv_path,
        )
        save_probability_histogram_csv(
            summary["probability_diagnostics"],
            histogram_csv_path,
        )
        save_probability_histogram(
            summary["probability_diagnostics"],
            histogram_png_path,
        )
        save_roi_sampling_stats(summary["roi_sampling_stats"], roi_stats_csv_path)

        save_txt(
            summary,
            txt_path,
            model_path,
            image_dir,
            mask_dir,
            pair_count=len(pairs),
            img_size=img_size,
        )

        roi_final = summary["roi_selection"]["threshold_final_balanced_error"]
        global_final = summary["global_selection"]["threshold_final_balanced_error"]
        roi_stats = summary["roi_sampling_stats"]

        print("\n" + "=" * 90)
        print("ERGEBNIS")
        print("=" * 90)
        print("\nPRIMAER: BALANCED CRACK ROI / Minimum Balanced Error")
        print(f"Threshold:          {roi_final['threshold']:.10f}  ({roi_final['threshold']:.6e})")
        print(f"Balanced Error:     {roi_final['balanced_error']:.6f}")
        print(f"Balanced Accuracy:  {roi_final['balanced_accuracy']:.6f}")
        print(f"FPR:                {roi_final['false_positive_rate']:.6f}")
        print(f"FNR:                {roi_final['false_negative_rate']:.6f}")
        print(f"Dice/F1:            {roi_final['dice']:.6f}")
        print(f"IoU:                {roi_final['iou']:.6f}")
        print(f"Precision:          {roi_final['precision']:.6f}")
        print(f"Recall:             {roi_final['recall']:.6f}")

        print("\nVERGLEICH: GLOBAL / Minimum Balanced Error")
        print(f"Threshold:          {global_final['threshold']:.10f}  ({global_final['threshold']:.6e})")
        print(f"Balanced Error:     {global_final['balanced_error']:.6f}")
        print(f"Dice/F1:            {global_final['dice']:.6f}")

        print("\nROI-Sampling")
        print(f"Positive Pixel:     {roi_stats['positive_pixels']}")
        print(f"Negative Pixel:     {roi_stats['negative_pixels_sampled']}")
        if roi_stats["positive_pixels"] > 0:
            print(
                "N_neg/N_pos:        "
                f"{roi_stats['negative_pixels_sampled'] / roi_stats['positive_pixels']:.6f}"
            )
        print(f"Ring gesampelt:     {roi_stats['ring_pixels_sampled']}")
        print(f"Far BG gesampelt:   {roi_stats['far_background_sampled']}")
        print(f"Leere Masken skip:  {roi_stats['images_skipped_no_positive']}")

        roi_f2 = summary["roi_selection"]["threshold_best_f2"]
        global_fnr_constraint = summary["global_selection"]["threshold_best_fnr_under_fpr"]
        print("\n" + "=" * 90)
        print("FINALE 3 THRESHOLD-ENTSCHEIDUNGEN")
        print("=" * 90)
        print(f"1. ROI min Balanced Error: Threshold = {roi_final['threshold']:.10g}")
        print(f"2. ROI max F2:             Threshold = {roi_f2['threshold']:.10g}")
        if global_fnr_constraint is None:
            print(f"3. GLOBAL min FNR bei FPR <= {100*FPR_CONSTRAINT_MAX:.1f}%: kein gueltiger Threshold")
        else:
            print(
                f"3. GLOBAL min FNR bei FPR <= {100*FPR_CONSTRAINT_MAX:.1f}%: "
                f"Threshold = {global_fnr_constraint['threshold']:.10g}"
            )

        # Erst jetzt gilt der Run als fertig.
        if output_dir.exists():
            raise RuntimeError(
                f"Zielordner wurde waehrend des Sweeps unerwartet angelegt: {output_dir}"
            )
        tmp_output_dir.rename(output_dir)

        print("\nGespeichert in:")
        print(output_dir)
        print("=" * 90)

    except Exception:
        # Kein falsches "fertig"-Signal hinterlassen.
        if tmp_output_dir.exists():
            shutil.rmtree(tmp_output_dir, ignore_errors=True)
        raise
    finally:
        if model is not None:
            del model
        tf.keras.backend.clear_session()
        gc.collect()


# ============================================================
# MAIN: ALLE RUNS UNTER OUTPUTS_ROOT
# ============================================================

def main():
    outputs_root = OUTPUTS_ROOT.expanduser().resolve()

    print("=" * 100)
    print("BATCH-THRESHOLD-SWEEP FUER ALLE OUTPUT-RUNS")
    print("=" * 100)
    print(f"OUTPUTS_ROOT: {outputs_root}")
    print(f"Erwartete Bildgroesse: {IMG_SIZE} x {IMG_SIZE} px")
    print(
        f"Regel: Existiert <run>/{THRESHOLD_RESULTS_DIRNAME}, wird der Run uebersprungen."
    )
    print("=" * 100)

    discovered = discover_runs(outputs_root)
    if not discovered:
        print(
            "Keine Runs gefunden. Erwartet wird die Struktur "
            "<run>/metrics/*_epoch_metrics.json unter OUTPUTS_ROOT."
        )
        return

    print(f"Gefundene Run-Verzeichnisse mit Metrics: {len(discovered)}\n")

    completed = []
    skipped = []
    failed = []

    for idx, item in enumerate(discovered, start=1):
        run_dir = item["run_dir"]
        metrics_path = item["metrics_path"]
        final_output = run_dir / THRESHOLD_RESULTS_DIRNAME

        print("\n" + "#" * 100)
        print(f"RUN {idx}/{len(discovered)}: {run_dir}")
        print("#" * 100)

        if final_output.is_dir():
            print(f"SKIP: {THRESHOLD_RESULTS_DIRNAME} ist bereits vorhanden.")
            skipped.append(run_dir)
            continue

        try:
            config = resolve_run_configuration(run_dir, metrics_path)
            print(
                f"AUTO: best_epoch={config['best_epoch']} -> {config['model_path'].name}"
            )
            print(f"AUTO: Validation-Images -> {config['image_dir']}")
            print(f"AUTO: Validation-Masks  -> {config['mask_dir']}")
            run_threshold_sweep_for_run(config)
            completed.append(run_dir)
        except Exception as exc:
            failed.append((run_dir, exc))
            print("\nFEHLER IN DIESEM RUN - fahre mit dem naechsten Run fort:")
            print(f"{type(exc).__name__}: {exc}")
            traceback.print_exc()

    print("\n" + "=" * 100)
    print("BATCH-ZUSAMMENFASSUNG")
    print("=" * 100)
    print(f"Gefunden:        {len(discovered)}")
    print(f"Neu ausgewertet: {len(completed)}")
    print(f"Uebersprungen:   {len(skipped)}")
    print(f"Fehlgeschlagen:  {len(failed)}")

    if completed:
        print("\nErfolgreich:")
        for p in completed:
            print(f"  [OK]   {p}")

    if skipped:
        print("\nBereits vorhanden:")
        for p in skipped:
            print(f"  [SKIP] {p}")

    if failed:
        print("\nFehler:")
        for p, exc in failed:
            print(f"  [FAIL] {p}: {type(exc).__name__}: {exc}")

    print("=" * 100)

    if failed:
        # Ein non-zero Exitcode ist bei automatisierten Laeufen hilfreich,
        # nachdem trotzdem alle anderen Runs verarbeitet wurden.
        raise SystemExit(1)


if __name__ == "__main__":
    main()
