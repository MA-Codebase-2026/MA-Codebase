#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Benchmark für U-Net++ mit verschiedenen Batchgrößen.

Getestete Batchgrößen:
    2, 4, 6, 8

Ausgabe:
    - Trainingszeit
    - Sekunden pro Bild
    - Bilder pro Sekunde
    - GPU-Speicherverbrauch, sofern verfügbar
    - OOM-Fehler, falls eine Batchgröße nicht in den VRAM passt

Es werden keine Modelle oder Ergebnisse gespeichert.
"""

from __future__ import annotations

import os
os.environ["TF_GPU_ALLOCATOR"] = "cuda_malloc_async"
os.environ["TF_CPP_MIN_LOG_LEVEL"] = "2"
os.environ["PYTHONHASHSEED"] = str(42)
os.environ["KERAS_BACKEND"] = "tensorflow"
import sys
import time
import json
import subprocess
from pathlib import Path


# ============================================================
# Einstellungen
# ============================================================

DATASET_DIR = Path(
    "/home/mitte/crack_project/datasets/better_dataset_evtl"
)

IMG_SIZE = 1024
BATCH_SIZES = [1, 2, 4,  8]

WARMUP_STEPS = 15
BENCHMARK_STEPS = 40

LEARNING_RATE = 1e-4
SEED = 42


# ============================================================
# Elternprozess: alle Batchgrößen nacheinander testen
# ============================================================

def run_all_batch_sizes() -> None:
    script_path = Path(__file__).resolve()
    results = []

    print("\n" + "=" * 80)
    print("U-NET++ BATCHSIZE-BENCHMARK")
    print("=" * 80)
    print(f"Datensatz:          {DATASET_DIR}")
    print(f"Bildgröße:          {IMG_SIZE} x {IMG_SIZE}")
    print(f"Warm-up-Schritte:   {WARMUP_STEPS}")
    print(f"Messschritte:       {BENCHMARK_STEPS}")
    print(f"Batchgrößen:        {BATCH_SIZES}")
    print("=" * 80)

    for batch_size in BATCH_SIZES:
        print(f"\nStarte Test mit Batchgröße {batch_size} ...")
        print("-" * 80)

        command = [
            sys.executable,
            str(script_path),
            "--single-batch",
            str(batch_size),
        ]

        completed = subprocess.run(
            command,
            capture_output=True,
            text=True,
        )

        if completed.stdout:
            print(completed.stdout, end="")

        if completed.stderr and completed.returncode != 0:
            print("\nFehlerausgabe:")
            print(completed.stderr)

        result = parse_result_from_output(completed.stdout)

        if result is None:
            result = {
                "batch_size": batch_size,
                "status": "FEHLER",
                "seconds_per_image": None,
                "images_per_second": None,
                "elapsed_seconds": None,
                "processed_images": None,
                "peak_memory_mb": None,
            }

        results.append(result)

    print_summary(results)


def parse_result_from_output(output: str) -> dict | None:
    prefix = "BENCHMARK_RESULT_JSON="

    for line in output.splitlines():
        if line.startswith(prefix):
            try:
                return json.loads(line[len(prefix):])
            except json.JSONDecodeError:
                return None

    return None


def print_summary(results: list[dict]) -> None:
    print("\n\n" + "=" * 96)
    print("ZUSAMMENFASSUNG")
    print("=" * 96)

    header = (
        f"{'Batch':>7} | "
        f"{'Status':>12} | "
        f"{'Bilder':>8} | "
        f"{'Zeit [s]':>10} | "
        f"{'s/Bild':>12} | "
        f"{'Bilder/s':>12} | "
        f"{'Peak VRAM [MB]':>15}"
    )

    print(header)
    print("-" * len(header))

    successful_results = []

    for result in results:
        batch_size = result["batch_size"]
        status = result["status"]

        if status == "OK":
            successful_results.append(result)

            peak_memory_mb = result.get("peak_memory_mb")
            peak_text = (
                f"{peak_memory_mb:.1f}"
                if peak_memory_mb is not None
                else "nicht verfügbar"
            )

            print(
                f"{batch_size:>7} | "
                f"{status:>12} | "
                f"{result['processed_images']:>8} | "
                f"{result['elapsed_seconds']:>10.2f} | "
                f"{result['seconds_per_image']:>12.6f} | "
                f"{result['images_per_second']:>12.2f} | "
                f"{peak_text:>15}"
            )
        else:
            print(
                f"{batch_size:>7} | "
                f"{status:>12} | "
                f"{'-':>8} | "
                f"{'-':>10} | "
                f"{'-':>12} | "
                f"{'-':>12} | "
                f"{'-':>15}"
            )

    print("=" * 96)

    if successful_results:
        fastest = min(
            successful_results,
            key=lambda x: x["seconds_per_image"],
        )

        largest_working = max(
            successful_results,
            key=lambda x: x["batch_size"],
        )

        print(
            f"\nSchnellster Durchsatz: Batch {fastest['batch_size']} "
            f"mit {fastest['seconds_per_image']:.6f} s/Bild "
            f"beziehungsweise {fastest['images_per_second']:.2f} Bildern/s."
        )

        print(
            f"Größte erfolgreich getestete Batchgröße: "
            f"{largest_working['batch_size']}"
        )
    else:
        print("\nKeine Batchgröße konnte erfolgreich getestet werden.")


# ============================================================
# Einzelner Benchmark-Prozess
# ============================================================

def benchmark_single_batch(batch_size: int) -> None:
    

    import random
    import numpy as np
    import tensorflow as tf
    from keras import mixed_precision

    random.seed(SEED)
    np.random.seed(SEED)
    tf.random.set_seed(SEED)

    mixed_precision.set_global_policy("float32")

    print(f"TensorFlow-Version:       {tf.__version__}")
    print(f"Mixed-Precision-Policy:   {mixed_precision.global_policy()}")
    print(f"Getestete Batchgröße:     {batch_size}")

    gpus = tf.config.list_physical_devices("GPU")

    if not gpus:
        print("FEHLER: TensorFlow erkennt keine GPU.")
        print_result(batch_size=batch_size, status="KEINE GPU")
        return

    try:
        for gpu in gpus:
            tf.config.experimental.set_memory_growth(gpu, True)
    except RuntimeError as error:
        print(f"Hinweis zu memory_growth: {error}")

    print(f"Erkannte GPU(s):          {gpus}")

    try:
        train_ds, image_count = create_training_dataset(
            tf=tf,
            batch_size=batch_size,
        )

        print(f"Gefundene Bildpaare:      {image_count}")

        if image_count == 0:
            raise RuntimeError(
                "Im Trainingsordner wurden keine passenden "
                "Bild-Masken-Paare gefunden."
            )

        model = build_unetplusplus(tf=tf)

        model.compile(
            optimizer=tf.keras.optimizers.Adam(
                learning_rate=LEARNING_RATE
            ),
            loss=dice_loss,
            metrics=[dice_coef_soft],
        )

        print(f"Modellparameter:          {model.count_params():,}")

        reset_gpu_memory_stats(tf)

        print(
            f"\nWarm-up mit {WARMUP_STEPS} Schritten "
            f"und Batchgröße {batch_size} ..."
        )

        model.fit(
            train_ds,
            epochs=1,
            steps_per_epoch=WARMUP_STEPS,
            verbose=0,
        )

        reset_gpu_memory_stats(tf)

        processed_images = BENCHMARK_STEPS * batch_size

        print(
            f"Benchmark mit {BENCHMARK_STEPS} Schritten "
            f"beziehungsweise {processed_images} Bildern ..."
        )

        start_time = time.perf_counter()

        history = model.fit(
            train_ds,
            epochs=1,
            steps_per_epoch=BENCHMARK_STEPS,
            verbose=0,
        )

        elapsed_seconds = time.perf_counter() - start_time

        seconds_per_image = elapsed_seconds / processed_images
        images_per_second = processed_images / elapsed_seconds
        peak_memory_mb = get_peak_gpu_memory_mb(tf)

        final_loss = float(history.history["loss"][-1])

        print("\nErgebnis:")
        print(f"Batchgröße:               {batch_size}")
        print(f"Verarbeitete Bilder:      {processed_images}")
        print(f"Gesamtzeit:               {elapsed_seconds:.2f} s")
        print(f"Sekunden pro Bild:        {seconds_per_image:.6f} s")
        print(f"Bilder pro Sekunde:       {images_per_second:.2f}")
        print(f"Loss am Ende:             {final_loss:.6f}")

        if peak_memory_mb is not None:
            print(f"Peak-GPU-Speicher:        {peak_memory_mb:.1f} MB")
        else:
            print("Peak-GPU-Speicher:        nicht verfügbar")

        print_result(
            batch_size=batch_size,
            status="OK",
            elapsed_seconds=elapsed_seconds,
            processed_images=processed_images,
            seconds_per_image=seconds_per_image,
            images_per_second=images_per_second,
            peak_memory_mb=peak_memory_mb,
        )

    except tf.errors.ResourceExhaustedError as error:
        print("\nERGEBNIS: GPU-Speicher reicht für diese Batchgröße nicht aus.")
        print(f"TensorFlow-Fehler: {error.__class__.__name__}")

        print_result(
            batch_size=batch_size,
            status="OOM",
        )

    except Exception as error:
        error_text = str(error).lower()

        if (
            "out of memory" in error_text
            or "resource exhausted" in error_text
            or "oom" in error_text
        ):
            status = "OOM"
            print("\nERGEBNIS: Wahrscheinlicher GPU-Speicherfehler.")
        else:
            status = "FEHLER"
            print("\nERGEBNIS: Der Test ist fehlgeschlagen.")

        print(f"{error.__class__.__name__}: {error}")

        print_result(
            batch_size=batch_size,
            status=status,
        )


# ============================================================
# Dataset
# ============================================================

def create_training_dataset(tf, batch_size: int):
    image_dir = DATASET_DIR / "train_1024" / "images"
    mask_dir = DATASET_DIR / "train_1024" / "masks"

    if not image_dir.exists():
        raise FileNotFoundError(f"Bildordner nicht gefunden: {image_dir}")

    if not mask_dir.exists():
        raise FileNotFoundError(f"Maskenordner nicht gefunden: {mask_dir}")

    allowed_suffixes = {
        ".png",
        ".jpg",
        ".jpeg",
        ".bmp",
        ".tif",
        ".tiff",
    }

    image_paths = sorted(
        path
        for path in image_dir.iterdir()
        if path.is_file()
        and not path.name.startswith(".")
        and path.suffix.lower() in allowed_suffixes
    )

    mask_lookup = {
        path.stem.lower(): path
        for path in mask_dir.iterdir()
        if path.is_file()
        and not path.name.startswith(".")
        and path.suffix.lower() in allowed_suffixes
    }

    valid_image_paths = []
    valid_mask_paths = []

    for image_path in image_paths:
        matching_mask = mask_lookup.get(image_path.stem.lower())

        if matching_mask is not None:
            valid_image_paths.append(str(image_path))
            valid_mask_paths.append(str(matching_mask))

    dataset = tf.data.Dataset.from_tensor_slices(
        (valid_image_paths, valid_mask_paths)
    )

    dataset = dataset.shuffle(
        buffer_size=len(valid_image_paths),
        seed=SEED,
        reshuffle_each_iteration=True,
    )

    dataset = dataset.repeat()

    dataset = dataset.map(
        lambda image_path, mask_path: load_and_preprocess(
            tf,
            image_path,
            mask_path,
        ),
        num_parallel_calls=tf.data.AUTOTUNE,
    )

    dataset = dataset.batch(
        batch_size,
        drop_remainder=True,
    )

    dataset = dataset.prefetch(tf.data.AUTOTUNE)

    return dataset, len(valid_image_paths)


def load_and_preprocess(tf, image_path, mask_path):
    image_bytes = tf.io.read_file(image_path)

    image = tf.image.decode_image(
        image_bytes,
        channels=3,
        expand_animations=False,
    )

    image = tf.image.resize(
        image,
        [IMG_SIZE, IMG_SIZE],
        method="bilinear",
    )

    image = tf.image.convert_image_dtype(
        image,
        tf.float32,
    )

    image.set_shape([IMG_SIZE, IMG_SIZE, 3])

    mask_bytes = tf.io.read_file(mask_path)

    mask = tf.image.decode_image(
        mask_bytes,
        channels=1,
        expand_animations=False,
    )

    mask = tf.image.resize(
        mask,
        [IMG_SIZE, IMG_SIZE],
        method="nearest",
    )

    mask = tf.cast(mask, tf.float32)

    mask = tf.cond(
        tf.reduce_max(mask) > 1.0,
        lambda: tf.cast(mask > 127.0, tf.float32),
        lambda: tf.cast(mask > 0.5, tf.float32),
    )

    mask.set_shape([IMG_SIZE, IMG_SIZE, 1])

    return image, mask


# ============================================================
# U-Net++ – identisch zur Architektur aus unetpp_02_tversky
# ============================================================

FILTER_NUM = [16, 32, 64, 128, 256]
CONVS_PER_BLOCK = 2
ACTIVATION = "relu"
BATCH_NORM = True
KERNEL_INITIALIZER = "he_normal"
DEEP_SUPERVISION = False


def conv_block(tf, inputs, filters: int, name: str, n_convs: int = CONVS_PER_BLOCK):
    """Conv2D -> BatchNorm -> ReLU, standardmäßig zweimal pro Knoten."""
    x = inputs

    for conv_index in range(1, n_convs + 1):
        x = tf.keras.layers.Conv2D(
            filters=filters,
            kernel_size=3,
            padding="same",
            use_bias=not BATCH_NORM,
            kernel_initializer=KERNEL_INITIALIZER,
            name=f"{name}_conv{conv_index}",
        )(x)

        if BATCH_NORM:
            x = tf.keras.layers.BatchNormalization(
                name=f"{name}_bn{conv_index}"
            )(x)

        x = tf.keras.layers.Activation(
            ACTIVATION,
            name=f"{name}_{ACTIVATION}{conv_index}",
        )(x)

    return x


def upsample_to_level(tf, inputs, filters: int, name: str):
    """Lernbares 2x-Upsampling in die nächsthöhere U-Net++-Ebene."""
    return tf.keras.layers.Conv2DTranspose(
        filters=filters,
        kernel_size=2,
        strides=2,
        padding="same",
        kernel_initializer=KERNEL_INITIALIZER,
        name=f"{name}_up",
    )(inputs)


def dense_decoder_node(
    tf,
    same_level_nodes: list,
    deeper_node,
    filters: int,
    name: str,
):
    """Erzeugt X_i_j aus allen X_i_0...X_i_(j-1) und Up(X_(i+1)_(j-1))."""
    upsampled = upsample_to_level(tf, deeper_node, filters, name)

    merged = tf.keras.layers.Concatenate(
        axis=-1,
        name=f"{name}_concat",
    )([*same_level_nodes, upsampled])

    return conv_block(tf, merged, filters, name)


def build_unetplusplus_base(tf):
    """Vollständiges U-Net++ mit Knoten X0_0 bis X0_4."""
    inputs = tf.keras.Input(
        shape=(IMG_SIZE, IMG_SIZE, 3),
        name="unetpp_input",
    )

    # Encoderpfad X_i_0
    x0_0 = conv_block(tf, inputs, FILTER_NUM[0], "X0_0")
    p0 = tf.keras.layers.MaxPooling2D(pool_size=2, name="pool0")(x0_0)

    x1_0 = conv_block(tf, p0, FILTER_NUM[1], "X1_0")
    p1 = tf.keras.layers.MaxPooling2D(pool_size=2, name="pool1")(x1_0)

    x2_0 = conv_block(tf, p1, FILTER_NUM[2], "X2_0")
    p2 = tf.keras.layers.MaxPooling2D(pool_size=2, name="pool2")(x2_0)

    x3_0 = conv_block(tf, p2, FILTER_NUM[3], "X3_0")
    p3 = tf.keras.layers.MaxPooling2D(pool_size=2, name="pool3")(x3_0)

    x4_0 = conv_block(tf, p3, FILTER_NUM[4], "X4_0")

    # Verschachtelte Decoderstufe j=1
    x0_1 = dense_decoder_node(tf, [x0_0], x1_0, FILTER_NUM[0], "X0_1")
    x1_1 = dense_decoder_node(tf, [x1_0], x2_0, FILTER_NUM[1], "X1_1")
    x2_1 = dense_decoder_node(tf, [x2_0], x3_0, FILTER_NUM[2], "X2_1")
    x3_1 = dense_decoder_node(tf, [x3_0], x4_0, FILTER_NUM[3], "X3_1")

    # Verschachtelte Decoderstufe j=2
    x0_2 = dense_decoder_node(
        tf, [x0_0, x0_1], x1_1, FILTER_NUM[0], "X0_2"
    )
    x1_2 = dense_decoder_node(
        tf, [x1_0, x1_1], x2_1, FILTER_NUM[1], "X1_2"
    )
    x2_2 = dense_decoder_node(
        tf, [x2_0, x2_1], x3_1, FILTER_NUM[2], "X2_2"
    )

    # Verschachtelte Decoderstufe j=3
    x0_3 = dense_decoder_node(
        tf,
        [x0_0, x0_1, x0_2],
        x1_2,
        FILTER_NUM[0],
        "X0_3",
    )
    x1_3 = dense_decoder_node(
        tf,
        [x1_0, x1_1, x1_2],
        x2_2,
        FILTER_NUM[1],
        "X1_3",
    )

    # Verschachtelte Decoderstufe j=4
    x0_4 = dense_decoder_node(
        tf,
        [x0_0, x0_1, x0_2, x0_3],
        x1_3,
        FILTER_NUM[0],
        "X0_4",
    )

    logits = tf.keras.layers.Conv2D(
        filters=1,
        kernel_size=1,
        padding="same",
        activation=None,
        name="segmentation_logits",
    )(x0_4)

    return tf.keras.Model(
        inputs=inputs,
        outputs=logits,
        name="unetplusplus_model",
    )


def build_unetplusplus(tf):
    """U-Net++ mit float32-Sigmoid-Ausgang für den Batchsize-Benchmark."""
    base_model = build_unetplusplus_base(tf)

    inputs = tf.keras.Input(
        shape=(IMG_SIZE, IMG_SIZE, 3),
        name="input_image",
    )

    logits = base_model(inputs)

    outputs = tf.keras.layers.Activation(
        "sigmoid",
        dtype="float32",
        name="predictions",
    )(logits)

    return tf.keras.Model(
        inputs=inputs,
        outputs=outputs,
        name="unetplusplus_benchmark",
    )


# ============================================================
# Loss und Metrik
# ============================================================

def dice_coef_soft(y_true, y_pred, smooth=1e-7):
    import tensorflow as tf

    y_true = tf.cast(y_true, tf.float32)
    y_pred = tf.cast(y_pred, tf.float32)

    intersection = tf.reduce_sum(
        y_true * y_pred,
        axis=[1, 2, 3],
    )

    union = tf.reduce_sum(
        y_true + y_pred,
        axis=[1, 2, 3],
    )

    return tf.reduce_mean(
        (2.0 * intersection + smooth) / (union + smooth)
    )


def dice_loss(y_true, y_pred):
    return 1.0 - dice_coef_soft(y_true, y_pred)


# ============================================================
# GPU-Speicher
# ============================================================

def reset_gpu_memory_stats(tf) -> None:
    try:
        tf.config.experimental.reset_memory_stats("GPU:0")
    except Exception:
        pass


def get_peak_gpu_memory_mb(tf) -> float | None:
    try:
        memory_info = tf.config.experimental.get_memory_info("GPU:0")
        return memory_info["peak"] / (1024 ** 2)
    except Exception:
        return None


# ============================================================
# Ergebnisübergabe
# ============================================================

def print_result(
    batch_size: int,
    status: str,
    elapsed_seconds: float | None = None,
    processed_images: int | None = None,
    seconds_per_image: float | None = None,
    images_per_second: float | None = None,
    peak_memory_mb: float | None = None,
) -> None:

    result = {
        "batch_size": batch_size,
        "status": status,
        "elapsed_seconds": elapsed_seconds,
        "processed_images": processed_images,
        "seconds_per_image": seconds_per_image,
        "images_per_second": images_per_second,
        "peak_memory_mb": peak_memory_mb,
    }

    print("BENCHMARK_RESULT_JSON=" + json.dumps(result))


# ============================================================
# Start
# ============================================================

def main() -> None:
    if len(sys.argv) == 3 and sys.argv[1] == "--single-batch":
        benchmark_single_batch(int(sys.argv[2]))
    else:
        run_all_batch_sizes()


if __name__ == "__main__":
    main()
