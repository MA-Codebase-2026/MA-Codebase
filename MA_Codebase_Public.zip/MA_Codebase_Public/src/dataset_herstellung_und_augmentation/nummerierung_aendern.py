import os
from pathlib import Path

# ==============================
# CONFIG
# ==============================

FOLDER_PATH = Path("/home/mitte/crack_project/datasets/gut_mit_rissmaske_crackseg_dataset_high_res/masks")
START_NUMBER = 1

# ==============================

def rename_images(folder, start_number):

    # Alle Bilddateien sammeln
    image_extensions = [".jpg", ".jpeg", ".png", ".bmp", ".tiff", ".webp", ".tif"]
    files = sorted([f for f in folder.iterdir() 
                    if f.suffix.lower() in image_extensions])

    print(f"Gefundene Bilder: {len(files)}")

    for i, file in enumerate(files):
        new_name = f"{start_number + i}{file.suffix.lower()}"
        new_path = folder / new_name
        
        file.rename(new_path)

    print("Fertig ✅")

if __name__ == "__main__":
    rename_images(FOLDER_PATH, START_NUMBER)