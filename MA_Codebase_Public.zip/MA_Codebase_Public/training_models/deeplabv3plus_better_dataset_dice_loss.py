#!/usr/bin/env python3
import os
import csv
import json
import math
import random
from pathlib import Path

import tensorflow as tf
import numpy as np
import matplotlib.pyplot as plt

from keras import mixed_precision
policy = mixed_precision.Policy('mixed_float16')
mixed_precision.set_global_policy(policy)

# --- Muss pro Lauf angepasst werden ---
RUN_NAME = "deeplabv3plus_better_dataset_dice_loss_256filter"
SEG_DIR = "/home/mitte/crack_project/datasets/better_dataset_evtl" # <- anpassen

# --- Training-Konfiguration ---
SEED = 42
IMG_SIZE = 512
BATCH = 8
LR = 1e-4
STEPS_PER_EPOCH = 1000
VALIDATION_STEPS = 250
EPOCHS = 40
THRESHOLD = 0.5

# --- Verzeichnisse --- ds
OUTPUT_ROOT = Path("/home/mitte/crack_project/outputs")
RUN_DIR = OUTPUT_ROOT / RUN_NAME
MODEL_DIR = RUN_DIR / "models"
METRICS_DIR = RUN_DIR / "metrics"
PLOT_DIR = METRICS_DIR / "plots"
LOG_FILE = METRICS_DIR / f"{RUN_NAME}_epoch_metrics.txt"
CSV_FILE = METRICS_DIR / f"{RUN_NAME}_epoch_metrics.csv"

# --- mAP-Approximation fuer binaere Segmentierung ---
MAP_THRESHOLDS = np.arange(0.50, 1.00, 0.05)
AP_THRESHOLDS = np.linspace(1.0, 0.0, 101)

# --- Reproduzierbarkeit / Seed ---
os.environ["PYTHONHASHSEED"] = str(SEED)
os.environ["TF_GPU_ALLOCATOR"] = "cuda_malloc_async"
os.environ["KERAS_BACKEND"] = "tensorflow"

random.seed(SEED)
np.random.seed(SEED)
tf.random.set_seed(SEED)

tf.config.optimizer.set_jit(False)

# --- Pipeline mit tf.data ---
def load_and_preprocess(img_path, msk_path):
    img = tf.io.read_file(img_path)
    img = tf.image.decode_png(img, channels=3)
    img = tf.image.convert_image_dtype(img, tf.float32)
    img.set_shape([IMG_SIZE, IMG_SIZE, 3])

    msk = tf.io.read_file(msk_path)
    msk = tf.image.decode_png(msk, channels=1)
    msk = tf.cast(msk > 127, tf.float32)
    msk.set_shape([IMG_SIZE, IMG_SIZE, 1])

    return img, msk

def get_dataset(split):
    img_dir = Path(SEG_DIR) / split / "images"
    msk_dir = Path(SEG_DIR) / split / "masks"

    img_paths = sorted([str(p) for p in img_dir.glob("*") if not p.name.startswith(".")])
    msk_map = {p.stem.lower(): str(p) for p in msk_dir.glob("*") if not p.name.startswith(".")}

    valid_imgs, valid_msks = [], []
    for p in img_paths:
        stem = Path(p).stem.lower()
        if stem in msk_map:
            valid_imgs.append(p)
            valid_msks.append(msk_map[stem])

    ds = tf.data.Dataset.from_tensor_slices((valid_imgs, valid_msks))

    if split == "train_512":
        ds = ds.shuffle(len(valid_imgs), seed=SEED, reshuffle_each_iteration=True)
        ds = ds.repeat()

    ds = ds.map(load_and_preprocess, num_parallel_calls=tf.data.AUTOTUNE)

    ds = ds.batch(BATCH)
    ds = ds.prefetch(tf.data.AUTOTUNE)
    return ds, len(valid_imgs)

# --- Modell: DeepLabV3+ ---
# DeepLabV3+ ersetzt hier U-Net++.
# Der Rest des Codes bleibt gleich: gleiche Datenpipeline, gleicher Dice Loss,
# gleiche Validierungsmetriken, gleiche Checkpoints.
#
# Backbone:
# MobileNetV2 mit ImageNet-Gewichten. Das ist deutlich leichter als Xception
# und damit fuer eine RTX 2070 Super mit 8 GB VRAM realistischer.
#
# Wichtig:
# Die Bilder werden in load_and_preprocess bereits auf [0, 1] skaliert.
# MobileNetV2-preprocess_input erwartet jedoch Werte im Bereich [0, 255] und
# skaliert intern auf [-1, 1]. Deshalb wird im Modell zuerst wieder mit 255
# multipliziert und danach preprocess_input angewandt.

BACKBONE_WEIGHTS = "imagenet"
BACKBONE_TRAINABLE = False

ASPP_FILTERS = 128
DECODER_FILTERS = 128
LOW_LEVEL_FILTERS = 32
DROPOUT_RATE = 0.10
USE_BATCH_NORM = True


def bn_relu(x, name):
    if USE_BATCH_NORM:
        x = tf.keras.layers.BatchNormalization(name=f"{name}_bn")(x)
    x = tf.keras.layers.Activation("relu", name=f"{name}_relu")(x)
    return x


def conv_bn_relu(x, filters, kernel_size=3, dilation_rate=1, name="conv"):
    x = tf.keras.layers.Conv2D(
        filters,
        kernel_size=kernel_size,
        padding="same",
        dilation_rate=dilation_rate,
        use_bias=not USE_BATCH_NORM,
        kernel_initializer="he_normal",
        name=f"{name}_conv",
    )(x)
    x = bn_relu(x, name=name)
    return x


def aspp_branch(x, filters, dilation_rate, name):
    return conv_bn_relu(
        x,
        filters=filters,
        kernel_size=3,
        dilation_rate=dilation_rate,
        name=name,
    )


def atrous_spatial_pyramid_pooling(x):
    """
    ASPP-Modul von DeepLabV3+.
    Bei Output-Stride 16 sind die klassischen Dilation-Raten 6, 12, 18.
    Fuer 512x512 und MobileNetV2-Bottleneck auf 16x16 ist das ein sinnvoller
    Kompromiss aus grossem Kontext und Speicherbedarf.
    """
    shape = tf.keras.backend.int_shape(x)
    if shape[1] is None or shape[2] is None:
        raise ValueError("ASPP erwartet feste raeumliche Featuregroessen.")

    # Image-level pooling branch
    pooled = tf.keras.layers.GlobalAveragePooling2D(name="aspp_image_pool_gap")(x)
    pooled = tf.keras.layers.Reshape((1, 1, shape[-1]), name="aspp_image_pool_reshape")(pooled)
    pooled = conv_bn_relu(
        pooled,
        filters=ASPP_FILTERS,
        kernel_size=1,
        name="aspp_image_pool_project",
    )
    pooled = tf.keras.layers.UpSampling2D(
        size=(shape[1], shape[2]),
        interpolation="bilinear",
        name="aspp_image_pool_upsample",
    )(pooled)

    # 1x1 branch
    branch_1 = conv_bn_relu(
        x,
        filters=ASPP_FILTERS,
        kernel_size=1,
        name="aspp_branch_1x1",
    )

    # Atrous branches
    branch_6 = aspp_branch(x, ASPP_FILTERS, dilation_rate=6, name="aspp_branch_rate6")
    branch_12 = aspp_branch(x, ASPP_FILTERS, dilation_rate=12, name="aspp_branch_rate12")
    branch_18 = aspp_branch(x, ASPP_FILTERS, dilation_rate=18, name="aspp_branch_rate18")

    x = tf.keras.layers.Concatenate(name="aspp_concat")(
        [pooled, branch_1, branch_6, branch_12, branch_18]
    )

    x = conv_bn_relu(
        x,
        filters=ASPP_FILTERS,
        kernel_size=1,
        name="aspp_project",
    )
    x = tf.keras.layers.Dropout(DROPOUT_RATE, name="aspp_dropout")(x)
    return x


def build_optimized_model():
    """
    DeepLabV3+ fuer binaere Crack-Segmentierung.

    Verwendete MobileNetV2-Featureebenen bei 512x512 Input:
    - low-level feature: block_3_expand_relu, ca. 128x128
    - high-level feature: out_relu, ca. 16x16

    Decoder:
    - ASPP auf 16x16
    - Upsampling auf 128x128
    - Fusion mit Low-Level-Features
    - finales Upsampling auf 512x512
    """
    inputs = tf.keras.Input(shape=(IMG_SIZE, IMG_SIZE, 3), name="image")

    # [0, 1] -> [0, 255] -> MobileNetV2 preprocess -> [-1, 1]
    x_in = tf.keras.layers.Lambda(
        lambda z: z * 255.0,
        name="scale_0_1_to_0_255",
    )(inputs)

    x_in = tf.keras.layers.Lambda(
        tf.keras.applications.mobilenet_v2.preprocess_input,
        name="mobilenetv2_preprocess",
    )(x_in)

    backbone = tf.keras.applications.MobileNetV2(
        input_tensor=x_in,
        include_top=False,
        weights=BACKBONE_WEIGHTS,
        alpha=1.0,
    )
    backbone.trainable = BACKBONE_TRAINABLE

    low_level = backbone.get_layer("block_3_expand_relu").output
    high_level = backbone.get_layer("out_relu").output

    x = atrous_spatial_pyramid_pooling(high_level)

    low_shape = tf.keras.backend.int_shape(low_level)
    x_shape = tf.keras.backend.int_shape(x)
    up_factor_to_low = (
        low_shape[1] // x_shape[1],
        low_shape[2] // x_shape[2],
    )

    x = tf.keras.layers.UpSampling2D(
        size=up_factor_to_low,
        interpolation="bilinear",
        name="decoder_aspp_to_low_upsample",
    )(x)

    low_level = conv_bn_relu(
        low_level,
        filters=LOW_LEVEL_FILTERS,
        kernel_size=1,
        name="decoder_low_level_project",
    )

    x = tf.keras.layers.Concatenate(name="decoder_concat")([x, low_level])

    x = conv_bn_relu(
        x,
        filters=DECODER_FILTERS,
        kernel_size=3,
        name="decoder_conv1",
    )
    x = conv_bn_relu(
        x,
        filters=DECODER_FILTERS,
        kernel_size=3,
        name="decoder_conv2",
    )
    x = tf.keras.layers.Dropout(DROPOUT_RATE, name="decoder_dropout")(x)

    x_shape = tf.keras.backend.int_shape(x)
    final_up_factor = (
        IMG_SIZE // x_shape[1],
        IMG_SIZE // x_shape[2],
    )

    x = tf.keras.layers.UpSampling2D(
        size=final_up_factor,
        interpolation="bilinear",
        name="decoder_final_upsample",
    )(x)

    logits = tf.keras.layers.Conv2D(
        1,
        kernel_size=1,
        padding="same",
        kernel_initializer="he_normal",
        name="segmentation_logits",
    )(x)

    outputs = tf.keras.layers.Activation(
        "sigmoid",
        dtype="float32",
        name="predictions",
    )(logits)

    return tf.keras.Model(
        inputs=inputs,
        outputs=outputs,
        name="deeplabv3plus_mobilenetv2_crack_segmentation",
    )


# --- Loss & Soft Dice ---
def dice_coef_soft(y_true, y_pred, smooth=1e-7):
    y_true = tf.cast(y_true, tf.float32)
    y_pred = tf.cast(y_pred, tf.float32)

    intersection = tf.reduce_sum(y_true * y_pred, axis=[1, 2, 3])
    union = tf.reduce_sum(y_true + y_pred, axis=[1, 2, 3])

    return tf.reduce_mean((2.0 * intersection + smooth) / (union + smooth))

def dice_loss(y_true, y_pred):
    return 1.0 - dice_coef_soft(y_true, y_pred)

# --- Hilfsfunktionen ---
def safe_div(n, d, eps=1e-7):
    return float((n + eps) / (d + eps))

def compute_confusion_from_binary(y_true_bin, y_pred_bin):
    y_true_bool = y_true_bin.astype(bool)
    y_pred_bool = y_pred_bin.astype(bool)

    tp = np.logical_and(y_true_bool, y_pred_bool).sum()
    fp = np.logical_and(~y_true_bool, y_pred_bool).sum()
    fn = np.logical_and(y_true_bool, ~y_pred_bool).sum()
    tn = np.logical_and(~y_true_bool, ~y_pred_bool).sum()

    return tp, fp, fn, tn

def compute_fg_metrics_from_confusion(tp, fp, fn, tn):
    precision = safe_div(tp, tp + fp)
    recall = safe_div(tp, tp + fn)
    dice = safe_div(2 * tp, 2 * tp + fp + fn)
    iou = safe_div(tp, tp + fp + fn)
    f1 = safe_div(2 * precision * recall, precision + recall)
    accuracy = safe_div(tp + tn, tp + tn + fp + fn) * 100.0

    return {
        "precision_fg": precision,
        "recall_fg": recall,
        "dice_fg": dice,
        "iou_fg": iou,
        "f1_fg": f1,
        "accuracy_percent": accuracy,
    }

def update_threshold_confusions(y_true_bin, y_pred_prob, thresholds, tp, fp, fn):
    for idx, thr in enumerate(thresholds):
        y_pred_bin = (y_pred_prob >= thr).astype(np.uint8)
        batch_tp, batch_fp, batch_fn, _ = compute_confusion_from_binary(y_true_bin, y_pred_bin)
        tp[idx] += batch_tp
        fp[idx] += batch_fp
        fn[idx] += batch_fn

def compute_map_from_threshold_confusions(tp, fp):
    precisions = [safe_div(t, t + f) for t, f in zip(tp, fp)]
    return float(np.mean(precisions))

def compute_ap_from_threshold_confusions(tp, fp, fn):
    total_positives = float(np.max(tp + fn))
    if total_positives == 0:
        return float("nan")

    predicted_positives = tp + fp
    precision = np.divide(
        tp,
        predicted_positives,
        out=np.ones_like(tp, dtype=np.float64),
        where=predicted_positives > 0,
    )
    recall = tp / total_positives

    order = np.argsort(recall)
    recall = recall[order]
    precision = precision[order]

    recall = np.concatenate(([0.0], recall, [1.0]))
    precision = np.concatenate(([precision[0] if precision.size else 0.0], precision, [0.0]))

    for idx in range(precision.size - 2, -1, -1):
        precision[idx] = max(precision[idx], precision[idx + 1])

    return float(np.sum((recall[1:] - recall[:-1]) * precision[1:]))

def save_plot(x, ys, labels, title, ylabel, out_path):
    plt.figure(figsize=(10, 6))
    for y, label in zip(ys, labels):
        plt.plot(x, y, label=label)
    plt.xlabel("Epoch")
    plt.ylabel(ylabel)
    plt.title(title)
    plt.grid(True, alpha=0.3)
    plt.legend()
    plt.tight_layout()
    plt.savefig(out_path, dpi=200)
    plt.close()

def save_training_plots(history_rows, plot_dir):
    plot_dir = Path(plot_dir)
    plot_dir.mkdir(parents=True, exist_ok=True)

    if not history_rows:
        return

    epochs = [row["epoch"] for row in history_rows]

    loss = [row["train_loss"] for row in history_rows]
    val_loss = [row["val_loss"] for row in history_rows]

    dice_soft = [row["train_dice_soft"] for row in history_rows]
    val_dice_soft = [row["val_dice_soft"] for row in history_rows]
    val_dice_fg = [row["val_dice_fg"] for row in history_rows]

    val_iou_fg = [row["val_iou_fg"] for row in history_rows]
    val_precision_fg = [row["val_precision_fg"] for row in history_rows]
    val_recall_fg = [row["val_recall_fg"] for row in history_rows]
    val_f1_fg = [row["val_f1_fg"] for row in history_rows]

    val_accuracy_pct = [row["val_accuracy_pct"] for row in history_rows]
    val_mse = [row["val_mse"] for row in history_rows]
    val_auc_roc = [row["val_auc_roc"] for row in history_rows]
    val_auc_pr = [row["val_auc_pr"] for row in history_rows]
    val_ap = [row["val_ap"] for row in history_rows]
    val_map = [row["val_map"] for row in history_rows]

    save_plot(epochs, [loss, val_loss], ["train_loss", "val_loss"], "Loss Curve", "Loss", plot_dir / "loss_curve.png")
    save_plot(epochs, [dice_soft, val_dice_soft, val_dice_fg], ["train_dice_soft", "val_dice_soft", "val_dice_fg"], "Dice Curve", "Dice", plot_dir / "dice_curve.png")
    save_plot(epochs, [val_iou_fg], ["val_iou_fg"], "IoU Curve", "IoU", plot_dir / "iou_curve.png")
    save_plot(epochs, [val_precision_fg, val_recall_fg, val_f1_fg], ["val_precision_fg", "val_recall_fg", "val_f1_fg"], "Precision / Recall / F1", "Score", plot_dir / "precision_recall_f1_curve.png")
    save_plot(epochs, [val_accuracy_pct], ["val_accuracy_pct"], "Accuracy Curve", "Accuracy (%)", plot_dir / "accuracy_curve.png")
    save_plot(epochs, [val_mse], ["val_mse"], "MSE Curve", "MSE", plot_dir / "mse_curve.png")
    save_plot(epochs, [val_auc_roc, val_auc_pr], ["val_auc_roc", "val_auc_pr"], "AUC Curves", "AUC", plot_dir / "auc_curve.png")
    save_plot(epochs, [val_ap], ["val_ap"], "AP Curve", "AP", plot_dir / "ap_curve.png")
    save_plot(epochs, [val_map], ["val_map"], "mAP Approximation Curve", "mAP", plot_dir / "map_curve.png")

# --- Logging Callback ---
class ValidationMetricsLogger(tf.keras.callbacks.Callback):
    FIELDNAMES = [
        "epoch",
        "train_loss",
        "val_loss",
        "train_dice_soft",
        "val_dice_soft",
        "val_dice_fg",
        "val_iou_fg",
        "val_precision_fg",
        "val_recall_fg",
        "val_f1_fg",
        "val_accuracy_pct",
        "val_mse",
        "val_auc_roc",
        "val_auc_pr",
        "val_ap",
        "val_map",
    ]

    def __init__(self, val_ds, val_steps, log_txt_path, log_csv_path, run_name="run", threshold=0.5, plot_dir=None):
        super().__init__()
        self.val_ds = val_ds
        self.val_steps = val_steps
        self.log_txt_path = Path(log_txt_path)
        self.log_csv_path = Path(log_csv_path)
        self.run_name = run_name
        self.threshold = threshold
        self.plot_dir = Path(plot_dir) if plot_dir is not None else self.log_txt_path.parent / "plots"
        self.best_epoch = None
        self.best_val_dice_fg = -1.0
        self.epoch_history = []

        self.log_txt_path.parent.mkdir(parents=True, exist_ok=True)
        self.log_csv_path.parent.mkdir(parents=True, exist_ok=True)
        self.plot_dir.mkdir(parents=True, exist_ok=True)
        self._init_log_files()

    def _init_log_files(self):
        with open(self.log_txt_path, "w", encoding="utf-8") as f:
            f.write(f"Run: {self.run_name}\n")
            f.write(f"Seed: {SEED}\n")
            f.write(f"Dataset: {SEG_DIR}\n")
            f.write(f"Output: {RUN_DIR}\n")
            f.write(f"Threshold: {self.threshold}\n")
            f.write("Architecture: DeepLabV3+ with MobileNetV2 backbone\n")
            f.write(f"Backbone weights: {BACKBONE_WEIGHTS}\n")
            f.write(f"Backbone trainable: {BACKBONE_TRAINABLE}\n")
            f.write(f"ASPP filters: {ASPP_FILTERS}\n")
            f.write(f"Decoder filters: {DECODER_FILTERS}\n")
            f.write("Alle Validierungsmetriken werden in jeder Epoche berechnet.\n")
            f.write("=" * 180 + "\n")
            f.write("\t".join(self.FIELDNAMES) + "\n")

        with open(self.log_csv_path, "w", encoding="utf-8", newline="") as f:
            writer = csv.DictWriter(f, fieldnames=self.FIELDNAMES)
            writer.writeheader()

    def _evaluate_validation(self):
        total_loss = 0.0
        total_dice_soft = 0.0
        total_mse = 0.0
        total_samples = 0

        tp_total = 0
        fp_total = 0
        fn_total = 0
        tn_total = 0

        map_tp = np.zeros(len(MAP_THRESHOLDS), dtype=np.float64)
        map_fp = np.zeros(len(MAP_THRESHOLDS), dtype=np.float64)
        map_fn = np.zeros(len(MAP_THRESHOLDS), dtype=np.float64)
        ap_tp = np.zeros(len(AP_THRESHOLDS), dtype=np.float64)
        ap_fp = np.zeros(len(AP_THRESHOLDS), dtype=np.float64)
        ap_fn = np.zeros(len(AP_THRESHOLDS), dtype=np.float64)

        auc_roc_metric = tf.keras.metrics.AUC(curve="ROC")
        auc_pr_metric = tf.keras.metrics.AUC(curve="PR")

        for batch_idx, (images, masks) in enumerate(self.val_ds):
            if batch_idx >= self.val_steps:
                break

            preds = self.model(images, training=False)
            batch_size = int(images.shape[0])
            if batch_size == 0:
                continue

            preds_np = preds.numpy().astype(np.float32)
            masks_np = masks.numpy().astype(np.float32)
            y_true_bin = (masks_np >= 0.5).astype(np.uint8)
            y_pred_bin = (preds_np >= self.threshold).astype(np.uint8)

            batch_loss = float(tf.reduce_mean(dice_loss(masks, preds)).numpy())
            batch_dice_soft = float(dice_coef_soft(masks, preds).numpy())
            batch_mse = float(np.mean((preds_np - masks_np) ** 2))

            total_loss += batch_loss * batch_size
            total_dice_soft += batch_dice_soft * batch_size
            total_mse += batch_mse * batch_size
            total_samples += batch_size

            tp, fp, fn, tn = compute_confusion_from_binary(y_true_bin, y_pred_bin)
            tp_total += tp
            fp_total += fp
            fn_total += fn
            tn_total += tn

            auc_roc_metric.update_state(masks_np.reshape(-1), preds_np.reshape(-1))
            auc_pr_metric.update_state(masks_np.reshape(-1), preds_np.reshape(-1))
            update_threshold_confusions(y_true_bin, preds_np, MAP_THRESHOLDS, map_tp, map_fp, map_fn)
            update_threshold_confusions(y_true_bin, preds_np, AP_THRESHOLDS, ap_tp, ap_fp, ap_fn)

        if total_samples == 0:
            return {name: float("nan") for name in self.FIELDNAMES if name not in {"epoch", "train_loss"}}

        fg_metrics = compute_fg_metrics_from_confusion(tp_total, fp_total, fn_total, tn_total)

        return {
            "val_loss": total_loss / total_samples,
            "val_dice_soft": total_dice_soft / total_samples,
            "val_dice_fg": fg_metrics["dice_fg"],
            "val_iou_fg": fg_metrics["iou_fg"],
            "val_precision_fg": fg_metrics["precision_fg"],
            "val_recall_fg": fg_metrics["recall_fg"],
            "val_f1_fg": fg_metrics["f1_fg"],
            "val_accuracy_pct": fg_metrics["accuracy_percent"],
            "val_mse": total_mse / total_samples,
            "val_auc_roc": float(auc_roc_metric.result().numpy()),
            "val_auc_pr": float(auc_pr_metric.result().numpy()),
            "val_ap": compute_ap_from_threshold_confusions(ap_tp, ap_fp, ap_fn),
            "val_map": compute_map_from_threshold_confusions(map_tp, map_fp),
        }

    def _write_epoch_row(self, row):
        with open(self.log_txt_path, "a", encoding="utf-8") as f:
            values = [str(row["epoch"])] + [f"{row[name]:.6f}" for name in self.FIELDNAMES[1:]]
            f.write("\t".join(values) + "\n")

        with open(self.log_csv_path, "a", encoding="utf-8", newline="") as f:
            writer = csv.DictWriter(f, fieldnames=self.FIELDNAMES)
            writer.writerow(row)

    def on_epoch_end(self, epoch, logs=None):
        logs = logs or {}
        val_metrics = self._evaluate_validation()

        row = {
            "epoch": epoch + 1,
            "train_loss": float(logs.get("loss", np.nan)),
            "val_loss": float(val_metrics["val_loss"]),
            "train_dice_soft": float(logs.get("dice_coef_soft", np.nan)),
            "val_dice_soft": float(val_metrics["val_dice_soft"]),
            "val_dice_fg": float(val_metrics["val_dice_fg"]),
            "val_iou_fg": float(val_metrics["val_iou_fg"]),
            "val_precision_fg": float(val_metrics["val_precision_fg"]),
            "val_recall_fg": float(val_metrics["val_recall_fg"]),
            "val_f1_fg": float(val_metrics["val_f1_fg"]),
            "val_accuracy_pct": float(val_metrics["val_accuracy_pct"]),
            "val_mse": float(val_metrics["val_mse"]),
            "val_auc_roc": float(val_metrics["val_auc_roc"]),
            "val_auc_pr": float(val_metrics["val_auc_pr"]),
            "val_ap": float(val_metrics["val_ap"]),
            "val_map": float(val_metrics["val_map"]),
        }

        self.epoch_history.append(row)

        if not np.isnan(row["val_dice_fg"]) and row["val_dice_fg"] > self.best_val_dice_fg:
            self.best_val_dice_fg = row["val_dice_fg"]
            self.best_epoch = epoch + 1

        for key, value in row.items():
            if key != "epoch":
                logs[key] = value
        logs["loss"] = row["train_loss"]
        logs["dice_coef_soft"] = row["train_dice_soft"]

        self._write_epoch_row(row)

        print(
            f"\nVAL: "
            f"loss={row['val_loss']:.6f} | "
            f"dice={row['val_dice_fg']:.6f} | "
            f"iou={row['val_iou_fg']:.6f} | "
            f"precision={row['val_precision_fg']:.6f} | "
            f"recall={row['val_recall_fg']:.6f} | "
            f"f1={row['val_f1_fg']:.6f} | "
            f"ap={row['val_ap']:.6f} | "
            f"auc_roc={row['val_auc_roc']:.6f} | "
            f"auc_pr={row['val_auc_pr']:.6f} | "
            f"map={row['val_map']:.6f} | "
            f"acc={row['val_accuracy_pct']:.2f}% | "
            f"mse={row['val_mse']:.6f}"
        )

    def on_train_end(self, logs=None):
        json_path = self.log_txt_path.with_suffix(".json")
        summary = {
            "run": self.run_name,
            "seed": SEED,
            "dataset": SEG_DIR,
            "output_dir": str(RUN_DIR),
            "best_epoch": self.best_epoch,
            "best_val_dice_fg": self.best_val_dice_fg,
            "history": self.epoch_history,
        }

        with open(json_path, "w", encoding="utf-8") as f:
            json.dump(summary, f, indent=2)

        with open(self.log_txt_path, "a", encoding="utf-8") as f:
            f.write("=" * 180 + "\n")
            f.write(f"Best epoch: {self.best_epoch}\n")
            f.write(f"Best val_dice_fg: {self.best_val_dice_fg:.6f}\n")

        save_training_plots(self.epoch_history, self.plot_dir)
        print(f"\nMetriken gespeichert unter: {self.log_txt_path} und {self.log_csv_path}")
        print(f"Plots gespeichert unter: {self.plot_dir}")
# --- Main ---
def main():
    RUN_DIR.mkdir(parents=True, exist_ok=True)
    MODEL_DIR.mkdir(parents=True, exist_ok=True)
    METRICS_DIR.mkdir(parents=True, exist_ok=True)
    PLOT_DIR.mkdir(parents=True, exist_ok=True)

    gpus = tf.config.list_physical_devices("GPU")
    if gpus:
        for gpu in gpus:
            tf.config.experimental.set_memory_growth(gpu, True)

    train_ds, train_count = get_dataset("train_512")
    val_ds, val_count = get_dataset("val_512")
    _test_ds, test_count = get_dataset("test_512")

    print(f"Seed:          {SEED}")
    print(f"Train samples: {train_count}")
    print(f"Val samples:   {val_count}")
    print(f"Test samples:  {test_count}")
    print(f"Val batches:   {math.ceil(val_count / BATCH)}")
    images_per_epoch = STEPS_PER_EPOCH * BATCH
    epochs_for_full_pass = train_count / images_per_epoch if images_per_epoch > 0 else float("inf")

    print(f"Bilder pro Epoche (effektiv): {images_per_epoch}")
    print(f"Epochen fuer ~1 kompletten Durchlauf durchs Train-Set: {epochs_for_full_pass:.2f}")
    print(f"Validation steps pro Epoche: {VALIDATION_STEPS} -> {VALIDATION_STEPS * BATCH} Bilder")

    model = build_optimized_model()

    model.compile(
        optimizer=tf.keras.optimizers.Adam(learning_rate=LR),
        loss=dice_loss,
        metrics=[
            dice_coef_soft
        ],
        jit_compile=False
    )

    metrics_logger = ValidationMetricsLogger(
        val_ds=val_ds,
        val_steps=VALIDATION_STEPS,
        log_txt_path=LOG_FILE,
        log_csv_path=CSV_FILE,
        run_name=RUN_NAME,
        threshold=THRESHOLD,
        plot_dir=PLOT_DIR
    )

    callbacks = [
        metrics_logger,

        tf.keras.callbacks.ModelCheckpoint(
            filepath=str(MODEL_DIR / f"{RUN_NAME}_Epoche{{epoch:02d}}.keras"),
            save_best_only=False,
            save_weights_only=False,
            verbose=1
        ),

        tf.keras.callbacks.ModelCheckpoint(
            filepath=str(MODEL_DIR / f"{RUN_NAME}_best_checkpoint.keras"),
            monitor="val_dice_fg",
            mode="max",
            save_best_only=True,
            verbose=1
        ),

        tf.keras.callbacks.ReduceLROnPlateau(
            monitor="val_dice_fg",
            mode="max",
            patience=10,
            factor=0.5,
            verbose=1
        ),

        tf.keras.callbacks.EarlyStopping(
            monitor="val_dice_fg",
            mode="max",
            patience=25,
            restore_best_weights=True,
            verbose=1
        ),
    ]

    print(f"Start: Kurze Epochen mit {STEPS_PER_EPOCH} Schritten.")

    model.fit(
        train_ds,
        epochs=EPOCHS,
        steps_per_epoch=STEPS_PER_EPOCH,
        callbacks=callbacks,
        verbose=1
    )

if __name__ == "__main__":
    main()
