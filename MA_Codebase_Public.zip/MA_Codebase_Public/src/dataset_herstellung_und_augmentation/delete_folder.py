from pathlib import Path
from concurrent.futures import ThreadPoolExecutor, as_completed
import os

# !!! DIESEN PFAD ANPASSEN !!!
ROOT_FOLDER = Path("/home/mitte/crack_project/datasets/baseline_dataset/uncolored_set_30_hardnegatives")

# 16-32 ist meist sinnvoll.
MAX_WORKERS = 16


def delete_file(path: Path):
    try:
        path.unlink()
        return None
    except Exception as e:
        return path, e


def main():
    root = ROOT_FOLDER.resolve()

    if not root.exists():
        print(f"Ordner existiert nicht: {root}")
        return

    if not root.is_dir():
        print(f"Kein Ordner: {root}")
        return

    # Kleine Sicherheitsabfrage
    print(f"ACHTUNG: Folgender Ordner wird vollständig gelöscht:")
    print(root)

    confirmation = input("\nZum Bestätigen exakt x eingeben: ")

    if confirmation != "x":
        print("Abgebrochen.")
        return

    print("\nSuche Dateien ...")

    files = []
    directories = []

    for current_root, dirs, filenames in os.walk(root):
        current = Path(current_root)

        for filename in filenames:
            files.append(current / filename)

        for dirname in dirs:
            directories.append(current / dirname)

    print(f"{len(files):,} Dateien gefunden.")
    print(f"{len(directories):,} Unterordner gefunden.")
    print(f"Lösche mit {MAX_WORKERS} Threads ...")

    errors = []

    with ThreadPoolExecutor(max_workers=MAX_WORKERS) as executor:
        futures = [executor.submit(delete_file, file) for file in files]

        for i, future in enumerate(as_completed(futures), 1):
            error = future.result()

            if error:
                errors.append(error)

            if i % 10_000 == 0:
                print(f"{i:,} / {len(files):,} Dateien gelöscht")

    # Unterordner müssen von unten nach oben gelöscht werden
    directories.sort(key=lambda p: len(p.parts), reverse=True)

    print("Lösche Unterordner ...")

    for directory in directories:
        try:
            directory.rmdir()
        except Exception as e:
            errors.append((directory, e))

    # Hauptordner löschen
    try:
        root.rmdir()
    except Exception as e:
        errors.append((root, e))

    if errors:
        print(f"\nFertig, aber {len(errors):,} Fehler sind aufgetreten.")

        for path, error in errors[:20]:
            print(f"{path}: {error}")

        if len(errors) > 20:
            print("Weitere Fehler wurden nicht angezeigt.")
    else:
        print("\nFertig. Ordner vollständig gelöscht.")


if __name__ == "__main__":
    main()