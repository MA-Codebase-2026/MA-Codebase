#!/usr/bin/env python3
# -*- coding: utf-8 -*-

from __future__ import annotations

from pathlib import Path
from PIL import Image, ExifTags

SPLITS = ["train", "val", "test"]
SUBFOLDERS = ["images", "masks"]
EXTS = {".png", ".jpg", ".jpeg", ".bmp", ".tif", ".tiff", ".webp"}
DATASET_BASE = Path("/home/mitte/crack_project/datasets/better_dataset_evtl")  # <- anpassen

def is_image_file(p: Path) -> bool:
    return p.is_file() and p.suffix.lower() in EXTS


def safe_size(path: Path) -> tuple[int, int] | None:
    """Liest Bildgröße (w,h). Gibt None zurück bei Fehlern."""
    try:
        with Image.open(path) as im:
            return im.size  # (w, h)
    except Exception:
        return None


def check_split(base: Path, split: str) -> dict[str, int]:
    img_dir = base / split / "images"
    msk_dir = base / split / "masks"

    stats = {
        "pairs_checked": 0,
        "size_mismatch": 0,
        "missing_mask": 0,
        "missing_image": 0,
        "unreadable_image": 0,
        "unreadable_mask": 0,
    }

    if not img_dir.exists() or not msk_dir.exists():
        print(f"⚠️  Split '{split}' übersprungen: {img_dir} oder {msk_dir} fehlt.")
        return stats

    img_files = sorted([p for p in img_dir.iterdir() if is_image_file(p)])
    msk_files = sorted([p for p in msk_dir.iterdir() if is_image_file(p)])

    img_names = {p.name for p in img_files}
    msk_names = {p.name for p in msk_files}

    # Fehlende Gegenstücke
    for name in sorted(img_names - msk_names):
        stats["missing_mask"] += 1
        print(f"[{split}] ❌ Maske fehlt für: images/{name}")

    for name in sorted(msk_names - img_names):
        stats["missing_image"] += 1
        print(f"[{split}] ❌ Bild fehlt für: masks/{name}")

    # Gemeinsame Paare prüfen
    common = sorted(img_names & msk_names)
    for name in common:
        img_path = img_dir / name
        msk_path = msk_dir / name

        img_size = safe_size(img_path)
        if img_size is None:
            stats["unreadable_image"] += 1
            print(f"[{split}] ⚠️  Bild nicht lesbar: images/{name}")
            continue

        msk_size = safe_size(msk_path)
        if msk_size is None:
            stats["unreadable_mask"] += 1
            print(f"[{split}] ⚠️  Maske nicht lesbar: masks/{name}")
            continue

        stats["pairs_checked"] += 1
        if img_size != msk_size:
            stats["size_mismatch"] += 1
            print(
                f"[{split}] ❌ Größe passt nicht: {name} | "
                f"image={img_size[0]}x{img_size[1]} mask={msk_size[0]}x{msk_size[1]}"
            )
            with Image.open(img_path) as im:
                exif = im.getexif()
                orient_tag = [k for k,v in ExifTags.TAGS.items() if v=="Orientation"][0]
                print("Orientation image:", exif.get(orient_tag, 1))
            with Image.open(msk_path) as im:
                exif = im.getexif()
                orient_tag = [k for k,v in ExifTags.TAGS.items() if v=="Orientation"][0]
                print("Orientation mask:", exif.get(orient_tag, 1))

    return stats


def main() -> None:

    print(f"Dataset: {DATASET_BASE.resolve()}")
    if not DATASET_BASE.exists():
        raise FileNotFoundError(f"Base-Pfad existiert nicht: {DATASET_BASE}")

    total = {k: 0 for k in [
        "pairs_checked", "size_mismatch", "missing_mask", "missing_image",
        "unreadable_image", "unreadable_mask"
    ]}

    for split in SPLITS:
        print(f"\n=== Prüfe Split: {split} ===")
        stats = check_split(DATASET_BASE, split)
        for k, v in stats.items():
            total[k] += v

        print(
            f"[{split}] checked={stats['pairs_checked']} | "
            f"mismatch={stats['size_mismatch']} | "
            f"missing_mask={stats['missing_mask']} | missing_image={stats['missing_image']} | "
            f"bad_images={stats['unreadable_image']} | bad_masks={stats['unreadable_mask']}"
        )

    print("\n=== Gesamt ===")
    print(
        f"checked={total['pairs_checked']} | mismatch={total['size_mismatch']} | "
        f"missing_mask={total['missing_mask']} | missing_image={total['missing_image']} | "
        f"bad_images={total['unreadable_image']} | bad_masks={total['unreadable_mask']}"
    )


if __name__ == "__main__":
    main()