#!/usr/bin/env python3
# -*- coding: utf-8 -*-

from __future__ import annotations

from pathlib import Path
import os
from concurrent.futures import ProcessPoolExecutor
from io import BytesIO
from PIL import Image, ImageOps
import hashlib

from PIL import Image

# =========================
# Einstellungen (anpassen)
# =========================
INPUT_BASE = "/home/mitte/crack_project/datasets/better_dataset_evtl"   # <- nur das anpassen
OUTPUT_BASE = "/home/mitte/crack_project/datasets/better_dataset_evtl"   # <- nur das anpassen

# PNG: schneller -> geringere Kompression (größere Dateien, aber spürbar schneller)
PNG_COMPRESS_LEVEL = 1  # 0..9

SPLITS = ["train_1024", "val_1024", "test_1024"]
SUBFOLDERS = ["images", "masks"]

EXTS = {".png", ".jpg", ".jpeg", ".bmp", ".tif", ".tiff"}

ROTATIONS = [0, 90, 180, 270]
ROTATE_OPS = {
    0: None,
    90: Image.Transpose.ROTATE_90,
    180: Image.Transpose.ROTATE_180,
    270: Image.Transpose.ROTATE_270,
}


# =========================
# Hilfsfunktionen
# =========================
def normalize_to_rgb(img: Image.Image) -> Image.Image:
    """Konvertiert Bilder mit Transparenz sauber nach RGB (weiß als Hintergrund)."""
    if img.mode in ("RGBA", "LA") or (img.mode == "P" and "transparency" in img.info):
        rgba = img.convert("RGBA")
        bg = Image.new("RGBA", rgba.size, (255, 255, 255, 255))
        return Image.alpha_composite(bg, rgba).convert("RGB")
    return img.convert("RGB")


def rotate_exact_90(img: Image.Image, deg: int) -> Image.Image:
    """Exakte 0/90/180/270 Rotation ohne schwarze Ränder."""
    op = ROTATE_OPS.get(deg)
    return img if op is None else img.transpose(op)


def png_bytes_from_image(img: Image.Image) -> bytes:
    """Bild genau einmal als PNG-bytes encodieren."""
    bio = BytesIO()
    img.save(bio, format="PNG", compress_level=PNG_COMPRESS_LEVEL)
    return bio.getvalue()


def write_bytes(path: str, data: bytes) -> None:
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "wb") as f:
        f.write(data)


def ensure_output_structure(output_base: str) -> None:
    """Erstellt train/val/test + images/masks im Output, falls nicht vorhanden."""
    for split in SPLITS:
        for sub in SUBFOLDERS:
            out_dir = os.path.join(output_base, split, sub)
            os.makedirs(out_dir, exist_ok=True)


# =========================
# Worker: 1 Bild + 1 Maske rotieren
# =========================
def process_pair(args: tuple[str, str, str, str]) -> int:
    img_path = Path(args[0])
    msk_path = Path(args[1])
    out_img_dir = args[2]
    out_msk_dir = args[3]

    # eindeutige ID gegen Kollisionen (auch bei gleichem stem)
    uid = hashlib.md5(str(img_path).encode("utf-8")).hexdigest()[:10]
    base = img_path.stem  # lesbar lassen

    with Image.open(img_path) as img_in:
        img_in = ImageOps.exif_transpose(img_in)  # EXIF-Orientation einbacken
        img = normalize_to_rgb(img_in)

    with Image.open(msk_path) as m_in:
        # falls Masken auch mal EXIF hätten: schadet nicht
        m_in = ImageOps.exif_transpose(m_in)
        mask = m_in.copy()

    mask_bytes_by_deg: dict[int, bytes] = {}
    for deg in ROTATIONS:
        m_rot = rotate_exact_90(mask, deg)
        mask_bytes_by_deg[deg] = png_bytes_from_image(m_rot)

    os.makedirs(out_img_dir, exist_ok=True)
    os.makedirs(out_msk_dir, exist_ok=True)

    out_count = 0
    for deg in ROTATIONS:
        img_rot = rotate_exact_90(img, deg)

        # eindeutig + stabil
        name = f"{base}_{uid}_{deg}_grad.png"

        img_out_path = os.path.join(out_img_dir, name)
        msk_out_path = os.path.join(out_msk_dir, name)

        img_rot.save(img_out_path, format="PNG", compress_level=PNG_COMPRESS_LEVEL)
        write_bytes(msk_out_path, mask_bytes_by_deg[deg])
        out_count += 1

    return out_count


# =========================
# Main
# =========================
def main() -> None:
    input_base = Path(INPUT_BASE)
    output_base = Path(OUTPUT_BASE)

    print("INPUT_BASE :", input_base)
    print("OUTPUT_BASE:", output_base)

    if not input_base.exists():
        raise FileNotFoundError(f"Input-Base existiert nicht: {input_base}")

    ensure_output_structure(str(output_base))

    pairs: list[tuple[str, str, str, str]] = []
    missing_masks = 0

    for split in SPLITS:
        img_dir = input_base / split / "images"
        msk_dir = input_base / split / "masks"

        if not img_dir.exists() or not msk_dir.exists():
            print(f"⚠️ Überspringe Split '{split}' (images/masks Ordner fehlen).")
            continue

        out_img_dir = os.path.join(str(output_base), split, "images")
        out_msk_dir = os.path.join(str(output_base), split, "masks")

        img_files = sorted([p for p in img_dir.iterdir() if p.is_file() and p.suffix.lower() in EXTS])

        for img_path in img_files:
            msk_path = msk_dir / img_path.name
            if not msk_path.exists():
                missing_masks += 1
                continue
            pairs.append((str(img_path), str(msk_path), out_img_dir, out_msk_dir))

    if missing_masks:
        print(f"Warnung: {missing_masks} Bilder ohne passende Maske wurden übersprungen.")

    if not pairs:
        print("Keine gültigen Bild/Masken-Paare gefunden.")
        return

    max_workers = min(16, os.cpu_count() or 1)
    chunksize = 16
    print(f"Starte Rotation: {len(pairs)} Paare | workers={max_workers} | chunksize={chunksize}")

    total_out = 0
    with ProcessPoolExecutor(max_workers=max_workers) as ex:
        for cnt in ex.map(process_pair, pairs, chunksize=chunksize):
            total_out += cnt

    print(f"Fertig. Insgesamt erzeugte Dateien: {total_out}")
    print(f"Output-Base: {output_base.resolve()}")


if __name__ == "__main__":
    main()