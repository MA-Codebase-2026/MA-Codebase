# Crack Segmentation Pipeline – README

Diese README gehört zum Notebook:

`crack_pipeline_blocks_1_to_9_reviewed_v3.ipynb`

Das Notebook bildet eine vollständige Pipeline für:

1. Dataset-Aufbereitung
2. automatische Batchsize-Ermittlung
3. Classifier-Training
4. U-Net++-Training
5. Threshold-Sweep und Test-Evaluation
6. Ensemble-Erstellung
7. Vergleich Ensemble vs. Einzelmodelle
8. Visualisierung von Modellvorhersagen
9. Rissbreitenbestimmung in Pixeln

---

# 1. Projektstruktur

Standardmäßig wird von folgendem Projektordner ausgegangen:

```text
/home/mitte/crack_project/
```

Typische Struktur nach mehreren ausgeführten Blöcken:

```text
/home/mitte/crack_project/
├── datasets/
│   ├── mydataset_original/
│   └── mydataset_512/
│
├── output_classifier/
│   └── <CLASSIFIER_RUN_NAME>/
│
├── outputs_segmentation/
│   ├── <UNETPP_RUN_NAME>/
│   └── _test_evaluation/
│
├── ensemble/
│   ├── modell/
│   └── evaluation/
│
├── model_visualizations/
│
└── crack_width_results/
```

Alle Pfade können im jeweiligen Block angepasst werden.

---

# 2. Voraussetzungen

Empfohlen:

- Linux / WSL
- Python 3.10 oder neuer
- NVIDIA-GPU für Training
- passendes CUDA-/cuDNN-/TensorFlow-Setup
- Jupyter Notebook oder JupyterLab

Wichtige Python-Pakete:

```bash
pip install \
    numpy \
    pillow \
    tqdm \
    opencv-python \
    matplotlib \
    scipy \
    scikit-image \
    tensorflow \
    keras \
    jupyter \
    nbformat \
    pydot
```

Optional bzw. für vollständige Diagnoseinformationen:

```bash
pip install keras-unet-collection
```

Für die grafische Keras-Architekturdarstellung kann zusätzlich Graphviz benötigt werden.

Unter Ubuntu/Debian beispielsweise:

```bash
sudo apt install graphviz
```

## GPU prüfen

Vor langen Trainingsläufen empfiehlt sich:

```python
import tensorflow as tf

print(tf.__version__)
print(tf.config.list_physical_devices("GPU"))
```

Wenn keine GPU angezeigt wird, sollte das TensorFlow-/CUDA-Setup zuerst korrigiert werden.

---

# 3. Wichtiger Hinweis zur Ausführung

Das Notebook ist absichtlich so aufgebaut, dass rechenintensive Schritte nicht automatisch starten.

Viele Startzeilen sehen beispielsweise so aus:

```python
# CLASSIFIER_RUN_DIR = run_classifier_training()
```

Zum Starten muss das führende `#` entfernt werden:

```python
CLASSIFIER_RUN_DIR = run_classifier_training()
```

Das verhindert, dass beim Öffnen oder versehentlichen Ausführen einer Konfigurationszelle sofort ein mehrstündiges Training beginnt.

Block 1 ist stärker in einzelne Schritte aufgeteilt und kann Schritt für Schritt ausgeführt werden.

---

# 4. Empfohlene Reihenfolge

Für einen vollständigen neuen Lauf:

```text
Block 1
  ↓
Block 2
  ↓
Block 3
  ↓
Block 4
  ↓
Block 5A
  ↓
Block 5B
  ↓
Block 6
  ↓
Block 7
```

Block 8 und Block 9 sind Analyse-/Anwendungsblöcke und können später beliebig verwendet werden.

```text
Block 8 = Visualisierung
Block 9 = Rissbreitenbestimmung
```

Wenn dort ein Modellpfad explizit angegeben wird, müssen nicht zwingend alle vorherigen Blöcke im selben Kernel ausgeführt worden sein.

---

# 5. Block 1 – Dataset vorbereiten

## Zweck

Mehrere Crack-Segmentation-Datasets werden:

- validiert
- zusammengeführt
- bei Namenskonflikten neu nummeriert
- zu PNG konvertiert
- in Train / Validation / Test aufgeteilt
- gepatcht
- rotiert
- in normale Patches und Hard Negatives getrennt

Die Originalquellen werden nicht verändert.

## Konfiguration

Wichtigster Abschnitt:

```python
CRACKS_DIR = Path("/home/mitte/crack_project")

DATASET_PATHS = [
    Path("/pfad/zum/dataset_1"),
    Path("/pfad/zum/dataset_2"),
]

DATASET_NAME = "mydataset"

TRAIN_RATIO = 0.70
VAL_RATIO   = 0.15
TEST_RATIO  = 0.15

IMAGE_SIZE = 512

STRIDE = None

WHITE_THRESHOLD = 0
```

`STRIDE = None` bedeutet:

```text
STRIDE = IMAGE_SIZE // 2
```

Bei `IMAGE_SIZE = 512` wird also standardmäßig:

```text
STRIDE = 256
```

verwendet.

## Unterstützte Input-Strukturen

Variante 1:

```text
dataset/
├── images/
└── masks/
```

Variante 2:

```text
dataset/
├── train/
│   ├── images/
│   └── masks/
├── val/
│   ├── images/
│   └── masks/
└── test/
    ├── images/
    └── masks/
```

Vor der Verarbeitung werden unter anderem geprüft:

- eindeutige Dateinamen/Stems
- vollständiges Image-/Mask-Matching
- Dekodierbarkeit
- gleiche Image-/Mask-Größe

## Original-Dataset

Standard:

```text
/home/mitte/crack_project/datasets/mydataset_original/
```

Struktur:

```text
mydataset_original/
├── manifest.csv
├── train/
│   ├── images/
│   └── masks/
├── val/
│   ├── images/
│   └── masks/
└── test/
    ├── images/
    └── masks/
```

## Patch-Dataset

Bei `IMAGE_SIZE = 512`:

```text
/home/mitte/crack_project/datasets/mydataset_512/
```

Struktur:

```text
mydataset_512/
├── train/
│   ├── images/
│   ├── masks/
│   ├── images_hard_negatives/
│   └── masks_hard_negatives/
├── val/
│   ├── images/
│   ├── masks/
│   ├── images_hard_negatives/
│   └── masks_hard_negatives/
└── test/
    ├── images/
    ├── masks/
    ├── images_hard_negatives/
    └── masks_hard_negatives/
```

Jeder Patch wird standardmäßig in vier Orientierungen gespeichert:

```text
0°
90°
180°
270°
```

Ein Patch gilt standardmäßig als Hard Negative, wenn:

```python
mask.max() <= WHITE_THRESHOLD
```

Bei:

```python
WHITE_THRESHOLD = 0
```

ist also nur eine vollständig schwarze Maske ein Hard Negative.

## Ausführung

Schritt 1:

```python
validated_pairs = validate_all_sources(DATASET_PATHS)
```

Schritt 2:

```python
original_pairs = build_original_dataset(validated_pairs)
```

Schritt 3:

```python
patch_stats = build_patch_dataset()
```

Schritt 4:

```python
deleted_identifiers = delete_identifier_files(
    ORIGINAL_DATASET_DIR,
    PATCH_DATASET_DIR,
)
```

---

# 6. Block 2 – Batchsize bestimmen

Block 2 bestimmt getrennt die maximal funktionierende Batchsize für:

```text
Classifier
U-Net++
```

Danach stehen unter anderem zur Verfügung:

```python
DETECTED_CLASSIFIER_BATCH_SIZE
DETECTED_UNETPP_BATCH_SIZE
DETECTED_IMAGE_SIZE
```

## Standard-Dataset

Standardmäßig wird das Patch-Dataset aus Block 1 verwendet.

Die Image Size wird normalerweise aus dem Dataset gelesen.

## Start

Am Ende von Block 2:

```python
DETECTED_CLASSIFIER_BATCH_SIZE, DETECTED_UNETPP_BATCH_SIZE = determine_batch_sizes()
```

Die Zeile ist standardmäßig aus Sicherheitsgründen auskommentiert.

## Warum getrennte Batchsizes?

Classifier und U-Net++ besitzen sehr unterschiedliche Speicheranforderungen.

Deshalb sollte nicht dieselbe Batchsize für beide Modelle angenommen werden.

---

# 7. Block 3 – Classifier trainieren

Der Classifier unterscheidet:

```text
positive Klasse:
train/images

negative Klasse:
train/images_hard_negatives
```

## Wichtige Konfiguration

```python
CLASSIFIER_RUN_NAME = "classifier_run_001"

CLASSIFIER_DATASET_DIR = None
CLASSIFIER_IMG_SIZE = None
CLASSIFIER_BATCH_SIZE = None

CLASSIFIER_STEPS_PER_EPOCH = 1000

CLASSIFIER_PHASE1_EPOCHS = 20
CLASSIFIER_PHASE2_EPOCHS = 20
```

Bedeutung von `None`:

```text
CLASSIFIER_DATASET_DIR = None
→ Patch-Dataset aus Block 1

CLASSIFIER_IMG_SIZE = None
→ automatisch / Wert aus Block 2

CLASSIFIER_BATCH_SIZE = None
→ DETECTED_CLASSIFIER_BATCH_SIZE
```

## Training

Das Training verwendet zwei Phasen:

```text
Phase 1
→ Backbone eingefroren

Phase 2
→ Fine-Tuning
```

## Output

```text
/home/mitte/crack_project/output_classifier/<CLASSIFIER_RUN_NAME>/
```

Typische Dateien:

```text
classifier_best.keras
classifier_final.keras
classifier_last.keras
training_history.csv
dataset_report.json
run_config.json
threshold_report.json
threshold_operating_points.json
checkpoints/
```

## Thresholds

Nach dem Training werden unter anderem bestimmt:

```text
Threshold mit maximalem Recall
Threshold mit minimalen False Negatives
```

Hinweis:

Auf einem festen Dataset sind maximaler Recall und minimale False Negatives mathematisch dasselbe Primärziel. Unterschiedliche Tie-Break-Regeln können trotzdem unterschiedliche dokumentierte Operating Points ergeben.

## Start

```python
CLASSIFIER_RUN_DIR = run_classifier_training()
```

---

# 8. Block 4 – U-Net++ trainieren

Block 4 enthält den vollständigen zugrundeliegenden U-Net++-Trainingscode.

Er wurde bewusst nicht verkürzt oder als versteckter Base64-Code abgelegt.

## Wichtige Konfiguration

```python
UNETPP_RUN_NAME = "unetpp_run_001"

UNETPP_DATASET_DIR = None

UNETPP_OUTPUT_ROOT = Path(
    "/home/mitte/crack_project/outputs_segmentation"
)

UNETPP_IMG_SIZE = None
UNETPP_BATCH = None
```

Standard:

```text
Dataset
→ Patch-Dataset aus Block 1

Image Size
→ Block 2 / Dataset

Batchsize
→ DETECTED_UNETPP_BATCH_SIZE
```

Weitere einstellbare Parameter umfassen unter anderem:

```text
Epochen
Steps per Epoch
Learning Rate
Filterzahlen
Convs pro Block
Activation
Batch Normalization
Deep Supervision
Hard-Negative-Anteil
LR Reduce Patience
Early Stopping
Mixed Precision
XLA
Determinismus
Validation Cache
Speichern aller Epochmodelle
Plot-Intervall
AP/AUC-Raster
```

## Best-Epoch-Auswahl

Die zentrale Modellselektion erfolgt über die Dice-F2-Idealpunkt-Distanz:

```text
D = sqrt(
      0.5 × (1 - Dice)²
    + 0.5 × (1 - F2)²
)
```

Kleiner ist besser.

## Output

```text
/home/mitte/crack_project/outputs_segmentation/<UNETPP_RUN_NAME>/
```

Typische Struktur:

```text
<UNETPP_RUN_NAME>/
├── models/
├── metrics/
│   └── plots/
├── architecture/
└── reproducibility/
```

Typische Modellfiles:

```text
<run>_Epoche01.keras
<run>_Epoche02.keras
...
<run>_best_val_loss.keras
<run>_best_dice_f2_distance.keras
```

Metrics werden unter anderem als:

```text
TXT
CSV
JSON
Plots
```

gespeichert.

Zusätzlich werden Architektur-, Software-, Hardware- und Datasetinformationen geloggt.

## Start

```python
UNETPP_RUN_DIR = run_unetpp_training()
```

Der vollständige Trainingscode wird dafür als reproduzierbares Python-Skript erzeugt und in einem separaten Prozess gestartet.

Das hält TensorFlow-/GPU-Zustände besser voneinander getrennt.

---

# 9. Block 5 – Threshold-Sweep und Test

Block 5 besteht aus:

```text
Block 5A = Threshold-Sweep auf Validation
Block 5B = Test-Evaluation
```

---

## Block 5A – Threshold-Sweep

Der Sweep untersucht parallel:

```text
GLOBAL
BALANCED CRACK ROI
```

### Balanced Crack ROI

Grundidee:

```text
alle positiven GT-Risspixel
+
rissnah gesampelte negative Pixel
```

Standardmäßig wird ungefähr ein Verhältnis von:

```text
positiv : negativ = 1 : 1
```

verwendet.

### Primärer Threshold

Standardmäßig:

```text
ROI minimaler Balanced Error
```

mit:

```text
FPR = FP / (FP + TN)
FNR = FN / (FN + TP)

Balanced Error = 0.5 × (FPR + FNR)
```

Zusätzlich werden unter anderem gesucht:

```text
Best Dice/F1
Best IoU
Best F2
Minimum |FPR - FNR|
```

Weiterhin werden Wahrscheinlichkeitsverteilungen und Quantile geloggt.

## Start

```python
THRESHOLD_SWEEP_SCRIPT_PATH = run_threshold_sweep()
```

---

## Block 5B – Test-Evaluation

Die Test-Evaluation verwendet die zuvor festgelegten Thresholds.

Standard:

```python
TEST_DATASET_DIR = None
```

bedeutet Dataset aus Block 1.

Die Ergebnisse landen standardmäßig unter:

```text
/home/mitte/crack_project/outputs_segmentation/_test_evaluation/
```

## Start

```python
SEGMENTATION_EVALUATION_DIR = run_segmentation_test_evaluation()
```

---

# 10. Block 6 – Ensemble erstellen

Das Ensemble besteht aus:

```text
1 × Classifier
1 × U-Net++ mit hoher Recall-Leistung
1 × U-Net++ mit hoher Precision-Leistung
```

## Standardpfad

```text
/home/mitte/crack_project/ensemble/modell/
```

## Automatische Auswahl

Standardmäßig wird wissenschaftlich sauber auf Validation ausgewählt:

```python
ENSEMBLE_UNET_SELECTION_SOURCE = "validation"
```

Nicht auf Test.

Das verhindert, dass das spätere Testset bereits zur Modellselektion verwendet wird.

Mögliche Werte:

```text
"validation"
"test"
"auto"
```

Für einen sauberen finalen Vergleich wird `"validation"` empfohlen.

## Manuelle Auswahl

Optional:

```python
ENSEMBLE_CLASSIFIER_MODEL_OVERRIDE = Path("...")
ENSEMBLE_RECALL_MODEL_OVERRIDE = Path("...")
ENSEMBLE_PRECISION_MODEL_OVERRIDE = Path("...")
```

Bei `None` erfolgt die Auswahl automatisch.

## Fusion

Standard:

```python
ENSEMBLE_CLASSIFIER_GATE_THRESHOLD = 0.10

ENSEMBLE_PIXEL_THRESHOLD_HIGH = 0.60
ENSEMBLE_PIXEL_THRESHOLD_LOW = 0.35

ENSEMBLE_RECALL_BASE_WEIGHT = 0.25
ENSEMBLE_RECALL_EXTRA_WEIGHT = 0.35
```

Die Classifier-Wahrscheinlichkeit beeinflusst damit:

- ob U-Net++ für einen Patch relevant ist
- die Gewichtung der beiden Segmentierer
- den dynamischen Pixelthreshold

## Gespeicherte Dateien

Es entstehen:

```text
<name_aus_3_modellen>.keras
<name_aus_3_modellen>.ensemble.json
```

Die `.ensemble.json` enthält insbesondere:

- Classifier-Pfad
- Recall-U-Net++-Pfad
- Precision-U-Net++-Pfad
- Auswahlmetadaten
- Fusionsparameter

Für spätere Analyseblöcke ist die `.ensemble.json` die eindeutigste Referenz.

## Start

```python
ENSEMBLE_MODEL_PATH, ENSEMBLE_CONFIG_PATH = create_ensemble()
```

---

# 11. Block 7 – Ensemble vergleichen

Ziel:

```text
Ensemble
vs.
Recall-U-Net++
vs.
Precision-U-Net++
```

auf exakt denselben Bildern und Masken vergleichen.

## Dataset

Standardstruktur:

```text
evaluationsordner/
├── images/
└── masks/
```

Konfiguration:

```python
BLOCK7_DATASET_DIR = Path("/pfad/zum/evaluationsordner")

BLOCK7_IMAGES_DIR = None
BLOCK7_MASKS_DIR = None
```

Bei `None` werden automatisch:

```text
<dataset>/images
<dataset>/masks
```

verwendet.

## Ensemble

```python
BLOCK7_ENSEMBLE_PATH = None
```

bedeutet:

```text
ENSEMBLE_CONFIG_PATH aus Block 6
```

Alternativ kann eine `.ensemble.json` explizit angegeben werden.

## Geloggte Metriken

Unter anderem:

```text
TP
TN
FP
FN

Accuracy
Balanced Accuracy

Precision
Recall
Specificity

FPR
FNR
Balanced Error

Dice / F1
IoU
F2

Soft Dice
Dice Loss
Binary Crossentropy

ROC-AUC
PR-AUC / AP

Dice-F2-Idealpunkt-Distanz D
```

Zusätzlich:

```text
GLOBAL
Balanced Crack ROI
Probability Quantiles
diagnostischer Threshold-Sweep
Per-Image-Metriken
```

## Wichtig

Der diagnostische Threshold-Sweep auf dem Vergleichsset ist nicht als primäre Testmetrik gedacht.

Für einen fairen Modellvergleich sollten die zuvor auf Validation festgelegten Thresholds als primäre Entscheidung verwendet werden.

## Output

```text
/home/mitte/crack_project/ensemble/evaluation/<ensemble_name>/
```

mit unter anderem:

```text
comparison_metrics.json
comparison_metrics.csv
per_image_metrics.csv
```

## Start

```python
BLOCK7_RESULTS = evaluate_ensemble_and_unets()
```

---

# 12. Block 8 – Visualisierung

Block 8 verarbeitet alle Bilder eines Ordners.

## Konfiguration

```python
BLOCK8_IMAGE_DIR = Path("/pfad/zu/images")

BLOCK8_MASK_DIR = None

BLOCK8_MODEL_OR_ENSEMBLE_PATH = Path(
    "/pfad/zum/model.keras"
)
```

Alternativ:

```python
BLOCK8_MODEL_OR_ENSEMBLE_PATH = Path(
    "/pfad/zum/ensemble.ensemble.json"
)
```

Korrekte Endung:

```text
.ensemble.json
```

Eine `.keras`-Ensembledatei mit danebenliegender `.ensemble.json` wird automatisch auf die JSON-Konfiguration aufgelöst.

## Output pro Bild

```text
01_probability.png
02_mask.png
03_heatmap.png
04_overlay.png
```

Wenn eine passende Ground-Truth-Maske gefunden wird:

```text
05_difference_FP_red_FN_blue.png
```

Farben:

```text
Rot  = False Positive
Blau = False Negative
Schwarz = keine Abweichung
```

## Mask-Suche

Wenn:

```python
BLOCK8_MASK_DIR = None
```

wird unter anderem automatisch nach einem passenden `masks`-Ordner gesucht.

## Threshold

```python
BLOCK8_THRESHOLD = None
```

bedeutet bei einem einzelnen U-Net++:

1. Threshold aus `threshold_results2` suchen
2. falls nicht vorhanden: `0.5`

Beim Ensemble wird die Ensemble-Konfiguration verwendet.

## Output-Root

```text
/home/mitte/crack_project/model_visualizations/
```

## Start

```python
BLOCK8_RESULT_DIR = visualize_folder_predictions()
```

---

# 13. Block 9 – Rissbreite bestimmen

Block 9 verarbeitet alle Bilder eines Ordners und bestimmt Rissbreiten in Pixeln.

## Konfiguration

```python
BLOCK9_IMAGE_DIR = Path("/pfad/zu/images")

BLOCK9_MODEL_OR_ENSEMBLE_PATH = Path(
    "/pfad/zum/model.keras"
)
```

oder:

```python
BLOCK9_MODEL_OR_ENSEMBLE_PATH = Path(
    "/pfad/zum/ensemble.ensemble.json"
)
```

## Standardparameter

```python
BLOCK9_PATCH_OVERLAP = 64
BLOCK9_BATCH_SIZE = 8

BLOCK9_MIN_OBJECT_AREA = 20
BLOCK9_REMOVE_HOLES_AREA = 20

BLOCK9_WIDTH_THRESHOLD_PX = 2.0
BLOCK9_RATIO_SMALL_THRESHOLD = 0.2
BLOCK9_MIN_SKELETON_POINTS = 5
```

Optional:

```python
BLOCK9_MM_PER_PX = None
```

Wenn eine bekannte Skalierung vorhanden ist, kann beispielsweise gesetzt werden:

```python
BLOCK9_MM_PER_PX = 0.05
```

Dann werden zusätzlich Breiten in Millimetern berechnet.

## Verfahren

Die Breite wird aus der vorhergesagten Binärmaske bestimmt:

```text
Probability Map
      ↓
Threshold
      ↓
Binärmaske
      ↓
kleine Objekte/Löcher entfernen
      ↓
Connected Components
      ↓
Skeletonize
      ↓
Distance Transform
      ↓
lokale Breite = 2 × Distance am Skeleton
```

## Werte pro Rissobjekt

Unter anderem:

```text
crack_id
Bounding Box

area_px
length_px

mean_width_px
median_width_px
max_width_px
min_width_px

ratio_width_leq_threshold

measurable
needs_closeup
status

centroid
skeleton_points
```

Wenn `MM_PER_PX` gesetzt ist zusätzlich:

```text
width_mm_mean
width_mm_median
width_mm_max
```

## Output

Standard:

```text
/home/mitte/crack_project/crack_width_results/
```

Pro Bild werden unter anderem gespeichert:

```text
probability_map.png
binary_mask.png
annotated_widths.png
crack_widths.csv
crack_widths.json
```

Zusätzlich über alle Bilder:

```text
all_images_crack_widths.csv
all_images_crack_widths.json
```

## Start

```python
BLOCK9_RESULTS = run_crack_width_folder()
```

---

# 14. Empfohlener Workflow für einen neuen Versuch

## A. Dataset erzeugen

1. Block 1 öffnen
2. `DATASET_PATHS` setzen
3. `DATASET_NAME` setzen
4. `IMAGE_SIZE` setzen
5. Validierung ausführen
6. Original-Dataset erstellen
7. Patch-Dataset erstellen
8. Cleanup ausführen

## B. Hardware testen

Block 2:

```python
DETECTED_CLASSIFIER_BATCH_SIZE, DETECTED_UNETPP_BATCH_SIZE = determine_batch_sizes()
```

Ergebnisse notieren.

## C. Classifier trainieren

Block 3:

```python
CLASSIFIER_RUN_NAME = "classifier_run_001"
CLASSIFIER_RUN_DIR = run_classifier_training()
```

## D. U-Net++ trainieren

Block 4:

```python
UNETPP_RUN_NAME = "unetpp_run_001"
UNETPP_RUN_DIR = run_unetpp_training()
```

## E. Threshold bestimmen

Block 5A:

```python
THRESHOLD_SWEEP_SCRIPT_PATH = run_threshold_sweep()
```

## F. Test auswerten

Block 5B:

```python
SEGMENTATION_EVALUATION_DIR = run_segmentation_test_evaluation()
```

## G. Ensemble bauen

Block 6:

```python
ENSEMBLE_MODEL_PATH, ENSEMBLE_CONFIG_PATH = create_ensemble()
```

## H. Vergleich durchführen

Block 7:

```python
BLOCK7_DATASET_DIR = Path("/pfad/zum/vergleichsset")
BLOCK7_RESULTS = evaluate_ensemble_and_unets()
```

---

# 15. Wissenschaftlich saubere Trennung der Daten

Empfohlen:

```text
Train
→ Gewichte lernen

Validation
→ Hyperparameter
→ Modell-/Epochenauswahl
→ Threshold-Auswahl
→ Auswahl der Ensemble-Komponenten

Test / unabhängiges Vergleichsset
→ nur finale Bewertung
```

Das Testset sollte möglichst nicht verwendet werden, um nachträglich:

- das beste Modell auszuwählen
- einen Threshold zu optimieren
- Ensemble-Gewichte einzustellen

Sonst besteht die Gefahr, dass das Testset indirekt Teil der Optimierung wird.

Deshalb verwendet Block 6 standardmäßig:

```python
ENSEMBLE_UNET_SELECTION_SOURCE = "validation"
```

---

# 16. Run-Namen

Für Classifier und U-Net++ sollten immer eindeutige Run-Namen verwendet werden.

Beispiel:

```python
CLASSIFIER_RUN_NAME = "classifier_512_betterdataset_v01"

UNETPP_RUN_NAME = "unetpp_512_f16-256_hn00_v01"
```

Ein sinnvoller Name kann enthalten:

```text
Modelltyp
Image Size
Filter
Dataset
Hard-Negative-Anteil
Loss
Version
```

Beispiel:

```text
unetpp_512_f16-256_betterdataset_hn20_dice_v03
```

---

# 17. Überschreiben vorhandener Runs

Standardmäßig wird Überschreiben verhindert.

Classifier:

```python
CLASSIFIER_OVERWRITE_RUN = False
```

U-Net++:

```python
UNETPP_OVERWRITE_RUN = False
```

Das schützt bestehende Modelle und Metrics.

Nur bewusst auf `True` setzen.

---

# 18. Hinweise zu Batchsize und OOM

Eine automatisch bestimmte Batchsize ist hardwareabhängig.

Sie kann sich ändern durch:

- andere GPU
- andere TensorFlow-Version
- andere CUDA-Version
- andere Image Size
- andere Modellarchitektur
- Mixed Precision
- andere gleichzeitig laufende GPU-Prozesse

Bei:

```text
ResourceExhaustedError
CUDA out of memory
OOM
```

Batchsize reduzieren.

Beispiel:

```python
UNETPP_BATCH = 4
```

oder:

```python
CLASSIFIER_BATCH_SIZE = 4
```

Manuelle Werte überschreiben die automatische Batchsize.

---

# 19. Hinweise zu Image Size

Trainings- und Inferenzgröße müssen zum Modell passen.

Bei Patch-Datasets sollte normalerweise gelten:

```text
Dataset-Patchgröße
=
Modell-Inputgröße
```

Beispiel:

```text
mydataset_512
→ 512 × 512
```

Für große Originalbilder verwenden Block 7–9 Patch-/Tile-Inferenz.

---

# 20. Hard Negatives

Hard Negatives sind Patches ohne Risspixel.

Sie sind besonders für den Classifier wichtig, können aber auch im U-Net++-Training zugemischt werden.

Classifier:

```text
positive:
images/

negative:
images_hard_negatives/
```

Beim U-Net++ wird der Zielanteil separat konfiguriert.

Ein zu hoher Hard-Negative-Anteil kann Recall verschlechtern.

Ein zu niedriger Anteil kann zu vielen False Positives führen.

Der optimale Anteil sollte über Validation untersucht werden.

---

# 21. Thresholds

Ein Segmentierungsmodell liefert zunächst Wahrscheinlichkeiten.

Beispiel:

```text
0.02
0.16
0.48
0.83
0.97
```

Erst der Threshold macht daraus eine Binärmaske:

```python
mask = probability >= threshold
```

Ein niedriger Threshold:

```text
↑ Recall
↓ False Negatives
↑ möglicherweise False Positives
```

Ein hoher Threshold:

```text
↑ Precision
↓ False Positives
↑ möglicherweise False Negatives
```

Deshalb sollte der Threshold nicht automatisch immer `0.5` sein.

---

# 22. Ensemble-Grundidee

Der Classifier bewertet Patch-Level:

```text
Ist in diesem Patch wahrscheinlich ein Riss?
```

Die beiden U-Net++-Modelle bewerten Pixel-Level:

```text
Welche Pixel gehören zum Riss?
```

Das Ensemble kombiniert:

```text
Classifier
    +
Recall-orientiertes U-Net++
    +
Precision-orientiertes U-Net++
```

Ziel:

```text
weniger übersehene Risse
bei gleichzeitig weniger Fehlmarkierungen
```

Ob dieses Ziel tatsächlich erreicht wird, soll mit Block 7 objektiv geprüft werden.

---

# 23. Rissbreite – Interpretation

Die in Block 9 berechnete Breite ist zunächst:

```text
Breite in Pixeln
```

Sie ist keine reale physikalische Breite, solange keine Bildskalierung bekannt ist.

Für Millimeterwerte wird benötigt:

```text
mm_per_px
```

Beispiel:

```python
BLOCK9_MM_PER_PX = 0.05
```

Dann:

```text
10 px × 0.05 mm/px = 0.5 mm
```

Die Messgenauigkeit hängt unter anderem ab von:

- Kameraauflösung
- Aufnahmeabstand
- Perspektive
- Fokus/Schärfe
- Segmentierungsqualität
- tatsächlicher Pixelauflösung des Risses

Sehr schmale Risse nahe der Pixelauflösung können nicht zuverlässig physikalisch vermessen werden.

---

# 24. Typische Fehler

## Keine Bilder gefunden

Prüfen:

```text
Pfad korrekt?
images-Ordner vorhanden?
Dateiendung unterstützt?
```

## Keine Masks gefunden

Prüfen:

```text
gleicher Dateiname/Stems wie Images?
richtiger masks-Ordner?
```

Beispiel:

```text
image:
000123.png

mask:
000123.png
```

## U-Net++ findet Hard Negatives nicht

Prüfen:

```text
images_hard_negatives/
masks_hard_negatives/
```

## Ensemble kann Modelle nicht automatisch auswählen

Zuerst ausführen:

```text
Block 3
Block 4
Block 5
```

oder Modellpfade in Block 6 manuell setzen.

## Block 8 oder 9 erkennt Ensemble nicht

Am sichersten direkt die Datei:

```text
<ensemble_name>.ensemble.json
```

angeben.

## Architektur-PNG wird nicht erstellt

Graphviz und pydot prüfen.

## GPU OOM

Batchsize reduzieren.

---

# 25. Sicherheit vor Datenverlust

Vor großen Läufen empfohlen:

```text
1. Dataset-Quellen niemals als Output-Ziel verwenden.
2. Eindeutige RUN_NAMEs verwenden.
3. OVERWRITE_RUN zunächst False lassen.
4. Erst mit kleinem Testdataset prüfen.
5. Danach vollständiges Training starten.
```

Block 1 verändert die angegebenen Originalquellen nicht.

---

# 26. Reproduzierbarkeit

Mehrere Blöcke verwenden feste Seeds.

Standard häufig:

```python
SEED = 42
```

Zusätzlich werden beim U-Net++-Training umfangreiche:

```text
Hardwareinformationen
Softwareversionen
Datasetinformationen
Run-Konfiguration
Architekturinformationen
```

gespeichert.

Für wissenschaftliche Vergleiche sollten folgende Angaben zusammen archiviert werden:

```text
Notebook-Version
Run-Konfiguration
Dataset-Version
Random Seed
TensorFlow-Version
CUDA/cuDNN-Version
GPU
Batchsize
Image Size
Threshold
Modellcheckpoint
```

---

# 27. Empfohlene Dateien für spätere Auswertung aufbewahren

Classifier:

```text
classifier_best.keras
run_config.json
training_history.csv
threshold_report.json
```

U-Net++:

```text
models/
metrics/
architecture/
threshold_results2/
```

Test:

```text
*_test_metrics.json
```

Ensemble:

```text
*.keras
*.ensemble.json
```

Vergleich:

```text
comparison_metrics.json
comparison_metrics.csv
per_image_metrics.csv
```

---

# 28. Kurzfassung

Für einen normalen kompletten Lauf:

```text
1. Datasetpfade setzen
2. Block 1 ausführen
3. Block 2 Batchsizes bestimmen
4. Block 3 Classifier trainieren
5. Block 4 U-Net++ trainieren
6. Block 5A Threshold-Sweep
7. Block 5B Test
8. Block 6 Ensemble erstellen
9. Block 7 Ensemble vergleichen
10. Block 8 Visualisierungen erzeugen
11. Block 9 Rissbreiten bestimmen
```

Für wissenschaftlich saubere Ergebnisse:

```text
Train      → Training
Validation → Auswahl / Thresholds / Ensemble-Komponenten
Test       → finale Bewertung
```

---

## Zugehörige Notebook-Datei

```text
crack_pipeline_blocks_1_to_9_reviewed_v3.ipynb
```
