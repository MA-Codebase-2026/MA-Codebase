#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Auswertung einer binären Rissmaske.

Berechnet pro zusammenhängendem Riss:
- Fläche [px²]
- Länge des Skeletts [px]
- durchschnittliche Breite [px]
- Medianbreite [px]

Zusätzlich werden Gesamtwerte über alle Risse ausgegeben.

Es wird KEIN Modell geladen.
Die Eingabe ist direkt eine fertige Maske:
- Weiß / > Schwellwert = Riss
- Schwarz / <= Schwellwert = Hintergrund

Methode:
1. Maske binarisieren
2. optional kleine Objekte / Löcher bereinigen
3. zusammenhängende Rissobjekte bestimmen
4. Skelettierung
5. euklidische Distanztransformation
6. lokale Breite am Skelett: 2 * Abstand zum Rand
7. Skelettlänge mit 8er-Nachbarschaft berechnen

Installation:
    pip install numpy opencv-python scipy scikit-image

Beispiel:
    python rissmaske_auswerten.py --mask binary_mask.png

Ohne Argumente kannst du unten in DEFAULT_MASK_PATH einen festen Eingabepfad
und in DEFAULT_OUTPUT_DIR den gewünschten Ausgabeordner eintragen.

Alle Ausgabedateien enthalten automatisch den Namen der analysierten Maske,
z. B. ``bild_01_cleaned_mask.png`` oder
``bild_01_crack_measurements.json``.
"""

from __future__ import annotations

import argparse
import csv
import json
import math
import re
import sys
from pathlib import Path
from typing import Any

import cv2
import numpy as np
from scipy.ndimage import distance_transform_edt
from skimage.measure import label, regionprops
from skimage.morphology import (
    remove_small_holes,
    remove_small_objects,
    skeletonize,
)


# ---------------------------------------------------------------------------
# Pfade direkt im Code einstellen
# ---------------------------------------------------------------------------

DEFAULT_MASK_PATH = Path("/home/mitte/crack_project/test_images/10_Bilder_test/masks/5_64702f5f34_90_grad_x3840_y4864.png")

# Beispiel für einen festen Eingabepfad:
# DEFAULT_MASK_PATH = Path("/home/mitte/crack_project/test_images/bild_01_mask.png")

# Gewünschten Ausgabeordner hier direkt eintragen.
DEFAULT_OUTPUT_DIR = Path("/home/mitte/crack_project/test_images/unterschied_betterdataset_und_perfect_label")


# ---------------------------------------------------------------------------
# Laden und Bereinigen
# ---------------------------------------------------------------------------

def load_binary_mask(mask_path: str | Path, threshold: int = 127) -> np.ndarray:
    """Lädt eine Graustufenmaske und wandelt sie in bool um."""
    mask_path = Path(mask_path)

    if not mask_path.is_file():
        raise FileNotFoundError(f"Maskendatei nicht gefunden: {mask_path}")

    image = cv2.imread(str(mask_path), cv2.IMREAD_GRAYSCALE)
    if image is None:
        raise ValueError(f"Maske konnte nicht gelesen werden: {mask_path}")

    return image > threshold


def clean_mask(
    mask: np.ndarray,
    min_object_area: int = 0,
    max_hole_area: int = 0,
) -> np.ndarray:
    """
    Optionale Nachbearbeitung.

    min_object_area = 0:
        keine kleinen Objekte entfernen

    max_hole_area = 0:
        keine kleinen Löcher schließen
    """
    result = mask.astype(bool)

    if min_object_area > 0:
        result = remove_small_objects(result, min_size=min_object_area)

    if max_hole_area > 0:
        result = remove_small_holes(result, area_threshold=max_hole_area)

    return result.astype(bool)


# ---------------------------------------------------------------------------
# Skelett und Breite
# ---------------------------------------------------------------------------

def compute_skeleton_and_widths(
    mask: np.ndarray,
) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
    """
    Berechnet:
    - Skelett
    - euklidische Distanztransformation
    - lokale Rissbreite an jedem Skelettpixel

    Wie im Ausgangscode:
        Breite = 2 * distance_transform(mask) am Skelett
    """
    skeleton = skeletonize(mask)
    distance = distance_transform_edt(mask)
    local_widths = 2.0 * distance[skeleton]

    return skeleton, distance, local_widths


def compute_skeleton_length(skeleton: np.ndarray) -> float:
    """
    Berechnet die geometrische Länge des Skeletts in Pixeln.

    Anders als einfach nur die Anzahl der Skelettpixel zu verwenden,
    werden Verbindungen zwischen benachbarten Skelettpixeln ausgewertet:

    horizontal / vertikal -> Länge 1
    diagonal              -> Länge sqrt(2)

    Jede Verbindung wird genau einmal gezählt.
    """
    skel = skeleton.astype(bool)

    if not np.any(skel):
        return 0.0

    # Nur vier "Vorwärtsrichtungen", damit jede Kante einmal gezählt wird.
    directions = [
        (0, 1, 1.0),                # rechts
        (1, 0, 1.0),                # unten
        (1, 1, math.sqrt(2.0)),     # unten-rechts
        (1, -1, math.sqrt(2.0)),    # unten-links
    ]

    h, w = skel.shape
    length = 0.0

    for dy, dx, weight in directions:
        y1_start = max(0, -dy)
        y1_end = min(h, h - dy)
        x1_start = max(0, -dx)
        x1_end = min(w, w - dx)

        y2_start = y1_start + dy
        y2_end = y1_end + dy
        x2_start = x1_start + dx
        x2_end = x1_end + dx

        connected = (
            skel[y1_start:y1_end, x1_start:x1_end]
            & skel[y2_start:y2_end, x2_start:x2_end]
        )

        length += float(np.count_nonzero(connected)) * weight

    # Ein einzelner isolierter Skelettpixel hätte sonst Länge 0.
    if length == 0.0 and np.count_nonzero(skel) == 1:
        return 1.0

    return length


# ---------------------------------------------------------------------------
# Rissanalyse
# ---------------------------------------------------------------------------

def analyze_crack_mask(mask: np.ndarray) -> tuple[list[dict[str, Any]], dict[str, Any]]:
    """Analysiert jeden zusammenhängenden Riss separat."""
    labeled = label(mask, connectivity=2)
    regions = regionprops(labeled)

    results: list[dict[str, Any]] = []

    all_widths: list[np.ndarray] = []
    total_area = 0
    total_length = 0.0
    total_skeleton_points = 0

    for crack_id, region in enumerate(regions, start=1):
        min_row, min_col, max_row, max_col = region.bbox

        region_mask = (
            labeled[min_row:max_row, min_col:max_col] == region.label
        )

        skeleton, distance, local_widths = compute_skeleton_and_widths(region_mask)

        area_px = int(region.area)
        length_px = compute_skeleton_length(skeleton)
        skeleton_points = int(np.count_nonzero(skeleton))

        if local_widths.size:
            mean_width_px = float(np.mean(local_widths))
            median_width_px = float(np.median(local_widths))
        else:
            mean_width_px = None
            median_width_px = None

        centroid_y, centroid_x = region.centroid

        result = {
            "crack_id": crack_id,
            "area_px": area_px,
            "length_px": float(length_px),
            "mean_width_px": mean_width_px,
            "median_width_px": median_width_px,
            "skeleton_points": skeleton_points,
            "bbox_xyxy": [
                int(min_col),
                int(min_row),
                int(max_col),
                int(max_row),
            ],
            "centroid_xy": [
                float(centroid_x),
                float(centroid_y),
            ],
        }

        results.append(result)

        total_area += area_px
        total_length += length_px
        total_skeleton_points += skeleton_points

        if local_widths.size:
            all_widths.append(local_widths)

    if all_widths:
        widths = np.concatenate(all_widths)
        global_mean_width = float(np.mean(widths))
        global_median_width = float(np.median(widths))
    else:
        global_mean_width = None
        global_median_width = None

    summary = {
        "number_of_cracks": len(results),
        "area_px": int(total_area),
        "length_px": float(total_length),
        "mean_width_px": global_mean_width,
        "median_width_px": global_median_width,
        "skeleton_points": int(total_skeleton_points),
    }

    return results, summary


# ---------------------------------------------------------------------------
# Visualisierung
# ---------------------------------------------------------------------------

def create_visualization(
    mask: np.ndarray,
    results: list[dict[str, Any]],
) -> np.ndarray:
    """
    Erstellt ein Kontrollbild:
    - Rissmaske weiß
    - Skelett rot
    - Bounding Boxes + Werte
    """
    base = (mask.astype(np.uint8) * 255)
    vis = cv2.cvtColor(base, cv2.COLOR_GRAY2BGR)

    labeled = label(mask, connectivity=2)

    for result in results:
        crack_id = result["crack_id"]
        x1, y1, x2, y2 = result["bbox_xyxy"]

        region_mask = labeled[y1:y2, x1:x2] == crack_id
        skeleton = skeletonize(region_mask)

        ys, xs = np.nonzero(skeleton)
        vis[ys + y1, xs + x1] = (0, 0, 255)

        cv2.rectangle(vis, (x1, y1), (x2 - 1, y2 - 1), (0, 255, 0), 1)

        mean_width = result["mean_width_px"]
        median_width = result["median_width_px"]

        if mean_width is not None and median_width is not None:
            text = (
                f"ID {crack_id}: "
                f"B={mean_width:.2f}px "
                f"Med={median_width:.2f}px "
                f"L={result['length_px']:.1f}px "
                f"A={result['area_px']}px2"
            )
        else:
            text = f"ID {crack_id}"

        text_y = max(15, y1 - 5)

        cv2.putText(
            vis,
            text,
            (x1, text_y),
            cv2.FONT_HERSHEY_SIMPLEX,
            0.45,
            (0, 255, 0),
            1,
            cv2.LINE_AA,
        )

    return vis


# ---------------------------------------------------------------------------
# Ausgabe
# ---------------------------------------------------------------------------

def print_results(results: list[dict[str, Any]], summary: dict[str, Any]) -> None:
    print()
    print("=" * 72)
    print("RISS-AUSWERTUNG")
    print("=" * 72)

    if not results:
        print("Keine zusammenhängenden Risspixel in der Maske gefunden.")
        return

    for r in results:
        print()
        print(f"Riss {r['crack_id']}")
        print(f"  Durchschnittliche Breite : {format_value(r['mean_width_px'])} px")
        print(f"  Medianbreite              : {format_value(r['median_width_px'])} px")
        print(f"  Länge                     : {r['length_px']:.3f} px")
        print(f"  Fläche                    : {r['area_px']} px²")

    print()
    print("-" * 72)
    print("GESAMT")
    print("-" * 72)
    print(f"Anzahl Risse                : {summary['number_of_cracks']}")
    print(f"Durchschnittliche Breite    : {format_value(summary['mean_width_px'])} px")
    print(f"Medianbreite                : {format_value(summary['median_width_px'])} px")
    print(f"Gesamtlänge                 : {summary['length_px']:.3f} px")
    print(f"Gesamtfläche                : {summary['area_px']} px²")
    print()


def format_value(value: float | None) -> str:
    if value is None:
        return "n/a"
    return f"{value:.3f}"


def safe_output_stem(mask_path: Path) -> str:
    """Erzeugt einen sicheren Dateinamen aus dem Namen der analysierten Maske."""
    stem = re.sub(r"[^A-Za-z0-9._-]+", "_", mask_path.stem).strip("._")
    return stem or "analysierte_maske"


def save_csv(results: list[dict[str, Any]], path: Path) -> None:
    fieldnames = [
        "crack_id",
        "mean_width_px",
        "median_width_px",
        "length_px",
        "area_px",
        "skeleton_points",
        "bbox_xyxy",
        "centroid_xy",
    ]

    with path.open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()

        for result in results:
            row = result.copy()
            row["bbox_xyxy"] = json.dumps(row["bbox_xyxy"])
            row["centroid_xy"] = json.dumps(row["centroid_xy"])
            writer.writerow(row)


def save_json(
    results: list[dict[str, Any]],
    summary: dict[str, Any],
    path: Path,
) -> None:
    data = {
        "summary": summary,
        "cracks": results,
    }

    with path.open("w", encoding="utf-8") as f:
        json.dump(data, f, indent=2, ensure_ascii=False)


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------

def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description=(
            "Wertet eine fertige binäre Rissmaske mittels "
            "Skelettierung und Distanztransformation aus."
        )
    )

    parser.add_argument(
        "--mask",
        type=str,
        required=DEFAULT_MASK_PATH is None,
        default=DEFAULT_MASK_PATH,
        help="Pfad zur binären Rissmaske.",
    )

    parser.add_argument(
        "--output_dir",
        type=Path,
        default=DEFAULT_OUTPUT_DIR,
        help=f"Ausgabeordner (Standard aus dem Code: {DEFAULT_OUTPUT_DIR}).",
    )

    parser.add_argument(
        "--threshold",
        type=int,
        default=127,
        help=(
            "Grauwert-Schwellwert der Eingabemaske. "
            "Pixel > threshold gelten als Riss (Default: 127)."
        ),
    )

    parser.add_argument(
        "--min_object_area",
        type=int,
        default=0,
        help=(
            "Optional: Objekte kleiner als diese Fläche entfernen. "
            "0 = deaktiviert."
        ),
    )

    parser.add_argument(
        "--max_hole_area",
        type=int,
        default=0,
        help=(
            "Optional: Löcher bis zu dieser Fläche schließen. "
            "0 = deaktiviert."
        ),
    )

    return parser.parse_args()


def main() -> int:
    args = parse_args()

    mask_path = Path(args.mask).expanduser()
    output_dir = Path(args.output_dir).expanduser()
    output_dir.mkdir(parents=True, exist_ok=True)

    image_name = safe_output_stem(mask_path)

    print(f"Lade Maske: {mask_path}")
    print(f"Ausgabeordner: {output_dir}")
    print(f"Namenspräfix: {image_name}")

    mask = load_binary_mask(
        mask_path,
        threshold=args.threshold,
    )

    mask = clean_mask(
        mask,
        min_object_area=args.min_object_area,
        max_hole_area=args.max_hole_area,
    )

    results, summary = analyze_crack_mask(mask)

    print_results(results, summary)

    cleaned_mask_path = output_dir / f"{image_name}_cleaned_mask.png"
    visualization_path = output_dir / f"{image_name}_skeleton_analysis.png"
    csv_path = output_dir / f"{image_name}_crack_measurements.csv"
    json_path = output_dir / f"{image_name}_crack_measurements.json"

    cv2.imwrite(
        str(cleaned_mask_path),
        mask.astype(np.uint8) * 255,
    )

    visualization = create_visualization(mask, results)
    cv2.imwrite(str(visualization_path), visualization)

    save_csv(results, csv_path)
    save_json(results, summary, json_path)

    print("Dateien gespeichert:")
    print(f"  Bereinigte Maske : {cleaned_mask_path}")
    print(f"  Skelettbild      : {visualization_path}")
    print(f"  CSV              : {csv_path}")
    print(f"  JSON             : {json_path}")

    return 0


if __name__ == "__main__":
    raise SystemExit(main())
