#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
U-Net++ Baseline-Training mit vollständigem Logging.

Enthalten:
- vollständiges Modell jeder Epoche
- bestes Modell nach val_dice_fg
- ReduceLROnPlateau und EarlyStopping nach val_dice_fg
- TXT-, CSV- und JSON-Protokoll
- vollständige Plot-Sammlung plus gemeinsamer 0-1-Metrikplot
- ausführlicher Architekturbericht inklusive Konnektivitäts-/Concat-Audit
- Lauf-, Hardware-, Software- und Datensatzmetadaten
- Keras-Standardfortschrittsanzeige über model.fit(verbose=1)

Wichtiger Hinweis zu val_map:
val_ap ist die pixelweise Average Precision der Vordergrundklasse (Riss).
val_map ist hier die pixelweise Mean Average Precision über die beiden Klassen
Vordergrund und Hintergrund: mean(AP_fg, AP_bg). Dadurch ist val_map fachlich
klar definiert. Sie ist nicht direkt mit einer früheren, nur als Mittelwert von
Precision-Werten über Schwellen berechneten "mAP-Approximation" vergleichbar.
"""

from __future__ import annotations

import csv
import importlib.metadata
import json
import math
import os

os.environ["TF_GPU_ALLOCATOR"] = "cuda_malloc_async"
os.environ["KERAS_BACKEND"] = "tensorflow"

import tensorflow as tf

import platform
import random
import shutil
import subprocess
import sys
from datetime import datetime
from pathlib import Path
from typing import Any, Iterable

import matplotlib.pyplot as plt
import numpy as np
import tensorflow as tf
from keras import mixed_precision
from keras.utils import plot_model



# =============================================================================
# 1. KONFIGURATION – HIER ANPASSEN
# ============================================================================= 

RUN_NAME = "unetpp_512px_f8-128_mixedDatasets"
# Ein oder zwei Datensätze angeben.
# - Ein Pfad: Der Datensatz wird vollständig verwendet.
# - Zwei Pfade: Jeder Split wird deterministisch auf exakt 50/50 aus beiden
#   Datensätzen zusammengesetzt; der größere Datensatz wird heruntergesampelt.
SEG_DIRS = [
    Path("/home/mitte/crack_project/datasets/baseline_dataset/uncolored_set"),
    Path("/home/mitte/crack_project/datasets/better_dataset_evtl"),
]

if len(SEG_DIRS) not in (1, 2):
    raise ValueError("SEG_DIRS muss genau einen oder zwei Datensatzpfade enthalten.")
OUTPUT_ROOT = Path("/home/mitte/crack_project/outputs")

TRAIN_SPLIT = "train_512"
VAL_SPLIT = "val_512"
TEST_SPLIT = "test_512"

SEED = 42
IMG_SIZE = 512
BATCH = 8
INITIAL_LR = 1e-4
STEPS_PER_EPOCH = 1000
VALIDATION_STEPS = 200
EPOCHS = 40
THRESHOLD = 0.5

# U-Net++-Architektur
# Fünf Encoderstufen und vier vollständig verschachtelte Decoderstufen.
# Jeder Knoten X_i_j erhält alle vorherigen Knoten derselben Auflösung sowie
# den hochskalierten Knoten aus der nächsttieferen Ebene.
FILTER_NUM = [8, 16, 32, 64, 128]
CONVS_PER_BLOCK = 2
ACTIVATION = "relu"
BATCH_NORM = True
KERNEL_INITIALIZER = "he_normal"
DEEP_SUPERVISION = False

# Zielanteil der Hard Negatives im tatsächlich verwendeten Trainingssplit.
# Die HN-Paare werden je Datensatz aus folgenden Ordnern gelesen:
#   <dataset>/<train_split>/images_512px_hard_negatives
#   <dataset>/<train_split>/masks_512px_hard_negatives
# Bei 0.0 werden keine Hard Negatives ergänzt.
HARD_NEGATIVE_TARGET_SHARE = 0.0  # 0.0 = 0 %, 0.20 = 20 %, 0.35 = 35 %

MASK_FORMAT_DESCRIPTION = (
    "PNG, 1 Kanal; Pixel > 127 werden als Rissklasse 1, sonst als 0 eingelesen"
)
LOSS_NAME = "Dice Loss = 1 - Soft Dice"
OPTIMIZER_NAME = "Adam"

LR_REDUCE_PATIENCE = 5
LR_REDUCE_FACTOR = 0.5
EARLY_STOPPING_PATIENCE = 10
MIN_DELTA = 0.0

# Plots werden nach jeder Epoche aktualisiert. Bei 0 nur am Trainingsende.
PLOTS_EVERY_N_EPOCHS = 1

# 101 Konfidenzschwellen für pixelweise AP-Berechnung
AP_THRESHOLDS = np.linspace(1.0, 0.0, 101, dtype=np.float64)

# Unterstützte Dateien. Die TensorFlow-Decodierung unten ist bewusst auf PNG
# ausgelegt, damit Masken exakt und ohne verlustbehaftete JPEG-Artefakte bleiben.
SUPPORTED_EXTENSIONS = {".png"}


# =============================================================================
# 2. AUSGABEPFADE
# =============================================================================

RUN_DIR = OUTPUT_ROOT / RUN_NAME
MODEL_DIR = RUN_DIR / "models"
METRICS_DIR = RUN_DIR / "metrics"
PLOT_DIR = METRICS_DIR / "plots"
ARCH_DIR = RUN_DIR / "architecture"

METRICS_TXT_FILE = METRICS_DIR / f"{RUN_NAME}_epoch_metrics.txt"
METRICS_CSV_FILE = METRICS_DIR / f"{RUN_NAME}_epoch_metrics.csv"
METRICS_JSON_FILE = METRICS_DIR / f"{RUN_NAME}_epoch_metrics.json"
RUN_CONFIG_FILE = METRICS_DIR / f"{RUN_NAME}_run_configuration.txt"

ARCHITECTURE_TXT_FILE = ARCH_DIR / f"{RUN_NAME}_architecture_detailed.txt"
ARCHITECTURE_JSON_FILE = ARCH_DIR / f"{RUN_NAME}_architecture_config.json"
ARCHITECTURE_KERAS_JSON_FILE = ARCH_DIR / f"{RUN_NAME}_architecture_keras.json"
ARCHITECTURE_PNG_FILE = ARCH_DIR / f"{RUN_NAME}_architecture.png"


# =============================================================================
# 3. REPRODUZIERBARKEIT / MIXED PRECISION
# =============================================================================

os.environ["PYTHONHASHSEED"] = str(SEED)

random.seed(SEED)
np.random.seed(SEED)
tf.random.set_seed(SEED)

tf.config.optimizer.set_jit(False)

MIXED_PRECISION_POLICY = "float32"
mixed_precision.set_global_policy(MIXED_PRECISION_POLICY)

# Keras-Standardausgabe/Progbar im Terminal aktivieren.
try:
    tf.keras.utils.enable_interactive_logging()
except AttributeError:
    pass


# =============================================================================
# 4. ALLGEMEINE HILFSFUNKTIONEN
# =============================================================================

def json_safe(value: Any) -> Any:
    """Konvertiert typische Python-/NumPy-/TensorFlow-Werte JSON-sicher."""
    if isinstance(value, dict):
        return {str(k): json_safe(v) for k, v in value.items()}
    if isinstance(value, (list, tuple, set)):
        return [json_safe(v) for v in value]
    if isinstance(value, Path):
        return str(value)
    if isinstance(value, np.ndarray):
        return value.tolist()
    if isinstance(value, np.generic):
        return value.item()
    if isinstance(value, (datetime,)):
        return value.isoformat()
    if isinstance(value, bytes):
        return value.decode("utf-8", errors="replace")
    try:
        json.dumps(value)
        return value
    except TypeError:
        return str(value)


def write_json_atomic(path: Path, data: dict[str, Any]) -> None:
    """Schreibt JSON atomar, damit bei einem Abbruch keine halbe Datei bleibt."""
    path.parent.mkdir(parents=True, exist_ok=True)
    temp_path = path.with_suffix(path.suffix + ".tmp")
    with temp_path.open("w", encoding="utf-8") as file:
        json.dump(json_safe(data), file, indent=2, ensure_ascii=False)
    temp_path.replace(path)


def package_version(*package_names: str) -> str:
    """Liefert die erste gefundene Paketversion."""
    for package_name in package_names:
        try:
            return importlib.metadata.version(package_name)
        except importlib.metadata.PackageNotFoundError:
            continue
        except Exception as exc:  # pragma: no cover - reine Diagnose
            return f"Fehler beim Auslesen: {exc}"
    return "nicht gefunden"


def run_command(command: list[str], timeout: int = 15) -> str:
    """Führt einen Diagnosebefehl aus und gibt dessen Ausgabe zurück."""
    try:
        result = subprocess.run(
            command,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True,
            timeout=timeout,
            check=False,
        )
        if result.returncode == 0 and result.stdout.strip():
            return result.stdout.strip()
        error = result.stderr.strip() or f"Returncode {result.returncode}"
        return f"nicht verfügbar ({error})"
    except FileNotFoundError:
        return "nicht verfügbar (Befehl nicht gefunden)"
    except subprocess.TimeoutExpired:
        return "nicht verfügbar (Timeout)"
    except Exception as exc:  # pragma: no cover - reine Diagnose
        return f"nicht verfügbar ({exc})"


def find_nvidia_smi() -> str | None:
    candidates = [
        shutil.which("nvidia-smi"),
        "/usr/lib/wsl/lib/nvidia-smi",
        "/usr/bin/nvidia-smi",
    ]
    for candidate in candidates:
        if candidate and Path(candidate).exists():
            return str(candidate)
    return None


def get_current_learning_rate(optimizer: tf.keras.optimizers.Optimizer) -> float:
    try:
        lr = optimizer.learning_rate
        if callable(lr):
            lr = lr(optimizer.iterations)
        return float(tf.keras.backend.get_value(lr))
    except Exception:
        return float("nan")


def safe_div(numerator: float, denominator: float, eps: float = 1e-7) -> float:
    return float((numerator + eps) / (denominator + eps))


# =============================================================================
# 5. SYSTEM- UND SOFTWAREINFORMATIONEN
# =============================================================================

def collect_environment_info() -> dict[str, Any]:
    tf_build_info = {}
    try:
        tf_build_info = dict(tf.sysconfig.get_build_info())
    except Exception as exc:
        tf_build_info = {"error": str(exc)}

    nvidia_smi = find_nvidia_smi()
    if nvidia_smi:
        gpu_query = run_command(
            [
                nvidia_smi,
                "--query-gpu=name,driver_version,memory.total",
                "--format=csv,noheader",
            ]
        )
        driver_query = run_command(
            [nvidia_smi, "--query-gpu=driver_version", "--format=csv,noheader"]
        )
        nvidia_smi_full = run_command([nvidia_smi])
    else:
        gpu_query = "nicht verfügbar"
        driver_query = "nicht verfügbar"
        nvidia_smi_full = "nicht verfügbar"

    physical_gpus = tf.config.list_physical_devices("GPU")
    tensorflow_gpu_details: list[dict[str, Any]] = []
    for gpu in physical_gpus:
        details: dict[str, Any] = {"name": gpu.name, "device_type": gpu.device_type}
        try:
            details.update(tf.config.experimental.get_device_details(gpu))
        except Exception as exc:
            details["details_error"] = str(exc)
        tensorflow_gpu_details.append(details)

    keras_version = getattr(tf.keras, "__version__", None)
    if not keras_version:
        keras_version = package_version("keras")

    cuda_build = tf_build_info.get("cuda_version", "nicht angegeben")
    cudnn_build = tf_build_info.get("cudnn_version", "nicht angegeben")

    cuda_runtime_pkg = package_version(
        "nvidia-cuda-runtime-cu12",
        "nvidia-cuda-runtime-cu11",
    )
    cudnn_runtime_pkg = package_version(
        "nvidia-cudnn-cu12",
        "nvidia-cudnn-cu11",
    )

    return {
        "timestamp_start": datetime.now().astimezone().isoformat(),
        "python_version": sys.version.replace("\n", " "),
        "python_executable": sys.executable,
        "platform": platform.platform(),
        "system": platform.system(),
        "release": platform.release(),
        "machine": platform.machine(),
        "tensorflow_version": tf.__version__,
        "keras_version": keras_version,
        "keras_unet_collection_version": package_version("keras-unet-collection"),
        "numpy_version": np.__version__,
        "matplotlib_version": package_version("matplotlib"),
        "mixed_precision_policy": mixed_precision.global_policy().name,
        "tensorflow_built_with_cuda": bool(tf.test.is_built_with_cuda()),
        "tensorflow_build_info": json_safe(tf_build_info),
        "cuda_runtime": (
            f"TensorFlow-Build: {cuda_build}; "
            f"Python-Paket nvidia-cuda-runtime: {cuda_runtime_pkg}"
        ),
        "cudnn_version": (
            f"TensorFlow-Build: {cudnn_build}; "
            f"Python-Paket nvidia-cudnn: {cudnn_runtime_pkg}"
        ),
        "nvidia_windows_driver": driver_query,
        "nvidia_gpu_query": gpu_query,
        "nvidia_smi_full": nvidia_smi_full,
        "tensorflow_visible_gpus": json_safe(tensorflow_gpu_details),
        "cuda_visible_devices": os.environ.get("CUDA_VISIBLE_DEVICES", "nicht gesetzt"),
    }


# =============================================================================
# 6. DATENSATZ UND TF.DATA-PIPELINE
# =============================================================================

def collect_pairs_from_directories(
    image_dir: Path,
    mask_dir: Path,
    source_label: str,
) -> tuple[list[str], list[str], dict[str, Any]]:
    """Sammelt namensgleiche PNG-Bild-/Maskenpaare aus zwei Ordnern."""
    if not image_dir.is_dir():
        raise FileNotFoundError(f"Bilderordner fehlt: {image_dir}")
    if not mask_dir.is_dir():
        raise FileNotFoundError(f"Maskenordner fehlt: {mask_dir}")

    image_paths = sorted(
        p for p in image_dir.iterdir()
        if p.is_file()
        and not p.name.startswith(".")
        and p.suffix.lower() in SUPPORTED_EXTENSIONS
    )
    mask_paths = sorted(
        p for p in mask_dir.iterdir()
        if p.is_file()
        and not p.name.startswith(".")
        and p.suffix.lower() in SUPPORTED_EXTENSIONS
    )

    mask_map: dict[str, Path] = {}
    duplicate_mask_stems: list[str] = []
    for mask_path in mask_paths:
        stem = mask_path.stem.lower()
        if stem in mask_map:
            duplicate_mask_stems.append(stem)
        mask_map[stem] = mask_path

    valid_images: list[str] = []
    valid_masks: list[str] = []
    images_without_mask: list[str] = []
    for image_path in image_paths:
        mask_path = mask_map.get(image_path.stem.lower())
        if mask_path is None:
            images_without_mask.append(str(image_path))
            continue
        valid_images.append(str(image_path))
        valid_masks.append(str(mask_path))

    image_stems = {p.stem.lower() for p in image_paths}
    masks_without_image = [
        str(mask_path) for mask_path in mask_paths
        if mask_path.stem.lower() not in image_stems
    ]

    info = {
        "source_label": source_label,
        "image_dir": str(image_dir),
        "mask_dir": str(mask_dir),
        "images_found": len(image_paths),
        "masks_found": len(mask_paths),
        "matched_pairs": len(valid_images),
        "images_without_mask_count": len(images_without_mask),
        "masks_without_image_count": len(masks_without_image),
        "duplicate_mask_stems_count": len(duplicate_mask_stems),
        "images_without_mask_examples": images_without_mask[:20],
        "masks_without_image_examples": masks_without_image[:20],
        "duplicate_mask_stems_examples": duplicate_mask_stems[:20],
    }
    return valid_images, valid_masks, info


def deterministic_sample_pairs(
    images: list[str],
    masks: list[str],
    count: int,
    seed_offset: int,
) -> tuple[list[str], list[str]]:
    if count < 0 or count > len(images):
        raise ValueError(f"Ungültige Stichprobengröße {count} für {len(images)} Paare.")
    if count == len(images):
        return list(images), list(masks)
    rng = np.random.default_rng(SEED + seed_offset)
    indices = np.sort(rng.choice(len(images), size=count, replace=False))
    return [images[i] for i in indices], [masks[i] for i in indices]


def desired_hn_count(normal_count: int) -> int:
    if HARD_NEGATIVE_TARGET_SHARE <= 0.0:
        return 0
    if not 0.0 <= HARD_NEGATIVE_TARGET_SHARE < 1.0:
        raise ValueError("HARD_NEGATIVE_TARGET_SHARE muss im Intervall [0, 1) liegen.")
    return int(round(normal_count * HARD_NEGATIVE_TARGET_SHARE / (1.0 - HARD_NEGATIVE_TARGET_SHARE)))


def collect_dataset_split(
    dataset_root: Path,
    split: str,
    dataset_index: int,
) -> dict[str, Any]:
    split_dir = dataset_root / split
    normal_images, normal_masks, normal_info = collect_pairs_from_directories(
        split_dir / "images", split_dir / "masks", "normal"
    )
    if not normal_images:
        raise RuntimeError(f"Keine normalen Bild-Masken-Paare in {split_dir} gefunden.")

    hn_images: list[str] = []
    hn_masks: list[str] = []
    hn_info: dict[str, Any] = {"matched_pairs": 0, "enabled": False}
    if split == TRAIN_SPLIT and HARD_NEGATIVE_TARGET_SHARE > 0.0:
        hn_images, hn_masks, hn_info = collect_pairs_from_directories(
            split_dir / "images_512px_hard_negatives",
            split_dir / "masks_512px_hard_negatives",
            "hard_negative",
        )
        hn_info["enabled"] = True
        if not hn_images:
            raise RuntimeError(
                f"HARD_NEGATIVE_TARGET_SHARE={HARD_NEGATIVE_TARGET_SHARE} gesetzt, "
                f"aber keine HN-Paare in {split_dir} gefunden."
            )

    return {
        "dataset_index": dataset_index,
        "dataset_root": str(dataset_root),
        "split": split,
        "normal_images": normal_images,
        "normal_masks": normal_masks,
        "hn_images": hn_images,
        "hn_masks": hn_masks,
        "normal_info": normal_info,
        "hard_negative_info": hn_info,
    }


def load_and_preprocess(
    image_path: tf.Tensor,
    mask_path: tf.Tensor,
) -> tuple[tf.Tensor, tf.Tensor]:
    image = tf.io.read_file(image_path)
    image = tf.image.decode_png(image, channels=3)
    image = tf.image.convert_image_dtype(image, tf.float32)
    image.set_shape([IMG_SIZE, IMG_SIZE, 3])

    mask = tf.io.read_file(mask_path)
    mask = tf.image.decode_png(mask, channels=1)
    mask = tf.cast(mask > 127, tf.float32)
    mask.set_shape([IMG_SIZE, IMG_SIZE, 1])

    return image, mask


def build_dataset(
    split: str,
) -> tuple[tf.data.Dataset, int, dict[str, Any]]:
    sources = [
        collect_dataset_split(root, split, index)
        for index, root in enumerate(SEG_DIRS)
    ]

    selected_by_source: list[dict[str, Any]] = []

    if len(sources) == 1:
        source = sources[0]
        normal_count = len(source["normal_images"])
        hn_requested = desired_hn_count(normal_count) if split == TRAIN_SPLIT else 0
        hn_used = min(hn_requested, len(source["hn_images"]))
        hn_images, hn_masks = deterministic_sample_pairs(
            source["hn_images"], source["hn_masks"], hn_used, 1000
        )
        images = list(source["normal_images"]) + hn_images
        masks = list(source["normal_masks"]) + hn_masks
        selected_by_source.append({
            "dataset_root": source["dataset_root"],
            "normal_available": normal_count,
            "normal_used": normal_count,
            "hard_negatives_available": len(source["hn_images"]),
            "hard_negatives_requested": hn_requested,
            "hard_negatives_used": hn_used,
            "total_used": len(images),
        })
    else:
        # Für jeden Split genau gleich viele Beispiele aus beiden Ursprungsdatensätzen.
        if split == TRAIN_SPLIT and HARD_NEGATIVE_TARGET_SHARE > 0.0:
            # Pro Ursprung wird zunächst der maximal mögliche Pool mit gewünschtem
            # HN-Anteil bestimmt. Danach werden beide Ursprünge auf denselben
            # Gesamtumfang gebracht. Dadurch bleiben sowohl 50/50 Dataset-Anteil
            # als auch der HN-Zielanteil je Ursprung erhalten (bis auf Rundung).
            feasible_totals = []
            for source in sources:
                n = len(source["normal_images"])
                h = len(source["hn_images"])
                max_by_normal = int(n / (1.0 - HARD_NEGATIVE_TARGET_SHARE))
                max_by_hn = int(h / HARD_NEGATIVE_TARGET_SHARE)
                feasible_totals.append(min(max_by_normal, max_by_hn))
            per_source_total = min(feasible_totals)
            if per_source_total <= 0:
                raise RuntimeError("Kein gemeinsamer 50/50-Trainingspool mit Hard Negatives möglich.")
            hn_per_source = int(round(per_source_total * HARD_NEGATIVE_TARGET_SHARE))
            normal_per_source = per_source_total - hn_per_source
        else:
            normal_per_source = min(len(source["normal_images"]) for source in sources)
            hn_per_source = 0
            per_source_total = normal_per_source

        images = []
        masks = []
        for index, source in enumerate(sources):
            normal_images, normal_masks = deterministic_sample_pairs(
                source["normal_images"], source["normal_masks"], normal_per_source, 100 + index
            )
            hn_images, hn_masks = deterministic_sample_pairs(
                source["hn_images"], source["hn_masks"], hn_per_source, 1100 + index
            )
            images.extend(normal_images + hn_images)
            masks.extend(normal_masks + hn_masks)
            selected_by_source.append({
                "dataset_root": source["dataset_root"],
                "normal_available": len(source["normal_images"]),
                "normal_used": normal_per_source,
                "hard_negatives_available": len(source["hn_images"]),
                "hard_negatives_requested": hn_per_source,
                "hard_negatives_used": hn_per_source,
                "total_used": per_source_total,
                "dataset_share": 0.5,
            })

    # Einmal deterministisch mischen, damit die Ursprungsdatensätze nicht blockweise
    # im TensorFlow-Dataset stehen. Das Epochenshuffling folgt zusätzlich unten.
    rng = np.random.default_rng(SEED + 5000 + [TRAIN_SPLIT, VAL_SPLIT, TEST_SPLIT].index(split))
    order = rng.permutation(len(images))
    image_paths = [images[i] for i in order]
    mask_paths = [masks[i] for i in order]

    dataset = tf.data.Dataset.from_tensor_slices((image_paths, mask_paths))
    if split == TRAIN_SPLIT:
        dataset = dataset.shuffle(
            buffer_size=len(image_paths), seed=SEED, reshuffle_each_iteration=True
        ).repeat()

    dataset = dataset.map(load_and_preprocess, num_parallel_calls=tf.data.AUTOTUNE)
    if split != TRAIN_SPLIT:
        dataset = dataset.cache()
    dataset = dataset.batch(BATCH, drop_remainder=False).prefetch(tf.data.AUTOTUNE)

    total_hn = sum(item["hard_negatives_used"] for item in selected_by_source)
    info = {
        "split": split,
        "dataset_roots": [str(root) for root in SEG_DIRS],
        "dataset_count": len(SEG_DIRS),
        "mixing_mode": "single_full" if len(SEG_DIRS) == 1 else "exact_50_50",
        "matched_pairs": len(image_paths),
        "normal_pairs_used": len(image_paths) - total_hn,
        "hard_negative_pairs_used": total_hn,
        "hard_negative_actual_share": total_hn / len(image_paths) if image_paths else 0.0,
        "hard_negative_target_share": HARD_NEGATIVE_TARGET_SHARE if split == TRAIN_SPLIT else 0.0,
        "sources": selected_by_source,
        "source_scan_details": [
            {
                "dataset_root": source["dataset_root"],
                "normal": source["normal_info"],
                "hard_negative": source["hard_negative_info"],
            }
            for source in sources
        ],
    }
    return dataset, len(image_paths), info


# =============================================================================
# 7. MODELL: VOLLSTÄNDIGES U-NET++ MIT DICHTEN SKIP-CONNECTIONS
# =============================================================================

def conv_block(
    inputs: tf.Tensor,
    filters: int,
    name: str,
    n_convs: int = CONVS_PER_BLOCK,
) -> tf.Tensor:
    """Conv2D -> BatchNorm -> ReLU, standardmäßig zweimal pro Knoten."""
    x = inputs
    for conv_index in range(1, n_convs + 1):
        x = tf.keras.layers.Conv2D(
            filters=filters,
            kernel_size=3,
            padding="same",
            use_bias=not BATCH_NORM,
            kernel_initializer=KERNEL_INITIALIZER,
            name=f"{name}_conv{conv_index}",
        )(x)
        if BATCH_NORM:
            x = tf.keras.layers.BatchNormalization(
                name=f"{name}_bn{conv_index}"
            )(x)
        x = tf.keras.layers.Activation(
            ACTIVATION,
            name=f"{name}_{ACTIVATION}{conv_index}",
        )(x)
    return x


def upsample_to_level(
    inputs: tf.Tensor,
    filters: int,
    name: str,
) -> tf.Tensor:
    """Lernbares 2x-Upsampling in die nächsthöhere U-Net++-Ebene."""
    return tf.keras.layers.Conv2DTranspose(
        filters=filters,
        kernel_size=2,
        strides=2,
        padding="same",
        kernel_initializer=KERNEL_INITIALIZER,
        name=f"{name}_up",
    )(inputs)


def dense_decoder_node(
    same_level_nodes: list[tf.Tensor],
    deeper_node: tf.Tensor,
    filters: int,
    name: str,
) -> tf.Tensor:
    """Erzeugt X_i_j aus allen X_i_0...X_i_(j-1) und Up(X_(i+1)_(j-1))."""
    upsampled = upsample_to_level(deeper_node, filters, name)
    merged = tf.keras.layers.Concatenate(
        axis=-1,
        name=f"{name}_concat",
    )([*same_level_nodes, upsampled])
    return conv_block(merged, filters, name)


def build_unetplusplus_base() -> tf.keras.Model:
    """Vollständiges U-Net++ mit Knoten X0_0 bis X0_4."""
    inputs = tf.keras.Input(
        shape=(IMG_SIZE, IMG_SIZE, 3),
        name="unetpp_input",
    )

    # Encoderpfad X_i_0
    x0_0 = conv_block(inputs, FILTER_NUM[0], "X0_0")
    p0 = tf.keras.layers.MaxPooling2D(pool_size=2, name="pool0")(x0_0)

    x1_0 = conv_block(p0, FILTER_NUM[1], "X1_0")
    p1 = tf.keras.layers.MaxPooling2D(pool_size=2, name="pool1")(x1_0)

    x2_0 = conv_block(p1, FILTER_NUM[2], "X2_0")
    p2 = tf.keras.layers.MaxPooling2D(pool_size=2, name="pool2")(x2_0)

    x3_0 = conv_block(p2, FILTER_NUM[3], "X3_0")
    p3 = tf.keras.layers.MaxPooling2D(pool_size=2, name="pool3")(x3_0)

    x4_0 = conv_block(p3, FILTER_NUM[4], "X4_0")

    # Verschachtelte Decoderstufe j=1
    x0_1 = dense_decoder_node([x0_0], x1_0, FILTER_NUM[0], "X0_1")
    x1_1 = dense_decoder_node([x1_0], x2_0, FILTER_NUM[1], "X1_1")
    x2_1 = dense_decoder_node([x2_0], x3_0, FILTER_NUM[2], "X2_1")
    x3_1 = dense_decoder_node([x3_0], x4_0, FILTER_NUM[3], "X3_1")

    # Verschachtelte Decoderstufe j=2
    x0_2 = dense_decoder_node([x0_0, x0_1], x1_1, FILTER_NUM[0], "X0_2")
    x1_2 = dense_decoder_node([x1_0, x1_1], x2_1, FILTER_NUM[1], "X1_2")
    x2_2 = dense_decoder_node([x2_0, x2_1], x3_1, FILTER_NUM[2], "X2_2")

    # Verschachtelte Decoderstufe j=3
    x0_3 = dense_decoder_node(
        [x0_0, x0_1, x0_2],
        x1_2,
        FILTER_NUM[0],
        "X0_3",
    )
    x1_3 = dense_decoder_node(
        [x1_0, x1_1, x1_2],
        x2_2,
        FILTER_NUM[1],
        "X1_3",
    )

    # Verschachtelte Decoderstufe j=4; finale hochaufgelöste Repräsentation
    x0_4 = dense_decoder_node(
        [x0_0, x0_1, x0_2, x0_3],
        x1_3,
        FILTER_NUM[0],
        "X0_4",
    )

    logits = tf.keras.layers.Conv2D(
        filters=1,
        kernel_size=1,
        padding="same",
        activation=None,
        name="segmentation_logits",
    )(x0_4)

    return tf.keras.Model(
        inputs=inputs,
        outputs=logits,
        name="unetplusplus_model",
    )


def build_optimized_model() -> tf.keras.Model:
    base_model = build_unetplusplus_base()

    inputs = tf.keras.Input(
        shape=(IMG_SIZE, IMG_SIZE, 3),
        name="input_image",
    )
    logits = base_model(inputs)

    # float32-Ausgang für numerisch stabile Loss-/Metrikberechnung
    outputs = tf.keras.layers.Activation(
        "sigmoid",
        dtype="float32",
        name="predictions",
    )(logits)

    return tf.keras.Model(
        inputs=inputs,
        outputs=outputs,
        name="unetplusplus_training_model",
    )


# =============================================================================
# 8. LOSS UND METRIKEN
# =============================================================================

def dice_coef_soft(
    y_true: tf.Tensor,
    y_pred: tf.Tensor,
    smooth: float = 1e-7,
) -> tf.Tensor:
    y_true = tf.cast(y_true, tf.float32)
    y_pred = tf.cast(y_pred, tf.float32)

    intersection = tf.reduce_sum(y_true * y_pred, axis=[1, 2, 3])
    union = tf.reduce_sum(y_true + y_pred, axis=[1, 2, 3])

    dice_per_sample = (2.0 * intersection + smooth) / (union + smooth)
    return tf.reduce_mean(dice_per_sample)


def dice_loss(y_true: tf.Tensor, y_pred: tf.Tensor) -> tf.Tensor:
    return 1.0 - dice_coef_soft(y_true, y_pred)


def compute_confusion_from_binary(
    y_true_binary: np.ndarray,
    y_pred_binary: np.ndarray,
) -> tuple[int, int, int, int]:
    y_true_bool = y_true_binary.astype(bool)
    y_pred_bool = y_pred_binary.astype(bool)

    true_positive = int(np.logical_and(y_true_bool, y_pred_bool).sum())
    false_positive = int(np.logical_and(~y_true_bool, y_pred_bool).sum())
    false_negative = int(np.logical_and(y_true_bool, ~y_pred_bool).sum())
    true_negative = int(np.logical_and(~y_true_bool, ~y_pred_bool).sum())

    return true_positive, false_positive, false_negative, true_negative


def compute_fg_metrics_from_confusion(
    true_positive: int,
    false_positive: int,
    false_negative: int,
    true_negative: int,
) -> dict[str, float]:
    precision = safe_div(true_positive, true_positive + false_positive)
    recall = safe_div(true_positive, true_positive + false_negative)
    dice = safe_div(
        2 * true_positive,
        2 * true_positive + false_positive + false_negative,
    )
    iou = safe_div(
        true_positive,
        true_positive + false_positive + false_negative,
    )
    f1 = safe_div(2 * precision * recall, precision + recall)
    accuracy = safe_div(
        true_positive + true_negative,
        true_positive + true_negative + false_positive + false_negative,
    ) * 100.0

    return {
        "precision_fg": precision,
        "recall_fg": recall,
        "dice_fg": dice,
        "iou_fg": iou,
        "f1_fg": f1,
        "accuracy_percent": accuracy,
    }


def update_threshold_confusions(
    y_true_binary: np.ndarray,
    y_pred_probability: np.ndarray,
    thresholds: np.ndarray,
    true_positive: np.ndarray,
    false_positive: np.ndarray,
    false_negative: np.ndarray,
) -> None:
    """Akkumuliert TP/FP/FN für jede Konfidenzschwelle.

    Vorher: Python-for-Schleife über alle 101 Schwellen, die pro Schwelle
    mehrere volle Arrayoperationen über alle Pixel eines Batches ausgeführt
    hat (compute_confusion_from_binary). Bei VALIDATION_STEPS=250 und zwei
    Aufrufen pro Batch (Vordergrund + Hintergrund) ergab das rund 50.000
    einzelne Python-/NumPy-Aufrufe pro Epoche – das war der dominante
    Zeitfresser.

    Jetzt: einmal sortieren + np.searchsorted (Vektorbinärsuche über alle
    Schwellen gleichzeitig). Liefert exakt dieselben TP/FP/FN-Werte, aber in
    O(N log N + T log N) statt O(T · N) und ohne Python-Schleife.
    """
    y_true_flat = y_true_binary.reshape(-1).astype(bool)
    y_score_flat = y_pred_probability.reshape(-1).astype(np.float32)

    positive_scores = np.sort(y_score_flat[y_true_flat])
    negative_scores = np.sort(y_score_flat[~y_true_flat])

    total_positive = positive_scores.size

    # Anzahl Scores >= threshold = N - Einfügeindex im aufsteigend
    # sortierten Array (side="left" passt zum ">="-Vergleich des Originals).
    tp_counts = total_positive - np.searchsorted(positive_scores, thresholds, side="left")
    fp_counts = negative_scores.size - np.searchsorted(negative_scores, thresholds, side="left")

    true_positive += tp_counts
    false_positive += fp_counts
    false_negative += (total_positive - tp_counts)


def compute_ap_from_threshold_confusions(
    true_positive: np.ndarray,
    false_positive: np.ndarray,
    false_negative: np.ndarray,
) -> float:
    """
    Pixelweise interpolierte Average Precision aus der globalen PR-Kurve.
    """
    total_positives = float(np.max(true_positive + false_negative))
    if total_positives <= 0:
        return float("nan")

    predicted_positives = true_positive + false_positive
    precision = np.divide(
        true_positive,
        predicted_positives,
        out=np.ones_like(true_positive, dtype=np.float64),
        where=predicted_positives > 0,
    )
    recall = true_positive / total_positives

    order = np.argsort(recall)
    recall = recall[order]
    precision = precision[order]

    # Doppelte Recall-Werte zusammenfassen: je Recall den höchsten Precision-Wert.
    unique_recall, inverse = np.unique(recall, return_inverse=True)
    max_precision = np.zeros_like(unique_recall, dtype=np.float64)
    for index, precision_value in zip(inverse, precision):
        max_precision[index] = max(max_precision[index], precision_value)

    recall = np.concatenate(([0.0], unique_recall, [1.0]))
    precision = np.concatenate(
        ([max_precision[0] if max_precision.size else 0.0], max_precision, [0.0])
    )

    # Monotone Precision-Hüllkurve
    for index in range(precision.size - 2, -1, -1):
        precision[index] = max(precision[index], precision[index + 1])

    return float(np.sum((recall[1:] - recall[:-1]) * precision[1:]))


# =============================================================================
# 9. PLOTS
# =============================================================================

def save_plot(
    x_values: list[int],
    y_series: list[list[float]],
    labels: list[str],
    title: str,
    y_label: str,
    output_path: Path,
    y_limits: tuple[float, float] | None = None,
) -> None:
    plt.figure(figsize=(11, 6.5))
    for values, label in zip(y_series, labels):
        plt.plot(x_values, values, label=label)
    plt.xlabel("Epoche")
    plt.ylabel(y_label)
    plt.title(title)
    plt.grid(True, alpha=0.3)
    if y_limits is not None:
        plt.ylim(*y_limits)
    plt.legend(loc="best")
    plt.tight_layout()
    plt.savefig(output_path, dpi=200)
    plt.close()


def save_training_plots(
    history_rows: list[dict[str, float]],
    plot_dir: Path,
) -> None:
    plot_dir.mkdir(parents=True, exist_ok=True)
    if not history_rows:
        return

    epochs = [int(row["epoch"]) for row in history_rows]

    def values(field: str) -> list[float]:
        return [float(row[field]) for row in history_rows]

    save_plot(
        epochs,
        [values("train_loss"), values("val_loss")],
        ["train_loss", "val_loss"],
        "Loss-Verlauf",
        "Loss",
        plot_dir / "loss_curve.png",
    )

    save_plot(
        epochs,
        [
            values("train_dice_soft"),
            values("val_dice_soft"),
            values("val_dice_fg"),
        ],
        ["train_dice_soft", "val_dice_soft", "val_dice_fg"],
        "Dice-Verlauf",
        "Dice",
        plot_dir / "dice_curve.png",
        y_limits=(0.0, 1.02),
    )

    save_plot(
        epochs,
        [values("val_iou_fg")],
        ["val_iou_fg"],
        "IoU-Verlauf",
        "IoU",
        plot_dir / "iou_curve.png",
        y_limits=(0.0, 1.02),
    )

    save_plot(
        epochs,
        [
            values("val_precision_fg"),
            values("val_recall_fg"),
            values("val_f1_fg"),
        ],
        ["val_precision_fg", "val_recall_fg", "val_f1_fg"],
        "Precision / Recall / F1",
        "Score",
        plot_dir / "precision_recall_f1_curve.png",
        y_limits=(0.0, 1.02),
    )

    save_plot(
        epochs,
        [values("val_accuracy_pct")],
        ["val_accuracy_pct"],
        "Accuracy-Verlauf",
        "Accuracy (%)",
        plot_dir / "accuracy_curve.png",
        y_limits=(0.0, 100.5),
    )

    save_plot(
        epochs,
        [values("val_mse")],
        ["val_mse"],
        "MSE-Verlauf",
        "MSE",
        plot_dir / "mse_curve.png",
    )

    save_plot(
        epochs,
        [values("val_auc_roc"), values("val_auc_pr")],
        ["val_auc_roc", "val_auc_pr"],
        "AUC-Verläufe",
        "AUC",
        plot_dir / "auc_curve.png",
        y_limits=(0.0, 1.02),
    )

    save_plot(
        epochs,
        [values("val_ap")],
        ["val_ap_fg"],
        "Average Precision der Rissklasse",
        "AP",
        plot_dir / "ap_curve.png",
        y_limits=(0.0, 1.02),
    )

    save_plot(
        epochs,
        [values("val_map")],
        ["val_map_fg_bg"],
        "Pixelweise mAP über Vordergrund und Hintergrund",
        "mAP",
        plot_dir / "map_curve.png",
        y_limits=(0.0, 1.02),
    )

    # Gemeinsamer Plot nur für höher-ist-besser-Metriken im Intervall [0, 1].
    # Accuracy wird hierfür von Prozent auf 0...1 normiert. Loss und MSE werden
    # nicht aufgenommen, da bei ihnen kleinere Werte besser sind.
    accuracy_0_to_1 = [value / 100.0 for value in values("val_accuracy_pct")]
    save_plot(
        epochs,
        [
            values("train_dice_soft"),
            values("val_dice_soft"),
            values("val_dice_fg"),
            values("val_iou_fg"),
            values("val_precision_fg"),
            values("val_recall_fg"),
            values("val_f1_fg"),
            accuracy_0_to_1,
            values("val_auc_roc"),
            values("val_auc_pr"),
            values("val_ap"),
            values("val_map"),
        ],
        [
            "train_dice_soft",
            "val_dice_soft",
            "val_dice_fg",
            "val_iou_fg",
            "val_precision_fg",
            "val_recall_fg",
            "val_f1_fg",
            "val_accuracy",
            "val_auc_roc",
            "val_auc_pr",
            "val_ap_fg",
            "val_map_fg_bg",
        ],
        "Alle vergleichbaren höher-ist-besser-Metriken",
        "Score (0–1)",
        plot_dir / "all_metrics_same_scale.png",
        y_limits=(0.0, 1.02),
    )


# =============================================================================
# 10. ARCHITEKTUR-EXPORT
# =============================================================================

def tensor_shape_string(tensor_or_tensors: Any) -> str:
    try:
        if isinstance(tensor_or_tensors, (list, tuple)):
            return "[" + ", ".join(str(t.shape) for t in tensor_or_tensors) + "]"
        return str(tensor_or_tensors.shape)
    except Exception:
        return "nicht verfügbar"


def keras_tensor_source(tensor: Any) -> str:
    try:
        history = getattr(tensor, "_keras_history", None)
        if history is None:
            return "unbekannt"

        operation = getattr(history, "operation", None)
        node_index = getattr(history, "node_index", None)
        tensor_index = getattr(history, "tensor_index", None)

        if operation is None and isinstance(history, (tuple, list)) and history:
            operation = history[0]
            if len(history) > 1:
                node_index = history[1]
            if len(history) > 2:
                tensor_index = history[2]

        operation_name = getattr(operation, "name", str(operation))
        return f"{operation_name}[node={node_index}, tensor={tensor_index}]"
    except Exception as exc:
        return f"unbekannt ({exc})"


def flatten_tensors(tensors: Any) -> list[Any]:
    if isinstance(tensors, (list, tuple)):
        result: list[Any] = []
        for item in tensors:
            result.extend(flatten_tensors(item))
        return result
    return [tensors]


def iter_layers_recursive(
    model: tf.keras.Model,
    prefix: str = "",
) -> Iterable[tuple[str, tf.keras.layers.Layer]]:
    for index, layer in enumerate(model.layers):
        path = f"{prefix}{index:03d}:{layer.name}"
        yield path, layer
        if isinstance(layer, tf.keras.Model):
            yield from iter_layers_recursive(layer, prefix=path + "/")


def write_model_summary(file, model: tf.keras.Model, title: str) -> None:
    file.write("=" * 200 + "\n")
    file.write(title + "\n")
    file.write("=" * 200 + "\n\n")
    model.summary(
        expand_nested=True,
        line_length=200,
        print_fn=lambda line: file.write(line + "\n"),
    )
    file.write("\n\n")


def export_architecture(model: tf.keras.Model) -> dict[str, Any]:
    ARCH_DIR.mkdir(parents=True, exist_ok=True)

    # Maschinenlesbare Konfiguration
    write_json_atomic(ARCHITECTURE_JSON_FILE, model.get_config())
    ARCHITECTURE_KERAS_JSON_FILE.write_text(
        model.to_json(),
        encoding="utf-8",
    )

    all_layers = list(iter_layers_recursive(model))
    concat_layers = [
        (path, layer)
        for path, layer in all_layers
        if isinstance(layer, tf.keras.layers.Concatenate)
        or "concatenate" in layer.__class__.__name__.lower()
    ]
    add_layers = [
        (path, layer)
        for path, layer in all_layers
        if isinstance(layer, tf.keras.layers.Add)
    ]
    nested_models = [
        (path, layer)
        for path, layer in all_layers
        if isinstance(layer, tf.keras.Model) and layer is not model
    ]

    with ARCHITECTURE_TXT_FILE.open("w", encoding="utf-8") as file:
        file.write(f"Run: {RUN_NAME}\n")
        file.write("Architecture: U-Net++ mit dichten verschachtelten Skip-Connections\n")
        file.write(f"Input: ({IMG_SIZE}, {IMG_SIZE}, 3)\n")
        file.write("Output: binäre Wahrscheinlichkeitsmaske, 1 Kanal\n")
        file.write(f"Filter pro Ebene: {FILTER_NUM}\n")
        file.write(f"Convs pro Block: {CONVS_PER_BLOCK}\n")
        file.write(f"Aktivierung: {ACTIVATION}\n")
        file.write("Encoder-Tiefe: 5 Ebenen\n")
        file.write("Verschachtelte Decoderstufen: 4\n")
        file.write(f"Kernel initializer: {KERNEL_INITIALIZER}\n")
        file.write(f"Batch Normalization: {BATCH_NORM}\n")
        file.write("Pooling: MaxPooling2D, Faktor 2\n")
        file.write("Upsampling: Conv2DTranspose, Faktor 2\n")
        file.write(f"Deep Supervision: {DEEP_SUPERVISION}\n")
        file.write(f"Mixed Precision: {mixed_precision.global_policy().name}\n")
        file.write(f"Gesamtparameter: {model.count_params():,}\n")
        file.write(f"Rekursiv gefundene Layer: {len(all_layers)}\n")
        file.write(f"Gefundene Concatenate-Layer: {len(concat_layers)}\n")
        file.write(f"Gefundene Add-Layer: {len(add_layers)}\n\n")

        if not concat_layers:
            file.write(
                "WARNUNG: Es wurde kein Concatenate-Layer gefunden. "
                "Die tatsächliche Skip-Konnektivität sollte geprüft werden.\n\n"
            )

        write_model_summary(file, model, "1. VOLLSTÄNDIGE MODELLZUSAMMENFASSUNG")

        for nested_index, (path, nested_model) in enumerate(nested_models, start=1):
            write_model_summary(
                file,
                nested_model,
                f"2.{nested_index} DETAILLIERTE SUMMARY DES INNEREN MODELLS: {path}",
            )

        file.write("=" * 200 + "\n")
        file.write("3. REKURSIVE LAYERLISTE MIT INPUT-/OUTPUTQUELLEN\n")
        file.write("=" * 200 + "\n\n")

        for path, layer in all_layers:
            try:
                layer_input = layer.input
            except Exception:
                layer_input = None
            try:
                layer_output = layer.output
            except Exception:
                layer_output = None

            input_tensors = flatten_tensors(layer_input) if layer_input is not None else []
            input_sources = [keras_tensor_source(tensor) for tensor in input_tensors]

            try:
                parameters = int(layer.count_params())
            except Exception:
                parameters = -1

            file.write(f"Pfad: {path}\n")
            file.write(f"  Klasse: {layer.__class__.__name__}\n")
            file.write(f"  Trainable: {layer.trainable}\n")
            file.write(f"  dtype: {getattr(layer, 'dtype', 'nicht verfügbar')}\n")
            file.write(f"  Parameter: {parameters}\n")
            file.write(f"  Input shape: {tensor_shape_string(layer_input)}\n")
            file.write(f"  Output shape: {tensor_shape_string(layer_output)}\n")
            file.write(f"  Input-Quellen: {input_sources}\n")
            try:
                file.write(
                    "  Konfiguration: "
                    + json.dumps(
                        json_safe(layer.get_config()),
                        ensure_ascii=False,
                        sort_keys=True,
                    )
                    + "\n"
                )
            except Exception as exc:
                file.write(f"  Konfiguration nicht verfügbar: {exc}\n")
            file.write("\n")

        file.write("=" * 200 + "\n")
        file.write("4. CONCATENATE-/SKIP-CONNECTION-AUDIT\n")
        file.write("=" * 200 + "\n\n")

        for concat_index, (path, layer) in enumerate(concat_layers, start=1):
            try:
                inputs = flatten_tensors(layer.input)
            except Exception:
                inputs = []
            file.write(f"Concat {concat_index}: {path}\n")
            file.write(f"  Anzahl Inputs: {len(inputs)}\n")
            for input_index, tensor in enumerate(inputs):
                file.write(
                    f"  Input {input_index}: Quelle={keras_tensor_source(tensor)}, "
                    f"Shape={getattr(tensor, 'shape', 'nicht verfügbar')}\n"
                )
            try:
                file.write(f"  Output shape: {layer.output.shape}\n")
            except Exception:
                file.write("  Output shape: nicht verfügbar\n")
            file.write("\n")

        file.write("=" * 200 + "\n")
        file.write("5. VOLLSTÄNDIGE MODELLKONFIGURATION ALS JSON\n")
        file.write("=" * 200 + "\n\n")
        json.dump(
            json_safe(model.get_config()),
            file,
            indent=2,
            ensure_ascii=False,
        )
        file.write("\n")

    plot_error = None
    try:
        plot_model(
            model,
            to_file=str(ARCHITECTURE_PNG_FILE),
            show_shapes=True,
            show_layer_names=True,
            expand_nested=True,
            dpi=200,
            rankdir="TB",
        )
    except Exception as exc:
        plot_error = str(exc)
        (ARCH_DIR / f"{RUN_NAME}_architecture_plot_error.txt").write_text(
            "Die PNG-Architektur konnte nicht erstellt werden.\n"
            f"Fehler: {exc}\n"
            "Prüfe insbesondere die Installation von pydot und Graphviz.\n",
            encoding="utf-8",
        )

    return {
        "total_parameters": int(model.count_params()),
        "recursive_layer_count": len(all_layers),
        "nested_model_count": len(nested_models),
        "concatenate_layer_count": len(concat_layers),
        "add_layer_count": len(add_layers),
        "architecture_txt": str(ARCHITECTURE_TXT_FILE),
        "architecture_json": str(ARCHITECTURE_JSON_FILE),
        "architecture_keras_json": str(ARCHITECTURE_KERAS_JSON_FILE),
        "architecture_png": str(ARCHITECTURE_PNG_FILE),
        "plot_error": plot_error,
    }


# =============================================================================
# 11. LAUFMETADATEN UND KONFIGURATIONSDATEIEN
# =============================================================================

def build_run_metadata(
    environment_info: dict[str, Any],
    dataset_info: dict[str, Any],
    architecture_info: dict[str, Any],
) -> dict[str, Any]:
    train_count = int(dataset_info[TRAIN_SPLIT]["matched_pairs"])
    val_count = int(dataset_info[VAL_SPLIT]["matched_pairs"])
    test_count = int(dataset_info[TEST_SPLIT]["matched_pairs"])

    return {
        "run": RUN_NAME,
        "seed": SEED,
        "dataset_roots": [str(path) for path in SEG_DIRS],
        "dataset_splits": {
            str(path): {
                "train": str(path / TRAIN_SPLIT),
                "validation": str(path / VAL_SPLIT),
                "test": str(path / TEST_SPLIT),
            }
            for path in SEG_DIRS
        },
        "output_dir": str(RUN_DIR),
        "threshold": THRESHOLD,
        "hard_negative_target_share": HARD_NEGATIVE_TARGET_SHARE,
        "hard_negative_target_share_percent": HARD_NEGATIVE_TARGET_SHARE * 100.0,
        "hard_negative_note": (
            "Hard Negatives werden ausschließlich im Trainingssplit aus den "
            "konfigurierten HN-Unterordnern eingelesen und auf den Zielanteil gesampelt."
        ),
        "loss": LOSS_NAME,
        "optimizer": OPTIMIZER_NAME,
        "initial_learning_rate": INITIAL_LR,
        "architecture": "U-Net++ mit dichten verschachtelten Skip-Connections",
        "filter_num": FILTER_NUM,
        "convs_per_block": CONVS_PER_BLOCK,
        "kernel_initializer": KERNEL_INITIALIZER,
        "encoder_levels": len(FILTER_NUM),
        "nested_decoder_stages": len(FILTER_NUM) - 1,
        "activation": ACTIVATION,
        "batch_normalization": BATCH_NORM,
        "pooling": "MaxPooling2D factor 2",
        "upsampling": "Conv2DTranspose factor 2",
        "deep_supervision": DEEP_SUPERVISION,
        "patch_resolution": f"{IMG_SIZE} x {IMG_SIZE} px",
        "image_channels": 3,
        "mask_format": MASK_FORMAT_DESCRIPTION,
        "batch_size": BATCH,
        "steps_per_epoch": STEPS_PER_EPOCH,
        "images_per_epoch_effective": STEPS_PER_EPOCH * BATCH,
        "validation_steps": VALIDATION_STEPS,
        "validation_images_max_per_epoch": VALIDATION_STEPS * BATCH,
        "epochs_planned": EPOCHS,
        "lr_scheduler": {
            "name": "ReduceLROnPlateau",
            "monitor": "val_dice_fg",
            "mode": "max",
            "patience": LR_REDUCE_PATIENCE,
            "factor": LR_REDUCE_FACTOR,
            "min_delta": MIN_DELTA,
        },
        "early_stopping": {
            "monitor": "val_dice_fg",
            "mode": "max",
            "patience": EARLY_STOPPING_PATIENCE,
            "restore_best_weights": True,
            "min_delta": MIN_DELTA,
        },
        "checkpointing": {
            "save_every_epoch": True,
            "save_best_model": True,
            "monitor_best_model": "val_dice_fg",
            "save_weights_only": False,
        },
        "dataset_counts": {
            "train": train_count,
            "validation": val_count,
            "test": test_count,
            "total": train_count + val_count + test_count,
        },
        "epochs_for_approx_full_train_pass": (
            train_count / (STEPS_PER_EPOCH * BATCH)
            if STEPS_PER_EPOCH * BATCH > 0
            else float("inf")
        ),
        "map_definition": (
            "Pixel-wise mean Average Precision over foreground and background: "
            "mean(AP_fg, AP_bg). val_ap is AP_fg."
        ),
        "environment": environment_info,
        "dataset_details": dataset_info,
        "architecture_export": architecture_info,
    }


def write_run_configuration_file(metadata: dict[str, Any]) -> None:
    environment = metadata["environment"]
    counts = metadata["dataset_counts"]

    with RUN_CONFIG_FILE.open("w", encoding="utf-8") as file:
        file.write(f"Run: {RUN_NAME}\n")
        file.write(f"Zeitpunkt: {environment['timestamp_start']}\n")
        file.write(f"Seed: {SEED}\n")
        file.write(f"Datasets: {[str(path) for path in SEG_DIRS]}\n")
        for dataset_path in SEG_DIRS:
            file.write(f"Train-Split: {dataset_path / TRAIN_SPLIT}\n")
            file.write(f"Validation-Split: {dataset_path / VAL_SPLIT}\n")
            file.write(f"Test-Split: {dataset_path / TEST_SPLIT}\n")
        file.write(f"Output: {RUN_DIR}\n")
        file.write(f"Threshold: {THRESHOLD}\n")
        file.write(
            "Hard-negative target share (train only): "
            f"{HARD_NEGATIVE_TARGET_SHARE * 100.0:.1f}%\n"
        )
        file.write(
            "Hard-negative Hinweis: HN-Paare werden im Trainingssplit tatsächlich "
            "eingelesen und auf den Zielanteil gesampelt.\n"
        )
        file.write(f"Loss: {LOSS_NAME}\n")
        file.write(f"Optimizer: {OPTIMIZER_NAME}\n")
        file.write(f"Initial learning rate: {INITIAL_LR}\n")
        file.write("Architecture: U-Net++ mit dichten verschachtelten Skip-Connections\n")
        file.write(f"Filter pro Ebene: {FILTER_NUM}\n")
        file.write(f"Convs pro Block: {CONVS_PER_BLOCK}\n")
        file.write(f"Aktivierung: {ACTIVATION}\n")
        file.write("Encoder-Tiefe: 5 Ebenen\n")
        file.write("Verschachtelte Decoderstufen: 4\n")
        file.write(f"Kernel initializer: {KERNEL_INITIALIZER}\n")
        file.write(f"Batch normalization: {BATCH_NORM}\n")
        file.write("Pooling: MaxPooling2D, Faktor 2\n")
        file.write("Upsampling: Conv2DTranspose, Faktor 2\n")
        file.write(f"Deep supervision: {DEEP_SUPERVISION}\n")
        file.write(f"Patch resolution: {IMG_SIZE} x {IMG_SIZE} px\n")
        file.write(f"Mask format: {MASK_FORMAT_DESCRIPTION}\n")
        file.write(f"Batch size: {BATCH}\n")
        file.write(f"Steps per epoch: {STEPS_PER_EPOCH}\n")
        file.write(f"Effective images per epoch: {STEPS_PER_EPOCH * BATCH}\n")
        file.write(f"Validation steps: {VALIDATION_STEPS}\n")
        file.write(f"Planned epochs: {EPOCHS}\n")
        file.write(
            f"ReduceLROnPlateau: monitor=val_dice_fg, patience={LR_REDUCE_PATIENCE}, "
            f"factor={LR_REDUCE_FACTOR}\n"
        )
        file.write(
            f"EarlyStopping: monitor=val_dice_fg, patience={EARLY_STOPPING_PATIENCE}, "
            "restore_best_weights=True\n"
        )
        file.write(f"Train images: {counts['train']}\n")
        file.write(f"Validation images: {counts['validation']}\n")
        file.write(f"Test images: {counts['test']}\n")
        file.write(f"Dataset total: {counts['total']}\n")
        for split_name, split_info in metadata["dataset_details"].items():
            file.write(f"{split_name} mixing mode: {split_info['mixing_mode']}\n")
            file.write(f"{split_name} normal pairs used: {split_info['normal_pairs_used']}\n")
            file.write(f"{split_name} HN pairs used: {split_info['hard_negative_pairs_used']}\n")
            file.write(f"{split_name} HN actual share: {split_info['hard_negative_actual_share'] * 100.0:.3f}%\n")
            for source in split_info["sources"]:
                file.write(f"  Source: {source}\n")
        file.write(
            "Epochs for approximately one complete train-set pass: "
            f"{metadata['epochs_for_approx_full_train_pass']:.4f}\n"
        )
        file.write(f"Python version: {environment['python_version']}\n")
        file.write(f"Python executable: {environment['python_executable']}\n")
        file.write(f"TensorFlow version: {environment['tensorflow_version']}\n")
        file.write(f"Keras version: {environment['keras_version']}\n")
        file.write(
            "keras_unet_collection version: "
            f"{environment['keras_unet_collection_version']}\n"
        )
        file.write(f"NVIDIA Windows driver: {environment['nvidia_windows_driver']}\n")
        file.write(f"CUDA runtime: {environment['cuda_runtime']}\n")
        file.write(f"cuDNN version: {environment['cudnn_version']}\n")
        file.write(f"Mixed precision policy: {environment['mixed_precision_policy']}\n")
        file.write(f"Platform: {environment['platform']}\n")
        file.write(f"GPU: {environment['nvidia_gpu_query']}\n")
        file.write(
            "mAP definition: Pixel-wise mean(AP_fg, AP_bg); "
            "val_ap entspricht AP_fg.\n"
        )
        file.write("=" * 180 + "\n")
        file.write("VOLLSTÄNDIGE METADATEN ALS JSON\n")
        file.write("=" * 180 + "\n")
        json.dump(json_safe(metadata), file, indent=2, ensure_ascii=False)
        file.write("\n")


# =============================================================================
# 12. VALIDIERUNGS- UND LOGGING-CALLBACK
# =============================================================================

class ValidationMetricsLogger(tf.keras.callbacks.Callback):
    FIELDNAMES = [
        "epoch",
        "train_loss",
        "val_loss",
        "train_dice_soft",
        "val_dice_soft",
        "val_dice_fg",
        "val_iou_fg",
        "val_precision_fg",
        "val_recall_fg",
        "val_f1_fg",
        "val_accuracy_pct",
        "val_mse",
        "val_auc_roc",
        "val_auc_pr",
        "val_ap",
        "val_map",
    ]

    def __init__(
        self,
        validation_dataset: tf.data.Dataset,
        validation_steps: int,
        metrics_txt_path: Path,
        metrics_csv_path: Path,
        metrics_json_path: Path,
        run_metadata: dict[str, Any],
        threshold: float = 0.5,
        plot_dir: Path | None = None,
    ) -> None:
        super().__init__()
        self.validation_dataset = validation_dataset
        self.validation_steps = validation_steps
        self.metrics_txt_path = Path(metrics_txt_path)
        self.metrics_csv_path = Path(metrics_csv_path)
        self.metrics_json_path = Path(metrics_json_path)
        self.run_metadata = run_metadata
        self.threshold = threshold
        self.plot_dir = Path(plot_dir) if plot_dir is not None else self.metrics_txt_path.parent / "plots"

        self.best_epoch: int | None = None
        self.best_val_dice_fg = -1.0
        self.epoch_history: list[dict[str, float]] = []
        self.training_started_at = datetime.now().astimezone()

        self._initialize_log_files()
        self._write_json(status="initialized")

    def _initialize_log_files(self) -> None:
        self.metrics_txt_path.parent.mkdir(parents=True, exist_ok=True)
        self.metrics_csv_path.parent.mkdir(parents=True, exist_ok=True)
        self.metrics_json_path.parent.mkdir(parents=True, exist_ok=True)
        self.plot_dir.mkdir(parents=True, exist_ok=True)

        environment = self.run_metadata["environment"]
        counts = self.run_metadata["dataset_counts"]

        with self.metrics_txt_path.open("w", encoding="utf-8") as file:
            file.write(f"Run: {RUN_NAME}\n")
            file.write(f"Seed: {SEED}\n")
            file.write(f"Datasets: {[str(path) for path in SEG_DIRS]}\n")
            file.write(f"Output: {RUN_DIR}\n")
            file.write(f"Threshold: {self.threshold}\n")
            file.write(
                "Hard-negative target share (train only): "
                f"{HARD_NEGATIVE_TARGET_SHARE * 100.0:.1f}%\n"
            )
            file.write(f"Loss: {LOSS_NAME}\n")
            file.write(f"Architecture: U-Net++ mit dichten verschachtelten Skip-Connections\n")
            file.write(f"Filter pro Ebene: {FILTER_NUM}\n")
            file.write(f"Convs pro Block: {CONVS_PER_BLOCK}\n")
            file.write(f"Aktivierung: {ACTIVATION}\n")
            file.write(f"Deep supervision: {DEEP_SUPERVISION}\n")
            file.write(f"Patch resolution: {IMG_SIZE} x {IMG_SIZE} px\n")
            file.write(f"Mask format: {MASK_FORMAT_DESCRIPTION}\n")
            file.write(f"Batch size: {BATCH}\n")
            file.write(f"Optimizer: {OPTIMIZER_NAME}\n")
            file.write(f"Initial learning rate: {INITIAL_LR}\n")
            file.write(f"Steps per epoch: {STEPS_PER_EPOCH}\n")
            file.write(f"Validation steps: {VALIDATION_STEPS}\n")
            file.write(f"Planned epochs: {EPOCHS}\n")
            file.write(f"Train images: {counts['train']}\n")
            file.write(f"Validation images: {counts['validation']}\n")
            file.write(f"Test images: {counts['test']}\n")
            file.write(f"Dataset total: {counts['total']}\n")
            file.write(f"Python version: {environment['python_version']}\n")
            file.write(f"Keras version: {environment['keras_version']}\n")
            file.write(f"NVIDIA Windows driver: {environment['nvidia_windows_driver']}\n")
            file.write(f"CUDA runtime: {environment['cuda_runtime']}\n")
            file.write(f"cuDNN version: {environment['cudnn_version']}\n")
            file.write(
                "val_map: pixel-wise mean(AP foreground, AP background); "
                "val_ap: AP foreground.\n"
            )
            file.write("Alle Validierungsmetriken werden in jeder Epoche berechnet.\n")
            file.write("=" * 180 + "\n")
            file.write("\t".join(self.FIELDNAMES) + "\n")

        with self.metrics_csv_path.open("w", encoding="utf-8", newline="") as file:
            writer = csv.DictWriter(file, fieldnames=self.FIELDNAMES)
            writer.writeheader()

    def _evaluate_validation(self) -> dict[str, float]:
        total_loss = 0.0
        total_dice_soft = 0.0
        total_mse = 0.0
        total_samples = 0

        tp_total = 0
        fp_total = 0
        fn_total = 0
        tn_total = 0

        # Vordergrund-AP
        ap_fg_tp = np.zeros(len(AP_THRESHOLDS), dtype=np.float64)
        ap_fg_fp = np.zeros(len(AP_THRESHOLDS), dtype=np.float64)
        ap_fg_fn = np.zeros(len(AP_THRESHOLDS), dtype=np.float64)

        # Hintergrund-AP für eine fachlich definierte Klassen-mAP
        ap_bg_tp = np.zeros(len(AP_THRESHOLDS), dtype=np.float64)
        ap_bg_fp = np.zeros(len(AP_THRESHOLDS), dtype=np.float64)
        ap_bg_fn = np.zeros(len(AP_THRESHOLDS), dtype=np.float64)

        auc_roc_metric = tf.keras.metrics.AUC(curve="ROC")
        auc_pr_metric = tf.keras.metrics.AUC(curve="PR")

        for batch_index, (images, masks) in enumerate(self.validation_dataset):
            if batch_index >= self.validation_steps:
                break

            predictions = self.model(images, training=False)
            batch_size = int(tf.shape(images)[0].numpy())
            if batch_size == 0:
                continue

            prediction_np = predictions.numpy().astype(np.float32)
            mask_np = masks.numpy().astype(np.float32)

            y_true_binary = (mask_np >= 0.5).astype(np.uint8)
            y_pred_binary = (prediction_np >= self.threshold).astype(np.uint8)

            batch_loss = float(dice_loss(masks, predictions).numpy())
            batch_dice_soft = float(dice_coef_soft(masks, predictions).numpy())
            batch_mse = float(np.mean((prediction_np - mask_np) ** 2))

            total_loss += batch_loss * batch_size
            total_dice_soft += batch_dice_soft * batch_size
            total_mse += batch_mse * batch_size
            total_samples += batch_size

            tp, fp, fn, tn = compute_confusion_from_binary(
                y_true_binary,
                y_pred_binary,
            )
            tp_total += tp
            fp_total += fp
            fn_total += fn
            tn_total += tn

            auc_roc_metric.update_state(mask_np.reshape(-1), prediction_np.reshape(-1))
            auc_pr_metric.update_state(mask_np.reshape(-1), prediction_np.reshape(-1))

            update_threshold_confusions(
                y_true_binary,
                prediction_np,
                AP_THRESHOLDS,
                ap_fg_tp,
                ap_fg_fp,
                ap_fg_fn,
            )

            y_true_background = 1 - y_true_binary
            y_pred_background_probability = 1.0 - prediction_np
            update_threshold_confusions(
                y_true_background,
                y_pred_background_probability,
                AP_THRESHOLDS,
                ap_bg_tp,
                ap_bg_fp,
                ap_bg_fn,
            )

        if total_samples == 0:
            return {
                field: float("nan")
                for field in self.FIELDNAMES
                if field not in {"epoch", "train_loss", "train_dice_soft"}
            }

        foreground_metrics = compute_fg_metrics_from_confusion(
            tp_total,
            fp_total,
            fn_total,
            tn_total,
        )

        ap_foreground = compute_ap_from_threshold_confusions(
            ap_fg_tp,
            ap_fg_fp,
            ap_fg_fn,
        )
        ap_background = compute_ap_from_threshold_confusions(
            ap_bg_tp,
            ap_bg_fp,
            ap_bg_fn,
        )

        valid_ap_values = [
            value
            for value in (ap_foreground, ap_background)
            if not np.isnan(value)
        ]
        mean_average_precision = (
            float(np.mean(valid_ap_values))
            if valid_ap_values
            else float("nan")
        )

        return {
            "val_loss": total_loss / total_samples,
            "val_dice_soft": total_dice_soft / total_samples,
            "val_dice_fg": foreground_metrics["dice_fg"],
            "val_iou_fg": foreground_metrics["iou_fg"],
            "val_precision_fg": foreground_metrics["precision_fg"],
            "val_recall_fg": foreground_metrics["recall_fg"],
            "val_f1_fg": foreground_metrics["f1_fg"],
            "val_accuracy_pct": foreground_metrics["accuracy_percent"],
            "val_mse": total_mse / total_samples,
            "val_auc_roc": float(auc_roc_metric.result().numpy()),
            "val_auc_pr": float(auc_pr_metric.result().numpy()),
            "val_ap": ap_foreground,
            "val_map": mean_average_precision,
        }

    def _append_epoch_row(self, row: dict[str, float]) -> None:
        with self.metrics_txt_path.open("a", encoding="utf-8") as file:
            values = [str(int(row["epoch"]))]
            values.extend(f"{float(row[field]):.6f}" for field in self.FIELDNAMES[1:])
            file.write("\t".join(values) + "\n")

        with self.metrics_csv_path.open("a", encoding="utf-8", newline="") as file:
            writer = csv.DictWriter(file, fieldnames=self.FIELDNAMES)
            writer.writerow(row)

    def _write_json(self, status: str) -> None:
        elapsed_seconds = (
            datetime.now().astimezone() - self.training_started_at
        ).total_seconds()

        payload = {
            "status": status,
            "run_metadata": self.run_metadata,
            "best_epoch": self.best_epoch,
            "best_val_dice_fg": (
                self.best_val_dice_fg
                if self.best_val_dice_fg >= 0.0
                else None
            ),
            "epochs_completed": len(self.epoch_history),
            "elapsed_seconds": elapsed_seconds,
            "history": self.epoch_history,
        }
        write_json_atomic(self.metrics_json_path, payload)

    def on_epoch_end(self, epoch: int, logs: dict[str, Any] | None = None) -> None:
        # Nicht "logs = logs or {}" verwenden, da bei einem leeren Dict sonst
        # ein neues Objekt entstehen könnte. Spätere Callbacks müssen genau das
        # von Keras übergebene Dict mit val_dice_fg erhalten.
        if logs is None:
            logs = {}

        validation_metrics = self._evaluate_validation()

        row: dict[str, float] = {
            "epoch": float(epoch + 1),
            "train_loss": float(logs.get("loss", np.nan)),
            "val_loss": float(validation_metrics["val_loss"]),
            "train_dice_soft": float(logs.get("dice_coef_soft", np.nan)),
            "val_dice_soft": float(validation_metrics["val_dice_soft"]),
            "val_dice_fg": float(validation_metrics["val_dice_fg"]),
            "val_iou_fg": float(validation_metrics["val_iou_fg"]),
            "val_precision_fg": float(validation_metrics["val_precision_fg"]),
            "val_recall_fg": float(validation_metrics["val_recall_fg"]),
            "val_f1_fg": float(validation_metrics["val_f1_fg"]),
            "val_accuracy_pct": float(validation_metrics["val_accuracy_pct"]),
            "val_mse": float(validation_metrics["val_mse"]),
            "val_auc_roc": float(validation_metrics["val_auc_roc"]),
            "val_auc_pr": float(validation_metrics["val_auc_pr"]),
            "val_ap": float(validation_metrics["val_ap"]),
            "val_map": float(validation_metrics["val_map"]),
        }

        self.epoch_history.append(row)

        if (
            not np.isnan(row["val_dice_fg"])
            and row["val_dice_fg"] > self.best_val_dice_fg
        ):
            self.best_val_dice_fg = row["val_dice_fg"]
            self.best_epoch = epoch + 1

        # Entscheidend: alle berechneten Werte in das originale logs-Dict
        # zurückschreiben. Dadurch funktionieren die nachfolgenden Checkpoint-,
        # LR-Scheduler- und Early-Stopping-Callbacks mit val_dice_fg.
        for key, value in row.items():
            if key != "epoch":
                logs[key] = value
        logs["loss"] = row["train_loss"]
        logs["dice_coef_soft"] = row["train_dice_soft"]
        logs["learning_rate"] = get_current_learning_rate(self.model.optimizer)

        self._append_epoch_row(row)
        self._write_json(status="training")

        if PLOTS_EVERY_N_EPOCHS > 0 and (epoch + 1) % PLOTS_EVERY_N_EPOCHS == 0:
            save_training_plots(self.epoch_history, self.plot_dir)

        print(
            "\nVALIDIERUNG: "
            f"loss={row['val_loss']:.6f} | "
            f"dice_soft={row['val_dice_soft']:.6f} | "
            f"dice_fg={row['val_dice_fg']:.6f} | "
            f"iou={row['val_iou_fg']:.6f} | "
            f"precision={row['val_precision_fg']:.6f} | "
            f"recall={row['val_recall_fg']:.6f} | "
            f"f1={row['val_f1_fg']:.6f} | "
            f"ap_fg={row['val_ap']:.6f} | "
            f"map_fg_bg={row['val_map']:.6f} | "
            f"auc_roc={row['val_auc_roc']:.6f} | "
            f"auc_pr={row['val_auc_pr']:.6f} | "
            f"accuracy={row['val_accuracy_pct']:.2f}% | "
            f"mse={row['val_mse']:.6f} | "
            f"lr={logs['learning_rate']:.8g}"
        )

    def on_train_end(self, logs: dict[str, Any] | None = None) -> None:
        save_training_plots(self.epoch_history, self.plot_dir)

        with self.metrics_txt_path.open("a", encoding="utf-8") as file:
            file.write("=" * 180 + "\n")
            file.write(f"Completed epochs: {len(self.epoch_history)}\n")
            file.write(f"Best epoch: {self.best_epoch}\n")
            if self.best_epoch is not None:
                file.write(f"Best val_dice_fg: {self.best_val_dice_fg:.6f}\n")
            else:
                file.write("Best val_dice_fg: nicht verfügbar\n")

        self._write_json(status="completed")

        print(f"\nMetrik-TXT:  {self.metrics_txt_path}")
        print(f"Metrik-CSV:  {self.metrics_csv_path}")
        print(f"Metrik-JSON: {self.metrics_json_path}")
        print(f"Plots:       {self.plot_dir}")


# =============================================================================
# 13. MAIN
# =============================================================================


def main() -> None:
    for directory in (RUN_DIR, MODEL_DIR, METRICS_DIR, PLOT_DIR, ARCH_DIR):
        directory.mkdir(parents=True, exist_ok=True)

    physical_gpus = tf.config.list_physical_devices("GPU")
    if physical_gpus:
        for gpu in physical_gpus:
            try:
                tf.config.experimental.set_memory_growth(gpu, True)
            except RuntimeError as exc:
                print(f"Hinweis: GPU memory growth konnte nicht gesetzt werden: {exc}")

    print("Ermittle System- und Softwareinformationen ...")
    environment_info = collect_environment_info()

    print("Erstelle Datensätze und prüfe Bild-Masken-Paare ...")
    train_dataset, train_count, train_info = build_dataset(TRAIN_SPLIT)
    validation_dataset, validation_count, validation_info = build_dataset(VAL_SPLIT)
    _test_dataset, test_count, test_info = build_dataset(TEST_SPLIT)

    dataset_info = {
        TRAIN_SPLIT: train_info,
        VAL_SPLIT: validation_info,
        TEST_SPLIT: test_info,
    }

    print(f"Seed:                         {SEED}")
    print(f"Train samples:                {train_count}")
    print(f"Validation samples:           {validation_count}")
    print(f"Test samples:                 {test_count}")
    print(f"Total samples:                {train_count + validation_count + test_count}")
    print(f"Dataset roots:                {[str(path) for path in SEG_DIRS]}")
    print(f"Mixing mode train:            {train_info['mixing_mode']}")
    print(f"Train hard negatives:         {train_info['hard_negative_pairs_used']}")
    print(f"Train HN share actual:        {train_info['hard_negative_actual_share'] * 100.0:.3f}%")
    for source in train_info["sources"]:
        print(f"Train source usage:           {source}")
    print(f"Validation batches vorhanden: {math.ceil(validation_count / BATCH)}")
    print(f"Validation steps verwendet:   {VALIDATION_STEPS}")
    print(f"Bilder pro Epoche effektiv:   {STEPS_PER_EPOCH * BATCH}")
    print(
        "Epochen für ungefähr einen vollständigen Train-Set-Durchlauf: "
        f"{train_count / (STEPS_PER_EPOCH * BATCH):.4f}"
    )

    print("Baue U-Net++-Modell ...")
    model = build_optimized_model()

    print("Exportiere ausführliche Architektur ...")
    architecture_info = export_architecture(model)
    print(
        "Architektur-Audit: "
        f"{architecture_info['concatenate_layer_count']} Concatenate-Layer gefunden."
    )
    if architecture_info["concatenate_layer_count"] == 0:
        print(
            "WARNUNG: Kein Concatenate-Layer gefunden. Prüfe den ausführlichen "
            "Architekturbericht, bevor du das Training interpretierst."
        )

    run_metadata = build_run_metadata(
        environment_info=environment_info,
        dataset_info=dataset_info,
        architecture_info=architecture_info,
    )
    write_run_configuration_file(run_metadata)

    optimizer = tf.keras.optimizers.Adam(learning_rate=INITIAL_LR)
    model.compile(
        optimizer=optimizer,
        loss=dice_loss,
        metrics=[dice_coef_soft],
        jit_compile=True,
    )

    metrics_logger = ValidationMetricsLogger(
        validation_dataset=validation_dataset,
        validation_steps=VALIDATION_STEPS,
        metrics_txt_path=METRICS_TXT_FILE,
        metrics_csv_path=METRICS_CSV_FILE,
        metrics_json_path=METRICS_JSON_FILE,
        run_metadata=run_metadata,
        threshold=THRESHOLD,
        plot_dir=PLOT_DIR,
    )

    callbacks: list[tf.keras.callbacks.Callback] = [
        # Muss vor den monitorenden Callbacks stehen, da dieser Callback
        # val_dice_fg in das originale Keras-logs-Dictionary einträgt.
        metrics_logger,

        # Vollständiges Modell jeder einzelnen Epoche.
        tf.keras.callbacks.ModelCheckpoint(
            filepath=str(MODEL_DIR / f"{RUN_NAME}_Epoche{{epoch:02d}}.keras"),
            save_best_only=False,
            save_weights_only=False,
            verbose=1,
        ),

        # Bestes Modell anhand des vom ersten Callback berechneten val_dice_fg.
        tf.keras.callbacks.ModelCheckpoint(
            filepath=str(MODEL_DIR / f"{RUN_NAME}_best_val_dice.keras"),
            monitor="val_dice_fg",
            mode="max",
            save_best_only=True,
            save_weights_only=False,
            verbose=1,
        ),

        tf.keras.callbacks.ReduceLROnPlateau(
            monitor="val_dice_fg",
            mode="max",
            factor=LR_REDUCE_FACTOR,
            patience=LR_REDUCE_PATIENCE,
            min_delta=MIN_DELTA,
            verbose=1,
        ),

        tf.keras.callbacks.EarlyStopping(
            monitor="val_dice_fg",
            mode="max",
            patience=EARLY_STOPPING_PATIENCE,
            min_delta=MIN_DELTA,
            restore_best_weights=True,
            verbose=1,
        ),

        tf.keras.callbacks.TerminateOnNaN(),
    ]

    print(
        f"\nTraining startet: {EPOCHS} geplante Epochen, "
        f"{STEPS_PER_EPOCH} Steps pro Epoche, Batchsize {BATCH}."
    )

    model.fit(
        train_dataset,
        epochs=EPOCHS,
        steps_per_epoch=STEPS_PER_EPOCH,
        callbacks=callbacks,
        # Keras-Standardfortschrittsbalken: zeigt Batches, Loss, Dice und ETA.
        verbose=1,
    )

    # Nach EarlyStopping enthält model durch restore_best_weights=True die
    # Gewichte der besten Epoche. Diese zusätzliche Datei ist praktisch für
    # eine spätere direkte Verwendung, während alle Epochen separat erhalten bleiben.
    final_restored_model_path = MODEL_DIR / f"{RUN_NAME}_final_restored_best.keras"
    model.save(final_restored_model_path)
    print(f"Finales Modell mit wiederhergestellten Bestgewichten: {final_restored_model_path}")


if __name__ == "__main__":
    main()