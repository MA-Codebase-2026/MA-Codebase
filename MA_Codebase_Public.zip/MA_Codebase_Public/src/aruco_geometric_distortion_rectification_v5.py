#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
ArUco Geometric Distortion Rectification V5
============================================

Diese Version verfolgt bewusst einen anderen Ansatz als eine klassische
Einbild-Kamerakalibrierung.

Warum?
------
Mit nur drei Markern auf EINER ebenen Wand können sich Brennweite, Kamerapose,
Homographie und Linsenkoeffizienten gegenseitig kompensieren. Das kann zu einer
mathematisch passenden, aber praktisch schlechteren Entzerrung führen.

Hier wird stattdessen genau das genutzt, was sicher bekannt ist:

- reale Markergröße
- reale Mittelpunktkoordinaten aller drei Marker
- der Marker im Bereich der Bildmitte ist die lokale Null-/Referenz der Verzerrung
- 12 gemessene Marker-Ecken
- 3 gemessene Marker-Mittelpunkte
- die geometrische Bildmitte als fester Nullpunkt

Damit stehen 16 Kontrollstellen zur Verfügung.

Automatische Markerrollen
-------------------------
Die Rolle wird NUR aus center_mm bestimmt, nie aus der ArUco-ID:

    x = 0, y = 0   -> links oben
    x = 0, y > 0   -> bildmitte links
    x > 0, y > 0   -> bildmitte / Referenzmarker

Zielgeometrie
-------------
Der mittlere Marker definiert Rotation und px/mm-Maßstab einer idealen Ebene.
Aus den echten mm-Koordinaten wird anschließend berechnet, wo alle Marker-Ecken
und Marker-Mittelpunkte in einem geometrisch idealen Bild liegen müssen.

Dadurch gilt im Zielbild:

- alle gleich großen Marker haben dieselbe Pixel-Kantenlänge
- bekannte Mittelpunktabstände stimmen mit dem px/mm-Maßstab überein
- die Bildmitte bleibt unverändert

Modellvergleich
---------------
Der Code testet mehrere Korrekturfunktionen:

1. identity              keine Korrektur
2. radial_r2             radial, 1. Ordnung in r²
3. radial_r2_r4          radial, bis r⁴
4. radial_r2_r4_r6       radial, bis r⁶
5. polynomial_2d_deg2    allgemeines 2D-Feld 2. Grades
6. polynomial_2d_deg3    allgemeines 2D-Feld 3. Grades

Alle Modelle sind am geometrischen Bildzentrum so konstruiert, dass dort
Verschiebung = 0 und lokale lineare Änderung = 0 ist. Das heißt: Der zentrale
Bildbereich wird nicht durch eine freie Translation/Skalierung verändert.

Die Auswahl erfolgt mit Leave-One-Control-Point-Out-Validierung, Komplexitätsstrafe
und Sicherheitsprüfungen gegen Faltungen/extreme Extrapolation.

Wiederverwendung
----------------
Die gespeicherte Warp-Funktion kann auf Bilder ohne ArUco-Marker angewendet werden,
WENN Kamera, Zoom/Fokus, Auflösung/Crop und die Kamera-Wand-Pose gleich bleiben.

Wichtig: Dieses Verfahren korrigiert bewusst die GESAMTE geometrische Abweichung
(Linse + kleine Perspektiv-/Ausrichtungsfehler), weil das Ziel explizit ein überall
gleicher px/mm-Maßstab auf der Wand ist. Für eine pose-unabhängige reine
Objektivkalibrierung wären mehrere Kalibrieraufnahmen aus unterschiedlichen Posen
notwendig.

Benötigt:
    pip install opencv-contrib-python numpy scipy
"""

from __future__ import annotations

import json
import math
from dataclasses import dataclass
from pathlib import Path
from typing import Any

import cv2
import numpy as np
from scipy.optimize import lsq_linear


# =============================================================================
# 1. BENUTZERKONFIGURATION
# =============================================================================

CALIBRATION_IMAGE = Path(
    "/home/mitte/crack_project/test_images/Bildverzeichnung_aruco_150cm/kamera/DSC_0830.JPG"
)

OUTPUT_DIR = Path(
    "/home/mitte/crack_project/test_images/Bildverzeichnung_aruco_150cm/kamera"
)

# Optionale weitere Bilder OHNE Marker. Die gespeicherte Warp-Funktion wird direkt
# darauf angewendet. Nur sinnvoll bei identischer Kamera-Wand-Pose.
APPLY_IMAGES: list[Path] = [
    # Path("/pfad/zu/markerfreiem_bild.jpg"),
]

ARUCO_DICTIONARY_NAME = "DICT_5X5_50"
MARKER_SIZE_MM = 48.7

# Reale MARKERMITTELPUNKTE [mm].
# +X nach rechts, +Y nach unten.
# Die Marker-ID darf beliebig sein; die Rolle ergibt sich allein aus center_mm.
MARKERS: dict[int, dict[str, Any]] = {
    0: {"center_mm": (0.0,   473.7), "rotation_deg": 0.0},  # bildmitte links
    1: {"center_mm": (0.0,     0.0), "rotation_deg": 0.0},  # links oben
    2: {"center_mm": (745.7, 473.7), "rotation_deg": 0.0},  # bildmitte
    }

USE_SUBPIXEL_REFINEMENT = True
COORD_TOL_MM = 1e-6

# -----------------------------------------------------------------------------
# Modelle
# -----------------------------------------------------------------------------
TRY_RADIAL_R2 = True
TRY_RADIAL_R4 = True
TRY_RADIAL_R6 = True
TRY_POLYNOMIAL_DEG2 = True
TRY_POLYNOMIAL_DEG3 = True

# Ein Modell mit höherer Komplexität muss in der Cross-Validation tatsächlich
# besser sein. Pro freiem Parameter wird dieser Wert zum Auswahlscore addiert.
COMPLEXITY_PENALTY_PX_PER_PARAMETER = 0.30

# Liegen zwei Modelle fast gleichauf, wird das einfachere gewählt.
SIMPLER_MODEL_TOLERANCE_PERCENT = 3.0

# Eine Korrektur muss gegenüber identity mindestens so viel CV-Verbesserung bringen.
MIN_CV_IMPROVEMENT_PERCENT = 3.0

# -----------------------------------------------------------------------------
# Fit-Gewichte
# -----------------------------------------------------------------------------
# Mittlerer Marker = Referenz. Er soll möglichst wenig verändert werden.
REFERENCE_CORNER_WEIGHT = 4.0
REFERENCE_CENTER_WEIGHT = 8.0
OTHER_CORNER_WEIGHT = 1.0
OTHER_CENTER_WEIGHT = 1.5
IMAGE_CENTER_WEIGHT = 12.0

# Robuster Fit.
ROBUST_IRLS_ITERATIONS = 5
ROBUST_HUBER_K = 1.5
RIDGE_BASE = 1e-5

# -----------------------------------------------------------------------------
# Sicherheitsgrenzen
# -----------------------------------------------------------------------------
MAX_CORRECTION_FRACTION_OF_MAX_DIM = 0.15
MIN_JACOBIAN_DETERMINANT = 0.25
MIN_LOCAL_STRETCH = 0.45
MAX_LOCAL_STRETCH = 1.80

# Korrektur soll die Marker-Skalierung nicht verschlechtern.
MAX_SCALE_RMS_WORSENING_PERCENT_POINTS = 0.05
MAX_ANGLE_WORSENING_DEG = 0.35

# Inverse Remap-Berechnung.
INVERSE_MAP_ITERATIONS = 14
INVERSE_MAP_DAMPING = 0.85
INVERSE_MAP_CHUNK_ROWS = 128
REMAP_INTERPOLATION = cv2.INTER_LINEAR

# Proportional kleinere/größere Auflösungen mit identischem Seitenverhältnis dürfen
# dieselben NORMALISIERTEN Warp-Koeffizienten benutzen.
ALLOW_PROPORTIONAL_RESOLUTION_SCALING = True


# =============================================================================
# 2. DATENSTRUKTUREN
# =============================================================================

@dataclass(frozen=True)
class MarkerRoles:
    top_left_id: int
    left_middle_id: int
    center_id: int


@dataclass
class ControlGeometry:
    image: np.ndarray
    width: int
    height: int
    roles: MarkerRoles
    raw_corners: dict[int, np.ndarray]
    matched_corners: dict[int, np.ndarray]
    raw_centers: dict[int, np.ndarray]
    target_corners: dict[int, np.ndarray]
    target_centers: dict[int, np.ndarray]
    target_similarity: np.ndarray
    orientation_score_px: float
    source_points_px: np.ndarray
    target_points_px: np.ndarray
    point_weights: np.ndarray
    point_labels: list[str]


@dataclass
class WarpModel:
    name: str
    family: str
    degree: int
    coefficients: np.ndarray
    parameter_count: int
    full_rmse_px: float
    cv_rmse_px: float
    selection_score: float
    scale_rms_percent: float
    max_angle_deviation_deg: float
    center_distance_rmse_px: float
    max_correction_px: float
    min_jacobian_det: float
    min_local_stretch: float
    max_local_stretch: float
    accepted: bool
    reject_reasons: list[str]


# =============================================================================
# 3. KONFIGURATION UND MARKERROLLEN
# =============================================================================


def require_aruco() -> None:
    if not hasattr(cv2, "aruco"):
        raise RuntimeError("cv2.aruco fehlt. Installiere opencv-contrib-python.")



def determine_roles() -> MarkerRoles:
    if len(MARKERS) != 3:
        raise ValueError("Genau 3 Marker werden erwartet.")

    centers = {
        int(mid): np.asarray(cfg["center_mm"], dtype=np.float64).reshape(2)
        for mid, cfg in MARKERS.items()
    }

    top_left = [
        mid for mid, c in centers.items()
        if abs(float(c[0])) <= COORD_TOL_MM and abs(float(c[1])) <= COORD_TOL_MM
    ]
    left_middle = [
        mid for mid, c in centers.items()
        if abs(float(c[0])) <= COORD_TOL_MM and float(c[1]) > COORD_TOL_MM
    ]
    center = [
        mid for mid, c in centers.items()
        if float(c[0]) > COORD_TOL_MM and float(c[1]) > COORD_TOL_MM
    ]

    if len(top_left) != 1 or len(left_middle) != 1 or len(center) != 1:
        raise ValueError(
            "Markerrollen sind aus center_mm nicht eindeutig. Erwartet wird genau:\n"
            "  x=0,y=0   -> links oben\n"
            "  x=0,y>0   -> bildmitte links\n"
            "  x>0,y>0   -> bildmitte\n"
            f"Konfiguration: { {mid: tuple(map(float, c)) for mid, c in centers.items()} }"
        )

    return MarkerRoles(
        top_left_id=int(top_left[0]),
        left_middle_id=int(left_middle[0]),
        center_id=int(center[0]),
    )



def validate_configuration() -> MarkerRoles:
    if MARKER_SIZE_MM <= 0:
        raise ValueError("MARKER_SIZE_MM muss > 0 sein.")
    for mid, cfg in MARKERS.items():
        if "center_mm" not in cfg:
            raise ValueError(f"Marker {mid}: center_mm fehlt.")
        c = np.asarray(cfg["center_mm"], dtype=np.float64).reshape(-1)
        if c.size != 2 or not np.all(np.isfinite(c)):
            raise ValueError(f"Marker {mid}: ungültige center_mm.")
    return determine_roles()


# =============================================================================
# 4. ARUCO
# =============================================================================


def aruco_dictionary():
    if not hasattr(cv2.aruco, ARUCO_DICTIONARY_NAME):
        raise ValueError(f"Unbekanntes ArUco-Dictionary: {ARUCO_DICTIONARY_NAME}")
    return cv2.aruco.getPredefinedDictionary(
        getattr(cv2.aruco, ARUCO_DICTIONARY_NAME)
    )



def create_detector():
    dictionary = aruco_dictionary()
    if hasattr(cv2.aruco, "DetectorParameters"):
        params = cv2.aruco.DetectorParameters()
    else:
        params = cv2.aruco.DetectorParameters_create()

    if USE_SUBPIXEL_REFINEMENT and hasattr(cv2.aruco, "CORNER_REFINE_SUBPIX"):
        params.cornerRefinementMethod = cv2.aruco.CORNER_REFINE_SUBPIX
        if hasattr(params, "cornerRefinementWinSize"):
            params.cornerRefinementWinSize = 5
        if hasattr(params, "cornerRefinementMaxIterations"):
            params.cornerRefinementMaxIterations = 80
        if hasattr(params, "cornerRefinementMinAccuracy"):
            params.cornerRefinementMinAccuracy = 0.003

    if hasattr(cv2.aruco, "ArucoDetector"):
        return cv2.aruco.ArucoDetector(dictionary, params), dictionary, params
    return None, dictionary, params



def detect_configured_markers(image: np.ndarray) -> dict[int, np.ndarray]:
    gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
    detector, dictionary, params = create_detector()

    if detector is not None:
        corners, ids, _ = detector.detectMarkers(gray)
    else:
        corners, ids, _ = cv2.aruco.detectMarkers(gray, dictionary, parameters=params)

    if ids is None or len(ids) == 0:
        raise RuntimeError("Keine ArUco-Marker gefunden.")

    detected: dict[int, np.ndarray] = {}
    for i, marker_id in enumerate(ids.reshape(-1).astype(int)):
        pts = np.asarray(corners[i], dtype=np.float32).reshape(4, 2)
        if USE_SUBPIXEL_REFINEMENT:
            criteria = (
                cv2.TERM_CRITERIA_EPS + cv2.TERM_CRITERIA_MAX_ITER,
                80,
                1e-4,
            )
            cv2.cornerSubPix(gray, pts, (5, 5), (-1, -1), criteria)
        detected[int(marker_id)] = pts.astype(np.float64)

    missing = [mid for mid in MARKERS if mid not in detected]
    if missing:
        raise RuntimeError(
            f"Erwartete Marker fehlen: {missing}. Gefunden: {sorted(detected)}"
        )
    return {int(mid): detected[int(mid)] for mid in MARKERS}


# =============================================================================
# 5. REALE UND IDEALE GEOMETRIE
# =============================================================================


def world_center(marker_id: int) -> np.ndarray:
    return np.asarray(MARKERS[int(marker_id)]["center_mm"], dtype=np.float64).reshape(2)



def world_corners(marker_id: int) -> np.ndarray:
    cfg = MARKERS[int(marker_id)]
    cx, cy = map(float, cfg["center_mm"])
    h = float(MARKER_SIZE_MM) / 2.0
    local = np.array(
        [[-h, -h], [h, -h], [h, h], [-h, h]], dtype=np.float64
    )

    angle = math.radians(float(cfg.get("rotation_deg", 0.0)))
    c, s = math.cos(angle), math.sin(angle)
    R = np.array([[c, -s], [s, c]], dtype=np.float64)
    p = local @ R.T
    p[:, 0] += cx
    p[:, 1] += cy
    return p



def cyclic_variants(points: np.ndarray) -> list[np.ndarray]:
    p = np.asarray(points, dtype=np.float64).reshape(4, 2)
    out = []
    for base in (p, p[::-1]):
        for shift in range(4):
            out.append(np.roll(base, -shift, axis=0).copy())
    return out



def fit_similarity(src: np.ndarray, dst: np.ndarray) -> np.ndarray:
    """2D Similarity: einheitlicher Maßstab + Rotation + Translation."""
    X = np.asarray(src, dtype=np.float64).reshape(-1, 2)
    Y = np.asarray(dst, dtype=np.float64).reshape(-1, 2)
    mu_x = np.mean(X, axis=0)
    mu_y = np.mean(Y, axis=0)
    Xc = X - mu_x
    Yc = Y - mu_y

    C = Xc.T @ Yc
    U, singular, Vt = np.linalg.svd(C)
    R = Vt.T @ U.T
    if np.linalg.det(R) < 0:
        Vt[-1] *= -1.0
        R = Vt.T @ U.T
        singular[-1] *= -1.0

    denom = float(np.sum(Xc * Xc))
    if denom <= 1e-12:
        raise RuntimeError("Degenerierte Similarity-Geometrie.")
    scale = float(np.sum(singular) / denom)
    t = mu_y - scale * (R @ mu_x)

    M = np.eye(3, dtype=np.float64)
    M[:2, :2] = scale * R
    M[:2, 2] = t
    return M



def transform_points(points: np.ndarray, H: np.ndarray) -> np.ndarray:
    pts = np.asarray(points, dtype=np.float64).reshape(-1, 1, 2)
    return cv2.perspectiveTransform(pts, np.asarray(H, dtype=np.float64)).reshape(-1, 2)



def diagonal_intersection(quad: np.ndarray) -> np.ndarray:
    p = np.asarray(quad, dtype=np.float64).reshape(4, 2)

    def hp(q):
        return np.array([q[0], q[1], 1.0], dtype=np.float64)

    l1 = np.cross(hp(p[0]), hp(p[2]))
    l2 = np.cross(hp(p[1]), hp(p[3]))
    q = np.cross(l1, l2)
    if abs(float(q[2])) < 1e-12:
        return np.mean(p, axis=0)
    return (q[:2] / q[2]).astype(np.float64)



def choose_reference_orientation_and_targets(
    raw: dict[int, np.ndarray], roles: MarkerRoles
) -> tuple[dict[int, np.ndarray], dict[int, np.ndarray], dict[int, np.ndarray], np.ndarray, float]:
    """
    Der mittlere Marker definiert die ideale Similarity-Ebene.

    Da ein Quadrat rotationssymmetrisch ist, werden alle möglichen Eckstarts getestet.
    Die korrekte globale Orientierung wird über die bekannten Mittelpunktkoordinaten
    der beiden anderen Marker bestimmt. Keine Marker-ID trägt Positionswissen.
    """
    ref = roles.center_id
    ref_world = world_corners(ref)

    best_score = float("inf")
    best_matched = None
    best_target_corners = None
    best_target_centers = None
    best_S = None

    raw_centers = {mid: diagonal_intersection(raw[mid]) for mid in MARKERS}

    for ref_variant in cyclic_variants(raw[ref]):
        S = fit_similarity(ref_world, ref_variant)
        target_centers = {
            mid: transform_points(world_center(mid)[None, :], S)[0]
            for mid in MARKERS
        }
        target_corners = {
            mid: transform_points(world_corners(mid), S)
            for mid in MARKERS
        }

        # Mittelpunktfehler entscheidet primär die globale 0/90/180/270°-Orientierung.
        center_sq = []
        for mid in MARKERS:
            delta = raw_centers[mid] - target_centers[mid]
            center_sq.append(float(np.dot(delta, delta)))

        matched = {ref: ref_variant}
        corner_sq = []
        for mid in MARKERS:
            if mid == ref:
                continue

            target = target_corners[mid]
            target_center = target_centers[mid]
            raw_center = raw_centers[mid]

            # Nur die lokale Eckorientierung vergleichen. Die globale Verschiebung
            # des Markers kann gerade die gesuchte Verzeichnung sein.
            target_rel = target - target_center
            best_local = float("inf")
            best_variant = None
            for variant in cyclic_variants(raw[mid]):
                rel = variant - raw_center
                e = float(np.mean(np.sum((rel - target_rel) ** 2, axis=1)))
                if e < best_local:
                    best_local = e
                    best_variant = variant
            assert best_variant is not None
            matched[mid] = best_variant
            corner_sq.append(best_local)

        # Mittelpunktgeometrie stärker gewichten als lokale Eckform.
        score = math.sqrt(
            (4.0 * float(np.mean(center_sq)) + float(np.mean(corner_sq))) / 5.0
        )
        if score < best_score:
            best_score = float(score)
            best_matched = matched
            best_target_corners = target_corners
            best_target_centers = target_centers
            best_S = S

    if best_matched is None:
        raise RuntimeError("Eck-/Orientierungszuordnung fehlgeschlagen.")

    return best_matched, best_target_corners, best_target_centers, best_S, best_score



def build_control_geometry(image_path: Path, roles: MarkerRoles) -> ControlGeometry:
    image = cv2.imread(str(image_path), cv2.IMREAD_COLOR)
    if image is None:
        raise FileNotFoundError(f"Bild konnte nicht gelesen werden: {image_path}")

    h, w = image.shape[:2]
    raw = detect_configured_markers(image)
    matched, target_corners, target_centers, S, orientation_score = (
        choose_reference_orientation_and_targets(raw, roles)
    )
    raw_centers = {mid: diagonal_intersection(matched[mid]) for mid in MARKERS}

    src = []
    dst = []
    weights = []
    labels = []
    ref = roles.center_id

    for mid in MARKERS:
        is_ref = mid == ref
        wc = REFERENCE_CORNER_WEIGHT if is_ref else OTHER_CORNER_WEIGHT
        wm = REFERENCE_CENTER_WEIGHT if is_ref else OTHER_CENTER_WEIGHT

        for j in range(4):
            src.append(matched[mid][j])
            dst.append(target_corners[mid][j])
            weights.append(wc)
            labels.append(f"marker_{mid}_corner_{j}")

        src.append(raw_centers[mid])
        dst.append(target_centers[mid])
        weights.append(wm)
        labels.append(f"marker_{mid}_center")

    # 16. Kontrollstelle: geometrische Bildmitte bleibt EXAKT unverändert.
    image_center = np.array([(w - 1) / 2.0, (h - 1) / 2.0], dtype=np.float64)
    src.append(image_center)
    dst.append(image_center)
    weights.append(IMAGE_CENTER_WEIGHT)
    labels.append("image_center_fixed")

    return ControlGeometry(
        image=image,
        width=w,
        height=h,
        roles=roles,
        raw_corners=raw,
        matched_corners=matched,
        raw_centers=raw_centers,
        target_corners=target_corners,
        target_centers=target_centers,
        target_similarity=S,
        orientation_score_px=orientation_score,
        source_points_px=np.asarray(src, dtype=np.float64),
        target_points_px=np.asarray(dst, dtype=np.float64),
        point_weights=np.asarray(weights, dtype=np.float64),
        point_labels=labels,
    )


# =============================================================================
# 6. WARP-MODELLE
# =============================================================================


def normalization(width: int, height: int) -> tuple[float, float, float]:
    cx = (width - 1) / 2.0
    cy = (height - 1) / 2.0
    scale = float(max(width, height))
    return cx, cy, scale



def normalized_points(points_px: np.ndarray, width: int, height: int) -> tuple[np.ndarray, float]:
    cx, cy, scale = normalization(width, height)
    p = np.asarray(points_px, dtype=np.float64).reshape(-1, 2)
    n = np.column_stack([(p[:, 0] - cx) / scale, (p[:, 1] - cy) / scale])
    return n, scale



def polynomial_terms(X: np.ndarray, Y: np.ndarray, degree: int) -> tuple[np.ndarray, list[tuple[int, int]]]:
    exponents = []
    cols = []
    for total in range(2, degree + 1):
        for i in range(total, -1, -1):
            j = total - i
            exponents.append((i, j))
            cols.append((X ** i) * (Y ** j))
    if not cols:
        return np.empty((len(X), 0), dtype=np.float64), exponents
    return np.column_stack(cols).astype(np.float64), exponents



def design_matrix(
    source_px: np.ndarray,
    target_px: np.ndarray,
    width: int,
    height: int,
    family: str,
    degree: int,
) -> tuple[np.ndarray, np.ndarray, list[Any]]:
    src_n, scale = normalized_points(source_px, width, height)
    tgt_n, _ = normalized_points(target_px, width, height)
    X = src_n[:, 0]
    Y = src_n[:, 1]
    delta = tgt_n - src_n

    if family == "identity":
        return np.empty((2 * len(X), 0)), delta.reshape(-1), []

    if family == "radial":
        t = X * X + Y * Y
        A = np.zeros((2 * len(X), degree), dtype=np.float64)
        for j in range(1, degree + 1):
            basis = t ** j
            A[0::2, j - 1] = X * basis
            A[1::2, j - 1] = Y * basis
        b = np.empty(2 * len(X), dtype=np.float64)
        b[0::2] = delta[:, 0]
        b[1::2] = delta[:, 1]
        return A, b, [f"r^{2*j}" for j in range(1, degree + 1)]

    if family == "poly2d":
        B, exponents = polynomial_terms(X, Y, degree)
        m = B.shape[1]
        A = np.zeros((2 * len(X), 2 * m), dtype=np.float64)
        A[0::2, :m] = B
        A[1::2, m:] = B
        b = np.empty(2 * len(X), dtype=np.float64)
        b[0::2] = delta[:, 0]
        b[1::2] = delta[:, 1]
        labels = [("dx", e) for e in exponents] + [("dy", e) for e in exponents]
        return A, b, labels

    raise ValueError(f"Unbekannte Modellfamilie: {family}")



def ridge_weights(family: str, degree: int, labels: list[Any]) -> np.ndarray:
    if not labels:
        return np.empty((0,), dtype=np.float64)
    if family == "radial":
        # Höhere Ordnungen etwas stärker regularisieren.
        return np.array([RIDGE_BASE * (j ** 2) for j in range(1, degree + 1)], dtype=np.float64)
    out = []
    for axis, (i, j) in labels:
        total = i + j
        out.append(RIDGE_BASE * (total ** 2))
    return np.asarray(out, dtype=np.float64)



def solve_linear_model(
    source_px: np.ndarray,
    target_px: np.ndarray,
    point_weights: np.ndarray,
    width: int,
    height: int,
    family: str,
    degree: int,
) -> np.ndarray:
    A, b, labels = design_matrix(source_px, target_px, width, height, family, degree)
    if A.shape[1] == 0:
        return np.zeros((0,), dtype=np.float64)

    base_row_w = np.repeat(np.sqrt(np.asarray(point_weights, dtype=np.float64)), 2)
    robust_point_w = np.ones(len(point_weights), dtype=np.float64)
    ridge = ridge_weights(family, degree, labels)

    x = np.zeros(A.shape[1], dtype=np.float64)
    for _ in range(max(1, int(ROBUST_IRLS_ITERATIONS))):
        row_w = base_row_w * np.repeat(np.sqrt(robust_point_w), 2)
        Aw = A * row_w[:, None]
        bw = b * row_w

        if ridge.size:
            regA = np.diag(np.sqrt(ridge))
            Aw = np.vstack([Aw, regA])
            bw = np.concatenate([bw, np.zeros(len(ridge), dtype=np.float64)])

        # Breite Bounds nur als letzte Sicherung; Ridge + CV bestimmen die Stärke.
        bounds = (-3.0 * np.ones(A.shape[1]), 3.0 * np.ones(A.shape[1]))
        res = lsq_linear(Aw, bw, bounds=bounds, method="trf", lsmr_tol="auto")
        x = np.asarray(res.x, dtype=np.float64)

        residual = A @ x - b
        per_point = np.sqrt(residual[0::2] ** 2 + residual[1::2] ** 2)
        med = float(np.median(per_point))
        mad = float(np.median(np.abs(per_point - med)))
        sigma = max(1e-12, 1.4826 * mad)
        threshold = ROBUST_HUBER_K * sigma
        if threshold <= 1e-12:
            break
        robust_point_w = np.ones_like(per_point)
        mask = per_point > threshold
        robust_point_w[mask] = threshold / np.maximum(per_point[mask], 1e-12)

    return x



def warp_points(
    points_px: np.ndarray,
    width: int,
    height: int,
    family: str,
    degree: int,
    coeffs: np.ndarray,
) -> np.ndarray:
    p = np.asarray(points_px, dtype=np.float64).reshape(-1, 2)
    if family == "identity" or len(coeffs) == 0:
        return p.copy()

    n, scale = normalized_points(p, width, height)
    X = n[:, 0]
    Y = n[:, 1]

    if family == "radial":
        t = X * X + Y * Y
        factor_delta = np.zeros_like(t)
        for j, a in enumerate(np.asarray(coeffs, dtype=np.float64), start=1):
            factor_delta += float(a) * (t ** j)
        dn = np.column_stack([X * factor_delta, Y * factor_delta])

    elif family == "poly2d":
        B, _ = polynomial_terms(X, Y, degree)
        m = B.shape[1]
        c = np.asarray(coeffs, dtype=np.float64)
        dx = B @ c[:m]
        dy = B @ c[m:]
        dn = np.column_stack([dx, dy])

    else:
        raise ValueError(family)

    return p + scale * dn


# =============================================================================
# 7. MODELLBEWERTUNG / CROSS-VALIDATION
# =============================================================================


def rmse_points(pred: np.ndarray, target: np.ndarray) -> float:
    e = np.asarray(pred, dtype=np.float64) - np.asarray(target, dtype=np.float64)
    return float(np.sqrt(np.mean(np.sum(e * e, axis=1))))



def edge_lengths(corners: np.ndarray) -> np.ndarray:
    p = np.asarray(corners, dtype=np.float64).reshape(4, 2)
    return np.array([np.linalg.norm(p[(i + 1) % 4] - p[i]) for i in range(4)])



def interior_angles(corners: np.ndarray) -> np.ndarray:
    p = np.asarray(corners, dtype=np.float64).reshape(4, 2)
    angles = []
    for i in range(4):
        v1 = p[(i - 1) % 4] - p[i]
        v2 = p[(i + 1) % 4] - p[i]
        n1 = np.linalg.norm(v1)
        n2 = np.linalg.norm(v2)
        if n1 <= 1e-12 or n2 <= 1e-12:
            angles.append(np.nan)
        else:
            c = float(np.dot(v1, v2) / (n1 * n2))
            angles.append(math.degrees(math.acos(float(np.clip(c, -1.0, 1.0)))))
    return np.asarray(angles, dtype=np.float64)



def geometry_metrics_for_warp(ctrl: ControlGeometry, model: WarpModel | None, family: str, degree: int, coeffs: np.ndarray) -> dict[str, Any]:
    warped_corners = {
        mid: warp_points(ctrl.matched_corners[mid], ctrl.width, ctrl.height, family, degree, coeffs)
        for mid in MARKERS
    }
    warped_centers = {
        mid: warp_points(ctrl.raw_centers[mid][None, :], ctrl.width, ctrl.height, family, degree, coeffs)[0]
        for mid in MARKERS
    }

    ref = ctrl.roles.center_id
    ref_edges = edge_lengths(warped_corners[ref])
    ref_mean = float(np.mean(ref_edges))

    per_marker = {}
    scale_devs = []
    angle_devs = []
    for mid in MARKERS:
        edges = edge_lengths(warped_corners[mid])
        angles = interior_angles(warped_corners[mid])
        mean_edge = float(np.mean(edges))
        scale_dev = 100.0 * (mean_edge - ref_mean) / ref_mean
        max_angle = float(np.nanmax(np.abs(angles - 90.0)))
        if mid != ref:
            scale_devs.append(scale_dev)
        angle_devs.append(max_angle)
        per_marker[int(mid)] = {
            "mean_edge_px": mean_edge,
            "edge_lengths_px": edges.tolist(),
            "edge_scale_deviation_vs_center_percent": float(scale_dev),
            "angles_deg": angles.tolist(),
            "max_abs_angle_deviation_deg": max_angle,
        }

    center_errors = [
        np.linalg.norm(warped_centers[mid] - ctrl.target_centers[mid])
        for mid in MARKERS
    ]

    return {
        "per_marker": per_marker,
        "scale_rms_percent": float(np.sqrt(np.mean(np.square(scale_devs)))) if scale_devs else 0.0,
        "max_angle_deviation_deg": float(np.max(angle_devs)) if angle_devs else 0.0,
        "center_distance_rmse_px": float(np.sqrt(np.mean(np.square(center_errors)))),
    }



def loocv_rmse(ctrl: ControlGeometry, family: str, degree: int) -> float:
    # Der explizite image_center_fixed-Punkt wird nicht als Testpunkt verwendet, weil
    # alle Modelle ihn konstruktiv exakt festhalten. Er bleibt aber in jedem Training.
    test_indices = [i for i, label in enumerate(ctrl.point_labels) if label != "image_center_fixed"]
    errors = []

    for holdout in test_indices:
        mask = np.ones(len(ctrl.source_points_px), dtype=bool)
        mask[holdout] = False

        coeffs = solve_linear_model(
            ctrl.source_points_px[mask],
            ctrl.target_points_px[mask],
            ctrl.point_weights[mask],
            ctrl.width,
            ctrl.height,
            family,
            degree,
        )
        pred = warp_points(
            ctrl.source_points_px[holdout:holdout + 1],
            ctrl.width,
            ctrl.height,
            family,
            degree,
            coeffs,
        )[0]
        errors.append(float(np.linalg.norm(pred - ctrl.target_points_px[holdout])))

    return float(np.sqrt(np.mean(np.square(errors)))) if errors else 0.0



def jacobian_safety(ctrl: ControlGeometry, family: str, degree: int, coeffs: np.ndarray) -> tuple[float, float, float, float]:
    xs = np.linspace(0, ctrl.width - 1, 21)
    ys = np.linspace(0, ctrl.height - 1, 15)
    xx, yy = np.meshgrid(xs, ys)
    p = np.column_stack([xx.ravel(), yy.ravel()])

    q = warp_points(p, ctrl.width, ctrl.height, family, degree, coeffs)
    max_shift = float(np.max(np.linalg.norm(q - p, axis=1)))

    # Numerische lokale Jacobi-Matrix pro Rasterpunkt.
    eps = 1.0
    qx = warp_points(p + np.array([eps, 0.0]), ctrl.width, ctrl.height, family, degree, coeffs)
    qy = warp_points(p + np.array([0.0, eps]), ctrl.width, ctrl.height, family, degree, coeffs)
    jx = (qx - q) / eps
    jy = (qy - q) / eps

    min_det = float("inf")
    min_stretch = float("inf")
    max_stretch = 0.0
    for a, b in zip(jx, jy):
        J = np.column_stack([a, b])
        det = float(np.linalg.det(J))
        sv = np.linalg.svd(J, compute_uv=False)
        min_det = min(min_det, det)
        min_stretch = min(min_stretch, float(np.min(sv)))
        max_stretch = max(max_stretch, float(np.max(sv)))

    return max_shift, min_det, min_stretch, max_stretch



def evaluate_model(ctrl: ControlGeometry, name: str, family: str, degree: int, baseline: WarpModel | None) -> WarpModel:
    if family == "identity":
        coeffs = np.zeros((0,), dtype=np.float64)
        cv_rmse = rmse_points(ctrl.source_points_px[:-1], ctrl.target_points_px[:-1])
    else:
        coeffs = solve_linear_model(
            ctrl.source_points_px,
            ctrl.target_points_px,
            ctrl.point_weights,
            ctrl.width,
            ctrl.height,
            family,
            degree,
        )
        cv_rmse = loocv_rmse(ctrl, family, degree)

    pred = warp_points(
        ctrl.source_points_px,
        ctrl.width,
        ctrl.height,
        family,
        degree,
        coeffs,
    )
    full_rmse = rmse_points(pred, ctrl.target_points_px)
    geom = geometry_metrics_for_warp(ctrl, None, family, degree, coeffs)
    max_shift, min_det, min_stretch, max_stretch = jacobian_safety(
        ctrl, family, degree, coeffs
    )

    pcount = int(len(coeffs))
    selection_score = float(cv_rmse + COMPLEXITY_PENALTY_PX_PER_PARAMETER * pcount)

    reasons = []
    max_allowed = MAX_CORRECTION_FRACTION_OF_MAX_DIM * max(ctrl.width, ctrl.height)
    if max_shift > max_allowed:
        reasons.append(f"maxShift {max_shift:.2f}px > {max_allowed:.2f}px")
    if min_det < MIN_JACOBIAN_DETERMINANT:
        reasons.append(f"Jacobi-Determinante zu klein/negativ: {min_det:.4f}")
    if min_stretch < MIN_LOCAL_STRETCH:
        reasons.append(f"lokale Stauchung zu stark: min={min_stretch:.4f}")
    if max_stretch > MAX_LOCAL_STRETCH:
        reasons.append(f"lokale Streckung zu stark: max={max_stretch:.4f}")

    if baseline is not None and family != "identity":
        improvement = 100.0 * (baseline.cv_rmse_px - cv_rmse) / max(baseline.cv_rmse_px, 1e-12)
        if improvement < MIN_CV_IMPROVEMENT_PERCENT:
            reasons.append(
                f"CV-Verbesserung nur {improvement:.2f}% < {MIN_CV_IMPROVEMENT_PERCENT:.2f}%"
            )
        if geom["scale_rms_percent"] > baseline.scale_rms_percent + MAX_SCALE_RMS_WORSENING_PERCENT_POINTS:
            reasons.append(
                f"Skalen-RMS wird schlechter: {baseline.scale_rms_percent:.4f}% -> {geom['scale_rms_percent']:.4f}%"
            )
        if geom["max_angle_deviation_deg"] > baseline.max_angle_deviation_deg + MAX_ANGLE_WORSENING_DEG:
            reasons.append(
                f"Winkel werden schlechter: {baseline.max_angle_deviation_deg:.4f}deg -> {geom['max_angle_deviation_deg']:.4f}deg"
            )

    return WarpModel(
        name=name,
        family=family,
        degree=degree,
        coefficients=coeffs,
        parameter_count=pcount,
        full_rmse_px=full_rmse,
        cv_rmse_px=float(cv_rmse),
        selection_score=selection_score,
        scale_rms_percent=float(geom["scale_rms_percent"]),
        max_angle_deviation_deg=float(geom["max_angle_deviation_deg"]),
        center_distance_rmse_px=float(geom["center_distance_rmse_px"]),
        max_correction_px=max_shift,
        min_jacobian_det=min_det,
        min_local_stretch=min_stretch,
        max_local_stretch=max_stretch,
        accepted=(len(reasons) == 0),
        reject_reasons=reasons,
    )



def model_specs() -> list[tuple[str, str, int]]:
    specs = [("identity", "identity", 0)]
    if TRY_RADIAL_R2:
        specs.append(("radial_r2", "radial", 1))
    if TRY_RADIAL_R4:
        specs.append(("radial_r2_r4", "radial", 2))
    if TRY_RADIAL_R6:
        specs.append(("radial_r2_r4_r6", "radial", 3))
    if TRY_POLYNOMIAL_DEG2:
        specs.append(("polynomial_2d_deg2", "poly2d", 2))
    if TRY_POLYNOMIAL_DEG3:
        specs.append(("polynomial_2d_deg3", "poly2d", 3))
    return specs



def choose_best_model(ctrl: ControlGeometry) -> tuple[WarpModel, list[WarpModel]]:
    baseline = evaluate_model(ctrl, "identity", "identity", 0, baseline=None)
    baseline.accepted = True
    candidates = [baseline]

    for name, family, degree in model_specs()[1:]:
        candidates.append(evaluate_model(ctrl, name, family, degree, baseline))

    valid = [c for c in candidates if c.accepted]
    if not valid:
        return baseline, candidates

    best = min(valid, key=lambda c: c.selection_score)
    if best.name == "identity":
        return best, candidates

    # Falls ein einfacheres Modell innerhalb weniger Prozent liegt, dieses bevorzugen.
    tolerance = best.selection_score * (1.0 + SIMPLER_MODEL_TOLERANCE_PERCENT / 100.0)
    simpler = [
        c for c in valid
        if c.parameter_count < best.parameter_count and c.selection_score <= tolerance
    ]
    if simpler:
        best = min(simpler, key=lambda c: (c.parameter_count, c.selection_score))

    return best, candidates


def choose_lowest_scale_model(candidates: list[WarpModel]) -> WarpModel:
    """
    Wählt unter allen AKZEPTIERTEN Modellen das Modell mit dem kleinsten
    ScaleRMS. Bei praktisch gleichem ScaleRMS dienen Winkelabweichung,
    CV-Fehler und Modellkomplexität als Tie-Breaker.
    """
    valid = [c for c in candidates if c.accepted]
    if not valid:
        return next(c for c in candidates if c.name == "identity")

    return min(
        valid,
        key=lambda c: (
            c.scale_rms_percent,
            c.max_angle_deviation_deg,
            c.cv_rmse_px,
            c.parameter_count,
            c.selection_score,
        ),
    )


# =============================================================================
# 8. BILD-REMAP: INVERSE DER GEFITTETEN VORWÄRTS-WARP-FUNKTION
# =============================================================================


def build_inverse_remap(width: int, height: int, model: WarpModel) -> tuple[np.ndarray, np.ndarray, float]:
    """
    Gesucht ist für jedes Ausgabepixel q das Eingabepixel p mit warp(p)=q.
    Weil die gewählten Modelle nahe an der Identität bleiben, konvergiert eine
    gedämpfte Fixpunktiteration stabil. Die Berechnung erfolgt zeilenweise in Chunks.
    """
    map_x = np.empty((height, width), dtype=np.float32)
    map_y = np.empty((height, width), dtype=np.float32)
    max_final_error = 0.0

    xs = np.arange(width, dtype=np.float64)

    for y0 in range(0, height, INVERSE_MAP_CHUNK_ROWS):
        y1 = min(height, y0 + INVERSE_MAP_CHUNK_ROWS)
        ys = np.arange(y0, y1, dtype=np.float64)
        xx, yy = np.meshgrid(xs, ys)
        q = np.column_stack([xx.ravel(), yy.ravel()])
        p = q.copy()

        for _ in range(INVERSE_MAP_ITERATIONS):
            f = warp_points(p, width, height, model.family, model.degree, model.coefficients)
            err = q - f
            p += INVERSE_MAP_DAMPING * err

        final = warp_points(p, width, height, model.family, model.degree, model.coefficients)
        final_err = np.linalg.norm(q - final, axis=1)
        max_final_error = max(max_final_error, float(np.max(final_err)))

        map_x[y0:y1] = p[:, 0].reshape(y1 - y0, width).astype(np.float32)
        map_y[y0:y1] = p[:, 1].reshape(y1 - y0, width).astype(np.float32)

    return map_x, map_y, max_final_error



def apply_warp_to_image(image: np.ndarray, model: WarpModel) -> tuple[np.ndarray, float]:
    h, w = image.shape[:2]
    map_x, map_y, inversion_error = build_inverse_remap(w, h, model)
    corrected = cv2.remap(
        image,
        map_x,
        map_y,
        interpolation=REMAP_INTERPOLATION,
        borderMode=cv2.BORDER_CONSTANT,
        borderValue=(0, 0, 0),
    )
    return corrected, inversion_error


# =============================================================================
# 9. DIAGNOSTIK / REPORT
# =============================================================================


def model_to_dict(model: WarpModel) -> dict[str, Any]:
    return {
        "name": model.name,
        "family": model.family,
        "degree": model.degree,
        "coefficients": model.coefficients.tolist(),
        "parameter_count": model.parameter_count,
        "full_rmse_px": model.full_rmse_px,
        "cv_rmse_px": model.cv_rmse_px,
        "selection_score": model.selection_score,
        "scale_rms_percent": model.scale_rms_percent,
        "max_angle_deviation_deg": model.max_angle_deviation_deg,
        "center_distance_rmse_px": model.center_distance_rmse_px,
        "max_correction_px": model.max_correction_px,
        "min_jacobian_det": model.min_jacobian_det,
        "min_local_stretch": model.min_local_stretch,
        "max_local_stretch": model.max_local_stretch,
        "accepted": model.accepted,
        "reject_reasons": model.reject_reasons,
    }



def draw_control_overlay(ctrl: ControlGeometry, model: WarpModel) -> np.ndarray:
    out = ctrl.image.copy()
    predicted = warp_points(
        ctrl.source_points_px,
        ctrl.width,
        ctrl.height,
        model.family,
        model.degree,
        model.coefficients,
    )

    for src, pred, target, label in zip(
        ctrl.source_points_px, predicted, ctrl.target_points_px, ctrl.point_labels
    ):
        a = tuple(np.round(src).astype(int))
        b = tuple(np.round(pred).astype(int))
        t = tuple(np.round(target).astype(int))
        cv2.circle(out, a, 4, (255, 255, 0), 1)
        cv2.circle(out, b, 4, (0, 255, 0), 2)
        cv2.drawMarker(out, t, (0, 0, 255), cv2.MARKER_CROSS, 10, 2)
        cv2.line(out, b, t, (255, 0, 0), 1)

    return out



def detailed_geometry(ctrl: ControlGeometry, model: WarpModel) -> dict[str, Any]:
    warped_corners = {
        mid: warp_points(
            ctrl.matched_corners[mid], ctrl.width, ctrl.height,
            model.family, model.degree, model.coefficients
        )
        for mid in MARKERS
    }
    warped_centers = {
        mid: warp_points(
            ctrl.raw_centers[mid][None, :], ctrl.width, ctrl.height,
            model.family, model.degree, model.coefficients
        )[0]
        for mid in MARKERS
    }

    ref = ctrl.roles.center_id
    ref_mean = float(np.mean(edge_lengths(warped_corners[ref])))
    per_marker = {}
    for mid in MARKERS:
        edges = edge_lengths(warped_corners[mid])
        angles = interior_angles(warped_corners[mid])
        mean_edge = float(np.mean(edges))
        per_marker[str(mid)] = {
            "role": (
                "links_oben" if mid == ctrl.roles.top_left_id else
                "bildmitte_links" if mid == ctrl.roles.left_middle_id else
                "bildmitte"
            ),
            "mean_edge_px": mean_edge,
            "edge_lengths_px": edges.tolist(),
            "edge_scale_deviation_vs_center_percent": float(100.0 * (mean_edge - ref_mean) / ref_mean),
            "angles_deg": angles.tolist(),
            "max_abs_angle_deviation_deg": float(np.nanmax(np.abs(angles - 90.0))),
            "center_px_after": warped_centers[mid].tolist(),
            "target_center_px": ctrl.target_centers[mid].tolist(),
            "center_error_px": float(np.linalg.norm(warped_centers[mid] - ctrl.target_centers[mid])),
        }

    return per_marker



def save_calibration(
    ctrl: ControlGeometry,
    chosen_score: WarpModel,
    chosen_scale: WarpModel,
    candidates: list[WarpModel],
) -> None:
    out = OUTPUT_DIR.expanduser().resolve()
    out.mkdir(parents=True, exist_ok=True)

    def save_model_npz(path: Path, model: WarpModel, selection_rule: str) -> None:
        np.savez(
            path,
            model_name=np.array([model.name]),
            family=np.array([model.family]),
            degree=np.array([model.degree], dtype=np.int32),
            coefficients=model.coefficients,
            image_size=np.array([ctrl.width, ctrl.height], dtype=np.int32),
            marker_size_mm=np.array([MARKER_SIZE_MM], dtype=np.float64),
            top_left_marker_id=np.array([ctrl.roles.top_left_id], dtype=np.int32),
            left_middle_marker_id=np.array([ctrl.roles.left_middle_id], dtype=np.int32),
            center_marker_id=np.array([ctrl.roles.center_id], dtype=np.int32),
            target_similarity=ctrl.target_similarity,
            selection_rule=np.array([selection_rule]),
            scale_rms_percent=np.array([model.scale_rms_percent], dtype=np.float64),
            cv_rmse_px=np.array([model.cv_rmse_px], dtype=np.float64),
        )

    # Zwei separat wiederverwendbare Kalibrierungen speichern.
    score_npz = out / "geometric_warp_calibration_v5_score.npz"
    scale_npz = out / "geometric_warp_calibration_v5_min_scale.npz"
    save_model_npz(score_npz, chosen_score, "minimum_selection_score")
    save_model_npz(scale_npz, chosen_scale, "minimum_scale_rms")

    # Rückwärtskompatibel: bisheriger Dateiname enthält weiterhin den Score-Gewinner.
    save_model_npz(
        out / "geometric_warp_calibration_v5.npz",
        chosen_score,
        "minimum_selection_score",
    )

    # Beide Korrekturvarianten erzeugen.
    corrected_score, inversion_error_score = apply_warp_to_image(ctrl.image, chosen_score)
    corrected_scale, inversion_error_scale = apply_warp_to_image(ctrl.image, chosen_scale)

    cv2.imwrite(str(out / f"{CALIBRATION_IMAGE.stem}_00_original.png"), ctrl.image)
    cv2.imwrite(
        str(out / f"{CALIBRATION_IMAGE.stem}_01_corrected_score.png"),
        corrected_score,
    )
    cv2.imwrite(
        str(out / f"{CALIBRATION_IMAGE.stem}_02_corrected_min_scale.png"),
        corrected_scale,
    )

    overlay_score = draw_control_overlay(ctrl, chosen_score)
    overlay_scale = draw_control_overlay(ctrl, chosen_scale)
    cv2.imwrite(
        str(out / f"{CALIBRATION_IMAGE.stem}_03_control_overlay_score.png"),
        overlay_score,
    )
    cv2.imwrite(
        str(out / f"{CALIBRATION_IMAGE.stem}_04_control_overlay_min_scale.png"),
        overlay_scale,
    )

    identity = WarpModel(
        name="identity", family="identity", degree=0, coefficients=np.zeros(0),
        parameter_count=0, full_rmse_px=0, cv_rmse_px=0, selection_score=0,
        scale_rms_percent=0, max_angle_deviation_deg=0, center_distance_rmse_px=0,
        max_correction_px=0, min_jacobian_det=1, min_local_stretch=1, max_local_stretch=1,
        accepted=True, reject_reasons=[]
    )

    report = {
        "method": "direct_metric_control_point_warp_v5_dual_output",
        "important": (
            "Es werden zwei Korrekturen ausgegeben: (1) der bisherige Gewinner nach "
            "selection_score und (2) das akzeptierte Modell mit dem kleinsten ScaleRMS."
        ),
        "image": str(CALIBRATION_IMAGE.expanduser().resolve()),
        "image_size": [ctrl.width, ctrl.height],
        "marker_size_mm": MARKER_SIZE_MM,
        "roles_from_coordinates": {
            "links_oben": ctrl.roles.top_left_id,
            "bildmitte_links": ctrl.roles.left_middle_id,
            "bildmitte": ctrl.roles.center_id,
        },
        "marker_configuration": {
            str(mid): {
                "center_mm": list(map(float, MARKERS[mid]["center_mm"])),
                "rotation_deg": float(MARKERS[mid].get("rotation_deg", 0.0)),
            }
            for mid in MARKERS
        },
        "orientation_score_px": ctrl.orientation_score_px,
        "chosen_by_score": model_to_dict(chosen_score),
        "chosen_by_min_scale_rms": model_to_dict(chosen_scale),
        "candidates": [model_to_dict(c) for c in candidates],
        "inverse_map_max_residual_px": {
            "score": inversion_error_score,
            "min_scale_rms": inversion_error_scale,
        },
        "before_marker_geometry": detailed_geometry(ctrl, identity),
        "after_marker_geometry_score": detailed_geometry(ctrl, chosen_score),
        "after_marker_geometry_min_scale_rms": detailed_geometry(ctrl, chosen_scale),
    }

    (out / "calibration_report_v5.json").write_text(
        json.dumps(report, indent=2, ensure_ascii=False), encoding="utf-8"
    )

    lines = [
        "ARUCO GEOMETRIC DISTORTION RECTIFICATION V5 - DUAL OUTPUT",
        "=" * 96,
        "",
        "Markerrollen aus center_mm (nicht aus ID):",
        f"  links oben      -> ID {ctrl.roles.top_left_id} | {MARKERS[ctrl.roles.top_left_id]['center_mm']}",
        f"  bildmitte links -> ID {ctrl.roles.left_middle_id} | {MARKERS[ctrl.roles.left_middle_id]['center_mm']}",
        f"  bildmitte       -> ID {ctrl.roles.center_id} | {MARKERS[ctrl.roles.center_id]['center_mm']}",
        "",
        f"Eck-/Orientierungs-Score: {ctrl.orientation_score_px:.4f} px",
        "",
        "AUSGABE A - bisherige Auswahl nach selection_score:",
        f"  Modell: {chosen_score.name}",
        f"  Score: {chosen_score.selection_score:.4f}",
        f"  LOO-CV RMSE: {chosen_score.cv_rmse_px:.4f} px",
        f"  ScaleRMS: {chosen_score.scale_rms_percent:.4f} %",
        f"  Max. Winkelabweichung: {chosen_score.max_angle_deviation_deg:.4f} deg",
        f"  Max. Korrektur: {chosen_score.max_correction_px:.2f} px",
        f"  Inverse-Map Restfehler: {inversion_error_score:.6f} px",
        "",
        "AUSGABE B - akzeptiertes Modell mit kleinstem ScaleRMS:",
        f"  Modell: {chosen_scale.name}",
        f"  Score: {chosen_scale.selection_score:.4f}",
        f"  LOO-CV RMSE: {chosen_scale.cv_rmse_px:.4f} px",
        f"  ScaleRMS: {chosen_scale.scale_rms_percent:.4f} %",
        f"  Max. Winkelabweichung: {chosen_scale.max_angle_deviation_deg:.4f} deg",
        f"  Max. Korrektur: {chosen_scale.max_correction_px:.2f} px",
        f"  Inverse-Map Restfehler: {inversion_error_scale:.6f} px",
        "",
        "Modellvergleich:",
    ]

    for c in candidates:
        status = "AKZEPTIERT" if c.accepted else "VERWORFEN"
        tags = []
        if c.name == chosen_score.name:
            tags.append("SCORE-GEWINNER")
        if c.name == chosen_scale.name:
            tags.append("MIN-SCALERMS")
        tag_text = (" | " + ", ".join(tags)) if tags else ""
        lines.append(
            f"  {c.name:22s} | CV={c.cv_rmse_px:9.3f}px | Full={c.full_rmse_px:9.3f}px | "
            f"ScaleRMS={c.scale_rms_percent:7.3f}% | Angle={c.max_angle_deviation_deg:7.3f}deg | "
            f"Shift={c.max_correction_px:8.2f}px | Score={c.selection_score:9.3f} | {status}{tag_text}"
        )
        if c.coefficients.size:
            lines.append("      coeffs=" + np.array2string(c.coefficients, precision=8, separator=", "))
        for reason in c.reject_reasons:
            lines.append(f"      -> {reason}")

    lines += [
        "",
        "Ausgabedateien:",
        f"  {CALIBRATION_IMAGE.stem}_00_original.png",
        f"  {CALIBRATION_IMAGE.stem}_01_corrected_score.png",
        f"  {CALIBRATION_IMAGE.stem}_02_corrected_min_scale.png",
        f"  {CALIBRATION_IMAGE.stem}_03_control_overlay_score.png",
        f"  {CALIBRATION_IMAGE.stem}_04_control_overlay_min_scale.png",
        "  geometric_warp_calibration_v5_score.npz",
        "  geometric_warp_calibration_v5_min_scale.npz",
        "  geometric_warp_calibration_v5.npz  (Alias des Score-Gewinners)",
        "  calibration_report_v5.json",
        "  calibration_report_v5.txt",
    ]

    (out / "calibration_report_v5.txt").write_text(
        "\n".join(lines) + "\n", encoding="utf-8"
    )


# =============================================================================
# 10. GESPEICHERTE WARP AUF ANDERE BILDER ANWENDEN
# =============================================================================


def load_model_from_npz(path: Path) -> tuple[WarpModel, tuple[int, int]]:
    data = np.load(path)
    name = str(np.asarray(data["model_name"]).reshape(-1)[0])
    family = str(np.asarray(data["family"]).reshape(-1)[0])
    degree = int(np.asarray(data["degree"]).reshape(-1)[0])
    coeffs = np.asarray(data["coefficients"], dtype=np.float64).reshape(-1)
    w, h = map(int, np.asarray(data["image_size"]).reshape(2))

    dummy = WarpModel(
        name=name, family=family, degree=degree, coefficients=coeffs,
        parameter_count=len(coeffs), full_rmse_px=0.0, cv_rmse_px=0.0,
        selection_score=0.0, scale_rms_percent=0.0, max_angle_deviation_deg=0.0,
        center_distance_rmse_px=0.0, max_correction_px=0.0,
        min_jacobian_det=1.0, min_local_stretch=1.0, max_local_stretch=1.0,
        accepted=True, reject_reasons=[]
    )
    return dummy, (w, h)



def apply_saved_warp(calibration_npz: Path, input_path: Path, output_path: Path) -> None:
    model, (cal_w, cal_h) = load_model_from_npz(calibration_npz)
    image = cv2.imread(str(input_path), cv2.IMREAD_COLOR)
    if image is None:
        raise FileNotFoundError(f"Bild konnte nicht gelesen werden: {input_path}")
    h, w = image.shape[:2]

    if (w, h) != (cal_w, cal_h):
        sx = w / cal_w
        sy = h / cal_h
        if not ALLOW_PROPORTIONAL_RESOLUTION_SCALING or abs(sx - sy) > 1e-4:
            raise ValueError(
                f"Bildgröße {w}x{h} passt nicht zu Kalibrierung {cal_w}x{cal_h}. "
                "Nur proportionale Skalierung mit gleichem Crop/Seitenverhältnis ist erlaubt."
            )

    corrected, inversion_error = apply_warp_to_image(image, model)
    output_path.parent.mkdir(parents=True, exist_ok=True)
    if not cv2.imwrite(str(output_path), corrected):
        raise IOError(f"Konnte Bild nicht schreiben: {output_path}")
    print(f"  inverse-map Restfehler: {inversion_error:.6f}px")


# =============================================================================
# 11. MAIN
# =============================================================================


def main() -> None:
    require_aruco()
    roles = validate_configuration()

    print("Markerrollen automatisch aus center_mm:")
    print(f"  links oben      -> ID {roles.top_left_id} | {MARKERS[roles.top_left_id]['center_mm']}")
    print(f"  bildmitte links -> ID {roles.left_middle_id} | {MARKERS[roles.left_middle_id]['center_mm']}")
    print(f"  bildmitte       -> ID {roles.center_id} | {MARKERS[roles.center_id]['center_mm']}")

    ctrl = build_control_geometry(CALIBRATION_IMAGE.expanduser().resolve(), roles)
    print(f"\nBild: {CALIBRATION_IMAGE.name} | {ctrl.width}x{ctrl.height}")
    print(f"16 Kontrollstellen aufgebaut | Orientierungs-Score={ctrl.orientation_score_px:.3f}px")

    print("\nModellvergleich ...")
    chosen, candidates = choose_best_model(ctrl)
    for c in candidates:
        status = "AKZEPTIERT" if c.accepted else "VERWORFEN"
        print(
            f"  {c.name:22s} | CV={c.cv_rmse_px:9.3f}px | Full={c.full_rmse_px:9.3f}px | "
            f"ScaleRMS={c.scale_rms_percent:7.3f}% | Angle={c.max_angle_deviation_deg:7.3f}deg | "
            f"Shift={c.max_correction_px:8.2f}px | {status}"
        )
        for reason in c.reject_reasons:
            print(f"      -> {reason}")

    chosen_scale = choose_lowest_scale_model(candidates)

    print(f"\nGewählt nach Score: {chosen.name}")
    if chosen.coefficients.size:
        print("  Koeffizienten:", np.array2string(chosen.coefficients, precision=10, separator=", "))
    print(f"Gewählt nach kleinstem ScaleRMS: {chosen_scale.name}")
    if chosen_scale.coefficients.size:
        print("  Koeffizienten:", np.array2string(chosen_scale.coefficients, precision=10, separator=", "))

    save_calibration(ctrl, chosen, chosen_scale, candidates)

    if APPLY_IMAGES:
        apply_dir = OUTPUT_DIR.expanduser().resolve() / "applied"
        score_file = OUTPUT_DIR.expanduser().resolve() / "geometric_warp_calibration_v5_score.npz"
        scale_file = OUTPUT_DIR.expanduser().resolve() / "geometric_warp_calibration_v5_min_scale.npz"
        for p in APPLY_IMAGES:
            p = p.expanduser().resolve()
            dst_score = apply_dir / f"{p.stem}_corrected_score{p.suffix}"
            dst_scale = apply_dir / f"{p.stem}_corrected_min_scale{p.suffix}"
            print(f"\nAnwenden: {p.name}")
            apply_saved_warp(score_file, p, dst_score)
            apply_saved_warp(scale_file, p, dst_scale)
            print(f"  Score      -> {dst_score}")
            print(f"  MinScaleRMS-> {dst_scale}")

    print("\nFertig. Output:", OUTPUT_DIR.expanduser().resolve())


if __name__ == "__main__":
    main()
