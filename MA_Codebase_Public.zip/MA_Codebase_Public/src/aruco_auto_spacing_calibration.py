#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Approximate Einbild-Kamerakalibrierung mit >= 3 ArUco-Markern auf EINER ebenen Wand.

Es müssen KEINE realen Abstände zwischen den Markern bekannt sein.
Bekannt sein müssen nur:
    1) reale Kantenlänge aller Marker
    2) senkrechter Abstand Kamera <-> Wand

Idee:
- ArUco-Ecken subpixelgenau erkennen.
- Aus der bekannten Markergröße eine grobe Pixel/mm-Skalierung bestimmen.
- Daraus die relativen Markerpositionen auf der Wand interpolieren.
- Anschließend Kamerapose, Brennweite, radiale Verzeichnung und die unbekannten
  Markerpositionen GEMEINSAM optimieren.

Zur Stabilität wird bewusst ein reduziertes Objektivmodell verwendet:
    fx = fy = f
    cx, cy = Bildmitte
    p1 = p2 = 0
    radiale Verzeichnung = k1, k2, k3

Das ist keine laborfähige Kalibrierung, aber für eine praktische Rand-/Ecken-
Entzerrung aus nur einem Bild oft deutlich stabiler als ein komplett freies Modell.

Installation:
    pip install opencv-contrib-python numpy scipy
"""

from __future__ import annotations

import json
import math
from pathlib import Path

import cv2
import numpy as np
from scipy.optimize import least_squares


# =============================================================================
# BENUTZER-EINSTELLUNGEN
# =============================================================================

CALIBRATION_IMAGE = Path("/home/mitte/crack_project/test_images/Verzeichnung_reduzieren/150cm.JPG")
OUTPUT_DIR = Path("/home/mitte/crack_project/test_images/Verzeichnung_reduzieren")

# Muss zum erzeugten Marker-Dictionary passen.
ARUCO_DICTIONARY = cv2.aruco.DICT_5X5_50

# Reale Kantenlänge eines Markers.
MARKER_SIZE_MM = 48.7

# Senkrechter Abstand zwischen Kamerazentrum und Wandebene.
CAMERA_TO_WALL_MM = 1500.0

# None = alle erkannten Marker verwenden.
# Alternativ z.B. [0, 1, 2].
MARKER_IDS = [0, 1, 2] #None

# 0.0 -> schneidet stärker zu, vermeidet schwarze Ränder.
# 1.0 -> erhält mehr Bildinhalt, kann schwarze Ränder erzeugen.
UNDISTORT_ALPHA = 0.0

# Wie stark die aus Pixelabständen interpolierte Markeranordnung als weicher
# Start-/Plausibilitätswert erhalten bleiben soll.
# 0.0 = völlig frei optimieren; 0.03 ... 0.15 ist meist sinnvoll.
LAYOUT_PRIOR_WEIGHT = 0.06

# Entsprechende schwache Stabilisierung der relativen Markerdrehungen.
ANGLE_PRIOR_WEIGHT = 0.03

# Gewicht des bekannten Wandabstands. Der Abstand wird intern von mm in ungefähr
# Pixel umgerechnet. 1.0 ist ein guter Startwert.
DISTANCE_WEIGHT = 1.0

ROBUST_LOSS = "soft_l1"   # linear, soft_l1, huber, cauchy
ROBUST_F_SCALE = 1.0

# Grenzen gegen extreme numerische Scheinlösungen.
K1_LIMIT = 1.5
K2_LIMIT = 1.5
K3_LIMIT = 1.5


# =============================================================================
# GEOMETRIE / ERKENNUNG
# =============================================================================


def require_aruco() -> None:
    if not hasattr(cv2, "aruco"):
        raise RuntimeError(
            "cv2.aruco fehlt. Bitte 'opencv-contrib-python' installieren."
        )


def detect_aruco(image: np.ndarray):
    gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
    dictionary = cv2.aruco.getPredefinedDictionary(ARUCO_DICTIONARY)

    if hasattr(cv2.aruco, "ArucoDetector"):
        params = cv2.aruco.DetectorParameters()
        detector = cv2.aruco.ArucoDetector(dictionary, params)
        corners, ids, _ = detector.detectMarkers(gray)
    else:
        params = cv2.aruco.DetectorParameters_create()
        corners, ids, _ = cv2.aruco.detectMarkers(
            gray, dictionary, parameters=params
        )

    if ids is None or len(ids) == 0:
        raise RuntimeError("Keine ArUco-Marker gefunden.")

    ids = ids.reshape(-1).astype(int)

    criteria = (
        cv2.TERM_CRITERIA_EPS + cv2.TERM_CRITERIA_MAX_ITER,
        80,
        1e-5,
    )

    refined = []
    for c in corners:
        pts = np.asarray(c, dtype=np.float32).reshape(4, 2)
        cv2.cornerSubPix(
            gray,
            pts,
            winSize=(5, 5),
            zeroZone=(-1, -1),
            criteria=criteria,
        )
        refined.append(pts.astype(np.float64))

    return refined, ids


def select_markers(corners, ids):
    detected = {int(i): c for i, c in zip(ids, corners)}

    if MARKER_IDS is None:
        selected_ids = sorted(detected)
    else:
        selected_ids = [int(i) for i in MARKER_IDS]
        missing = [i for i in selected_ids if i not in detected]
        if missing:
            raise RuntimeError(
                f"Erwartete Marker fehlen: {missing}; gefunden: {sorted(detected)}"
            )

    if len(selected_ids) < 3:
        raise RuntimeError(
            f"Mindestens 3 Marker werden empfohlen/benötigt; verwendet würden nur {len(selected_ids)}."
        )

    selected = {i: detected[i] for i in selected_ids}
    return selected_ids, selected


def marker_center(corners: np.ndarray) -> np.ndarray:
    return np.mean(corners, axis=0)


def marker_mean_side_px(corners: np.ndarray) -> float:
    p = np.asarray(corners, dtype=np.float64)
    return float(np.mean([
        np.linalg.norm(p[1] - p[0]),
        np.linalg.norm(p[2] - p[1]),
        np.linalg.norm(p[3] - p[2]),
        np.linalg.norm(p[0] - p[3]),
    ]))


def wrap_angle(a: float) -> float:
    return (float(a) + math.pi) % (2.0 * math.pi) - math.pi


def estimate_pixel_layout(selected_ids, selected):
    """
    Erzeugt aus dem Bild eine grobe metrische Markeranordnung.

    Der erste Marker definiert das Wand-Koordinatensystem:
      Mittelpunkt = (0,0)
      Markerrotation = 0

    Die Bildabstände der anderen Marker werden mit der aus allen Markergrößen
    geschätzten Pixel/mm-Skalierung in mm umgerechnet.
    """
    side_px = np.array(
        [marker_mean_side_px(selected[i]) for i in selected_ids],
        dtype=np.float64,
    )
    px_per_mm = float(np.median(side_px / float(MARKER_SIZE_MM)))

    if not np.isfinite(px_per_mm) or px_per_mm <= 0:
        raise RuntimeError("Ungültige Pixel/mm-Schätzung.")

    ref_id = selected_ids[0]
    ref = selected[ref_id]
    ref_center = marker_center(ref)

    # Lokale Bildachsen des Referenzmarkers.
    ex = ref[1] - ref[0]
    ey_hint = ref[3] - ref[0]
    ex /= max(np.linalg.norm(ex), 1e-12)

    # Orthogonale y-Achse im Bild; Vorzeichen so wählen, dass sie grob nach
    # Marker-Unterkante zeigt.
    ey = np.array([-ex[1], ex[0]], dtype=np.float64)
    if np.dot(ey, ey_hint) < 0:
        ey *= -1.0

    layout = {}
    ref_edge_angle = math.atan2(
        float(ref[1, 1] - ref[0, 1]),
        float(ref[1, 0] - ref[0, 0]),
    )

    for marker_id in selected_ids:
        c = marker_center(selected[marker_id])
        d = c - ref_center

        x_mm = float(np.dot(d, ex) / px_per_mm)
        y_mm = float(np.dot(d, ey) / px_per_mm)

        edge = selected[marker_id][1] - selected[marker_id][0]
        edge_angle = math.atan2(float(edge[1]), float(edge[0]))
        rel_angle = wrap_angle(edge_angle - ref_edge_angle)

        if marker_id == ref_id:
            x_mm, y_mm, rel_angle = 0.0, 0.0, 0.0

        layout[marker_id] = {
            "center_mm": np.array([x_mm, y_mm], dtype=np.float64),
            "angle_rad": float(rel_angle),
            "mean_side_px": marker_mean_side_px(selected[marker_id]),
        }

    return layout, px_per_mm


def square_world_corners(center_xy, angle_rad: float) -> np.ndarray:
    """4 Marker-Ecken TL,TR,BR,BL im Wandkoordinatensystem."""
    half = float(MARKER_SIZE_MM) / 2.0
    local = np.array([
        [-half, -half],
        [ half, -half],
        [ half,  half],
        [-half,  half],
    ], dtype=np.float64)

    c = math.cos(float(angle_rad))
    s = math.sin(float(angle_rad))
    R2 = np.array([[c, -s], [s, c]], dtype=np.float64)
    xy = local @ R2.T
    xy += np.asarray(center_xy, dtype=np.float64).reshape(1, 2)
    return np.column_stack([xy, np.zeros(4, dtype=np.float64)])


def camera_center_world(rvec, tvec):
    R, _ = cv2.Rodrigues(np.asarray(rvec, dtype=np.float64).reshape(3, 1))
    t = np.asarray(tvec, dtype=np.float64).reshape(3, 1)
    return (-R.T @ t).reshape(3)


# =============================================================================
# OPTIMIERUNG
# =============================================================================


def build_object_points(selected_ids, layout):
    obj = []
    for marker_id in selected_ids:
        cfg = layout[marker_id]
        obj.append(square_world_corners(cfg["center_mm"], cfg["angle_rad"]))
    return np.vstack(obj).astype(np.float64)


def build_image_points(selected_ids, selected):
    return np.vstack([selected[i] for i in selected_ids]).astype(np.float64)


def initial_camera(selected_ids, selected, layout, px_per_mm, width, height):
    obj = build_object_points(selected_ids, layout)
    img = build_image_points(selected_ids, selected)

    # Für eine annähernd frontale Wand gilt grob f_px ~= px/mm * Abstand_mm.
    f0 = float(px_per_mm * CAMERA_TO_WALL_MM)
    f0 = float(np.clip(f0, 0.2 * max(width, height), 8.0 * max(width, height)))

    cx = (width - 1) / 2.0
    cy = (height - 1) / 2.0
    K0 = np.array([
        [f0, 0.0, cx],
        [0.0, f0, cy],
        [0.0, 0.0, 1.0],
    ], dtype=np.float64)

    ok, rvec, tvec = cv2.solvePnP(
        obj.reshape(-1, 1, 3),
        img.reshape(-1, 1, 2),
        K0,
        np.zeros((5, 1), dtype=np.float64),
        flags=cv2.SOLVEPNP_ITERATIVE,
    )

    if not ok or not np.all(np.isfinite(tvec)):
        rvec = np.zeros((3, 1), dtype=np.float64)
        tvec = np.array([[0.0], [0.0], [CAMERA_TO_WALL_MM]], dtype=np.float64)

    return f0, rvec.reshape(3), tvec.reshape(3)


def pack_initial(selected_ids, layout, f0, rvec, tvec):
    # Parameter:
    # log(f), k1,k2,k3, rvec(3), tvec(3),
    # dann für jeden Marker außer Referenz: center_x, center_y, angle
    x = [math.log(float(f0)), 0.0, 0.0, 0.0]
    x.extend(np.asarray(rvec, dtype=np.float64).tolist())
    x.extend(np.asarray(tvec, dtype=np.float64).tolist())

    for marker_id in selected_ids[1:]:
        cfg = layout[marker_id]
        x.extend([
            float(cfg["center_mm"][0]),
            float(cfg["center_mm"][1]),
            float(cfg["angle_rad"]),
        ])

    return np.asarray(x, dtype=np.float64)


def unpack(x, selected_ids, width, height):
    f = float(np.exp(x[0]))
    k1, k2, k3 = map(float, x[1:4])
    rvec = np.asarray(x[4:7], dtype=np.float64)
    tvec = np.asarray(x[7:10], dtype=np.float64)

    cx = (width - 1) / 2.0
    cy = (height - 1) / 2.0
    K = np.array([
        [f, 0.0, cx],
        [0.0, f, cy],
        [0.0, 0.0, 1.0],
    ], dtype=np.float64)

    # OpenCV-Reihenfolge: k1, k2, p1, p2, k3
    dist = np.array([k1, k2, 0.0, 0.0, k3], dtype=np.float64).reshape(1, 5)

    marker_states = {
        selected_ids[0]: {
            "center_mm": np.array([0.0, 0.0], dtype=np.float64),
            "angle_rad": 0.0,
        }
    }

    pos = 10
    for marker_id in selected_ids[1:]:
        marker_states[marker_id] = {
            "center_mm": np.array([x[pos], x[pos + 1]], dtype=np.float64),
            "angle_rad": float(x[pos + 2]),
        }
        pos += 3

    return K, dist, rvec, tvec, marker_states


def object_points_from_states(selected_ids, states):
    return np.vstack([
        square_world_corners(states[i]["center_mm"], states[i]["angle_rad"])
        for i in selected_ids
    ]).astype(np.float64)


def residuals(x, selected_ids, image_points, layout_prior, px_per_mm, width, height):
    K, dist, rvec, tvec, states = unpack(x, selected_ids, width, height)
    object_points = object_points_from_states(selected_ids, states)

    projected, _ = cv2.projectPoints(
        object_points.reshape(-1, 1, 3),
        rvec.reshape(3, 1),
        tvec.reshape(3, 1),
        K,
        dist,
    )
    projected = projected.reshape(-1, 2)

    res = list((projected - image_points).reshape(-1))

    # Bekannter senkrechter Kamera-Wand-Abstand, in ungefähre Pixel-Einheiten
    # umgerechnet, damit das Gewicht intuitiver bleibt.
    C = camera_center_world(rvec, tvec)
    wall_distance = abs(float(C[2]))
    res.append(
        (wall_distance - float(CAMERA_TO_WALL_MM))
        * float(px_per_mm)
        * float(DISTANCE_WEIGHT)
    )

    # Weiche Priors: Pixel->mm-Interpolation ist nur Start/Plausibilität,
    # NICHT harte Geometrie. Die Optimierung darf sie korrigieren.
    for marker_id in selected_ids[1:]:
        current = states[marker_id]
        prior = layout_prior[marker_id]

        delta_mm = current["center_mm"] - prior["center_mm"]
        res.extend(
            (delta_mm * float(px_per_mm) * float(LAYOUT_PRIOR_WEIGHT)).tolist()
        )

        da = wrap_angle(current["angle_rad"] - prior["angle_rad"])
        res.append(
            da
            * float(MARKER_SIZE_MM)
            * float(px_per_mm)
            * float(ANGLE_PRIOR_WEIGHT)
        )

    return np.asarray(res, dtype=np.float64)


def make_bounds(selected_ids, width, height, layout_prior):
    n_extra = len(selected_ids) - 1
    size = 10 + 3 * n_extra

    lower = np.full(size, -np.inf, dtype=np.float64)
    upper = np.full(size,  np.inf, dtype=np.float64)

    max_dim = max(width, height)
    lower[0] = math.log(0.15 * max_dim)
    upper[0] = math.log(12.0 * max_dim)

    lower[1:4] = [-K1_LIMIT, -K2_LIMIT, -K3_LIMIT]
    upper[1:4] = [ K1_LIMIT,  K2_LIMIT,  K3_LIMIT]

    lower[4:7] = -math.pi
    upper[4:7] =  math.pi

    # Translation großzügig begrenzen.
    lower[7:10] = [-1e6, -1e6, -1e6]
    upper[7:10] = [ 1e6,  1e6,  1e6]

    # Markerzentren: grobe Bildinterpolation ± großzügiger Bereich.
    pos = 10
    for marker_id in selected_ids[1:]:
        cx0, cy0 = layout_prior[marker_id]["center_mm"]
        span = max(5.0 * MARKER_SIZE_MM, 2.0 * math.hypot(cx0, cy0) + 5.0 * MARKER_SIZE_MM)
        lower[pos:pos + 3] = [cx0 - span, cy0 - span, -math.pi]
        upper[pos:pos + 3] = [cx0 + span, cy0 + span,  math.pi]
        pos += 3

    return lower, upper


def calibrate(selected_ids, selected, width, height):
    layout_prior, px_per_mm = estimate_pixel_layout(selected_ids, selected)
    image_points = build_image_points(selected_ids, selected)

    f0, r0, t0 = initial_camera(
        selected_ids, selected, layout_prior, px_per_mm, width, height
    )
    x0 = pack_initial(selected_ids, layout_prior, f0, r0, t0)
    lower, upper = make_bounds(selected_ids, width, height, layout_prior)

    result = least_squares(
        residuals,
        x0,
        bounds=(lower, upper),
        args=(selected_ids, image_points, layout_prior, px_per_mm, width, height),
        method="trf",
        loss=ROBUST_LOSS,
        f_scale=ROBUST_F_SCALE,
        x_scale="jac",
        max_nfev=10000,
        ftol=1e-11,
        xtol=1e-11,
        gtol=1e-11,
        verbose=1,
    )

    K, dist, rvec, tvec, states = unpack(result.x, selected_ids, width, height)
    object_points = object_points_from_states(selected_ids, states)

    projected, _ = cv2.projectPoints(
        object_points.reshape(-1, 1, 3),
        rvec.reshape(3, 1),
        tvec.reshape(3, 1),
        K,
        dist,
    )
    projected = projected.reshape(-1, 2)

    corner_errors = np.linalg.norm(projected - image_points, axis=1)
    C = camera_center_world(rvec, tvec)

    return {
        "optimizer": result,
        "K": K,
        "dist": dist,
        "rvec": rvec.reshape(3, 1),
        "tvec": tvec.reshape(3, 1),
        "camera_center_world": C,
        "estimated_wall_distance_mm": abs(float(C[2])),
        "states": states,
        "layout_prior": layout_prior,
        "px_per_mm_initial": px_per_mm,
        "image_points": image_points,
        "projected": projected,
        "rms_reprojection_px": float(np.sqrt(np.mean(corner_errors ** 2))),
        "mean_reprojection_px": float(np.mean(corner_errors)),
        "max_reprojection_px": float(np.max(corner_errors)),
    }


# =============================================================================
# AUSGABE
# =============================================================================


def draw_diagnostics(image, selected_ids, selected, result):
    out = image.copy()

    measured = result["image_points"]
    projected = result["projected"]

    for pm, pp in zip(measured, projected):
        a = tuple(np.round(pm).astype(int))
        b = tuple(np.round(pp).astype(int))
        cv2.circle(out, a, 5, (0, 255, 0), 2)
        cv2.drawMarker(
            out, b, (0, 0, 255),
            markerType=cv2.MARKER_CROSS,
            markerSize=12,
            thickness=2,
        )
        cv2.line(out, a, b, (255, 0, 0), 1)

    for marker_id in selected_ids:
        c = marker_center(selected[marker_id])
        pos = tuple((np.round(c) + np.array([8, -8])).astype(int))
        cv2.putText(
            out,
            f"ID {marker_id}",
            pos,
            cv2.FONT_HERSHEY_SIMPLEX,
            0.65,
            (255, 255, 0),
            2,
            cv2.LINE_AA,
        )

    return out


def save_yaml(path: Path, K, dist, new_K, image_size, roi):
    fs = cv2.FileStorage(str(path), cv2.FILE_STORAGE_WRITE)
    if not fs.isOpened():
        raise RuntimeError(f"YAML konnte nicht geschrieben werden: {path}")

    fs.write("image_width", int(image_size[0]))
    fs.write("image_height", int(image_size[1]))
    fs.write("camera_matrix", K)
    fs.write("dist_coeffs", dist)
    fs.write("new_camera_matrix", new_K)
    fs.write("roi_x", int(roi[0]))
    fs.write("roi_y", int(roi[1]))
    fs.write("roi_w", int(roi[2]))
    fs.write("roi_h", int(roi[3]))
    fs.release()


def main():
    require_aruco()
    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)

    image = cv2.imread(str(CALIBRATION_IMAGE), cv2.IMREAD_COLOR)
    if image is None:
        raise FileNotFoundError(
            f"Kalibrierungsbild konnte nicht geladen werden: {CALIBRATION_IMAGE}"
        )

    height, width = image.shape[:2]
    corners, ids = detect_aruco(image)
    selected_ids, selected = select_markers(corners, ids)

    print(f"Bild: {width} x {height}")
    print("Gefundene Marker:", sorted(map(int, ids)))
    print("Verwendete Marker:", selected_ids)

    result = calibrate(selected_ids, selected, width, height)
    K = result["K"]
    dist = result["dist"]

    new_K, roi = cv2.getOptimalNewCameraMatrix(
        K,
        dist,
        (width, height),
        UNDISTORT_ALPHA,
        (width, height),
    )

    print("\n=== GESCHÄTZTE KALIBRIERUNG ===")
    print("Erfolg:", result["optimizer"].success)
    print("Meldung:", result["optimizer"].message)
    print(f"Initiale Skalierung: {result['px_per_mm_initial']:.6f} px/mm")
    print("\nKameramatrix K:\n", K)
    print("\nVerzeichnung [k1, k2, p1, p2, k3]:\n", dist.reshape(-1))
    print(f"\nWandabstand geschätzt: {result['estimated_wall_distance_mm']:.3f} mm")
    print(f"Wandabstand vorgegeben: {CAMERA_TO_WALL_MM:.3f} mm")
    print(f"RMS-Reprojektionsfehler: {result['rms_reprojection_px']:.4f} px")
    print(f"Mittlerer Fehler:         {result['mean_reprojection_px']:.4f} px")
    print(f"Maximaler Fehler:         {result['max_reprojection_px']:.4f} px")

    print("\nAutomatisch geschätzte Markerpositionen auf der Wand:")
    for marker_id in selected_ids:
        p0 = result["layout_prior"][marker_id]["center_mm"]
        p1 = result["states"][marker_id]["center_mm"]
        angle_deg = math.degrees(result["states"][marker_id]["angle_rad"])
        print(
            f"  ID {marker_id}: Pixel-Interpolation=({p0[0]:.2f}, {p0[1]:.2f}) mm, "
            f"optimiert=({p1[0]:.2f}, {p1[1]:.2f}) mm, Winkel={angle_deg:.2f}°"
        )

    # NPZ -> direkt vom Apply-Skript verwendbar.
    np.savez(
        OUTPUT_DIR / "camera_calibration.npz",
        camera_matrix=K,
        dist_coeffs=dist,
        new_camera_matrix=new_K,
        image_size=np.array([width, height], dtype=np.int32),
        roi=np.array(roi, dtype=np.int32),
        marker_size_mm=np.array([MARKER_SIZE_MM], dtype=np.float64),
        camera_to_wall_mm=np.array([CAMERA_TO_WALL_MM], dtype=np.float64),
        rvec=result["rvec"],
        tvec=result["tvec"],
        camera_center_world=result["camera_center_world"],
        rms_reprojection_px=np.array([result["rms_reprojection_px"]], dtype=np.float64),
    )

    save_yaml(
        OUTPUT_DIR / "camera_calibration.yaml",
        K, dist, new_K, (width, height), roi
    )

    report = {
        "note": (
            "Approximation aus einem Bild ohne gemessene Markerabstände. "
            "Markerabstände wurden zuerst aus Pixelabständen und Markergröße interpoliert "
            "und danach gemeinsam mit Kamera/Verzeichnung optimiert."
        ),
        "image": str(CALIBRATION_IMAGE),
        "image_size": [width, height],
        "marker_ids": selected_ids,
        "marker_size_mm": MARKER_SIZE_MM,
        "camera_to_wall_mm_given": CAMERA_TO_WALL_MM,
        "camera_to_wall_mm_estimated": result["estimated_wall_distance_mm"],
        "initial_px_per_mm": result["px_per_mm_initial"],
        "camera_matrix": K.tolist(),
        "dist_coeffs_k1_k2_p1_p2_k3": dist.reshape(-1).tolist(),
        "rms_reprojection_px": result["rms_reprojection_px"],
        "mean_reprojection_px": result["mean_reprojection_px"],
        "max_reprojection_px": result["max_reprojection_px"],
        "marker_layout": {
            str(i): {
                "initial_center_mm": result["layout_prior"][i]["center_mm"].tolist(),
                "optimized_center_mm": result["states"][i]["center_mm"].tolist(),
                "optimized_rotation_deg": math.degrees(result["states"][i]["angle_rad"]),
                "observed_mean_side_px": result["layout_prior"][i]["mean_side_px"],
            }
            for i in selected_ids
        },
        "optimizer_success": bool(result["optimizer"].success),
        "optimizer_message": str(result["optimizer"].message),
        "roi": list(map(int, roi)),
    }

    (OUTPUT_DIR / "calibration_report.json").write_text(
        json.dumps(report, indent=2, ensure_ascii=False),
        encoding="utf-8",
    )

    diagnostic = draw_diagnostics(image, selected_ids, selected, result)
    cv2.imwrite(str(OUTPUT_DIR / "calibration_diagnostics.png"), diagnostic)

    undistorted = cv2.undistort(image, K, dist, None, new_K)
    cv2.imwrite(str(OUTPUT_DIR / "calibration_undistorted.png"), undistorted)

    print("\nGespeichert in:", OUTPUT_DIR.resolve())
    print(" - camera_calibration.npz")
    print(" - camera_calibration.yaml")
    print(" - calibration_report.json")
    print(" - calibration_diagnostics.png")
    print(" - calibration_undistorted.png")


if __name__ == "__main__":
    main()
