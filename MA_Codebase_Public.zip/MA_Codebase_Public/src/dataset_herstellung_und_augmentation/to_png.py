#!/usr/bin/env python3
# -*- coding: utf-8 -*-

from __future__ import annotations
import os
from pathlib import Path
from concurrent.futures import ProcessPoolExecutor
import cv2
from PIL import Image, ImageOps

BASE_PATH = Path("/home/mitte/crack_project/datasets/better_dataset_evtl")
DELETE_ORIGINAL = False

IMAGE_EXTENSIONS = {".jpg", ".jpeg", ".tif", ".tiff", ".bmp", ".png", ".webp"}
PNG_COMPRESSION = 0
MAX_WORKERS = min(16, (os.cpu_count() or 1))


def _gather_files(folder_path: Path) -> list[Path]:
    return sorted(
        p for p in folder_path.iterdir()
        if p.is_file() and p.suffix.lower() in IMAGE_EXTENSIONS
    )


def _convert_image_with_exif_to_png(path_str: str, delete_original: bool) -> tuple[int, int, int]:
    """Für 'images': EXIF-Orientation einbacken."""
    p = Path(path_str)
    if p.suffix.lower() == ".png":
        return (0, 1, 0)

    try:
        with Image.open(p) as im:
            im = ImageOps.exif_transpose(im)  # <-- WICHTIG

            # zu RGB konvertieren (verhindert Probleme bei LA/RGBA/P)
            if im.mode in ("RGBA", "LA") or (im.mode == "P" and "transparency" in im.info):
                bg = Image.new("RGBA", im.size, (255, 255, 255, 255))
                im = Image.alpha_composite(bg, im.convert("RGBA")).convert("RGB")
            else:
                im = im.convert("RGB")

            out = p.with_suffix(".png")
            im.save(out, format="PNG", compress_level=PNG_COMPRESSION)

    except Exception:
        return (0, 0, 1)

    if delete_original:
        try:
            p.unlink()
        except Exception:
            pass

    return (1, 0, 0)


def _convert_mask_to_png(path_str: str, delete_original: bool) -> tuple[int, int, int]:
    """Für 'masks': KEIN EXIF transpose."""
    p = Path(path_str)
    if p.suffix.lower() == ".png":
        return (0, 1, 0)

    try:
        cv2.setNumThreads(1)
    except Exception:
        pass

    img = cv2.imread(str(p), cv2.IMREAD_UNCHANGED)
    if img is None:
        return (0, 0, 1)

    out = p.with_suffix(".png")
    ok = cv2.imwrite(str(out), img, [cv2.IMWRITE_PNG_COMPRESSION, PNG_COMPRESSION])
    if not ok:
        return (0, 0, 1)

    if delete_original:
        try:
            p.unlink()
        except Exception:
            pass

    return (1, 0, 0)


def _dispatch_convert(task: tuple[str, str, bool]) -> tuple[int, int, int]:
    """
    task: (path_str, kind, delete_original)
    kind: "images" oder "masks"
    """
    path_str, kind, delete_original = task
    if kind == "images":
        return _convert_image_with_exif_to_png(path_str, delete_original)
    else:
        return _convert_mask_to_png(path_str, delete_original)


def convert_folder_parallel(folder_path: Path, kind: str) -> None:
    if not folder_path.exists():
        print(f"⚠️ Ordner existiert nicht: {folder_path}")
        return

    files = _gather_files(folder_path)
    total = len(files)
    print(f"\n📂 Verarbeite Ordner: {folder_path} ({kind})")
    print(f"Gefundene Bilddateien: {total}")
    if total == 0:
        return

    tasks = [(str(p), kind, DELETE_ORIGINAL) for p in files]

    chunksize = 32 if total >= 100 else 8
    converted = skipped = failed = 0

    with ProcessPoolExecutor(max_workers=MAX_WORKERS) as ex:
        for c, s, f in ex.map(_dispatch_convert, tasks, chunksize=chunksize):
            converted += c
            skipped += s
            failed += f

    print("------ Ergebnis ------")
    print(f"Konvertiert: {converted}")
    print(f"Übersprungen (bereits PNG): {skipped}")
    print(f"Fehlgeschlagen: {failed}")


def main():
    images_dir = BASE_PATH / "images"
    masks_dir = BASE_PATH / "masks"

    print(f"MAX_WORKERS = {MAX_WORKERS} (os.cpu_count={os.cpu_count()})")

    convert_folder_parallel(images_dir, "images")
    convert_folder_parallel(masks_dir, "masks")

    print("\n✅ Alles fertig.")


if __name__ == "__main__":
    main()