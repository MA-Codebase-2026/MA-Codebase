#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Erzeugt eine kontrollierte Label-Noise-Variante des Better Datasets.

Experimentelles Prinzip:
- NUR train_512/masks wird veraendert.
- train_512/images wird unveraendert physisch in den neuen Datensatz kopiert.
- val_512 und test_512 werden ebenfalls unveraendert kopiert.
- Die Originaldaten werden niemals ueberschrieben.
- Jede Transformation wird pro Datei in CSV/JSON protokolliert.

Damit kann dieselbe Trainingsarchitektur fuer Referenz- und Noise-Datensaetze
verwendet werden, ohne dass Validation/Test durch Label-Noise kontaminiert werden.
"""

from __future__ import annotations

import csv
import hashlib
import json
import os
import random
import shutil
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path

import cv2
import numpy as np


# =============================================================================
# KONFIGURATION
# =============================================================================

SOURCE_DATASET = Path("/home/mitte/crack_project/datasets/better_dataset_evtl")
SEED = 42
MAX_WORKERS = min(16, os.cpu_count() or 1)
OVERWRITE_EXISTING_MASKS = True

MASK_EXTENSIONS = {".png"}

TRAIN_SPLIT = "train_512"
VAL_SPLIT = "val_512"
TEST_SPLIT = "test_512"


def deterministic_rng(path: Path) -> random.Random:
    """Dateispezifischer RNG, damit Ergebnisse unabhaengig von Dateireihenfolge reproduzierbar sind."""
    key = f"{SEED}|{path.name}".encode("utf-8")
    digest = hashlib.sha256(key).digest()
    local_seed = int.from_bytes(digest[:8], "little", signed=False)
    return random.Random(local_seed)


def read_binary_mask(path: Path) -> np.ndarray:
    mask = cv2.imread(str(path), cv2.IMREAD_GRAYSCALE)
    if mask is None:
        raise ValueError(f"Maske konnte nicht gelesen werden: {path}")
    return (mask > 127).astype(np.uint8)


def write_binary_mask(path: Path, mask: np.ndarray) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    data = (np.asarray(mask) > 0).astype(np.uint8) * 255
    if not cv2.imwrite(str(path), data):
        raise IOError(f"Maske konnte nicht gespeichert werden: {path}")


def copy_tree_contents(source_dir: Path, target_dir: Path) -> None:
    """Kopiert einen Verzeichnisbaum, ohne Quelldaten zu veraendern."""
    if not source_dir.is_dir():
        raise FileNotFoundError(f"Quellordner fehlt: {source_dir}")
    target_dir.mkdir(parents=True, exist_ok=True)
    shutil.copytree(
        source_dir,
        target_dir,
        dirs_exist_ok=True,
        copy_function=shutil.copy2,
    )


def prepare_output_dataset(output_dataset: Path) -> Path:
    """Erzeugt eine vollstaendig eigenstaendige Dataset-Struktur per Kopie."""
    source_train_images = SOURCE_DATASET / TRAIN_SPLIT / "images"
    source_train_masks = SOURCE_DATASET / TRAIN_SPLIT / "masks"
    source_val = SOURCE_DATASET / VAL_SPLIT
    source_test = SOURCE_DATASET / TEST_SPLIT

    for required in (source_train_images, source_train_masks, source_val, source_test):
        if not required.exists():
            raise FileNotFoundError(f"Erforderlicher Quellpfad fehlt: {required}")

    output_dataset.mkdir(parents=True, exist_ok=True)
    train_out = output_dataset / TRAIN_SPLIT
    train_images_out = train_out / "images"
    masks_out = train_out / "masks"

    # Trainingsbilder werden physisch kopiert.
    copy_tree_contents(source_train_images, train_images_out)

    # Validation und Test werden ebenfalls physisch kopiert und bleiben unveraendert.
    copy_tree_contents(source_val, output_dataset / VAL_SPLIT)
    copy_tree_contents(source_test, output_dataset / TEST_SPLIT)

    masks_out.mkdir(parents=True, exist_ok=True)
    return masks_out



def source_masks() -> list[Path]:
    mask_dir = SOURCE_DATASET / TRAIN_SPLIT / "masks"
    paths = sorted(
        p for p in mask_dir.iterdir()
        if p.is_file()
        and not p.name.startswith(".")
        and p.suffix.lower() in MASK_EXTENSIONS
    )
    if not paths:
        raise RuntimeError(f"Keine PNG-Masken gefunden in: {mask_dir}")
    return paths


def save_logs(
    output_dataset: Path,
    transformation_name: str,
    transformation_config: dict,
    rows: list[dict],
) -> None:
    manifest_path = output_dataset / "label_noise_manifest.csv"
    summary_path = output_dataset / "label_noise_summary.json"

    if not rows:
        raise RuntimeError("Keine Masken verarbeitet.")

    with manifest_path.open("w", encoding="utf-8", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
        writer.writeheader()
        writer.writerows(rows)

    before = sum(int(r["positive_pixels_before"]) for r in rows)
    after = sum(int(r["positive_pixels_after"]) for r in rows)

    summary = {
        "transformation": transformation_name,
        "seed": SEED,
        "source_dataset": str(SOURCE_DATASET),
        "output_dataset": str(output_dataset),
        "train_masks_modified": True,
        "train_images_modified": False,
        "validation_modified": False,
        "test_modified": False,
        "configuration": transformation_config,
        "number_of_masks": len(rows),
        "positive_pixels_before_total": before,
        "positive_pixels_after_total": after,
        "delta_positive_pixels_total": after - before,
    }

    with summary_path.open("w", encoding="utf-8") as f:
        json.dump(summary, f, indent=2, ensure_ascii=False)

    print(f"\nFertig: {len(rows)} Masken verarbeitet.")
    print(f"Output:   {output_dataset}")
    print(f"Manifest: {manifest_path}")
    print(f"Summary:  {summary_path}")

OUTPUT_DATASET = Path("/home/mitte/crack_project/datasets/better_dataset_labelnoise_translation_1to4px")

MIN_SHIFT_PX = 1
MAX_SHIFT_PX = 4

# Acht diskrete Richtungen: horizontal, vertikal und diagonal.
DIRECTIONS = [
    (-1, 0),
    (1, 0),
    (0, -1),
    (0, 1),
    (-1, -1),
    (-1, 1),
    (1, -1),
    (1, 1),
]


def transform_mask(mask: np.ndarray, source_path: Path) -> tuple[np.ndarray, int, int, int]:
    rng = deterministic_rng(source_path)

    magnitude = rng.randint(MIN_SHIFT_PX, MAX_SHIFT_PX)
    dir_x, dir_y = rng.choice(DIRECTIONS)

    dx = int(dir_x * magnitude)
    dy = int(dir_y * magnitude)

    height, width = mask.shape[:2]
    matrix = np.float32([
        [1.0, 0.0, float(dx)],
        [0.0, 1.0, float(dy)],
    ])

    shifted = cv2.warpAffine(
        mask.astype(np.uint8),
        matrix,
        dsize=(width, height),
        flags=cv2.INTER_NEAREST,
        borderMode=cv2.BORDER_CONSTANT,
        borderValue=0,
    )

    # warpAffine mit identischem dsize garantiert:
    # - fehlende Randpixel werden schwarz (0) aufgefuellt
    # - ueber den Bildrand verschobene Pixel werden abgeschnitten
    # - Ausgabegroesse bleibt exakt unveraendert.
    return (shifted > 0).astype(np.uint8), dx, dy, magnitude


def process_one_mask(source_path: Path, masks_out: Path) -> dict:
    mask = read_binary_mask(source_path)
    noisy, dx, dy, magnitude = transform_mask(mask, source_path)

    if noisy.shape != mask.shape:
        raise RuntimeError(
            f"Groesse hat sich unerwartet geaendert: {source_path.name} "
            f"{mask.shape} -> {noisy.shape}"
        )

    output_path = masks_out / source_path.name
    if output_path.exists() and not OVERWRITE_EXISTING_MASKS:
        raise FileExistsError(output_path)
    write_binary_mask(output_path, noisy)

    before = int(mask.sum())
    after = int(noisy.sum())
    return {
        "filename": source_path.name,
        "source_mask": str(source_path),
        "output_mask": str(output_path),
        "height": int(mask.shape[0]),
        "width": int(mask.shape[1]),
        "positive_pixels_before": before,
        "positive_pixels_after": after,
        "pixels_lost_at_image_border": max(0, before - after),
        "shift_dx_px": dx,
        "shift_dy_px": dy,
        "shift_magnitude_px": magnitude,
        "seed": SEED,
    }



def main() -> None:
    masks_out = prepare_output_dataset(OUTPUT_DATASET)
    rows = []

    paths = source_masks()
    with ThreadPoolExecutor(max_workers=MAX_WORKERS) as executor:
        futures = {
            executor.submit(process_one_mask, source_path, masks_out): source_path
            for source_path in paths
        }
        for index, future in enumerate(as_completed(futures), start=1):
            rows.append(future.result())
            if index % 500 == 0 or index == len(paths):
                print(f"Translation: {index}/{len(paths)} | Threads={MAX_WORKERS}", flush=True)

    rows.sort(key=lambda row: row["filename"])

    save_logs(
        OUTPUT_DATASET,
        transformation_name="spatial_misregistration_translation",
        transformation_config={
            "min_shift_px": MIN_SHIFT_PX,
            "max_shift_px": MAX_SHIFT_PX,
            "directions": "8-neighbour integer directions",
            "interpolation": "nearest",
            "border_fill": 0,
            "output_size": "identical to input",
            "seed": SEED,
        },
        rows=rows,
    )


if __name__ == "__main__":
    main()
