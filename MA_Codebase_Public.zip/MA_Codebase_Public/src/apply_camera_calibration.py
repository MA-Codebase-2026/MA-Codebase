#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Wendet eine zuvor gespeicherte Kalibrierung auf markerfreie Bilder an.
"""

from pathlib import Path
import cv2
import numpy as np


# =============================================================================
# BENUTZER-EINSTELLUNGEN
# =============================================================================

CALIBRATION_FILE = Path(r"C:\Pfad\zum\output\camera_calibration.npz")

# Einzelbild:
INPUT_IMAGE = Path(r"C:\Pfad\zum\bild_ohne_marker.jpg")
OUTPUT_IMAGE = Path(r"C:\Pfad\zum\output\bild_entzerrt.jpg")

# True: schwarze Randbereiche wegschneiden.
# False: volle von new_camera_matrix erzeugte Bildgröße behalten.
CROP_TO_ROI = True


def scaled_camera_matrix(K, old_size, new_size):
    """
    Skaliert K bei proportional geänderter Auflösung.
    Voraussetzung: gleicher Bildausschnitt / gleicher Crop-Modus / gleiches Seitenverhältnis.
    """
    old_w, old_h = map(float, old_size)
    new_w, new_h = map(float, new_size)

    sx = new_w / old_w
    sy = new_h / old_h

    if abs(sx - sy) > 1e-3:
        raise ValueError(
            "Die neue Auflösung hat nicht denselben Skalierungsfaktor in X und Y. "
            "Das deutet auf anderes Seitenverhältnis oder anderen Crop-Modus hin."
        )

    K2 = K.copy().astype(np.float64)
    K2[0, 0] *= sx
    K2[1, 1] *= sy
    K2[0, 2] *= sx
    K2[1, 2] *= sy
    return K2


def main():
    data = np.load(CALIBRATION_FILE)

    K = data["camera_matrix"].astype(np.float64)
    dist = data["dist_coeffs"].astype(np.float64)
    calib_w, calib_h = map(int, data["image_size"])

    image = cv2.imread(str(INPUT_IMAGE), cv2.IMREAD_COLOR)
    if image is None:
        raise FileNotFoundError(f"Bild konnte nicht geladen werden: {INPUT_IMAGE}")

    h, w = image.shape[:2]

    if (w, h) == (calib_w, calib_h):
        K_use = K
    else:
        K_use = scaled_camera_matrix(K, (calib_w, calib_h), (w, h))

    new_K, roi = cv2.getOptimalNewCameraMatrix(
        K_use,
        dist,
        (w, h),
        0.0,
        (w, h),
    )

    undistorted = cv2.undistort(image, K_use, dist, None, new_K)

    if CROP_TO_ROI:
        x, y, rw, rh = roi
        if rw > 0 and rh > 0:
            undistorted = undistorted[y:y + rh, x:x + rw]

    OUTPUT_IMAGE.parent.mkdir(parents=True, exist_ok=True)

    if not cv2.imwrite(str(OUTPUT_IMAGE), undistorted):
        raise RuntimeError(f"Bild konnte nicht gespeichert werden: {OUTPUT_IMAGE}")

    print("Entzerrtes Bild gespeichert:", OUTPUT_IMAGE.resolve())


if __name__ == "__main__":
    main()
