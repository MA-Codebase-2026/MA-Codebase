#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Bewertet genau ein frei gewähltes Segmentierungsmodell auf dem passenden Test-Dataset.

Der Modellpfad, die Bildgröße und der Threshold werden direkt im Einstellungsblock
angegeben. Die Ergebnisse werden ausschließlich in einem eigenen Unterordner für
dieses Modell als TXT und JSON gespeichert.
"""

import os
import gc
import json
import random
from pathlib import Path

import numpy as np
import tensorflow as tf
from keras import mixed_precision


# ============================================================
# EINSTELLUNGEN
# ============================================================

# Pfad zu genau dem Modell, das getestet werden soll.
MODEL_PATH = Path(
    "/home/mitte/crack_project/outputs/"
    "unetpp_512px_f8-128_DeepSupervision_BetterDataset/models/"
    "unetpp_512px_f8-128_DeepSupervision_BetterDataset_best_inference_x0_4.keras"
)

# Frei wählbarer Name für diesen Testlauf.
# Bei None wird automatisch der Dateiname des Modells verwendet.
MODEL_NAME = None

# Zum Modell passende Eingabegröße.
IMG_SIZE = 512

# Der für dieses Modell ermittelte beste Threshold.
THRESHOLD = 0.1

# Root des unabhängigen Test-Datasets.
# Darunter wird test_256, test_512 oder test_1024 mit images/ und masks/ erwartet.
TEST_DATASET_DIR = Path(
    "/home/mitte/crack_project/datasets/better_dataset_evtl"
)

# Übergeordneter Ergebnisordner.
# Darin wird automatisch ein eigener Unterordner für das Modell angelegt.
EVALUATION_ROOT = Path(
    "/home/mitte/crack_project/modellmetrics_einzelmodelle"
)

# Optional Hard Negatives des passenden Test-Splits mit auswerten.
INCLUDE_HARD_NEGATIVES = False

DEFAULT_BATCH_SIZE = 8
BATCH_SIZE_1024 = 2
SEED = 42

# None = vollständiges Testset.
# Eine ganze Zahl begrenzt die Anzahl ausgewerteter Batches.
TEST_STEPS = 1000

# Modell-Dateien mit diesen Endungen werden akzeptiert.
MODEL_SUFFIXES = {".keras", ".h5", ".hdf5"}

# Metrik-Einstellungen, identisch zum bisherigen Auswertungsskript.
MAP_THRESHOLDS = np.arange(0.50, 1.00, 0.05)
AP_THRESHOLDS = np.linspace(1.0, 0.0, 101)


def sanitize_name(name: str) -> str:
    """Erzeugt einen sicheren Ordner- und Dateinamen."""
    cleaned = "".join(
        character if character.isalnum() or character in "-_." else "_"
        for character in name
    )
    return cleaned.strip("._") or "modell"


def get_model_name() -> str:
    if MODEL_NAME is not None and str(MODEL_NAME).strip():
        return sanitize_name(str(MODEL_NAME))
    return sanitize_name(MODEL_PATH.stem)


def get_batch_size() -> int:
    return BATCH_SIZE_1024 if IMG_SIZE == 1024 else DEFAULT_BATCH_SIZE


# ============================================================
# REPRODUZIERBARKEIT / TENSORFLOW
# ============================================================

os.environ["PYTHONHASHSEED"] = str(SEED)
os.environ["TF_GPU_ALLOCATOR"] = "cuda_malloc_async"
os.environ["KERAS_BACKEND"] = "tensorflow"

random.seed(SEED)
np.random.seed(SEED)
tf.random.set_seed(SEED)

tf.config.optimizer.set_jit(False)

policy = mixed_precision.Policy("mixed_float16")
mixed_precision.set_global_policy(policy)


# ============================================================
# DATEN LADEN
# ============================================================

def get_valid_pairs(images_dir: Path, masks_dir: Path):
    """
    Findet Bild-Masken-Paare über den gleichen Dateinamen ohne Endung.
    """
    if not images_dir.exists():
        return [], []

    if not masks_dir.exists():
        return [], []

    img_paths = sorted(
        [
            p for p in images_dir.glob("*")
            if p.is_file() and not p.name.startswith(".")
        ]
    )

    mask_map = {
        p.stem.lower(): p
        for p in masks_dir.glob("*")
        if p.is_file() and not p.name.startswith(".")
    }

    valid_imgs = []
    valid_masks = []

    for img_path in img_paths:
        image_stem = img_path.stem.lower()

        if image_stem in mask_map:
            valid_imgs.append(str(img_path))
            valid_masks.append(str(mask_map[image_stem]))

    return valid_imgs, valid_masks


def load_and_preprocess(img_path, mask_path, img_size: int):
    """Lädt RGB-Bild und binäre Maske für die angegebene Patchgröße."""
    img = tf.io.read_file(img_path)
    img = tf.image.decode_png(img, channels=3)
    img = tf.image.convert_image_dtype(img, tf.float32)
    img.set_shape([img_size, img_size, 3])

    mask = tf.io.read_file(mask_path)
    mask = tf.image.decode_png(mask, channels=1)
    mask = tf.cast(mask > 127, tf.float32)
    mask.set_shape([img_size, img_size, 1])

    return img, mask


def get_test_dataset(img_size: int, batch_size: int):
    """Erstellt das zu ``img_size`` passende Testset (test_256/512/1024)."""
    split_name = f"test_{img_size}"
    base_test_dir = TEST_DATASET_DIR / split_name

    image_paths, mask_paths = get_valid_pairs(
        base_test_dir / "images",
        base_test_dir / "masks",
    )

    if INCLUDE_HARD_NEGATIVES:
        hn_images, hn_masks = get_valid_pairs(
            base_test_dir / f"images_{img_size}px_hard_negatives",
            base_test_dir / f"masks_{img_size}px_hard_negatives",
        )
        image_paths.extend(hn_images)
        mask_paths.extend(hn_masks)

    if not image_paths:
        raise RuntimeError(
            f"Keine passenden Bild-Masken-Paare gefunden.\n"
            f"Erwartet wurde:\n{base_test_dir / 'images'}\n"
            f"und\n{base_test_dir / 'masks'}"
        )

    def _loader(img_path, mask_path):
        return load_and_preprocess(img_path, mask_path, img_size)

    ds = tf.data.Dataset.from_tensor_slices((image_paths, mask_paths))
    ds = ds.map(_loader, num_parallel_calls=tf.data.AUTOTUNE)
    ds = ds.batch(batch_size)
    ds = ds.prefetch(tf.data.AUTOTUNE)

    return ds, len(image_paths), split_name


# ============================================================
# METRIKEN
# ============================================================

def dice_coef_soft(y_true, y_pred, smooth=1e-7):
    y_true = tf.cast(y_true, tf.float32)
    y_pred = tf.cast(y_pred, tf.float32)

    intersection = tf.reduce_sum(y_true * y_pred, axis=[1, 2, 3])
    union = tf.reduce_sum(y_true + y_pred, axis=[1, 2, 3])

    return tf.reduce_mean(
        (2.0 * intersection + smooth) / (union + smooth)
    )


def dice_loss(y_true, y_pred):
    return 1.0 - dice_coef_soft(y_true, y_pred)


def safe_div(numerator, denominator, eps=1e-7):
    return float((numerator + eps) / (denominator + eps))


def compute_confusion_from_binary(y_true_bin, y_pred_bin):
    y_true_bool = y_true_bin.astype(bool)
    y_pred_bool = y_pred_bin.astype(bool)

    tp = np.logical_and(y_true_bool, y_pred_bool).sum()
    fp = np.logical_and(~y_true_bool, y_pred_bool).sum()
    fn = np.logical_and(y_true_bool, ~y_pred_bool).sum()
    tn = np.logical_and(~y_true_bool, ~y_pred_bool).sum()

    return tp, fp, fn, tn


def compute_fg_metrics_from_confusion(tp, fp, fn, tn):
    precision = safe_div(tp, tp + fp)
    recall = safe_div(tp, tp + fn)
    dice = safe_div(2 * tp, 2 * tp + fp + fn)
    iou = safe_div(tp, tp + fp + fn)
    f1 = safe_div(2 * precision * recall, precision + recall)
    accuracy = safe_div(tp + tn, tp + tn + fp + fn) * 100.0

    return {
        "precision_fg": precision,
        "recall_fg": recall,
        "dice_fg": dice,
        "iou_fg": iou,
        "f1_fg": f1,
        "accuracy_percent": accuracy,
    }


def update_threshold_confusions(
    y_true_bin,
    y_pred_prob,
    thresholds,
    tp_values,
    fp_values,
    fn_values,
):
    for idx, threshold in enumerate(thresholds):
        y_pred_bin = (y_pred_prob >= threshold).astype(np.uint8)

        batch_tp, batch_fp, batch_fn, _ = compute_confusion_from_binary(
            y_true_bin,
            y_pred_bin,
        )

        tp_values[idx] += batch_tp
        fp_values[idx] += batch_fp
        fn_values[idx] += batch_fn


def compute_map_from_threshold_confusions(tp_values, fp_values):
    precisions = [
        safe_div(tp, tp + fp)
        for tp, fp in zip(tp_values, fp_values)
    ]

    return float(np.mean(precisions))


def compute_ap_from_threshold_confusions(tp_values, fp_values, fn_values):
    total_positives = float(np.max(tp_values + fn_values))

    if total_positives == 0:
        return float("nan")

    predicted_positives = tp_values + fp_values

    precision = np.divide(
        tp_values,
        predicted_positives,
        out=np.ones_like(tp_values, dtype=np.float64),
        where=predicted_positives > 0,
    )

    recall = tp_values / total_positives

    order = np.argsort(recall)
    recall = recall[order]
    precision = precision[order]

    recall = np.concatenate(([0.0], recall, [1.0]))
    precision = np.concatenate(
        ([precision[0] if precision.size else 0.0], precision, [0.0])
    )

    for idx in range(precision.size - 2, -1, -1):
        precision[idx] = max(precision[idx], precision[idx + 1])

    return float(
        np.sum((recall[1:] - recall[:-1]) * precision[1:])
    )


# ============================================================
# TEST-EVALUATION
# ============================================================

def evaluate_model_on_testset(model, test_ds, threshold: float):
    """
    Berechnet dieselben Metriken wie dein ValidationMetricsLogger.
    """
    total_loss = 0.0
    total_dice_soft = 0.0
    total_mse = 0.0
    total_samples = 0

    tp_total = 0
    fp_total = 0
    fn_total = 0
    tn_total = 0

    map_tp = np.zeros(len(MAP_THRESHOLDS), dtype=np.float64)
    map_fp = np.zeros(len(MAP_THRESHOLDS), dtype=np.float64)
    map_fn = np.zeros(len(MAP_THRESHOLDS), dtype=np.float64)

    ap_tp = np.zeros(len(AP_THRESHOLDS), dtype=np.float64)
    ap_fp = np.zeros(len(AP_THRESHOLDS), dtype=np.float64)
    ap_fn = np.zeros(len(AP_THRESHOLDS), dtype=np.float64)

    auc_roc_metric = tf.keras.metrics.AUC(curve="ROC")
    auc_pr_metric = tf.keras.metrics.AUC(curve="PR")

    evaluation_ds = test_ds if TEST_STEPS is None else test_ds.take(TEST_STEPS)

    for batch_index, (images, masks) in enumerate(
        evaluation_ds,
        start=1,
    ):
        predictions = model(images, training=False)

        batch_size = int(images.shape[0])

        if batch_size == 0:
            continue

        predictions_np = predictions.numpy().astype(np.float32)
        masks_np = masks.numpy().astype(np.float32)

        y_true_bin = (masks_np >= 0.5).astype(np.uint8)
        y_pred_bin = (predictions_np >= threshold).astype(np.uint8)

        batch_loss = float(
            tf.reduce_mean(dice_loss(masks, predictions)).numpy()
        )

        batch_dice_soft = float(
            dice_coef_soft(masks, predictions).numpy()
        )

        batch_mse = float(
            np.mean((predictions_np - masks_np) ** 2)
        )

        total_loss += batch_loss * batch_size
        total_dice_soft += batch_dice_soft * batch_size
        total_mse += batch_mse * batch_size
        total_samples += batch_size

        tp, fp, fn, tn = compute_confusion_from_binary(
            y_true_bin,
            y_pred_bin,
        )

        tp_total += tp
        fp_total += fp
        fn_total += fn
        tn_total += tn

        auc_roc_metric.update_state(
            masks_np.reshape(-1),
            predictions_np.reshape(-1),
        )

        auc_pr_metric.update_state(
            masks_np.reshape(-1),
            predictions_np.reshape(-1),
        )

        update_threshold_confusions(
            y_true_bin,
            predictions_np,
            MAP_THRESHOLDS,
            map_tp,
            map_fp,
            map_fn,
        )

        update_threshold_confusions(
            y_true_bin,
            predictions_np,
            AP_THRESHOLDS,
            ap_tp,
            ap_fp,
            ap_fn,
        )

        print(
            f"\r  Batch {batch_index}",
            end="",
            flush=True,
        )

    print()

    if total_samples == 0:
        raise RuntimeError("Das Testset enthält keine auswertbaren Bilder.")

    fg_metrics = compute_fg_metrics_from_confusion(
        tp_total,
        fp_total,
        fn_total,
        tn_total,
    )

    return {
        "test_loss": total_loss / total_samples,
        "test_dice_soft": total_dice_soft / total_samples,
        "test_dice_fg": fg_metrics["dice_fg"],
        "test_iou_fg": fg_metrics["iou_fg"],
        "test_precision_fg": fg_metrics["precision_fg"],
        "test_recall_fg": fg_metrics["recall_fg"],
        "test_f1_fg": fg_metrics["f1_fg"],
        "test_accuracy_pct": fg_metrics["accuracy_percent"],
        "test_mse": total_mse / total_samples,
        "test_auc_roc": float(auc_roc_metric.result().numpy()),
        "test_auc_pr": float(auc_pr_metric.result().numpy()),
        "test_ap": compute_ap_from_threshold_confusions(
            ap_tp,
            ap_fp,
            ap_fn,
        ),
        "test_map": compute_map_from_threshold_confusions(
            map_tp,
            map_fp,
        ),
        "tp": int(tp_total),
        "fp": int(fp_total),
        "fn": int(fn_total),
        "tn": int(tn_total),
        "test_samples": int(total_samples),
    }


# ============================================================
# ERGEBNISSE SPEICHERN
# ============================================================

RESULT_FIELDS = [
    "model_name",
    "model_path",
    "img_size",
    "batch_size",
    "threshold",
    "test_split",
    "test_samples",
    "test_loss",
    "test_dice_soft",
    "test_dice_fg",
    "test_iou_fg",
    "test_precision_fg",
    "test_recall_fg",
    "test_f1_fg",
    "test_accuracy_pct",
    "test_mse",
    "test_auc_roc",
    "test_auc_pr",
    "test_ap",
    "test_map",
    "tp",
    "fp",
    "fn",
    "tn",
]


def save_result(result: dict, result_dir: Path):
    """Speichert die Auswertung des einzelnen Modells als TXT und JSON."""
    result_dir.mkdir(parents=True, exist_ok=True)

    model_name = result["model_name"]
    txt_path = result_dir / f"{model_name}_test_metrics.txt"
    json_path = result_dir / f"{model_name}_test_metrics.json"

    with txt_path.open("w", encoding="utf-8") as file:
        file.write("=" * 100 + "\n")
        file.write("TEST-AUSWERTUNG EINES EINZELNEN MODELLS\n")
        file.write("=" * 100 + "\n")
        file.write(f"Modellname: {result['model_name']}\n")
        file.write(f"Modellpfad: {result['model_path']}\n")
        file.write(f"Test-Dataset: {TEST_DATASET_DIR / result['test_split']}\n")
        file.write(f"Bildgröße: {result['img_size']} x {result['img_size']} px\n")
        file.write(f"Batchgröße: {result['batch_size']}\n")
        file.write(f"Threshold: {result['threshold']}\n")
        file.write(f"Hard Negatives enthalten: {INCLUDE_HARD_NEGATIVES}\n")
        file.write(f"Anzahl Testbilder: {result['test_samples']}\n")
        file.write("=" * 100 + "\n")

        for field in RESULT_FIELDS:
            if field not in result or field in {
                "model_name",
                "model_path",
                "img_size",
                "batch_size",
                "threshold",
                "test_split",
            }:
                continue

            value = result[field]
            if isinstance(value, float):
                file.write(f"{field}: {value:.8f}\n")
            else:
                file.write(f"{field}: {value}\n")

    with json_path.open("w", encoding="utf-8") as file:
        json.dump(result, file, indent=2, ensure_ascii=False)

    return txt_path, json_path


# ============================================================
# MAIN
# ============================================================

def validate_settings():
    if not MODEL_PATH.exists():
        raise FileNotFoundError(f"Modell nicht gefunden: {MODEL_PATH}")

    if MODEL_PATH.suffix.lower() not in MODEL_SUFFIXES:
        raise ValueError(
            f"Nicht unterstütztes Modellformat: {MODEL_PATH.suffix}\n"
            f"Erlaubt sind: {sorted(MODEL_SUFFIXES)}"
        )

    if IMG_SIZE not in {256, 512, 1024}:
        raise ValueError("IMG_SIZE muss 256, 512 oder 1024 sein.")

    if not 0.0 <= THRESHOLD <= 1.0:
        raise ValueError("THRESHOLD muss zwischen 0 und 1 liegen.")

    if TEST_STEPS is not None and TEST_STEPS <= 0:
        raise ValueError("TEST_STEPS muss None oder eine positive ganze Zahl sein.")


def main():
    validate_settings()

    gpus = tf.config.list_physical_devices("GPU")
    if gpus:
        for gpu in gpus:
            tf.config.experimental.set_memory_growth(gpu, True)

    model_name = get_model_name()
    batch_size = get_batch_size()
    result_dir = EVALUATION_ROOT / model_name

    print("=" * 100)
    print("TEST-AUSWERTUNG EINES EINZELNEN MODELLS")
    print("=" * 100)
    print(f"Modellname:       {model_name}")
    print(f"Modellpfad:       {MODEL_PATH}")
    print(f"IMG_SIZE:         {IMG_SIZE}")
    print(f"Batchgröße:       {batch_size}")
    print(f"Threshold:        {THRESHOLD}")
    print(f"Test dataset:     {TEST_DATASET_DIR}")
    print(f"Ergebnisordner:   {result_dir}")
    print(f"Test-Batches:     {'vollständig' if TEST_STEPS is None else TEST_STEPS}")
    print("=" * 100)

    test_ds, test_count, test_split = get_test_dataset(
        img_size=IMG_SIZE,
        batch_size=batch_size,
    )
    print(f"Test-Split: {test_split} | Gefundene Testbilder: {test_count}")

    tf.keras.backend.clear_session()
    gc.collect()

    model = tf.keras.models.load_model(
        MODEL_PATH,
        compile=False,
    )

    test_metrics = evaluate_model_on_testset(
        model=model,
        test_ds=test_ds,
        threshold=THRESHOLD,
    )

    result = {
        "model_name": model_name,
        "model_path": str(MODEL_PATH),
        "img_size": IMG_SIZE,
        "batch_size": batch_size,
        "threshold": THRESHOLD,
        "test_split": test_split,
        **test_metrics,
    }

    txt_path, json_path = save_result(
        result=result,
        result_dir=result_dir,
    )

    print("\n" + "=" * 100)
    print("TEST-AUSWERTUNG ABGESCHLOSSEN")
    print("=" * 100)
    print(f"Test Dice: {result['test_dice_fg']:.6f}")
    print(f"Test IoU:  {result['test_iou_fg']:.6f}")
    print(f"Precision: {result['test_precision_fg']:.6f}")
    print(f"Recall:    {result['test_recall_fg']:.6f}")
    print(f"TXT:       {txt_path}")
    print(f"JSON:      {json_path}")

    del model
    tf.keras.backend.clear_session()
    gc.collect()


if __name__ == "__main__":
    main()
