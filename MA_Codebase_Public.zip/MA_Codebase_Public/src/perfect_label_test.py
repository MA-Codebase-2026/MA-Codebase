#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Auswertung der Best-Epoch-Modelle auf zwei perfekt gelabelten Bildern.

Erwartete Eingabestruktur (Dateiendungen duerfen abweichen):

    crack_project/datasets/perfect_label_test/
    ├── images/
    │   ├── bild_512.png
    │   └── bild_gross.png
    └── masks/
        ├── bild_512.png
        └── bild_gross.png

Das grosse Bild wird mit 512x512-Patches und ueberlappender, gewichteter
Rueckmontage verarbeitet. Fuer jeden Trainingslauf wird das Modell aus der
best_epoch geladen. Die Ergebnisse landen in:

    crack_project/outputs/RUNNAME/perfect_labels_test/

Pro Bild werden Prediction-Maske, FP/FN-Farbmaske und FP/FN-Overlay gespeichert.
Zusaetzlich entstehen genau zwei Metrik-TXT-Dateien: einmal ueber alle Pixel und
einmal in der gesampelten BALANCED CRACK ROI (alle positiven Pixel plus gleich
viele negative Pixel, bevorzugt aus dem rissnahen Ring).
"""

from __future__ import annotations

import argparse
import gc
import json
import math
import re
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path
from typing import Any, Iterable

import cv2
import numpy as np
import tensorflow as tf


# =============================================================================
# KONFIGURATION
# =============================================================================

PROJECT_ROOT = Path("/home/mitte/crack_project")
OUTPUT_ROOT = PROJECT_ROOT / "outputs"
INPUT_DIR = PROJECT_ROOT / "datasets" / "perfect_label"

PATCH_SIZE = 512
OVERLAP = 64
INFERENCE_BATCH_SIZE = 8
CRACK_CLASS_INDEX = 1
GROUND_TRUTH_THRESHOLD = 127
OVERLAY_ALPHA = 0.70

ROI_RING_RADIUS_PX = 10
ROI_NEGATIVE_TO_POSITIVE_RATIO = 1.0
ROI_RANDOM_SEED = 42

AP_THRESHOLDS = np.linspace(1.0, 0.0, 101, dtype=np.float64)
MODEL_SUFFIXES = {".keras", ".h5", ".hdf5"}
IMAGE_SUFFIXES = {".png", ".jpg", ".jpeg", ".tif", ".tiff", ".bmp"}
EPS = 1e-7


# =============================================================================
# CUSTOM OBJECTS / MODELL LADEN
# =============================================================================

@tf.keras.utils.register_keras_serializable(package="crack_segmentation")
class AddPositionEmbedding(tf.keras.layers.Layer):
    def __init__(self, num_tokens: int, embed_dim: int, **kwargs: Any):
        super().__init__(**kwargs)
        self.num_tokens = int(num_tokens)
        self.embed_dim = int(embed_dim)

    def build(self, input_shape: Any) -> None:
        self.pos_embedding = self.add_weight(
            name="pos_embedding",
            shape=(1, self.num_tokens, self.embed_dim),
            initializer="random_normal",
            trainable=True,
            dtype=self.dtype,
        )
        super().build(input_shape)

    def call(self, x: tf.Tensor) -> tf.Tensor:
        return x + tf.cast(self.pos_embedding, x.dtype)

    def get_config(self) -> dict[str, Any]:
        config = super().get_config()
        config.update({"num_tokens": self.num_tokens, "embed_dim": self.embed_dim})
        return config


CUSTOM_OBJECTS = {
    "AddPositionEmbedding": AddPositionEmbedding,
    "crack_segmentation>AddPositionEmbedding": AddPositionEmbedding,
}


def load_model(model_path: Path) -> tf.keras.Model:
    try:
        return tf.keras.models.load_model(
            str(model_path), compile=False, custom_objects=CUSTOM_OBJECTS
        )
    except TypeError:
        return tf.keras.models.load_model(
            str(model_path),
            compile=False,
            safe_mode=False,
            custom_objects=CUSTOM_OBJECTS,
        )


# =============================================================================
# RUN- UND DATEI-ERKENNUNG
# =============================================================================

@dataclass(frozen=True)
class RunRecord:
    run_name: str
    run_dir: Path
    model_path: Path
    best_epoch: int
    threshold: float
    metrics_source: Path
    threshold_source: Path | None


@dataclass(frozen=True)
class ImagePair:
    image_path: Path
    mask_path: Path


def recursive_find_key(data: Any, wanted: set[str]) -> Any | None:
    if isinstance(data, dict):
        for key, value in data.items():
            if str(key).strip().casefold() in wanted and not isinstance(value, (dict, list)):
                return value
        for value in data.values():
            found = recursive_find_key(value, wanted)
            if found is not None:
                return found
    elif isinstance(data, list):
        for value in data:
            found = recursive_find_key(value, wanted)
            if found is not None:
                return found
    return None


def read_best_epoch(run_dir: Path) -> tuple[int, Path]:
    metrics_dir = run_dir / "metrics"
    if not metrics_dir.is_dir():
        raise FileNotFoundError(f"metrics-Ordner fehlt: {metrics_dir}")

    for path in sorted(metrics_dir.glob("*.json")):
        try:
            data = json.loads(path.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError):
            continue
        value = recursive_find_key(data, {"best_epoch", "best epoch", "beste_epoche"})
        try:
            epoch = int(round(float(value)))
        except (TypeError, ValueError):
            continue
        if epoch >= 1:
            return epoch, path

    patterns = (
        r"Best\s*epoch\s*[:=]\s*(\d+)",
        r"Beste\s*Epoche\s*[:=]\s*(\d+)",
    )
    for path in sorted(metrics_dir.glob("*.txt")):
        text = path.read_text(encoding="utf-8", errors="replace")
        for pattern in patterns:
            match = re.search(pattern, text, re.IGNORECASE)
            if match:
                return int(match.group(1)), path

    raise FileNotFoundError(f"Keine best_epoch in {metrics_dir} gefunden.")


def find_model_for_epoch(run_dir: Path, best_epoch: int) -> Path:
    models_dir = run_dir / "models"
    if not models_dir.is_dir():
        raise FileNotFoundError(f"models-Ordner fehlt: {models_dir}")
    candidates = sorted(
        p for p in models_dir.iterdir()
        if p.is_file() and p.suffix.lower() in MODEL_SUFFIXES
    )
    pattern = re.compile(
        rf"(?:epoche|epoch)[_ -]*0*{int(best_epoch)}(?!\d)", re.IGNORECASE
    )
    matches = [path for path in candidates if pattern.search(path.stem)]
    if not matches:
        raise FileNotFoundError(
            f"Kein Modell fuer best_epoch={best_epoch} in {models_dir} gefunden."
        )
    if len(matches) > 1:
        exact_names = {
            f"{run_dir.name}_Epoche{best_epoch}".casefold(),
            f"{run_dir.name}_epoch{best_epoch}".casefold(),
        }
        exact = [path for path in matches if path.stem.casefold() in exact_names]
        if len(exact) == 1:
            return exact[0]
        raise RuntimeError(
            f"Mehrere Modelle fuer best_epoch={best_epoch} gefunden: "
            + ", ".join(path.name for path in matches)
        )
    return matches[0]


def parse_threshold_from_text(text: str) -> float | None:
    patterns = (
        r"ROI\s+minimaler\s+Balanced\s+Error\s*:\s*Threshold\s*=\s*([0-9.eE+-]+)",
        r"best[_ ]threshold\s*[:=]\s*([0-9.eE+-]+)",
        r"(?:segmentierungs|segmentation)[_ -]?threshold\s*[:=]\s*([0-9.eE+-]+)",
    )
    for pattern in patterns:
        match = re.search(pattern, text, re.IGNORECASE)
        if match:
            value = float(match.group(1))
            if 0.0 <= value <= 1.0:
                return value
    return None


def read_threshold(run_dir: Path) -> tuple[float, Path | None]:
    threshold_dir = run_dir / "threshold_results2"
    if threshold_dir.is_dir():
        for path in sorted(threshold_dir.glob("*.txt")):
            value = parse_threshold_from_text(
                path.read_text(encoding="utf-8", errors="replace")
            )
            if value is not None:
                return value, path
        for path in sorted(threshold_dir.glob("*.json")):
            try:
                data = json.loads(path.read_text(encoding="utf-8"))
            except (OSError, json.JSONDecodeError):
                continue
            raw = recursive_find_key(
                data,
                {
                    "roi_balanced_error_threshold",
                    "best_threshold",
                    "segmentation_threshold",
                    "threshold",
                },
            )
            try:
                value = float(raw)
            except (TypeError, ValueError):
                continue
            if 0.0 <= value <= 1.0:
                return value, path

    print(f"  [WARNUNG] Kein Run-Threshold fuer {run_dir.name}; Fallback 0.5 wird verwendet.")
    return 0.5, None


def discover_runs(output_root: Path, selected_runs: set[str] | None) -> list[RunRecord]:
    if not output_root.is_dir():
        raise FileNotFoundError(f"OUTPUT_ROOT existiert nicht: {output_root}")
    records: list[RunRecord] = []
    for run_dir in sorted(output_root.iterdir()):
        if not run_dir.is_dir() or run_dir.name.startswith("_"):
            continue
        if selected_runs and run_dir.name not in selected_runs:
            continue
        try:
            best_epoch, metrics_source = read_best_epoch(run_dir)
            model_path = find_model_for_epoch(run_dir, best_epoch)
            threshold, threshold_source = read_threshold(run_dir)
            records.append(
                RunRecord(
                    run_name=run_dir.name,
                    run_dir=run_dir,
                    model_path=model_path,
                    best_epoch=best_epoch,
                    threshold=threshold,
                    metrics_source=metrics_source,
                    threshold_source=threshold_source,
                )
            )
        except Exception as exc:
            print(f"[UEBERSPRUNGEN] {run_dir.name}: {exc}")
    if selected_runs:
        found = {record.run_name for record in records}
        missing = sorted(selected_runs - found)
        if missing:
            print("[WARNUNG] Nicht auswertbare/fehlende Runs: " + ", ".join(missing))
    return records


def normalize_stem(stem: str) -> str:
    value = stem.casefold()
    for suffix in ("_mask", "-mask", "_label", "-label", "_gt", "-gt"):
        if value.endswith(suffix):
            value = value[:-len(suffix)]
            break
    return value


def discover_image_pairs(input_dir: Path) -> list[ImagePair]:
    image_dir = input_dir / "images" if (input_dir / "images").is_dir() else input_dir
    mask_dir = next(
        (path for path in (input_dir / "masks", input_dir / "labels", input_dir / "ground_truth") if path.is_dir()),
        None,
    )
    if mask_dir is None:
        raise FileNotFoundError(
            f"Kein masks-, labels- oder ground_truth-Unterordner in {input_dir}."
        )

    images = sorted(
        path for path in image_dir.iterdir()
        if path.is_file() and path.suffix.lower() in IMAGE_SUFFIXES
    )
    masks = {
        normalize_stem(path.stem): path
        for path in sorted(mask_dir.iterdir())
        if path.is_file() and path.suffix.lower() in IMAGE_SUFFIXES
    }
    pairs = [
        ImagePair(image, masks[normalize_stem(image.stem)])
        for image in images
        if normalize_stem(image.stem) in masks
    ]
    if not pairs:
        raise RuntimeError(
            f"Keine Bild-/Maskenpaare gefunden: images={image_dir}, masks={mask_dir}."
        )
    if len(pairs) != 2:
        print(f"[WARNUNG] Erwartet waren 2 Bild-/Maskenpaare, gefunden wurden {len(pairs)}.")
    return pairs


# =============================================================================
# PATCH-INFERENZ
# =============================================================================

def model_input_spec(model: tf.keras.Model) -> tuple[int, int, int]:
    shape = model.input_shape
    if isinstance(shape, list):
        if len(shape) != 1:
            raise ValueError(f"Mehrere Modelleingaenge werden nicht unterstuetzt: {shape}")
        shape = shape[0]
    if len(shape) != 4:
        raise ValueError(f"Unerwarteter Modelleingang: {shape}")
    height = int(shape[1]) if shape[1] is not None else PATCH_SIZE
    width = int(shape[2]) if shape[2] is not None else PATCH_SIZE
    channels = int(shape[3]) if shape[3] is not None else 3
    if channels not in (1, 3):
        raise ValueError(f"Nur 1 oder 3 Eingangskanaele werden unterstuetzt: {shape}")
    return height, width, channels


def patch_positions(length: int, patch_size: int, stride: int) -> list[int]:
    if length <= patch_size:
        return [0]
    positions = list(range(0, length - patch_size + 1, stride))
    last = length - patch_size
    if positions[-1] != last:
        positions.append(last)
    return positions


def weight_map(size: int) -> np.ndarray:
    coords = np.linspace(-1.0, 1.0, size, dtype=np.float32)
    one_dimensional = 1.0 - np.abs(coords)
    return np.clip(np.outer(one_dimensional, one_dimensional), 1e-3, None)


def sigmoid(values: np.ndarray) -> np.ndarray:
    clipped = np.clip(values, -60.0, 60.0)
    return 1.0 / (1.0 + np.exp(-clipped))


def softmax(values: np.ndarray) -> np.ndarray:
    shifted = values - np.max(values, axis=-1, keepdims=True)
    exp_values = np.exp(shifted)
    return exp_values / np.maximum(np.sum(exp_values, axis=-1, keepdims=True), EPS)


def normalize_prediction(prediction: Any, output_size: int) -> np.ndarray:
    if isinstance(prediction, dict):
        prediction = next(iter(prediction.values()))
    if isinstance(prediction, (list, tuple)):
        prediction = prediction[0]
    array = np.asarray(prediction)
    if array.ndim == 3:
        probabilities = array
        if probabilities.min() < 0.0 or probabilities.max() > 1.0:
            probabilities = sigmoid(probabilities)
    elif array.ndim == 4 and array.shape[-1] == 1:
        probabilities = array[..., 0]
        if probabilities.min() < 0.0 or probabilities.max() > 1.0:
            probabilities = sigmoid(probabilities)
    elif array.ndim == 4 and array.shape[-1] > 1:
        sums = np.sum(array, axis=-1)
        looks_like_probability = (
            array.min() >= 0.0
            and array.max() <= 1.0
            and np.allclose(sums, 1.0, atol=1e-3)
        )
        all_probabilities = array if looks_like_probability else softmax(array)
        if not 0 <= CRACK_CLASS_INDEX < array.shape[-1]:
            raise IndexError(
                f"CRACK_CLASS_INDEX={CRACK_CLASS_INDEX} passt nicht zur Ausgabe {array.shape}."
            )
        probabilities = all_probabilities[..., CRACK_CLASS_INDEX]
    else:
        raise ValueError(f"Unerwartete Modellausgabe: {array.shape}")

    probabilities = np.asarray(probabilities, dtype=np.float32)
    if probabilities.shape[1:3] != (output_size, output_size):
        resized = np.empty((probabilities.shape[0], output_size, output_size), np.float32)
        for index, probability in enumerate(probabilities):
            resized[index] = cv2.resize(
                probability, (output_size, output_size), interpolation=cv2.INTER_LINEAR
            )
        probabilities = resized
    return np.clip(probabilities, 0.0, 1.0)


def prepare_patch(patch_rgb: np.ndarray, input_spec: tuple[int, int, int]) -> np.ndarray:
    height, width, channels = input_spec
    prepared = patch_rgb
    if (prepared.shape[0], prepared.shape[1]) != (height, width):
        prepared = cv2.resize(prepared, (width, height), interpolation=cv2.INTER_AREA)
    if channels == 1:
        prepared = cv2.cvtColor(prepared, cv2.COLOR_RGB2GRAY)[..., None]
    return prepared.astype(np.float32) / 255.0


def infer_full_image(
    model: tf.keras.Model,
    image_rgb: np.ndarray,
    overlap: int,
    batch_size: int,
) -> tuple[np.ndarray, int]:
    if not 0 <= overlap < PATCH_SIZE:
        raise ValueError(f"overlap muss zwischen 0 und {PATCH_SIZE - 1} liegen.")
    stride = PATCH_SIZE - overlap
    height, width = image_rgb.shape[:2]
    y_positions = patch_positions(height, PATCH_SIZE, stride)
    x_positions = patch_positions(width, PATCH_SIZE, stride)
    weights = weight_map(PATCH_SIZE)
    probability_sum = np.zeros((height, width), dtype=np.float32)
    weight_sum = np.zeros((height, width), dtype=np.float32)
    input_spec = model_input_spec(model)

    patches: list[np.ndarray] = []
    metadata: list[tuple[int, int, int, int]] = []

    def flush() -> None:
        if not patches:
            return
        batch = np.stack(patches, axis=0)
        prediction = model.predict(batch, verbose=0)
        probabilities = normalize_prediction(prediction, PATCH_SIZE)
        for index, (x, y, valid_h, valid_w) in enumerate(metadata):
            probability_sum[y:y + valid_h, x:x + valid_w] += (
                probabilities[index, :valid_h, :valid_w] * weights[:valid_h, :valid_w]
            )
            weight_sum[y:y + valid_h, x:x + valid_w] += weights[:valid_h, :valid_w]
        patches.clear()
        metadata.clear()

    for y in y_positions:
        for x in x_positions:
            patch = image_rgb[y:y + PATCH_SIZE, x:x + PATCH_SIZE]
            valid_h, valid_w = patch.shape[:2]
            if (valid_h, valid_w) != (PATCH_SIZE, PATCH_SIZE):
                padded = np.zeros((PATCH_SIZE, PATCH_SIZE, 3), dtype=np.uint8)
                padded[:valid_h, :valid_w] = patch
                patch = padded
            patches.append(prepare_patch(patch, input_spec))
            metadata.append((x, y, valid_h, valid_w))
            if len(patches) >= batch_size:
                flush()
    flush()

    probability = probability_sum / np.maximum(weight_sum, EPS)
    return np.clip(probability, 0.0, 1.0), len(y_positions) * len(x_positions)


# =============================================================================
# METRIKEN UND SAMPLING
# =============================================================================

def confusion_for_thresholds(
    ground_truth: np.ndarray,
    probability: np.ndarray,
    thresholds: np.ndarray,
) -> tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray]:
    truth = ground_truth.reshape(-1).astype(bool, copy=False)
    probs = probability.reshape(-1).astype(np.float32, copy=False)
    positive = np.sort(probs[truth])
    negative = np.sort(probs[~truth])
    tp = positive.size - np.searchsorted(positive, thresholds, side="left")
    fp = negative.size - np.searchsorted(negative, thresholds, side="left")
    fn = positive.size - tp
    tn = negative.size - fp
    return tp, fp, fn, tn


def average_precision(tp: np.ndarray, fp: np.ndarray, fn: np.ndarray) -> float:
    total_positive = float(np.max(tp + fn)) if len(tp) else 0.0
    if total_positive <= 0:
        return float("nan")
    predicted_positive = tp + fp
    precision = np.divide(
        tp,
        predicted_positive,
        out=np.ones_like(tp, dtype=np.float64),
        where=predicted_positive > 0,
    )
    recall = tp / total_positive
    order = np.argsort(recall)
    recall = np.concatenate(([0.0], recall[order], [1.0]))
    precision = np.concatenate((
        [precision[order][0] if precision.size else 0.0],
        precision[order],
        [0.0],
    ))
    for index in range(len(precision) - 2, -1, -1):
        precision[index] = max(precision[index], precision[index + 1])
    return float(np.sum((recall[1:] - recall[:-1]) * precision[1:]))


def safe_div(numerator: float, denominator: float) -> float:
    return float(numerator / (denominator + EPS))


def metric_values(tp: int, fp: int, fn: int, tn: int, ap: float) -> dict[str, Any]:
    precision = safe_div(tp, tp + fp)
    recall = safe_div(tp, tp + fn)
    dice = safe_div(2 * tp, 2 * tp + fp + fn)
    iou = safe_div(tp, tp + fp + fn)
    f1 = safe_div(2 * precision * recall, precision + recall)
    f2 = safe_div(5 * precision * recall, 4 * precision + recall)
    accuracy = safe_div(tp + tn, tp + fp + fn + tn)
    fpr = safe_div(fp, fp + tn)
    fnr = safe_div(fn, fn + tp)
    balanced_error = 0.5 * (fpr + fnr)
    d_score = math.sqrt(0.5 * (1.0 - dice) ** 2 + 0.5 * (1.0 - f2) ** 2)
    return {
        "test_dice_fg": dice,
        "test_iou_fg": iou,
        "test_precision_fg": precision,
        "test_recall_fg": recall,
        "test_f1_fg": f1,
        "test_f2": f2,
        "test_ap": ap,
        "test_accuracy_pct": accuracy * 100.0,
        "balanced_error": balanced_error,
        "balanced_accuracy": 1.0 - balanced_error,
        "fpr": fpr,
        "fnr": fnr,
        "tp": int(tp),
        "fp": int(fp),
        "fn": int(fn),
        "tn": int(tn),
        "D": d_score,
        "pixels_total": int(tp + fp + fn + tn),
    }


class MetricAccumulator:
    def __init__(self, threshold: float):
        self.threshold = float(threshold)
        self.thresholds = np.unique(np.concatenate((
            np.asarray([self.threshold], dtype=np.float64), AP_THRESHOLDS
        )))
        self.tp = np.zeros(len(self.thresholds), dtype=np.int64)
        self.fp = np.zeros(len(self.thresholds), dtype=np.int64)
        self.fn = np.zeros(len(self.thresholds), dtype=np.int64)
        self.tn = np.zeros(len(self.thresholds), dtype=np.int64)
        self.updates = 0

    def update(self, ground_truth: np.ndarray, probability: np.ndarray) -> None:
        tp, fp, fn, tn = confusion_for_thresholds(
            ground_truth, probability, self.thresholds
        )
        self.tp += tp
        self.fp += fp
        self.fn += fn
        self.tn += tn
        self.updates += 1

    def result(self) -> dict[str, Any] | None:
        if self.updates == 0:
            return None
        selected = int(np.argmin(np.abs(self.thresholds - self.threshold)))
        ap_indices = np.asarray([
            int(np.argmin(np.abs(self.thresholds - threshold)))
            for threshold in AP_THRESHOLDS
        ])
        ap = average_precision(
            self.tp[ap_indices], self.fp[ap_indices], self.fn[ap_indices]
        )
        return metric_values(
            int(self.tp[selected]),
            int(self.fp[selected]),
            int(self.fn[selected]),
            int(self.tn[selected]),
            ap,
        )


def evaluate_arrays(
    ground_truth: np.ndarray, probability: np.ndarray, threshold: float
) -> dict[str, Any]:
    accumulator = MetricAccumulator(threshold)
    accumulator.update(ground_truth, probability)
    result = accumulator.result()
    assert result is not None
    return result


def balanced_crack_sample(
    ground_truth: np.ndarray,
    probability: np.ndarray,
    rng: np.random.Generator,
    ring_radius: int,
    negative_ratio: float,
) -> tuple[np.ndarray, np.ndarray, dict[str, int]]:
    truth = ground_truth.astype(bool)
    positive_indices = np.flatnonzero(truth.reshape(-1))
    positive_count = int(positive_indices.size)
    stats = {
        "positive_pixels": positive_count,
        "negative_pixels": 0,
        "ring_pixels_available": 0,
        "ring_pixels_sampled": 0,
        "far_background_sampled": 0,
    }
    if positive_count == 0:
        return np.empty(0, np.uint8), np.empty(0, np.float32), stats

    if ring_radius > 0:
        kernel_size = 2 * ring_radius + 1
        kernel = cv2.getStructuringElement(
            cv2.MORPH_ELLIPSE, (kernel_size, kernel_size)
        )
        dilated = cv2.dilate(truth.astype(np.uint8), kernel).astype(bool)
    else:
        dilated = truth.copy()
    ring = np.flatnonzero((dilated & ~truth).reshape(-1))
    far = np.flatnonzero((~dilated).reshape(-1))
    stats["ring_pixels_available"] = int(ring.size)
    target_negative = max(0, int(round(positive_count * negative_ratio)))

    ring_count = min(target_negative, int(ring.size))
    sampled_ring = (
        ring
        if ring_count == ring.size
        else rng.choice(ring, size=ring_count, replace=False)
    )
    remaining = target_negative - ring_count
    far_count = min(remaining, int(far.size))
    sampled_far = (
        far
        if far_count == far.size
        else rng.choice(far, size=far_count, replace=False)
    )
    negative_indices = np.concatenate((sampled_ring, sampled_far)).astype(np.int64)
    flat_probability = probability.reshape(-1)
    sampled_truth = np.concatenate((
        np.ones(positive_count, dtype=np.uint8),
        np.zeros(negative_indices.size, dtype=np.uint8),
    ))
    sampled_probability = np.concatenate((
        flat_probability[positive_indices], flat_probability[negative_indices]
    )).astype(np.float32, copy=False)
    stats.update({
        "negative_pixels": int(negative_indices.size),
        "ring_pixels_sampled": int(sampled_ring.size),
        "far_background_sampled": int(sampled_far.size),
    })
    return sampled_truth, sampled_probability, stats


# =============================================================================
# BILDER UND AUSGABEN
# =============================================================================

def load_rgb(path: Path) -> np.ndarray:
    image = cv2.imread(str(path), cv2.IMREAD_COLOR)
    if image is None:
        raise ValueError(f"Bild konnte nicht gelesen werden: {path}")
    return cv2.cvtColor(image, cv2.COLOR_BGR2RGB)


def load_mask(path: Path) -> np.ndarray:
    mask = cv2.imread(str(path), cv2.IMREAD_GRAYSCALE)
    if mask is None:
        raise ValueError(f"Maske konnte nicht gelesen werden: {path}")
    return mask > GROUND_TRUTH_THRESHOLD


def save_rgb(path: Path, image: np.ndarray) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    if not cv2.imwrite(str(path), cv2.cvtColor(image, cv2.COLOR_RGB2BGR)):
        raise OSError(f"Bild konnte nicht gespeichert werden: {path}")


def save_gray(path: Path, image: np.ndarray) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    if not cv2.imwrite(str(path), image):
        raise OSError(f"Bild konnte nicht gespeichert werden: {path}")


def error_visuals(
    image_rgb: np.ndarray,
    predicted_mask: np.ndarray,
    ground_truth: np.ndarray,
) -> tuple[np.ndarray, np.ndarray]:
    predicted = predicted_mask.astype(bool)
    truth = ground_truth.astype(bool)
    tp = predicted & truth
    fp = predicted & ~truth
    fn = ~predicted & truth
    color_mask = np.zeros_like(image_rgb, dtype=np.uint8)
    color_mask[tp] = (255, 255, 255)
    color_mask[fp] = (255, 0, 0)
    color_mask[fn] = (0, 0, 255)
    error_pixels = tp | fp | fn
    overlay = image_rgb.copy().astype(np.float32)
    overlay[error_pixels] = (
        (1.0 - OVERLAY_ALPHA) * overlay[error_pixels]
        + OVERLAY_ALPHA * color_mask[error_pixels].astype(np.float32)
    )
    return color_mask, np.clip(overlay, 0, 255).astype(np.uint8)


METRIC_ORDER = (
    "test_dice_fg", "test_iou_fg", "test_precision_fg", "test_recall_fg",
    "test_f1_fg", "test_f2", "test_ap", "test_accuracy_pct",
    "balanced_error", "balanced_accuracy", "fpr", "fnr",
    "tp", "fp", "fn", "tn", "D", "pixels_total",
)


def format_value(value: Any) -> str:
    if isinstance(value, (float, np.floating)):
        return "nan" if not np.isfinite(value) else f"{float(value):.6f}"
    return str(value)


def write_metrics_txt(
    path: Path,
    title: str,
    record: RunRecord,
    total_metrics: dict[str, Any] | None,
    per_image: list[dict[str, Any]],
    extra: dict[str, Any],
) -> None:
    lines = [
        "=" * 110,
        title,
        f"RUNNAME: {record.run_name}",
        f"Modell: {record.model_path}",
        f"Best epoch: {record.best_epoch}",
        f"Threshold: {record.threshold:.10g}",
        f"Metrics-Quelle: {record.metrics_source}",
        f"Threshold-Quelle: {record.threshold_source or 'Fallback 0.5'}",
        f"Erstellt: {datetime.now().isoformat(timespec='seconds')}",
        "=" * 110,
        "GESAMT",
    ]
    if total_metrics is None:
        lines.append("Keine auswertbaren Pixel vorhanden.")
    else:
        lines.extend(
            f"{key}: {format_value(total_metrics[key])}"
            for key in METRIC_ORDER if key in total_metrics
        )
    lines.extend(("", "ZUSATZINFORMATIONEN"))
    lines.extend(f"{key}: {format_value(value)}" for key, value in extra.items())
    for item in per_image:
        lines.extend(("", "-" * 110, f"BILD: {item['image_name']}"))
        for key, value in item.items():
            if key == "image_name":
                continue
            lines.append(f"{key}: {format_value(value)}")
    path.write_text("\n".join(lines) + "\n", encoding="utf-8")


def process_run(
    record: RunRecord,
    pairs: Iterable[ImagePair],
    overlap: int,
    batch_size: int,
) -> None:
    print("\n" + "=" * 100)
    print(f"RUN: {record.run_name} | Best epoch: {record.best_epoch}")
    print(f"Modell: {record.model_path.name} | Threshold: {record.threshold:.8g}")
    # Jedes Best-Epoch-Modell schreibt ausschliesslich in seinen eigenen
    # RUNNAME-Ordner: outputs/RUNNAME/perfect_labels_test.
    output_dir = record.run_dir / "perfect_labels_test"
    output_dir.mkdir(parents=True, exist_ok=True)

    model = load_model(record.model_path)
    print(f"Modelleingang: {model.input_shape}")
    full_total = MetricAccumulator(record.threshold)
    sample_total = MetricAccumulator(record.threshold)
    full_per_image: list[dict[str, Any]] = []
    sample_per_image: list[dict[str, Any]] = []
    rng = np.random.default_rng(ROI_RANDOM_SEED)
    total_patches = 0
    sample_totals = {
        "sample_positive_pixels": 0,
        "sample_negative_pixels": 0,
        "sample_ring_pixels_available": 0,
        "sample_ring_pixels_sampled": 0,
        "sample_far_background_sampled": 0,
        "sample_images_without_positive_pixels": 0,
    }

    for pair in pairs:
        image_rgb = load_rgb(pair.image_path)
        ground_truth = load_mask(pair.mask_path)
        if image_rgb.shape[:2] != ground_truth.shape:
            raise ValueError(
                f"Groessenfehler fuer {pair.image_path.name}: "
                f"Bild={image_rgb.shape[:2]}, Maske={ground_truth.shape}"
            )
        print(f"  {pair.image_path.name}: {image_rgb.shape[1]}x{image_rgb.shape[0]} px")
        probability, patch_count = infer_full_image(
            model, image_rgb, overlap=overlap, batch_size=batch_size
        )
        total_patches += patch_count
        predicted = probability >= record.threshold
        full_total.update(ground_truth, probability)
        full_metrics = evaluate_arrays(ground_truth, probability, record.threshold)
        full_per_image.append({
            "image_name": pair.image_path.name,
            "width_px": image_rgb.shape[1],
            "height_px": image_rgb.shape[0],
            "patches": patch_count,
            **full_metrics,
        })

        sampled_truth, sampled_probability, sample_stats = balanced_crack_sample(
            ground_truth,
            probability,
            rng,
            ring_radius=ROI_RING_RADIUS_PX,
            negative_ratio=ROI_NEGATIVE_TO_POSITIVE_RATIO,
        )
        if sampled_truth.size:
            sample_total.update(sampled_truth, sampled_probability)
            sampled_metrics = evaluate_arrays(
                sampled_truth, sampled_probability, record.threshold
            )
        else:
            sampled_metrics = {}
            sample_totals["sample_images_without_positive_pixels"] += 1
        sample_per_image.append({
            "image_name": pair.image_path.name,
            **sample_stats,
            **sampled_metrics,
        })
        for source_key, target_key in (
            ("positive_pixels", "sample_positive_pixels"),
            ("negative_pixels", "sample_negative_pixels"),
            ("ring_pixels_available", "sample_ring_pixels_available"),
            ("ring_pixels_sampled", "sample_ring_pixels_sampled"),
            ("far_background_sampled", "sample_far_background_sampled"),
        ):
            sample_totals[target_key] += sample_stats[source_key]

        color_mask, overlay = error_visuals(image_rgb, predicted, ground_truth)
        image_output = output_dir / pair.image_path.stem
        save_gray(image_output / "prediction_mask.png", predicted.astype(np.uint8) * 255)
        save_gray(image_output / "ground_truth_mask.png", ground_truth.astype(np.uint8) * 255)
        save_rgb(image_output / "fp_fn_mask.png", color_mask)
        save_rgb(image_output / "fp_fn_overlay.png", overlay)

    common_extra = {
        "images_total": len(full_per_image),
        "patch_size": PATCH_SIZE,
        "overlap": overlap,
        "stride": PATCH_SIZE - overlap,
        "patches_total": total_patches,
    }
    write_metrics_txt(
        output_dir / "metrics_full.txt",
        "PERFECT-LABEL-TEST: METRIKEN UEBER ALLE PIXEL",
        record,
        full_total.result(),
        full_per_image,
        common_extra,
    )
    write_metrics_txt(
        output_dir / "metrics_sampled.txt",
        "PERFECT-LABEL-TEST: METRIKEN IN DER BALANCED CRACK ROI",
        record,
        sample_total.result(),
        sample_per_image,
        {
            **common_extra,
            "roi_ring_radius_px": ROI_RING_RADIUS_PX,
            "roi_negative_to_positive_ratio": ROI_NEGATIVE_TO_POSITIVE_RATIO,
            "roi_random_seed": ROI_RANDOM_SEED,
            **sample_totals,
        },
    )
    del model
    tf.keras.backend.clear_session()
    gc.collect()
    print(f"  Gespeichert: {output_dir}")


def parse_arguments() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Best-Epoch-Modelle auf perfekt gelabelten Bildern auswerten."
    )
    parser.add_argument(
        "--input-dir", type=Path, default=INPUT_DIR,
        help=f"Ordner mit images/ und masks/ (Standard: {INPUT_DIR})",
    )
    parser.add_argument(
        "--output-root", type=Path, default=OUTPUT_ROOT,
        help=f"crack_project/outputs (Standard: {OUTPUT_ROOT})",
    )
    parser.add_argument(
        "--run", action="append", default=[], metavar="RUNNAME",
        help="Optional nur diesen Run auswerten; mehrfach verwendbar.",
    )
    parser.add_argument("--overlap", type=int, default=OVERLAP)
    parser.add_argument("--batch-size", type=int, default=INFERENCE_BATCH_SIZE)
    return parser.parse_args()


def configure_tensorflow() -> None:
    try:
        for gpu in tf.config.list_physical_devices("GPU"):
            tf.config.experimental.set_memory_growth(gpu, True)
    except RuntimeError:
        pass


def main() -> int:
    args = parse_arguments()
    if args.batch_size < 1:
        raise ValueError("--batch-size muss mindestens 1 sein.")
    configure_tensorflow()
    pairs = discover_image_pairs(args.input_dir.expanduser().resolve())
    records = discover_runs(
        args.output_root.expanduser().resolve(), set(args.run) if args.run else None
    )
    if not records:
        raise RuntimeError("Keine auswertbaren Best-Epoch-Modelle gefunden.")
    print(f"Bild-/Maskenpaare: {len(pairs)} | Modelle: {len(records)}")
    failures: list[tuple[str, str]] = []
    for record in records:
        try:
            process_run(record, pairs, args.overlap, args.batch_size)
        except Exception as exc:
            failures.append((record.run_name, str(exc)))
            print(f"[FEHLER] {record.run_name}: {exc}")
            tf.keras.backend.clear_session()
            gc.collect()
    print("\nAuswertung abgeschlossen.")
    if failures:
        print("Fehlgeschlagene Runs:")
        for run_name, message in failures:
            print(f"  - {run_name}: {message}")
        return 1
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
