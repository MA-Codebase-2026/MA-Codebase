#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Rissbreitenanalyse für mehrere Bilder mit zwei Modell-Konfigurationsarten.

Ziel
====
Das Skript verarbeitet alle Bilder aus IMAGE_DIR. Es unterstützt zwei Modi:

1. Direkter Modellpfad (MODEL_PATH gesetzt)
   Für ein mit ensemble_validation_sweep_test_metrics exportiertes .keras-Ensemble
   reicht der direkte Modellpfad. Die Eingabegröße wird aus dem Modell gelesen und
   der finale Ausgang ``binary_mask`` wird verwendet. Ein externer Segmentierungs-
   Threshold ist dann nicht nötig, weil individuelle Thresholds, gewichteter Vote,
   Classifier-Gate und finaler Ensemble-Threshold bereits im Modell enthalten sind.

2. Bisherige RUN-Automatik (MODEL_PATH = None)
   Das Skript verwendet RUN_DIR und liest best_epoch, Modell, Threshold und
   Patchgröße wie bisher automatisch aus dem Trainings-RUN. RUN_DIR muss folgende
   Unterordner enthalten:

    RUN_DIR/
    ├── architecture/
    ├── metrics/
    ├── models/
    └── threshold_results2/

Automatisch aus dem RUN gelesen werden:
----------------------------------------
1. Bestes Epoch-Modell
   metrics/<RUNNAME>_epoch_metrics.json -> best_epoch

2. Modell-Datei
   models/<RUNNAME>_Epoche<best_epoch>.keras
   (mehrere robuste Namensvarianten werden unterstützt)

3. Segmentierungs-Threshold
   threshold_results2/*<best_epoch>*
   Primär wird aus der Threshold-Auswertung gelesen:
       "ROI minimaler Balanced Error: Threshold = ..."

4. Patchgröße
   architecture/<RUNNAME>_architecture_config.json
   Die Größe wird aus dem InputLayer / batch_shape bzw. input_shape gelesen.

Ausgabe
=======
Der Hauptausgabeordner wird automatisch erzeugt. Im RUN-Modus liegt er unter
RUN_DIR/rissbreite_in_px/. Bei einem direkten Modell unter <run>/models/*.keras
wird derselbe <run>-Ordner verwendet; sonst der Ordner der .keras-Datei.

Für jedes Eingabebild entsteht:

    <OUTPUT_ROOT>/<BILDNAME>/
        analysis_config.json
        analysis_config.txt
        probability_map.png
        probability_map.npy
        binary_mask.png
        annotated_image.png
        trigger_map.png
        skeleton.png
        fp_fn_overlay.png            # nur falls passende Ground-Truth-Maske existiert
        crack_report.csv
        crack_report.json
        crack_report.txt

Zusätzlich entstehen im Hauptausgabeordner:
    run_configuration.json
    run_configuration.txt
    batch_summary.csv
    batch_summary.json
    batch_summary.txt

Rissbreite
==========
Wie im bisherigen Code wird die lokale Rissbreite aus Skelettierung und
Distanztransformation bestimmt:

    lokale Breite = 2 * distance_transform(mask) am Skelett

Pro Riss werden geloggt:
- minimale Rissbreite [px]
- maximale Rissbreite [px]
- durchschnittliche Rissbreite [px]
- Median der Rissbreite [px]
- Risslänge [px]
- Rissfläche [px²]

Triggerlogik
============
Die Grenzwerte werden oben im Code konfiguriert.
Standard:
- ROT:    Median < 4 px
- ORANGE: 4 px <= Median < 5 px
- GRÜN:   Median >= 5 px

Hinweis zur Parallelisierung
============================
Das TensorFlow-Modell wird genau einmal geladen. Die Modellinferenz wird nicht
mit mehreren konkurrierenden Modellkopien parallelisiert, um unnötigen GPU-
Speicherverbrauch und instabiles Verhalten zu vermeiden. Die CPU-seitige
Analyse zusammenhängender Risse kann mit bis zu MAX_WORKERS Threads laufen.

Benötigte Pakete
================
    pip install tensorflow opencv-python numpy scipy scikit-image
"""

from __future__ import annotations

# =============================================================================
# 1. BENUTZERKONFIGURATION - HIER ANPASSEN
# =============================================================================

from pathlib import Path

# Ordner mit mehreren zu untersuchenden Bildern.
IMAGE_DIR = Path("/home/mitte/crack_project/test_images/10_Bilder_test")

# Optional: direkter Pfad zu einem konkreten .keras-Modell.
# Wenn MODEL_PATH gesetzt ist, hat dieser Pfad Vorrang vor RUN_DIR.
# Für ein mit ensemble_validation_sweep_test_metrics exportiertes Ensemble reicht
# ausschließlich dieser Modellpfad; ein externer Segmentierungs-Threshold wird
# dann NICHT benötigt, weil ``binary_mask`` bereits final im Modell erzeugt wird.
# Beispiel:
# MODEL_PATH: Path | None = Path(
#     "/home/mitte/crack_project/outputs/mein_ensemble_run/models/mein_ensemble_run_ensemble.keras"
# )
MODEL_PATH: Path | None = None #Path("/home/mitte/crack_project/outputs/ensemble_dynamic_finefocal_precisetversky_lowclassifierthreshold/models/ensemble_dynamic_finefocal_precisetversky_lowclassifierthreshold_ensemble.keras")

# Bisheriger Modus: Pfad zum konkreten RUNNAME-Ordner.
# Wird nur benutzt, wenn MODEL_PATH = None ist.
# Beispielstruktur darunter:
#   architecture/
#   metrics/
#   models/
#   threshold_results2/
RUN_DIR = Path("/home/mitte/crack_project/outputs/unetpp_labelnoise_translation_4px_rechts")

# -----------------------------------------------------------------------------
# Bildsuche
# -----------------------------------------------------------------------------

IMAGE_EXTENSIONS = (
    ".png",
    ".jpg",
    ".jpeg",
    ".bmp",
    ".tif",
    ".tiff",
)

# True = auch Unterordner von IMAGE_DIR durchsuchen.
RECURSIVE_IMAGE_SEARCH = False

# Optionaler Ground-Truth-Maskenordner innerhalb von IMAGE_DIR.
# Für ein Bild z. B. "IMG_001.jpg" wird in IMAGE_DIR/masks nach einer
# Maske mit demselben Dateistamm gesucht, z. B. "IMG_001.png".
GROUND_TRUTH_MASK_SUBDIR = "masks"

# Pixel > diesem Wert gelten in der Ground-Truth-Maske als Riss.
GROUND_TRUTH_MASK_THRESHOLD = 127

# True Positives im FP/FN-Overlay weiß darstellen.
# FP = rot, FN = blau, TN = schwarz.
SHOW_TP_IN_ERROR_OVERLAY = True

# -----------------------------------------------------------------------------
# Patch-Inferenz
# -----------------------------------------------------------------------------

# RUN-Modus: Patchgröße wird automatisch aus architecture/*config*.json gelesen.
# Direkter MODEL_PATH-Modus: Patchgröße wird direkt aus model.input_shape gelesen.
# Nur falls das automatische Auslesen scheitert, kann hier ein Fallback gesetzt
# werden. None bedeutet: bei Fehler abbrechen.
PATCH_SIZE_FALLBACK: int | None = None

# Überlappung benachbarter Patches in Pixeln.
OVERLAP = 64

# Anzahl Patches pro model.predict()-Batch.
INFERENCE_BATCH_SIZE = 8

# Index der Rissklasse, falls das Modell mehrere Output-Kanäle besitzt.
CRACK_CLASS_INDEX = 1

# -----------------------------------------------------------------------------
# Segmentierungs-Threshold
# -----------------------------------------------------------------------------

# RUN-Modus: Threshold automatisch aus threshold_results2 auslesen.
# Im direkten Ensemble-Modus wird diese Einstellung ignoriert.
USE_AUTOMATIC_SEGMENTATION_THRESHOLD = True

# Wird nur benutzt, wenn USE_AUTOMATIC_SEGMENTATION_THRESHOLD = False ist.
MANUAL_SEGMENTATION_THRESHOLD = 0.5

# Falls der automatische Parser keinen Threshold findet:
# None -> mit verständlicher Fehlermeldung abbrechen.
# float -> diesen Wert als Fallback verwenden.
SEGMENTATION_THRESHOLD_FALLBACK: float | None = None

# -----------------------------------------------------------------------------
# Maskenbereinigung
# -----------------------------------------------------------------------------

# Zusammenhängende Maskenobjekte unterhalb dieser Pixelanzahl entfernen.
MIN_OBJECT_AREA = 100

# Löcher bis zu dieser Pixelanzahl schließen.
REMOVE_HOLES_AREA = 100

# Mindestanzahl an Skelettpixeln für eine gültige Breitenmessung.
MIN_SKELETON_POINTS = 10

# -----------------------------------------------------------------------------
# Triggerlogik anhand des Rissbreiten-Medians
# -----------------------------------------------------------------------------

# ROT, wenn Median < diesem Wert.
TRIGGER_RED_MAX_PX = 4.0

# ORANGE, wenn Median >= TRIGGER_RED_MAX_PX und < diesem Wert.
# GRÜN, wenn Median >= diesem Wert.
TRIGGER_GREEN_MIN_PX = 5.0

# -----------------------------------------------------------------------------
# Parallelisierung / Threads
# -----------------------------------------------------------------------------

# Maximal 16 Worker. Werte > 16 werden automatisch auf 16 begrenzt.
MAX_WORKERS = 16

# OpenCV-interne Threads. None -> MAX_WORKERS verwenden.
OPENCV_THREADS: int | None = None

# TensorFlow CPU-Threading. Bei GPU-Inferenz betrifft dies vor allem CPU-Teile.
TF_INTRA_OP_THREADS: int | None = None
TF_INTER_OP_THREADS = 2

# -----------------------------------------------------------------------------
# Ausgabe / Visualisierung
# -----------------------------------------------------------------------------

OUTPUT_ROOT_NAME = "rissbreite_in_px"

# Transparenz der gelben Rissmasken-Überlagerung im annotierten Originalbild.
MASK_OVERLAY_ALPHA = 0.20

# Probability Map zusätzlich als Float32-NPY speichern.
SAVE_PROBABILITY_NPY = True

# =============================================================================
# 2. IMPORTS
# =============================================================================

import csv
import json
import math
import os
import re
import sys
import traceback
from concurrent.futures import ThreadPoolExecutor
from dataclasses import asdict, dataclass
from datetime import datetime
from typing import Any, Iterable, Optional

import cv2
import numpy as np
import tensorflow as tf
from keras.applications.mobilenet_v2 import preprocess_input as mobilenet_v2_preprocess_input
from keras.applications.resnet50 import preprocess_input as resnet50_preprocess_input
from keras.applications.efficientnet import preprocess_input as efficientnet_preprocess_input
from keras.applications.xception import preprocess_input as xception_preprocess_input
from keras.applications.vgg16 import preprocess_input as vgg16_preprocess_input
from keras.applications.vgg19 import preprocess_input as vgg19_preprocess_input
from keras.applications.densenet import preprocess_input as densenet_preprocess_input
from scipy.ndimage import distance_transform_edt
from skimage.measure import label, regionprops
from skimage.morphology import remove_small_holes, remove_small_objects, skeletonize


# =============================================================================
# 3. DATENSTRUKTUREN
# =============================================================================


@dataclass(frozen=True)
class AutoRunInfo:
    """Effektive Modell-/RUN-Konfiguration für die Rissmessung."""

    source_mode: str
    run_name: str
    run_dir: str

    metrics_file: Optional[str]
    best_epoch: Optional[int]

    architecture_config_file: Optional[str]
    patch_size: int

    model_file: str

    # Beim exportierten Ensemble ist dieser Wert None: Der finale Threshold steckt
    # bereits als FixedThreshold-Layer im Modell und wir verwenden ``binary_mask``.
    segmentation_threshold: Optional[float]
    threshold_source_file: Optional[str]
    threshold_selection_rule: str

    # "probability" = klassischer Segmentierungsoutput + externer Threshold
    # "binary_mask" = finaler binärer Sweep-Ensemble-Ausgang, kein externer Threshold
    # "decision_score" = Old-Fusion-Ensemble-Score; finale Exportentscheidung >= 0.5
    model_output_mode: str
    model_output_name: Optional[str]


@dataclass
class CrackResult:
    """Messwerte eines einzelnen zusammenhängenden Risses."""

    crack_id: int
    bbox_xyxy: tuple[int, int, int, int]
    centroid_xy: tuple[float, float]

    area_px: int
    length_px: float
    skeleton_points: int

    min_width_px: Optional[float]
    max_width_px: Optional[float]
    mean_width_px: Optional[float]
    median_width_px: Optional[float]

    trigger_level: str
    trigger_color: str


@dataclass
class CrackAnalysisPayload:
    """Internes Resultat eines Worker-Threads."""

    result: CrackResult
    skeleton_y_global: np.ndarray
    skeleton_x_global: np.ndarray


# =============================================================================
# 4. ALLGEMEINE HILFSFUNKTIONEN
# =============================================================================


def now_iso() -> str:
    return datetime.now().astimezone().isoformat()


def json_safe(value: Any) -> Any:
    """Konvertiert typische NumPy-/Path-Werte in JSON-kompatible Werte."""
    if value is None or isinstance(value, (str, int, float, bool)):
        return value
    if isinstance(value, Path):
        return str(value)
    if isinstance(value, np.generic):
        return value.item()
    if isinstance(value, np.ndarray):
        return value.tolist()
    if isinstance(value, dict):
        return {str(k): json_safe(v) for k, v in value.items()}
    if isinstance(value, (list, tuple, set)):
        return [json_safe(v) for v in value]
    return str(value)


def write_json(path: Path, data: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(
        json.dumps(json_safe(data), indent=2, ensure_ascii=False),
        encoding="utf-8",
    )


def dict_to_text(data: Any, indent: int = 0) -> str:
    """Erzeugt ein gut lesbares TXT-Format aus verschachtelten Dictionaries."""
    prefix = "  " * indent
    lines: list[str] = []

    if isinstance(data, dict):
        for key, value in data.items():
            if isinstance(value, (dict, list, tuple)):
                lines.append(f"{prefix}{key}:")
                lines.append(dict_to_text(value, indent + 1))
            else:
                lines.append(f"{prefix}{key}: {value}")
        return "\n".join(lines)

    if isinstance(data, (list, tuple)):
        for item in data:
            if isinstance(item, (dict, list, tuple)):
                lines.append(f"{prefix}-")
                lines.append(dict_to_text(item, indent + 1))
            else:
                lines.append(f"{prefix}- {item}")
        return "\n".join(lines)

    return f"{prefix}{data}"


def write_txt_dict(path: Path, title: str, data: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    text = (
        f"{title}\n"
        f"{'=' * len(title)}\n\n"
        f"{dict_to_text(json_safe(data))}\n"
    )
    path.write_text(text, encoding="utf-8")


def clamp_workers(value: int) -> int:
    """Erlaubt mindestens 1 und höchstens 16 Worker."""
    return max(1, min(int(value), 16))


def validate_user_configuration() -> None:
    if MODEL_PATH is not None and Path(MODEL_PATH).suffix.lower() != ".keras":
        raise ValueError("MODEL_PATH muss auf eine .keras-Datei zeigen.")
    if OVERLAP < 0:
        raise ValueError("OVERLAP darf nicht negativ sein.")
    if INFERENCE_BATCH_SIZE < 1:
        raise ValueError("INFERENCE_BATCH_SIZE muss >= 1 sein.")
    if MIN_OBJECT_AREA < 0:
        raise ValueError("MIN_OBJECT_AREA darf nicht negativ sein.")
    if REMOVE_HOLES_AREA < 0:
        raise ValueError("REMOVE_HOLES_AREA darf nicht negativ sein.")
    if MIN_SKELETON_POINTS < 1:
        raise ValueError("MIN_SKELETON_POINTS muss >= 1 sein.")
    if TRIGGER_RED_MAX_PX >= TRIGGER_GREEN_MIN_PX:
        raise ValueError(
            "TRIGGER_RED_MAX_PX muss kleiner als TRIGGER_GREEN_MIN_PX sein."
        )


# =============================================================================
# 5. THREAD-KONFIGURATION
# =============================================================================


def configure_threads() -> dict[str, int]:
    """Begrenzt OpenCV/TensorFlow auf die konfigurierte Threadzahl."""
    workers = clamp_workers(MAX_WORKERS)

    cv_threads = workers if OPENCV_THREADS is None else clamp_workers(OPENCV_THREADS)
    tf_intra = workers if TF_INTRA_OP_THREADS is None else clamp_workers(TF_INTRA_OP_THREADS)
    tf_inter = max(1, min(int(TF_INTER_OP_THREADS), 16))

    cv2.setNumThreads(cv_threads)

    # TensorFlow erlaubt das Setzen nur vor der eigentlichen Runtime-Initialisierung.
    try:
        tf.config.threading.set_intra_op_parallelism_threads(tf_intra)
        tf.config.threading.set_inter_op_parallelism_threads(tf_inter)
    except RuntimeError:
        # Falls TF bereits initialisiert wurde, wird nur protokolliert und weitergearbeitet.
        pass

    return {
        "max_workers": workers,
        "opencv_threads": cv_threads,
        "tf_intra_op_threads": tf_intra,
        "tf_inter_op_threads": tf_inter,
    }


# =============================================================================
# 6. RUN-STRUKTUR AUTOMATISCH AUSLESEN
# =============================================================================


def require_directory(path: Path, label_name: str) -> None:
    if not path.is_dir():
        raise FileNotFoundError(f"{label_name} nicht gefunden: {path}")


def resolve_single_preferred_file(
    directory: Path,
    preferred_name: str,
    glob_patterns: Iterable[str],
    description: str,
) -> Path:
    """Nimmt zuerst den exakten Namen, danach eindeutige Glob-Fallbacks."""
    exact = directory / preferred_name
    if exact.is_file():
        return exact

    candidates: list[Path] = []
    for pattern in glob_patterns:
        candidates.extend(directory.glob(pattern))

    candidates = sorted({p.resolve() for p in candidates if p.is_file()})

    if not candidates:
        raise FileNotFoundError(
            f"Keine passende Datei für {description} in {directory} gefunden."
        )

    if len(candidates) == 1:
        return candidates[0]

    # Bei mehreren Kandidaten RUNNAME im Dateinamen bevorzugen.
    run_name_lower = RUN_DIR.name.lower()
    run_candidates = [p for p in candidates if run_name_lower in p.name.lower()]
    if len(run_candidates) == 1:
        return run_candidates[0]

    raise RuntimeError(
        f"Mehrere mögliche Dateien für {description} gefunden:\n"
        + "\n".join(f"  - {p}" for p in candidates)
    )


def read_best_epoch(metrics_file: Path) -> tuple[int, dict[str, Any]]:
    """Liest best_epoch aus der Epoch-Metrikdatei."""
    data = json.loads(metrics_file.read_text(encoding="utf-8"))

    if "best_epoch" not in data:
        raise KeyError(
            f"In {metrics_file} wurde das Feld 'best_epoch' nicht gefunden."
        )

    best_epoch = int(round(float(data["best_epoch"])))
    if best_epoch < 1:
        raise ValueError(f"Ungültige best_epoch: {best_epoch}")

    return best_epoch, data


def extract_patch_size_from_architecture(data: Any) -> Optional[int]:
    """
    Sucht bevorzugt nach einem InputLayer und dessen batch_shape/input_shape.

    Unterstützt Keras-Config-Dateien, in denen z. B. steht:
        class_name = InputLayer
        batch_shape = [None, 512, 512, 3]
    """

    # 1) Bevorzugt echte InputLayer-Konfigurationen.
    if isinstance(data, dict):
        class_name = str(data.get("class_name", "")).lower()
        config = data.get("config")

        if class_name == "inputlayer" and isinstance(config, dict):
            for key in ("batch_shape", "input_shape", "batch_input_shape"):
                shape = config.get(key)
                size = patch_size_from_shape(shape)
                if size is not None:
                    return size

        for value in data.values():
            size = extract_patch_size_from_architecture(value)
            if size is not None:
                return size

    elif isinstance(data, list):
        for item in data:
            size = extract_patch_size_from_architecture(item)
            if size is not None:
                return size

    return None


def patch_size_from_shape(shape: Any) -> Optional[int]:
    if not isinstance(shape, (list, tuple)):
        return None

    numeric = [x for x in shape if isinstance(x, (int, float)) and int(x) > 1]
    if len(numeric) < 2:
        return None

    # Typisch: [H, W, C] oder [None, H, W, C].
    h = int(numeric[0])
    w = int(numeric[1])

    if h == w:
        return h

    return None


def read_patch_size(architecture_file: Path) -> int:
    data = json.loads(architecture_file.read_text(encoding="utf-8"))
    patch_size = extract_patch_size_from_architecture(data)

    if patch_size is not None:
        return patch_size

    if PATCH_SIZE_FALLBACK is not None:
        return int(PATCH_SIZE_FALLBACK)

    raise RuntimeError(
        "Patchgröße konnte nicht aus der Architektur-Konfiguration gelesen werden: "
        f"{architecture_file}"
    )


def epoch_name_matches(filename: str, epoch: int) -> bool:
    """Erkennt verschiedene Benennungen wie Epoche15, epoch15, epoch_15."""
    name = filename.lower()
    patterns = [
        rf"epoche[_-]?0*{epoch}(?!\d)",
        rf"epoch[_-]?0*{epoch}(?!\d)",
        rf"(?:^|[_-])e[_-]?0*{epoch}(?!\d)",
    ]
    return any(re.search(pattern, name) for pattern in patterns)


def resolve_best_model(models_dir: Path, run_name: str, best_epoch: int) -> Path:
    """Findet die .keras-Datei des automatisch ermittelten best_epoch."""
    preferred_names = [
        f"{run_name}_Epoche{best_epoch}.keras",
        f"{run_name}_epoch{best_epoch}.keras",
        f"{run_name}_Epoch{best_epoch}.keras",
        f"{run_name}_epoch_{best_epoch}.keras",
    ]

    for name in preferred_names:
        candidate = models_dir / name
        if candidate.is_file():
            return candidate

    keras_files = sorted(models_dir.glob("*.keras"))
    epoch_matches = [p for p in keras_files if epoch_name_matches(p.name, best_epoch)]

    if len(epoch_matches) == 1:
        return epoch_matches[0]

    run_epoch_matches = [
        p for p in epoch_matches if run_name.lower() in p.name.lower()
    ]
    if len(run_epoch_matches) == 1:
        return run_epoch_matches[0]

    if not epoch_matches:
        raise FileNotFoundError(
            f"Kein .keras-Modell für best_epoch={best_epoch} in {models_dir} gefunden."
        )

    raise RuntimeError(
        f"Mehrere Modelle für best_epoch={best_epoch} gefunden:\n"
        + "\n".join(f"  - {p}" for p in epoch_matches)
    )


def score_threshold_file(path: Path, run_name: str, best_epoch: int, model_file: Path) -> int:
    """Bewertet, wie gut eine Datei zum ausgewählten Modell/Epoch passt."""
    score = 0
    name = path.name.lower()

    if run_name.lower() in name:
        score += 10
    if epoch_name_matches(path.name, best_epoch):
        score += 20
    if "balanced" in name:
        score += 4
    if "threshold" in name:
        score += 3

    # Bei Textdateien zusätzlich prüfen, ob die konkrete Modelldatei erwähnt wird.
    if path.suffix.lower() in {".txt", ".log", ".csv"}:
        try:
            head = path.read_text(encoding="utf-8", errors="replace")[:12000]
            if model_file.name in head:
                score += 30
        except OSError:
            pass

    return score


def parse_threshold_from_text(text: str) -> tuple[Optional[float], Optional[str]]:
    """
    Liest den primären Threshold bevorzugt aus der finalen Empfehlung.

    Reihenfolge:
    1. "ROI minimaler Balanced Error: Threshold = ..."
    2. Tabelle "AUSWAHLPUNKTE BALANCED CRACK ROI" -> Spalte Min Bal Error
    """
    patterns = [
        (
            r"ROI\s+minimaler\s+Balanced\s+Error\s*:\s*Threshold\s*=\s*"
            r"([0-9]+(?:\.[0-9]+)?(?:[eE][+-]?\d+)?)",
            "ROI minimaler Balanced Error (finale Threshold-Empfehlung)",
        ),
        (
            r"minimaler\s+Balanced\s+Error.*?Threshold\s*=\s*"
            r"([0-9]+(?:\.[0-9]+)?(?:[eE][+-]?\d+)?)",
            "minimaler Balanced Error",
        ),
    ]

    for pattern, rule in patterns:
        match = re.search(pattern, text, flags=re.IGNORECASE | re.DOTALL)
        if match:
            return float(match.group(1)), rule

    # Fallback: Balanced-ROI-Auswahlpunkt-Tabelle. Die erste Zahl in der
    # Threshold-Zeile ist dort der Wert für "Min Bal Error".
    roi_pos = re.search(
        r"AUSWAHLPUNKTE\s+BALANCED\s+CRACK\s+ROI",
        text,
        flags=re.IGNORECASE,
    )
    if roi_pos:
        subsection = text[roi_pos.start(): roi_pos.start() + 5000]
        match = re.search(
            r"^\s*Threshold\s*\|\s*([0-9.eE+-]+)",
            subsection,
            flags=re.IGNORECASE | re.MULTILINE,
        )
        if match:
            return float(match.group(1)), "Balanced Crack ROI: Min Bal Error (Tabelle)"

    return None, None


def recursively_find_threshold_in_json(data: Any) -> tuple[Optional[float], Optional[str]]:
    """Konservativer JSON-Fallback für klar benannte Balanced-Error-Thresholds."""
    if isinstance(data, dict):
        for key, value in data.items():
            key_norm = re.sub(r"[^a-z0-9]+", "_", str(key).lower())

            if (
                "threshold" in key_norm
                and "balanced" in key_norm
                and isinstance(value, (int, float))
            ):
                return float(value), f"JSON-Feld: {key}"

        for key, value in data.items():
            key_norm = str(key).lower()
            if "balanced" in key_norm and isinstance(value, dict):
                # Innerhalb eines Balanced-Blocks nur eindeutig benannte Keys nehmen.
                for inner_key in (
                    "threshold_min_balanced_error",
                    "min_balanced_error_threshold",
                    "best_threshold",
                    "threshold",
                ):
                    inner_value = value.get(inner_key)
                    if isinstance(inner_value, (int, float)):
                        return float(inner_value), f"JSON: {key}.{inner_key}"

        for value in data.values():
            found, rule = recursively_find_threshold_in_json(value)
            if found is not None:
                return found, rule

    elif isinstance(data, list):
        for item in data:
            found, rule = recursively_find_threshold_in_json(item)
            if found is not None:
                return found, rule

    return None, None


def read_segmentation_threshold(
    threshold_dir: Path,
    run_name: str,
    best_epoch: int,
    model_file: Path,
) -> tuple[float, Optional[Path], str]:
    """Findet und liest den Threshold für das ausgewählte best_epoch-Modell."""

    if not USE_AUTOMATIC_SEGMENTATION_THRESHOLD:
        threshold = float(MANUAL_SEGMENTATION_THRESHOLD)
        if not 0.0 <= threshold <= 1.0:
            raise ValueError("MANUAL_SEGMENTATION_THRESHOLD muss in [0, 1] liegen.")
        return threshold, None, "manuell aus Skriptkonfiguration"

    files = sorted(p for p in threshold_dir.rglob("*") if p.is_file())
    if not files:
        raise FileNotFoundError(f"Keine Threshold-Dateien in {threshold_dir} gefunden.")

    scored = sorted(
        (
            (score_threshold_file(p, run_name, best_epoch, model_file), p)
            for p in files
        ),
        key=lambda item: (item[0], item[1].name),
        reverse=True,
    )

    # Zuerst Dateien mit best_epoch-Bezug versuchen, dann notfalls alle.
    epoch_files = [p for score, p in scored if epoch_name_matches(p.name, best_epoch)]
    ordered_candidates = epoch_files + [p for score, p in scored if p not in epoch_files]

    for path in ordered_candidates:
        try:
            suffix = path.suffix.lower()
            if suffix == ".json":
                data = json.loads(path.read_text(encoding="utf-8"))
                threshold, rule = recursively_find_threshold_in_json(data)
            elif suffix in {".txt", ".log", ".csv"}:
                text = path.read_text(encoding="utf-8", errors="replace")
                threshold, rule = parse_threshold_from_text(text)
            else:
                continue
        except (OSError, json.JSONDecodeError, ValueError):
            continue

        if threshold is not None:
            if not 0.0 <= threshold <= 1.0:
                raise ValueError(
                    f"Aus {path} gelesener Threshold liegt nicht in [0,1]: {threshold}"
                )
            return float(threshold), path, str(rule)

    if SEGMENTATION_THRESHOLD_FALLBACK is not None:
        threshold = float(SEGMENTATION_THRESHOLD_FALLBACK)
        if not 0.0 <= threshold <= 1.0:
            raise ValueError("SEGMENTATION_THRESHOLD_FALLBACK muss in [0,1] liegen.")
        return threshold, None, "SEGMENTATION_THRESHOLD_FALLBACK"

    raise RuntimeError(
        "Für das beste Modell konnte kein geeigneter Segmentierungs-Threshold "
        f"aus {threshold_dir} gelesen werden."
    )


def discover_run_info() -> tuple[AutoRunInfo, dict[str, Any]]:
    """Liest alle automatisch ableitbaren RUN-Parameter."""
    run_dir = RUN_DIR.expanduser().resolve()
    run_name = run_dir.name

    require_directory(run_dir, "RUN_DIR")

    architecture_dir = run_dir / "architecture"
    metrics_dir = run_dir / "metrics"
    models_dir = run_dir / "models"
    threshold_dir = run_dir / "threshold_results2"

    require_directory(architecture_dir, "architecture-Ordner")
    require_directory(metrics_dir, "metrics-Ordner")
    require_directory(models_dir, "models-Ordner")
    require_directory(threshold_dir, "threshold_results2-Ordner")

    metrics_file = resolve_single_preferred_file(
        metrics_dir,
        f"{run_name}_epoch_metrics.json",
        ("*_epoch_metrics.json", "*epoch*metrics*.json"),
        "Epoch-Metriken",
    )
    best_epoch, metrics_data = read_best_epoch(metrics_file)

    architecture_file = resolve_single_preferred_file(
        architecture_dir,
        f"{run_name}_architecture_config.json",
        ("*architecture*config*.json", "*config*.json"),
        "Architektur-Konfiguration",
    )
    patch_size = read_patch_size(architecture_file)

    model_file = resolve_best_model(models_dir, run_name, best_epoch)

    threshold, threshold_file, threshold_rule = read_segmentation_threshold(
        threshold_dir=threshold_dir,
        run_name=run_name,
        best_epoch=best_epoch,
        model_file=model_file,
    )

    info = AutoRunInfo(
        source_mode="run_auto",
        run_name=run_name,
        run_dir=str(run_dir),
        metrics_file=str(metrics_file),
        best_epoch=best_epoch,
        architecture_config_file=str(architecture_file),
        patch_size=patch_size,
        model_file=str(model_file),
        segmentation_threshold=threshold,
        threshold_source_file=str(threshold_file) if threshold_file else None,
        threshold_selection_rule=threshold_rule,
        model_output_mode="probability",
        model_output_name=None,
    )

    return info, metrics_data


# =============================================================================
# 7. BILDER LADEN UND PATCH-POSITIONEN
# =============================================================================


def find_input_images(image_dir: Path) -> list[Path]:
    """Findet Eingabebilder, aber niemals Dateien aus dem masks-Unterordner."""
    image_dir = image_dir.expanduser().resolve()
    require_directory(image_dir, "IMAGE_DIR")

    extensions = {ext.lower() for ext in IMAGE_EXTENSIONS}
    iterator = image_dir.rglob("*") if RECURSIVE_IMAGE_SEARCH else image_dir.glob("*")
    mask_dir = (image_dir / GROUND_TRUTH_MASK_SUBDIR).resolve()

    images: list[Path] = []
    for p in iterator:
        if not p.is_file() or p.suffix.lower() not in extensions:
            continue

        # Bei rekursiver Suche Ground-Truth-Masken nicht selbst segmentieren.
        try:
            p.resolve().relative_to(mask_dir)
            continue
        except ValueError:
            pass

        images.append(p)

    images = sorted(images)

    if not images:
        raise FileNotFoundError(
            f"Keine unterstützten Bilder in {image_dir} gefunden. "
            f"Extensions: {sorted(extensions)}"
        )

    return images


def find_matching_ground_truth_mask(image_path: Path) -> Path | None:
    """
    Sucht in IMAGE_DIR/masks nach einer Maske mit identischem Dateistamm.

    Beispiel:
        IMAGE_DIR/bild_01.jpg
        IMAGE_DIR/masks/bild_01.png

    Unterstützte Maskendateiendungen entsprechen IMAGE_EXTENSIONS.
    """
    mask_dir = IMAGE_DIR.expanduser().resolve() / GROUND_TRUTH_MASK_SUBDIR
    if not mask_dir.is_dir():
        return None

    # Zuerst exakt gleiche Dateiendung probieren.
    exact = mask_dir / image_path.name
    if exact.is_file():
        return exact

    extensions = {ext.lower() for ext in IMAGE_EXTENSIONS}
    candidates = sorted(
        p for p in mask_dir.iterdir()
        if p.is_file()
        and p.stem == image_path.stem
        and p.suffix.lower() in extensions
    )

    return candidates[0] if candidates else None


def load_ground_truth_mask(mask_path: Path) -> np.ndarray:
    """Lädt eine Ground-Truth-Maske als bool-Array."""
    mask_gray = cv2.imread(str(mask_path), cv2.IMREAD_GRAYSCALE)
    if mask_gray is None:
        raise ValueError(f"Ground-Truth-Maske konnte nicht gelesen werden: {mask_path}")
    return mask_gray > GROUND_TRUTH_MASK_THRESHOLD


def create_fp_fn_overlay(
    predicted_mask: np.ndarray,
    ground_truth_mask: np.ndarray,
) -> tuple[np.ndarray, dict[str, Any]]:
    """
    Erstellt eine pixelweise Fehlerkarte.

    Farben (RGB):
        FP = rot
        FN = blau
        TP = weiß (optional)
        TN = schwarz
    """
    pred = predicted_mask.astype(bool)
    gt = ground_truth_mask.astype(bool)

    if pred.shape != gt.shape:
        raise ValueError(
            "Prediction und Ground Truth haben unterschiedliche Größen: "
            f"Prediction={pred.shape}, Ground Truth={gt.shape}"
        )

    tp_mask = pred & gt
    fp_mask = pred & ~gt
    fn_mask = ~pred & gt
    tn_mask = ~pred & ~gt

    h, w = pred.shape
    overlay_rgb = np.zeros((h, w, 3), dtype=np.uint8)

    if SHOW_TP_IN_ERROR_OVERLAY:
        overlay_rgb[tp_mask] = (255, 255, 255)

    overlay_rgb[fp_mask] = (255, 0, 0)   # rot in RGB
    overlay_rgb[fn_mask] = (0, 0, 255)   # blau in RGB

    tp = int(np.count_nonzero(tp_mask))
    fp = int(np.count_nonzero(fp_mask))
    fn = int(np.count_nonzero(fn_mask))
    tn = int(np.count_nonzero(tn_mask))

    precision = tp / (tp + fp) if (tp + fp) else None
    recall = tp / (tp + fn) if (tp + fn) else None
    iou = tp / (tp + fp + fn) if (tp + fp + fn) else None
    dice = (2 * tp) / (2 * tp + fp + fn) if (2 * tp + fp + fn) else None

    stats = {
        "ground_truth_mask": None,
        "tp_px": tp,
        "fp_px": fp,
        "fn_px": fn,
        "tn_px": tn,
        "precision": precision,
        "recall": recall,
        "iou": iou,
        "dice": dice,
    }

    return overlay_rgb, stats


def load_image_rgb(image_path: Path) -> np.ndarray:
    image_bgr = cv2.imread(str(image_path), cv2.IMREAD_COLOR)
    if image_bgr is None:
        raise ValueError(f"Bild konnte nicht gelesen werden: {image_path}")
    return cv2.cvtColor(image_bgr, cv2.COLOR_BGR2RGB)


def preprocess_patch(patch_rgb: np.ndarray) -> np.ndarray:
    """Wie im bisherigen Code: RGB uint8 -> float32 in [0, 1]."""
    return patch_rgb.astype(np.float32) / 255.0


def get_patch_positions(length: int, patch_size: int, stride: int) -> list[int]:
    """Deckt auch den letzten Bildrand vollständig ab."""
    if length <= patch_size:
        return [0]

    positions = list(range(0, length - patch_size + 1, stride))
    last_start = length - patch_size

    if positions[-1] != last_start:
        positions.append(last_start)

    return positions


def build_weight_map(patch_size: int) -> np.ndarray:
    """Gewichtet Patchmitte stärker als Patchränder."""
    coords = np.linspace(-1.0, 1.0, patch_size, dtype=np.float32)
    weights_1d = 1.0 - np.abs(coords)
    weight = np.outer(weights_1d, weights_1d)
    return np.clip(weight, 1e-3, None).astype(np.float32)


# =============================================================================
# 8. MODELL LADEN UND INFERENZ
# =============================================================================


@tf.keras.utils.register_keras_serializable(package="crack_segmentation")
class AddPositionEmbedding(tf.keras.layers.Layer):
    """Custom Layer, der in einzelnen Segmentierungszweigen vorkommen kann."""

    def __init__(self, num_tokens, embed_dim, **kwargs):
        super().__init__(**kwargs)
        self.num_tokens = int(num_tokens)
        self.embed_dim = int(embed_dim)

    def build(self, input_shape):
        self.pos_embedding = self.add_weight(
            name="pos_embedding",
            shape=(1, self.num_tokens, self.embed_dim),
            initializer="random_normal",
            trainable=True,
            dtype=self.dtype,
        )
        super().build(input_shape)

    def call(self, x):
        return x + tf.cast(self.pos_embedding, x.dtype)

    def get_config(self):
        config = super().get_config()
        config.update({"num_tokens": self.num_tokens, "embed_dim": self.embed_dim})
        return config


# -----------------------------------------------------------------------------
# Gemeinsame / Sweep-Ensemble-Custom-Layer
# -----------------------------------------------------------------------------

@tf.keras.utils.register_keras_serializable(package="crack_ensemble")
class EnsureOneChannel(tf.keras.layers.Layer):
    def call(self, x):
        x = tf.cast(x, tf.float32)
        if x.shape.rank == 3:
            x = x[..., tf.newaxis]
        if x.shape.rank != 4:
            raise ValueError(f"Unerwarteter Segmentierungsoutput: {x.shape}")
        return x[..., :1]


@tf.keras.utils.register_keras_serializable(package="crack_ensemble")
class FixedThreshold(tf.keras.layers.Layer):
    def __init__(self, threshold: float, **kwargs):
        super().__init__(**kwargs)
        self.threshold = float(threshold)

    def call(self, x):
        return tf.cast(tf.cast(x, tf.float32) >= self.threshold, tf.float32)

    def get_config(self):
        config = super().get_config()
        config.update({"threshold": self.threshold})
        return config


@tf.keras.utils.register_keras_serializable(package="crack_ensemble")
class WeightedVote(tf.keras.layers.Layer):
    def __init__(self, weights: list[float], **kwargs):
        super().__init__(**kwargs)
        # Layer.weights ist reserviert, daher eigener Attributname.
        self.vote_weights = tuple(float(w) for w in weights)

    def call(self, inputs):
        if len(inputs) != len(self.vote_weights):
            raise ValueError("Anzahl Inputs passt nicht zu Anzahl Gewichte.")
        terms = [
            tf.cast(x, tf.float32) * w
            for x, w in zip(inputs, self.vote_weights)
        ]
        return tf.add_n(terms)

    def get_config(self):
        config = super().get_config()
        config.update({"weights": list(self.vote_weights)})
        return config


@tf.keras.utils.register_keras_serializable(package="crack_ensemble")
class ClassifierGate(tf.keras.layers.Layer):
    """Gate des Sweep-Ensembles."""

    def __init__(
        self,
        threshold: float,
        positive_class_index: int = 1,
        output_is_logits: bool = False,
        **kwargs,
    ):
        super().__init__(**kwargs)
        self.threshold = float(threshold)
        self.positive_class_index = int(positive_class_index)
        self.output_is_logits = bool(output_is_logits)

    def call(self, x):
        x = tf.cast(x, tf.float32)
        if x.shape.rank == 1:
            prob = x
            if self.output_is_logits:
                prob = tf.math.sigmoid(prob)
        elif x.shape.rank == 2:
            last_dim = x.shape[-1]
            if last_dim == 1:
                prob = x[:, 0]
                if self.output_is_logits:
                    prob = tf.math.sigmoid(prob)
            else:
                if self.output_is_logits:
                    x = tf.nn.softmax(x, axis=-1)
                prob = x[:, self.positive_class_index]
        else:
            raise ValueError(f"Classifier-Ausgabe muss Rang 1 oder 2 haben: {x.shape}")

        gate = tf.cast(prob >= self.threshold, tf.float32)
        return tf.reshape(gate, (-1, 1, 1, 1))

    def get_config(self):
        config = super().get_config()
        config.update({
            "threshold": self.threshold,
            "positive_class_index": self.positive_class_index,
            "output_is_logits": self.output_is_logits,
        })
        return config


# -----------------------------------------------------------------------------
# Custom-Layer aus ensemble_oldfusion_thresholdcentered_test
# Diese Klassen muessen beim Laden des gespeicherten .keras bereits registriert
# sein. Sonst entsteht z.B. "Could not locate class 'ClassifierProbability'".
# -----------------------------------------------------------------------------

@tf.keras.utils.register_keras_serializable(package="crack_ensemble")
class ThresholdCenteredOdds(tf.keras.layers.Layer):
    """Mappt einen individuellen Modellthreshold kontinuierlich auf 0.5."""

    def __init__(self, threshold: float, **kwargs):
        super().__init__(**kwargs)
        self.threshold = float(threshold)

    def call(self, x):
        p = tf.clip_by_value(tf.cast(x, tf.float32), 0.0, 1.0)
        t = tf.cast(self.threshold, tf.float32)
        numerator = p * (1.0 - t)
        denominator = numerator + (1.0 - p) * t
        return tf.math.divide_no_nan(numerator, denominator)

    def get_config(self):
        config = super().get_config()
        config.update({"threshold": self.threshold})
        return config


@tf.keras.utils.register_keras_serializable(package="crack_ensemble")
class ClassifierProbability(tf.keras.layers.Layer):
    def __init__(
        self,
        positive_class_index: int = 1,
        output_is_logits: bool = False,
        **kwargs,
    ):
        super().__init__(**kwargs)
        self.positive_class_index = int(positive_class_index)
        self.output_is_logits = bool(output_is_logits)

    def call(self, x):
        x = tf.cast(x, tf.float32)
        if x.shape.rank == 1:
            prob = x
            if self.output_is_logits:
                prob = tf.math.sigmoid(prob)
        elif x.shape.rank == 2:
            if x.shape[-1] == 1:
                prob = x[:, 0]
                if self.output_is_logits:
                    prob = tf.math.sigmoid(prob)
            else:
                if self.output_is_logits:
                    x = tf.nn.softmax(x, axis=-1)
                prob = x[:, self.positive_class_index]
        else:
            raise ValueError(f"Classifier-Ausgabe muss Rang 1 oder 2 haben: {x.shape}")
        prob = tf.clip_by_value(prob, 0.0, 1.0)
        return tf.reshape(prob, (-1, 1, 1, 1))

    def get_config(self):
        config = super().get_config()
        config.update({
            "positive_class_index": self.positive_class_index,
            "output_is_logits": self.output_is_logits,
        })
        return config


@tf.keras.utils.register_keras_serializable(package="crack_ensemble")
class FineDynamicWeight(tf.keras.layers.Layer):
    def __init__(self, base_weight: float, extra_weight: float, **kwargs):
        super().__init__(**kwargs)
        self.base_weight = float(base_weight)
        self.extra_weight = float(extra_weight)

    def call(self, classifier_probability):
        c = tf.cast(classifier_probability, tf.float32)
        w = self.base_weight + self.extra_weight * c
        return tf.clip_by_value(w, 0.0, 1.0)

    def get_config(self):
        config = super().get_config()
        config.update({
            "base_weight": self.base_weight,
            "extra_weight": self.extra_weight,
        })
        return config


@tf.keras.utils.register_keras_serializable(package="crack_ensemble")
class OneMinus(tf.keras.layers.Layer):
    def call(self, x):
        return 1.0 - tf.cast(x, tf.float32)


@tf.keras.utils.register_keras_serializable(package="crack_ensemble")
class WeightedBlend(tf.keras.layers.Layer):
    def call(self, inputs):
        fine, precise, fine_weight, precise_weight = inputs
        return (
            tf.cast(fine, tf.float32) * tf.cast(fine_weight, tf.float32)
            + tf.cast(precise, tf.float32) * tf.cast(precise_weight, tf.float32)
        )


@tf.keras.utils.register_keras_serializable(package="crack_ensemble")
class ClassifierDynamicThreshold(tf.keras.layers.Layer):
    def __init__(self, high: float, low: float, **kwargs):
        super().__init__(**kwargs)
        self.high = float(high)
        self.low = float(low)

    def call(self, classifier_probability):
        c = tf.cast(classifier_probability, tf.float32)
        return self.high - (self.high - self.low) * c

    def get_config(self):
        config = super().get_config()
        config.update({"high": self.high, "low": self.low})
        return config


@tf.keras.utils.register_keras_serializable(package="crack_ensemble")
class DynamicThresholdCenteredOdds(tf.keras.layers.Layer):
    """Mappt einen bildabhängigen dynamischen Threshold tensorweise auf 0.5."""

    def call(self, inputs):
        score, threshold = inputs
        p = tf.clip_by_value(tf.cast(score, tf.float32), 0.0, 1.0)
        t = tf.clip_by_value(tf.cast(threshold, tf.float32), 0.0, 1.0)
        numerator = p * (1.0 - t)
        denominator = numerator + (1.0 - p) * t
        return tf.math.divide_no_nan(numerator, denominator)


@tf.keras.utils.register_keras_serializable(package="crack_ensemble")
class ClassifierGateScore(tf.keras.layers.Layer):
    def __init__(self, threshold: float, **kwargs):
        super().__init__(**kwargs)
        self.threshold = float(threshold)

    def call(self, inputs):
        score, classifier_probability = inputs
        gate = tf.cast(
            tf.cast(classifier_probability, tf.float32) >= self.threshold,
            tf.float32,
        )
        return tf.cast(score, tf.float32) * gate

    def get_config(self):
        config = super().get_config()
        config.update({"threshold": self.threshold})
        return config


CUSTOM_OBJECTS = {
    # Segmentierungs-Custom-Objects
    "AddPositionEmbedding": AddPositionEmbedding,
    "crack_segmentation>AddPositionEmbedding": AddPositionEmbedding,

    # Gemeinsam / Sweep
    "EnsureOneChannel": EnsureOneChannel,
    "crack_ensemble>EnsureOneChannel": EnsureOneChannel,
    "FixedThreshold": FixedThreshold,
    "crack_ensemble>FixedThreshold": FixedThreshold,
    "WeightedVote": WeightedVote,
    "crack_ensemble>WeightedVote": WeightedVote,
    "ClassifierGate": ClassifierGate,
    "crack_ensemble>ClassifierGate": ClassifierGate,

    # Old-Fusion
    "ThresholdCenteredOdds": ThresholdCenteredOdds,
    "crack_ensemble>ThresholdCenteredOdds": ThresholdCenteredOdds,
    "ClassifierProbability": ClassifierProbability,
    "crack_ensemble>ClassifierProbability": ClassifierProbability,
    "FineDynamicWeight": FineDynamicWeight,
    "crack_ensemble>FineDynamicWeight": FineDynamicWeight,
    "OneMinus": OneMinus,
    "crack_ensemble>OneMinus": OneMinus,
    "WeightedBlend": WeightedBlend,
    "crack_ensemble>WeightedBlend": WeightedBlend,
    "ClassifierDynamicThreshold": ClassifierDynamicThreshold,
    "crack_ensemble>ClassifierDynamicThreshold": ClassifierDynamicThreshold,
    "DynamicThresholdCenteredOdds": DynamicThresholdCenteredOdds,
    "crack_ensemble>DynamicThresholdCenteredOdds": DynamicThresholdCenteredOdds,
    "ClassifierGateScore": ClassifierGateScore,
    "crack_ensemble>ClassifierGateScore": ClassifierGateScore,

    # Keras-Application preprocess_input aliases, die in verschachtelten Modellen
    # serialisiert sein koennen.
    "preprocess_input": mobilenet_v2_preprocess_input,
    "mobilenetv2_preprocess_input": mobilenet_v2_preprocess_input,
    "mobilenet_v2_preprocess_input": mobilenet_v2_preprocess_input,
    "resnet50_preprocess_input": resnet50_preprocess_input,
    "efficientnet_preprocess_input": efficientnet_preprocess_input,
    "xception_preprocess_input": xception_preprocess_input,
    "vgg16_preprocess_input": vgg16_preprocess_input,
    "vgg19_preprocess_input": vgg19_preprocess_input,
    "densenet_preprocess_input": densenet_preprocess_input,
}

def load_model(model_path: Path) -> tf.keras.Model:
    """
    Lädt klassische Segmentierungsmodelle sowie beide unterstützten Ensemble-Typen.

    Wichtig: Eine TypeError aus der eigentlichen Keras-Deserialisierung ist NICHT
    automatisch ein Hinweis auf eine alte Keras-Version. Nur wenn die Fehlermeldung
    explizit zeigt, dass safe_mode als Argument unbekannt ist, wird ohne safe_mode
    erneut geladen.
    """
    model_path = Path(model_path).expanduser().resolve()
    if not model_path.is_file():
        raise FileNotFoundError(f"Modell nicht gefunden: {model_path}")

    common_kwargs = {
        "compile": False,
        "custom_objects": CUSTOM_OBJECTS,
    }

    try:
        return tf.keras.models.load_model(
            str(model_path),
            safe_mode=False,
            **common_kwargs,
        )
    except TypeError as exc:
        msg = str(exc).casefold()
        safe_mode_unsupported = (
            "safe_mode" in msg
            and (
                "unexpected keyword" in msg
                or "unexpected argument" in msg
                or "got an unexpected" in msg
                or "unrecognized" in msg
            )
        )
        if safe_mode_unsupported:
            try:
                return tf.keras.models.load_model(
                    str(model_path),
                    **common_kwargs,
                )
            except Exception as fallback_exc:
                raise RuntimeError(
                    "Modell konnte auch ohne safe_mode nicht geladen werden. "
                    "Die bekannten Custom-Layer des Sweep- und Old-Fusion-Ensembles "
                    "sind registriert.\n"
                    f"Modell: {model_path}\nOriginalfehler: {fallback_exc}"
                ) from fallback_exc

        raise RuntimeError(
            "Keras konnte das Modell nicht deserialisieren. Die bekannten Custom-Layer "
            "des Sweep- und Old-Fusion-Ensembles sind registriert.\n"
            f"Modell: {model_path}\nOriginalfehler: {exc}"
        ) from exc
    except Exception as exc:
        raise RuntimeError(
            "Modell konnte nicht geladen werden. Die bekannten Custom-Layer des "
            "Sweep- und Old-Fusion-Ensembles sind registriert; der folgende Fehler "
            "stammt vom eigentlichen Keras-Ladevorgang.\n"
            f"Modell: {model_path}\nOriginalfehler: {exc}"
        ) from exc

def infer_square_model_input_size(model: tf.keras.Model) -> int:
    """Liest eine feste quadratische Eingabegröße direkt aus dem geladenen Modell."""
    shape = model.input_shape
    if isinstance(shape, dict):
        if len(shape) != 1:
            raise ValueError(f"Mehrere Modelleingänge werden nicht unterstützt: {shape}")
        shape = next(iter(shape.values()))
    if isinstance(shape, list):
        if len(shape) != 1:
            raise ValueError(f"Mehrere Modelleingänge werden nicht unterstützt: {shape}")
        shape = shape[0]

    if not isinstance(shape, (list, tuple)) or len(shape) != 4:
        raise ValueError(f"Unerwartete model.input_shape: {shape}")
    if shape[1] is None or shape[2] is None:
        if PATCH_SIZE_FALLBACK is not None:
            return int(PATCH_SIZE_FALLBACK)
        raise ValueError(
            f"Eingabegröße ist dynamisch und PATCH_SIZE_FALLBACK ist None: {shape}"
        )

    h = int(shape[1])
    w = int(shape[2])
    if h != w:
        raise ValueError(f"Nicht-quadratischer Modellinput wird nicht unterstützt: {shape}")
    return h


def _direct_model_run_dir(model_path: Path) -> Path:
    """Leitet für den Output möglichst den zugehörigen Run-Ordner ab."""
    model_path = model_path.expanduser().resolve()
    if model_path.parent.name.casefold() == "models":
        return model_path.parent.parent
    return model_path.parent


def _model_output_dict_keys(model: tf.keras.Model) -> set[str]:
    output = model.output
    if isinstance(output, dict):
        return {str(k).casefold() for k in output.keys()}
    return set()


def detect_direct_ensemble_kind(model: tf.keras.Model) -> str:
    """
    Erkennt die unterstützte exportierte Ensemble-Art.

    Rückgabe:
      - "sweep_binary_mask": Ensemble mit explizitem finalem binary_mask-Ausgang
      - "oldfusion_decision_score": Old-Fusion-Deployable mit kontinuierlichem
        Decision-Score, dessen finale Entscheidung bei 0.5 liegt
      - "unknown": kein unterstütztes direktes Ensemble erkannt
    """
    output_keys = _model_output_dict_keys(model)
    output_names = {
        str(name).casefold()
        for name in (getattr(model, "output_names", None) or [])
    }
    layer_names = {layer.name.casefold() for layer in model.layers}
    class_names = {layer.__class__.__name__.casefold() for layer in model.layers}

    # Sweep-Ensemble bzw. diagnostischer Old-Fusion-Wrapper mit explizitem
    # binary_mask: Der fertige binäre Ausgang hat immer Vorrang.
    if "binary_mask" in output_keys:
        return "sweep_binary_mask"
    if any("binary_mask" in name for name in output_names):
        return "sweep_binary_mask"
    if "ensemble_decision_threshold" in layer_names:
        return "sweep_binary_mask"
    if "final_binary_mask_threshold_0p5" in layer_names and "binary_mask" in output_keys:
        return "sweep_binary_mask"

    # Das deploybare ensemble_oldfusion_thresholdcentered_test-Modell wird mit
    # outputs=classifier_gate.output gespeichert. Es enthält daher keinen
    # binary_mask-Ausgang, sondern den bereits threshold-zentrierten und gegateten
    # kontinuierlichen Decision-Score. Starke Marker sind die eigens serialisierten
    # Old-Fusion-Layer.
    oldfusion_markers = {
        "classifierprobability",
        "thresholdcenteredodds",
        "finedynamicweight",
        "classifierdynamicthreshold",
        "dynamicthresholdcenteredodds",
        "classifiergatescore",
    }
    marker_hits = oldfusion_markers.intersection(class_names)
    if "classifiergatescore" in class_names and "dynamicthresholdcenteredodds" in class_names:
        return "oldfusion_decision_score"
    if len(marker_hits) >= 3 and (
        "classifier_gate" in layer_names
        or any("classifier_gate" in name for name in output_names)
    ):
        return "oldfusion_decision_score"

    # Zusätzlicher Namens-Fallback für Modelle aus genau diesem Exportcode.
    model_name = str(getattr(model, "name", "")).casefold()
    if "deployable_ensemble" in model_name and "classifier_gate" in layer_names:
        return "oldfusion_decision_score"

    return "unknown"


def is_exported_ensemble_model(model: tf.keras.Model) -> bool:
    """Kompatibilitätshelper für unterstützte direkte Ensemble-Modelle."""
    return detect_direct_ensemble_kind(model) != "unknown"


def discover_direct_model_info(
    model_path: Path,
    model: tf.keras.Model,
) -> AutoRunInfo:
    """Konfiguration für MODEL_PATH ohne metrics/architecture/threshold_results2."""
    model_path = model_path.expanduser().resolve()
    patch_size = infer_square_model_input_size(model)
    ensemble_kind = detect_direct_ensemble_kind(model)

    if ensemble_kind == "unknown":
        class_names = sorted({layer.__class__.__name__ for layer in model.layers})
        output_names = list(getattr(model, "output_names", []) or [])
        raise ValueError(
            "MODEL_PATH wurde gesetzt, das geladene Modell wurde aber nicht als "
            "unterstütztes exportiertes Ensemble erkannt. Unterstützt werden "
            "ensemble_validation_sweep_test_metrics und "
            "ensemble_oldfusion_thresholdcentered_test. "
            f"Modelname={getattr(model, 'name', None)!r}, "
            f"output_names={output_names}, Custom-Layer={class_names}. "
            "Für klassische Einzelmodelle bitte MODEL_PATH=None lassen und RUN_DIR "
            "verwenden, damit der externe Threshold korrekt geladen wird."
        )

    run_dir = _direct_model_run_dir(model_path)
    run_name = run_dir.name if run_dir.name else model_path.stem

    if ensemble_kind == "sweep_binary_mask":
        return AutoRunInfo(
            source_mode="direct_ensemble_model_sweep_binary_mask",
            run_name=run_name,
            run_dir=str(run_dir),
            metrics_file=None,
            best_epoch=None,
            architecture_config_file=None,
            patch_size=patch_size,
            model_file=str(model_path),
            segmentation_threshold=None,
            threshold_source_file=None,
            threshold_selection_rule=(
                "kein externer Threshold: finaler 'binary_mask'-Ausgang des Ensemble-Modells"
            ),
            model_output_mode="binary_mask",
            model_output_name="binary_mask",
        )

    # ensemble_oldfusion_thresholdcentered_test:
    # Im gespeicherten deploybaren Modell sind Einzelmodellthresholds, dynamischer
    # classifier-gesteuerter Threshold und Gate bereits enthalten. Der Exportcode
    # definiert den resultierenden Decision-Score so, dass die finale Maske exakt
    # bei 0.5 entsteht. Das ist KEIN aus threshold_results2 nachzuladender Threshold.
    return AutoRunInfo(
        source_mode="direct_ensemble_model_oldfusion_decision_score",
        run_name=run_name,
        run_dir=str(run_dir),
        metrics_file=None,
        best_epoch=None,
        architecture_config_file=None,
        patch_size=patch_size,
        model_file=str(model_path),
        segmentation_threshold=0.5,
        threshold_source_file=None,
        threshold_selection_rule=(
            "Old-Fusion-Exportsemantik: alle internen/dynamischen Thresholds im Modell; "
            "finale Maske = decision_score >= 0.5"
        ),
        model_output_mode="decision_score",
        model_output_name=None,
    )

def sigmoid(x: np.ndarray) -> np.ndarray:
    return 1.0 / (1.0 + np.exp(-x))


def softmax(x: np.ndarray, axis: int = -1) -> np.ndarray:
    x = x - np.max(x, axis=axis, keepdims=True)
    e = np.exp(x)
    return e / np.sum(e, axis=axis, keepdims=True)


def extract_prediction_output(
    model: tf.keras.Model,
    y_pred: Any,
    output_mode: str,
    output_name: Optional[str],
) -> Any:
    """Wählt bei Multi-Output-Ensembles den für die Rissmessung relevanten Ausgang."""
    if isinstance(y_pred, dict):
        if output_name is not None:
            for key, value in y_pred.items():
                if str(key).casefold() == output_name.casefold():
                    return value
        if output_mode == "binary_mask":
            for key, value in y_pred.items():
                if str(key).casefold() == "binary_mask":
                    return value
        if len(y_pred) == 1:
            return next(iter(y_pred.values()))
        raise ValueError(
            "Das Modell liefert mehrere Dict-Ausgänge, aber der gewünschte Ausgang "
            f"'{output_name}' wurde nicht gefunden. Vorhanden: {list(y_pred.keys())}"
        )

    if isinstance(y_pred, (list, tuple)):
        if len(y_pred) == 1:
            return y_pred[0]

        names = list(getattr(model, "output_names", []) or [])
        if output_mode == "binary_mask":
            for i, name in enumerate(names):
                name_cf = str(name).casefold()
                if "binary_mask" in name_cf or "ensemble_decision_threshold" in name_cf:
                    return y_pred[i]
        if output_mode == "decision_score":
            for i, name in enumerate(names):
                name_cf = str(name).casefold()
                if "decision_score" in name_cf or "classifier_gate" in name_cf:
                    return y_pred[i]

        raise ValueError(
            "Das Modell liefert mehrere Ausgänge; der gewünschte CRACK-Ausgang "
            "konnte nicht eindeutig zugeordnet werden."
        )

    return y_pred


def normalize_model_output(
    y_pred: Any,
    patch_size: int,
    output_mode: str,
) -> np.ndarray:
    """Normalisiert Keras-Ausgaben auf [B, H, W]."""
    arr = np.asarray(y_pred)

    if arr.ndim == 4:
        if arr.shape[-1] == 1:
            values = arr[..., 0]
        else:
            if output_mode == "binary_mask":
                raise ValueError(
                    "Der Ensemble-Ausgang 'binary_mask' muss genau einen Kanal haben; "
                    f"erhalten: {arr.shape}."
                )
            if CRACK_CLASS_INDEX < 0 or CRACK_CLASS_INDEX >= arr.shape[-1]:
                raise IndexError(
                    f"CRACK_CLASS_INDEX={CRACK_CLASS_INDEX} passt nicht zu "
                    f"Modellausgabe {arr.shape}."
                )
            values_all = arr
            if values_all.min() < 0.0 or values_all.max() > 1.0:
                values_all = softmax(values_all, axis=-1)
            values = values_all[..., CRACK_CLASS_INDEX]

    elif arr.ndim == 3:
        values = arr
    else:
        raise ValueError(f"Unerwartete Modellausgabe: shape={arr.shape}")

    values = np.asarray(values, dtype=np.float32)

    # Nur nicht-binäre Outputs ggf. von Logits in [0,1] wandeln. Der Old-Fusion-
    # decision_score liegt bereits in [0,1]; dadurch wird hier nichts verändert.
    # Der binary_mask-Ausgang ist bereits vollständig thresholded.
    if output_mode != "binary_mask":
        if values.min() < 0.0 or values.max() > 1.0:
            values = sigmoid(values)

    if values.shape[1] != patch_size or values.shape[2] != patch_size:
        resized = np.empty((values.shape[0], patch_size, patch_size), dtype=np.float32)
        interpolation = cv2.INTER_NEAREST if output_mode == "binary_mask" else cv2.INTER_LINEAR
        for i in range(values.shape[0]):
            resized[i] = cv2.resize(
                values[i],
                (patch_size, patch_size),
                interpolation=interpolation,
            )
        values = resized

    return np.clip(values, 0.0, 1.0)


def run_model_batch(
    model: tf.keras.Model,
    batch_patches: list[np.ndarray],
    patch_size: int,
    output_mode: str,
    output_name: Optional[str],
) -> np.ndarray:
    x = np.stack(batch_patches, axis=0).astype(np.float32)
    y_pred = model.predict(x, verbose=0)
    selected = extract_prediction_output(model, y_pred, output_mode, output_name)
    return normalize_model_output(selected, patch_size, output_mode)

def stitch_batch_weighted(
    prob_sum: np.ndarray,
    weight_sum: np.ndarray,
    probs: np.ndarray,
    batch_meta: list[tuple[int, int, int, int]],
    weight_2d: np.ndarray,
    patch_size: int,
    image_h: int,
    image_w: int,
) -> None:
    for i, (x, y, original_h, original_w) in enumerate(batch_meta):
        valid_h = min(patch_size, image_h - y, original_h)
        valid_w = min(patch_size, image_w - x, original_w)

        pred_valid = probs[i][:valid_h, :valid_w]
        weight_valid = weight_2d[:valid_h, :valid_w]

        prob_sum[y:y + valid_h, x:x + valid_w] += pred_valid * weight_valid
        weight_sum[y:y + valid_h, x:x + valid_w] += weight_valid


def infer_full_image(
    model: tf.keras.Model,
    image_rgb: np.ndarray,
    patch_size: int,
    output_mode: str,
    output_name: Optional[str],
) -> np.ndarray:
    """Patch-Inferenz mit Overlap und gewichteter Überblendung."""
    if OVERLAP >= patch_size:
        raise ValueError(
            f"OVERLAP ({OVERLAP}) muss kleiner als PATCH_SIZE ({patch_size}) sein."
        )

    stride = patch_size - OVERLAP
    h, w = image_rgb.shape[:2]

    y_positions = get_patch_positions(h, patch_size, stride)
    x_positions = get_patch_positions(w, patch_size, stride)
    weight_2d = build_weight_map(patch_size)

    prob_sum = np.zeros((h, w), dtype=np.float32)
    weight_sum = np.zeros((h, w), dtype=np.float32)

    batch_patches: list[np.ndarray] = []
    batch_meta: list[tuple[int, int, int, int]] = []

    for y in y_positions:
        for x in x_positions:
            patch = image_rgb[y:y + patch_size, x:x + patch_size]
            ph, pw = patch.shape[:2]

            if ph != patch_size or pw != patch_size:
                padded = np.zeros((patch_size, patch_size, 3), dtype=patch.dtype)
                padded[:ph, :pw] = patch
                patch = padded

            batch_patches.append(preprocess_patch(patch))
            batch_meta.append((x, y, ph, pw))

            if len(batch_patches) >= INFERENCE_BATCH_SIZE:
                probs = run_model_batch(
                    model, batch_patches, patch_size, output_mode, output_name
                )
                stitch_batch_weighted(
                    prob_sum,
                    weight_sum,
                    probs,
                    batch_meta,
                    weight_2d,
                    patch_size,
                    h,
                    w,
                )
                batch_patches.clear()
                batch_meta.clear()

    if batch_patches:
        probs = run_model_batch(
            model, batch_patches, patch_size, output_mode, output_name
        )
        stitch_batch_weighted(
            prob_sum,
            weight_sum,
            probs,
            batch_meta,
            weight_2d,
            patch_size,
            h,
            w,
        )

    probability = prob_sum / np.maximum(weight_sum, 1e-8)
    return np.clip(probability, 0.0, 1.0).astype(np.float32)


# =============================================================================
# 9. BINÄRMASKE UND RISSANALYSE
# =============================================================================


def postprocess_mask(
    prediction_map: np.ndarray,
    threshold: Optional[float],
    output_mode: str,
) -> np.ndarray:
    if output_mode == "binary_mask":
        # Das Sweep-Ensemble hat bereits final thresholded. Bei exakt einem 512x512-Patch
        # besteht prediction_map aus 0/1. Nur bei überlappender Patch-Inferenz können
        # durch das Stitching Zwischenwerte entstehen; >=0.5 ist dann lediglich die
        # Mehrheitsentscheidung der überlappenden bereits-binären Patchmasken.
        mask = prediction_map >= 0.5
    elif output_mode == "decision_score":
        # Old-Fusion: Einzelmodellthresholds, classifier-gesteuerter dynamischer
        # Endthreshold und Gate sind bereits in den exportierten Decision-Score
        # eingerechnet/auf 0.5 zentriert. Laut Exportsemantik gilt final exakt >= 0.5.
        mask = prediction_map >= 0.5
    else:
        if threshold is None:
            raise ValueError("Für einen Probability-Output fehlt der Segmentierungs-Threshold.")
        mask = prediction_map >= float(threshold)

    if MIN_OBJECT_AREA > 0:
        mask = remove_small_objects(mask, min_size=MIN_OBJECT_AREA)

    if REMOVE_HOLES_AREA > 0:
        mask = remove_small_holes(mask, area_threshold=REMOVE_HOLES_AREA)

    return mask.astype(bool)


def compute_skeleton_length(skeleton: np.ndarray) -> float:
    """
    Geometrische Länge des Skeletts in Pixeln.

    Horizontal/vertikal verbundene Skelettpixel zählen mit 1 px,
    diagonale Verbindungen mit sqrt(2) px. Jede Verbindung wird einmal gezählt.
    """
    skel = skeleton.astype(bool)
    count = int(np.count_nonzero(skel))

    if count == 0:
        return 0.0
    if count == 1:
        return 1.0

    h, w = skel.shape
    length = 0.0

    directions = (
        (0, 1, 1.0),
        (1, 0, 1.0),
        (1, 1, math.sqrt(2.0)),
        (1, -1, math.sqrt(2.0)),
    )

    for dy, dx, weight in directions:
        y1_start = max(0, -dy)
        y1_end = min(h, h - dy)
        x1_start = max(0, -dx)
        x1_end = min(w, w - dx)

        y2_start = y1_start + dy
        y2_end = y1_end + dy
        x2_start = x1_start + dx
        x2_end = x1_end + dx

        connected = (
            skel[y1_start:y1_end, x1_start:x1_end]
            & skel[y2_start:y2_end, x2_start:x2_end]
        )

        length += float(np.count_nonzero(connected)) * weight

    return float(length)


def trigger_from_median(median_width_px: Optional[float]) -> tuple[str, str]:
    """Dreistufige Triggerlogik anhand des Medianwerts."""
    if median_width_px is None:
        return "UNGUELTIG", "gray"

    if median_width_px < TRIGGER_RED_MAX_PX:
        return "ROT", "red"

    if median_width_px < TRIGGER_GREEN_MIN_PX:
        return "ORANGE", "orange"

    return "GRUEN", "green"


def analyze_one_region(
    labeled: np.ndarray,
    region_label: int,
    crack_id: int,
    bbox: tuple[int, int, int, int],
    centroid_yx: tuple[float, float],
    area_px: int,
) -> CrackAnalysisPayload:
    """Worker-Funktion für einen einzelnen zusammenhängenden Riss."""
    minr, minc, maxr, maxc = bbox
    region_mask = labeled[minr:maxr, minc:maxc] == region_label

    skeleton = skeletonize(region_mask)
    distance = distance_transform_edt(region_mask)
    local_widths = 2.0 * distance[skeleton]

    skeleton_points = int(np.count_nonzero(skeleton))
    length_px = compute_skeleton_length(skeleton)

    if skeleton_points < MIN_SKELETON_POINTS or local_widths.size == 0:
        min_width = None
        max_width = None
        mean_width = None
        median_width = None
    else:
        min_width = float(np.min(local_widths))
        max_width = float(np.max(local_widths))
        mean_width = float(np.mean(local_widths))
        median_width = float(np.median(local_widths))

    trigger_level, trigger_color = trigger_from_median(median_width)

    centroid_y, centroid_x = centroid_yx

    result = CrackResult(
        crack_id=crack_id,
        bbox_xyxy=(int(minc), int(minr), int(maxc), int(maxr)),
        centroid_xy=(float(centroid_x), float(centroid_y)),
        area_px=int(area_px),
        length_px=float(length_px),
        skeleton_points=skeleton_points,
        min_width_px=min_width,
        max_width_px=max_width,
        mean_width_px=mean_width,
        median_width_px=median_width,
        trigger_level=trigger_level,
        trigger_color=trigger_color,
    )

    local_y, local_x = np.nonzero(skeleton)

    return CrackAnalysisPayload(
        result=result,
        skeleton_y_global=local_y.astype(np.int32) + int(minr),
        skeleton_x_global=local_x.astype(np.int32) + int(minc),
    )


def analyze_cracks_parallel(
    mask_bool: np.ndarray,
    max_workers: int,
) -> tuple[list[CrackResult], np.ndarray, np.ndarray]:
    """
    Analysiert zusammenhängende Risse parallel.

    Rückgabe:
    - sortierte CrackResult-Liste
    - Gesamt-Skelettmaske
    - Labelbild der Komponenten
    """
    labeled = label(mask_bool, connectivity=2)
    props = regionprops(labeled)

    skeleton_full = np.zeros(mask_bool.shape, dtype=bool)

    if not props:
        return [], skeleton_full, labeled

    jobs: list[tuple[int, int, tuple[int, int, int, int], tuple[float, float], int]] = []

    for crack_id, region in enumerate(props, start=1):
        jobs.append(
            (
                int(region.label),
                crack_id,
                tuple(int(v) for v in region.bbox),
                (float(region.centroid[0]), float(region.centroid[1])),
                int(region.area),
            )
        )

    worker_count = min(max_workers, len(jobs))

    if worker_count <= 1:
        payloads = [
            analyze_one_region(labeled, region_label, crack_id, bbox, centroid, area)
            for region_label, crack_id, bbox, centroid, area in jobs
        ]
    else:
        with ThreadPoolExecutor(max_workers=worker_count) as executor:
            futures = [
                executor.submit(
                    analyze_one_region,
                    labeled,
                    region_label,
                    crack_id,
                    bbox,
                    centroid,
                    area,
                )
                for region_label, crack_id, bbox, centroid, area in jobs
            ]
            payloads = [future.result() for future in futures]

    payloads.sort(key=lambda item: item.result.crack_id)

    results: list[CrackResult] = []
    for payload in payloads:
        results.append(payload.result)
        skeleton_full[payload.skeleton_y_global, payload.skeleton_x_global] = True

    return results, skeleton_full, labeled


# =============================================================================
# 10. VISUALISIERUNG
# =============================================================================


TRIGGER_COLORS_RGB: dict[str, tuple[int, int, int]] = {
    "ROT": (255, 0, 0),
    "ORANGE": (255, 165, 0),
    "GRUEN": (0, 200, 0),
    "UNGUELTIG": (160, 160, 160),
}


def create_annotated_image(
    image_rgb: np.ndarray,
    mask_bool: np.ndarray,
    results: list[CrackResult],
) -> np.ndarray:
    """Originalbild + Maskenoverlay + triggerfarbene Bounding Boxes."""
    vis = image_rgb.copy()

    if np.any(mask_bool):
        overlay = vis.copy()
        overlay[mask_bool] = (255, 255, 0)
        alpha = float(np.clip(MASK_OVERLAY_ALPHA, 0.0, 1.0))
        vis = cv2.addWeighted(overlay, alpha, vis, 1.0 - alpha, 0.0)

    for crack in results:
        x1, y1, x2, y2 = crack.bbox_xyxy
        color = TRIGGER_COLORS_RGB[crack.trigger_level]

        cv2.rectangle(vis, (x1, y1), (max(x1, x2 - 1), max(y1, y2 - 1)), color, 2)

        median_text = (
            f"{crack.median_width_px:.2f}px"
            if crack.median_width_px is not None
            else "n/a"
        )
        mean_text = (
            f"{crack.mean_width_px:.2f}px"
            if crack.mean_width_px is not None
            else "n/a"
        )

        line1 = f"ID {crack.crack_id} {crack.trigger_level} | Med={median_text} Mean={mean_text}"
        line2 = f"L={crack.length_px:.1f}px A={crack.area_px}px2"

        text_y1 = max(18, y1 - 24)
        text_y2 = max(36, y1 - 7)

        cv2.putText(
            vis,
            line1,
            (x1, text_y1),
            cv2.FONT_HERSHEY_SIMPLEX,
            0.50,
            color,
            2,
            cv2.LINE_AA,
        )
        cv2.putText(
            vis,
            line2,
            (x1, text_y2),
            cv2.FONT_HERSHEY_SIMPLEX,
            0.50,
            color,
            2,
            cv2.LINE_AA,
        )

    return vis


def create_trigger_map(
    mask_bool: np.ndarray,
    labeled: np.ndarray,
    results: list[CrackResult],
) -> np.ndarray:
    """Jeder Riss wird vollständig entsprechend seines Median-Triggers eingefärbt."""
    rgb = np.zeros((*mask_bool.shape, 3), dtype=np.uint8)

    for crack in results:
        color = TRIGGER_COLORS_RGB[crack.trigger_level]
        rgb[labeled == crack.crack_id] = color

    return rgb


def create_skeleton_image(mask_bool: np.ndarray, skeleton_bool: np.ndarray) -> np.ndarray:
    """Maske grau/weiß, Skelett rot."""
    rgb = np.zeros((*mask_bool.shape, 3), dtype=np.uint8)
    rgb[mask_bool] = (220, 220, 220)
    rgb[skeleton_bool] = (255, 0, 0)
    return rgb


# =============================================================================
# 11. REPORTS / DATEIEN SPEICHERN
# =============================================================================


def save_rgb_image(path: Path, image_rgb: np.ndarray) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    bgr = cv2.cvtColor(image_rgb, cv2.COLOR_RGB2BGR)
    if not cv2.imwrite(str(path), bgr):
        raise IOError(f"Bild konnte nicht gespeichert werden: {path}")


def save_probability_map(path: Path, probability_map: np.ndarray) -> None:
    img = np.clip(probability_map * 255.0, 0, 255).astype(np.uint8)
    if not cv2.imwrite(str(path), img):
        raise IOError(f"Probability Map konnte nicht gespeichert werden: {path}")


def save_binary_mask(path: Path, mask_bool: np.ndarray) -> None:
    img = mask_bool.astype(np.uint8) * 255
    if not cv2.imwrite(str(path), img):
        raise IOError(f"Binärmaske konnte nicht gespeichert werden: {path}")


def crack_result_to_dict(result: CrackResult) -> dict[str, Any]:
    return json_safe(asdict(result))


def write_crack_csv(path: Path, results: list[CrackResult]) -> None:
    fieldnames = [
        "crack_id",
        "trigger_level",
        "trigger_color",
        "min_width_px",
        "max_width_px",
        "mean_width_px",
        "median_width_px",
        "length_px",
        "area_px",
        "skeleton_points",
        "bbox_xyxy",
        "centroid_xy",
    ]

    with path.open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()
        for result in results:
            row = crack_result_to_dict(result)
            row["bbox_xyxy"] = json.dumps(row["bbox_xyxy"])
            row["centroid_xy"] = json.dumps(row["centroid_xy"])
            writer.writerow({key: row.get(key) for key in fieldnames})


def build_crack_report(
    image_path: Path,
    results: list[CrackResult],
    mask_bool: np.ndarray,
) -> dict[str, Any]:
    valid = [r for r in results if r.median_width_px is not None]

    trigger_counts = {
        "ROT": sum(r.trigger_level == "ROT" for r in results),
        "ORANGE": sum(r.trigger_level == "ORANGE" for r in results),
        "GRUEN": sum(r.trigger_level == "GRUEN" for r in results),
        "UNGUELTIG": sum(r.trigger_level == "UNGUELTIG" for r in results),
    }

    summary = {
        "image_name": image_path.name,
        "image_path": str(image_path),
        "crack_count": len(results),
        "valid_width_measurement_count": len(valid),
        "total_crack_area_px": int(np.count_nonzero(mask_bool)),
        "total_crack_length_px": float(sum(r.length_px for r in results)),
        "trigger_counts": trigger_counts,
    }

    if valid:
        medians = np.array([r.median_width_px for r in valid], dtype=np.float64)
        summary["mean_of_crack_medians_px"] = float(np.mean(medians))
        summary["median_of_crack_medians_px"] = float(np.median(medians))
    else:
        summary["mean_of_crack_medians_px"] = None
        summary["median_of_crack_medians_px"] = None

    return {
        "summary": summary,
        "cracks": [crack_result_to_dict(r) for r in results],
    }


def write_crack_txt(path: Path, report: dict[str, Any]) -> None:
    lines: list[str] = []
    summary = report["summary"]

    lines.append("RISSREPORT")
    lines.append("=" * 80)
    lines.append("")
    lines.append(f"Bild: {summary['image_name']}")
    lines.append(f"Pfad: {summary['image_path']}")
    lines.append(f"Anzahl Risse: {summary['crack_count']}")
    lines.append(f"Gesamt-Rissfläche: {summary['total_crack_area_px']} px²")
    lines.append(f"Gesamt-Risslänge: {summary['total_crack_length_px']:.3f} px")
    lines.append("")

    for crack in report["cracks"]:
        lines.append("-" * 80)
        lines.append(f"Riss-ID: {crack['crack_id']}")
        lines.append(f"Trigger: {crack['trigger_level']}")
        lines.append(f"Min. Rissbreite [px]: {format_optional(crack['min_width_px'])}")
        lines.append(f"Max. Rissbreite [px]: {format_optional(crack['max_width_px'])}")
        lines.append(
            "Durchschnittliche Rissbreite [px]: "
            f"{format_optional(crack['mean_width_px'])}"
        )
        lines.append(f"Rissbreitenmedian [px]: {format_optional(crack['median_width_px'])}")
        lines.append(f"Risslänge [px]: {float(crack['length_px']):.3f}")
        lines.append(f"Rissfläche [px²]: {crack['area_px']}")
        lines.append(f"Skelettpunkte: {crack['skeleton_points']}")
        lines.append(f"Bounding Box xyxy: {crack['bbox_xyxy']}")
        lines.append("")

    path.write_text("\n".join(lines), encoding="utf-8")


def format_optional(value: Any) -> str:
    if value is None:
        return "n/a"
    return f"{float(value):.3f}"


def build_configuration_log(
    auto: AutoRunInfo,
    thread_config: dict[str, int],
    image_path: Optional[Path] = None,
    output_dir: Optional[Path] = None,
) -> dict[str, Any]:
    """Alle relevanten automatischen und manuellen Variablen in einem Log."""
    return {
        "created_at": now_iso(),
        "run": {
            "source_mode": auto.source_mode,
            "run_name": auto.run_name,
            "run_dir": auto.run_dir,
            "metrics_file": auto.metrics_file,
            "best_epoch": auto.best_epoch,
            "model_file": auto.model_file,
            "architecture_config_file": auto.architecture_config_file,
            "patch_size_auto": auto.patch_size,
            "threshold_source_file": auto.threshold_source_file,
            "threshold_selection_rule": auto.threshold_selection_rule,
            "segmentation_threshold": auto.segmentation_threshold,
            "model_output_mode": auto.model_output_mode,
            "model_output_name": auto.model_output_name,
        },
        "input_output": {
            "image_dir": str(IMAGE_DIR.expanduser().resolve()),
            "image_path": str(image_path) if image_path else None,
            "output_root": str(Path(auto.run_dir) / OUTPUT_ROOT_NAME),
            "output_dir": str(output_dir) if output_dir else None,
            "recursive_image_search": RECURSIVE_IMAGE_SEARCH,
            "image_extensions": list(IMAGE_EXTENSIONS),
        },
        "inference": {
            "patch_size": auto.patch_size,
            "overlap": OVERLAP,
            "stride": auto.patch_size - OVERLAP,
            "inference_batch_size": INFERENCE_BATCH_SIZE,
            "crack_class_index": CRACK_CLASS_INDEX,
            "use_automatic_segmentation_threshold": USE_AUTOMATIC_SEGMENTATION_THRESHOLD,
            "manual_segmentation_threshold": MANUAL_SEGMENTATION_THRESHOLD,
            "segmentation_threshold_fallback": SEGMENTATION_THRESHOLD_FALLBACK,
            "effective_segmentation_threshold": auto.segmentation_threshold,
            "model_output_mode": auto.model_output_mode,
            "model_output_name": auto.model_output_name,
            "embedded_ensemble_threshold": auto.model_output_mode in {"binary_mask", "decision_score"},
            "final_decision_rule": (
                "binary_mask direct; overlapping binary patches use weighted consensus >= 0.5"
                if auto.model_output_mode == "binary_mask"
                else "Old-Fusion decision_score >= 0.5; internal model/dynamic thresholds already embedded"
                if auto.model_output_mode == "decision_score"
                else f"probability >= {auto.segmentation_threshold}"
            ),
        },
        "mask_postprocessing": {
            "min_object_area": MIN_OBJECT_AREA,
            "remove_holes_area": REMOVE_HOLES_AREA,
            "min_skeleton_points": MIN_SKELETON_POINTS,
        },
        "trigger_logic": {
            "red_rule": f"median_width_px < {TRIGGER_RED_MAX_PX}",
            "orange_rule": (
                f"{TRIGGER_RED_MAX_PX} <= median_width_px < "
                f"{TRIGGER_GREEN_MIN_PX}"
            ),
            "green_rule": f"median_width_px >= {TRIGGER_GREEN_MIN_PX}",
            "trigger_red_max_px": TRIGGER_RED_MAX_PX,
            "trigger_green_min_px": TRIGGER_GREEN_MIN_PX,
        },
        "parallelism": thread_config,
        "output_settings": {
            "output_root_name": OUTPUT_ROOT_NAME,
            "mask_overlay_alpha": MASK_OVERLAY_ALPHA,
            "save_probability_npy": SAVE_PROBABILITY_NPY,
            "ground_truth_mask_subdir": GROUND_TRUTH_MASK_SUBDIR,
            "ground_truth_mask_threshold": GROUND_TRUTH_MASK_THRESHOLD,
            "show_tp_in_error_overlay": SHOW_TP_IN_ERROR_OVERLAY,
        },
        "software": {
            "python": sys.version,
            "tensorflow": tf.__version__,
            "opencv": cv2.__version__,
            "numpy": np.__version__,
        },
    }


# =============================================================================
# 12. EIN BILD VERARBEITEN
# =============================================================================


def process_one_image(
    model: tf.keras.Model,
    image_path: Path,
    image_output_dir: Path,
    auto: AutoRunInfo,
    thread_config: dict[str, int],
) -> dict[str, Any]:
    image_output_dir.mkdir(parents=True, exist_ok=True)

    print(f"\n{'=' * 100}")
    print(f"Bild: {image_path.name}")
    print(f"Output: {image_output_dir}")
    print(f"{'=' * 100}")

    image_rgb = load_image_rgb(image_path)

    print("  [1/5] Segmentierung / Prediction Map ...")
    probability_map = infer_full_image(
        model=model,
        image_rgb=image_rgb,
        patch_size=auto.patch_size,
        output_mode=auto.model_output_mode,
        output_name=auto.model_output_name,
    )

    if auto.model_output_mode == "binary_mask":
        print(
            "  [2/5] Binärmaske direkt aus Ensemble-Ausgang 'binary_mask' "
            "(kein externer Segmentierungs-Threshold) ..."
        )
    elif auto.model_output_mode == "decision_score":
        print(
            "  [2/5] Old-Fusion Decision-Score -> Binärmaske bei 0.5 "
            "(interne/dynamische Thresholds bereits im Modell) ..."
        )
    else:
        print(
            "  [2/5] Binärmaske mit Threshold "
            f"{auto.segmentation_threshold:.10g} ..."
        )
    mask_bool = postprocess_mask(
        probability_map,
        threshold=auto.segmentation_threshold,
        output_mode=auto.model_output_mode,
    )

    print("  [3/5] Skelett / Rissbreiten / Trigger ...")
    crack_results, skeleton_bool, labeled = analyze_cracks_parallel(
        mask_bool,
        max_workers=thread_config["max_workers"],
    )

    print("  [4/5] Visualisierungen ...")
    annotated = create_annotated_image(image_rgb, mask_bool, crack_results)
    trigger_map = create_trigger_map(mask_bool, labeled, crack_results)
    skeleton_image = create_skeleton_image(mask_bool, skeleton_bool)

    # Optionaler Vergleich gegen Ground-Truth-Maske aus IMAGE_DIR/masks.
    ground_truth_path = find_matching_ground_truth_mask(image_path)
    fp_fn_overlay: np.ndarray | None = None
    segmentation_comparison: dict[str, Any] | None = None

    if ground_truth_path is not None:
        print(f"        Ground Truth gefunden: {ground_truth_path.name}")
        try:
            ground_truth_mask = load_ground_truth_mask(ground_truth_path)
            fp_fn_overlay, segmentation_comparison = create_fp_fn_overlay(
                predicted_mask=mask_bool,
                ground_truth_mask=ground_truth_mask,
            )
            segmentation_comparison["ground_truth_mask"] = str(ground_truth_path)
        except Exception as exc:
            print(f"        WARNUNG: FP/FN-Vergleich übersprungen: {exc}")
            segmentation_comparison = {
                "ground_truth_mask": str(ground_truth_path),
                "status": "error",
                "error": str(exc),
            }
    else:
        print("        Keine gleichnamige Ground-Truth-Maske gefunden.")

    print("  [5/5] Reports / Dateien speichern ...")

    config = build_configuration_log(
        auto=auto,
        thread_config=thread_config,
        image_path=image_path,
        output_dir=image_output_dir,
    )

    report = build_crack_report(
        image_path=image_path,
        results=crack_results,
        mask_bool=mask_bool,
    )
    report["segmentation_comparison"] = segmentation_comparison

    # Konfiguration
    write_json(image_output_dir / "analysis_config.json", config)
    write_txt_dict(
        image_output_dir / "analysis_config.txt",
        "ANALYSE-KONFIGURATION",
        config,
    )

    # Bilder / Maps
    save_probability_map(image_output_dir / "probability_map.png", probability_map)
    if SAVE_PROBABILITY_NPY:
        np.save(image_output_dir / "probability_map.npy", probability_map.astype(np.float32))

    save_binary_mask(image_output_dir / "binary_mask.png", mask_bool)
    save_rgb_image(image_output_dir / "annotated_image.png", annotated)
    save_rgb_image(image_output_dir / "trigger_map.png", trigger_map)
    save_rgb_image(image_output_dir / "skeleton.png", skeleton_image)

    if fp_fn_overlay is not None:
        save_rgb_image(image_output_dir / "fp_fn_overlay.png", fp_fn_overlay)

    # Crack Reports
    write_crack_csv(image_output_dir / "crack_report.csv", crack_results)
    write_json(image_output_dir / "crack_report.json", report)
    write_crack_txt(image_output_dir / "crack_report.txt", report)

    summary = dict(report["summary"])
    summary.update(
        {
            "status": "ok",
            "output_dir": str(image_output_dir),
            "segmentation_threshold": auto.segmentation_threshold,
            "best_epoch": auto.best_epoch,
            "model_file": auto.model_file,
            "ground_truth_mask_found": ground_truth_path is not None,
            "segmentation_comparison": segmentation_comparison,
        }
    )

    print(
        f"  Fertig: {summary['crack_count']} Risse | "
        f"ROT={summary['trigger_counts']['ROT']} | "
        f"ORANGE={summary['trigger_counts']['ORANGE']} | "
        f"GRÜN={summary['trigger_counts']['GRUEN']}"
    )

    return summary


# =============================================================================
# 13. BATCH-SUMMARY
# =============================================================================


def write_batch_summary(output_root: Path, summaries: list[dict[str, Any]]) -> None:
    write_json(output_root / "batch_summary.json", summaries)

    write_txt_dict(
        output_root / "batch_summary.txt",
        "BATCH-ZUSAMMENFASSUNG",
        summaries,
    )

    fieldnames = [
        "image_name",
        "status",
        "crack_count",
        "valid_width_measurement_count",
        "total_crack_area_px",
        "total_crack_length_px",
        "mean_of_crack_medians_px",
        "median_of_crack_medians_px",
        "red_count",
        "orange_count",
        "green_count",
        "invalid_count",
        "segmentation_threshold",
        "best_epoch",
        "model_file",
        "output_dir",
        "error",
    ]

    with (output_root / "batch_summary.csv").open(
        "w", newline="", encoding="utf-8"
    ) as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()

        for summary in summaries:
            trigger_counts = summary.get("trigger_counts", {}) or {}
            row = {
                "image_name": summary.get("image_name"),
                "status": summary.get("status"),
                "crack_count": summary.get("crack_count"),
                "valid_width_measurement_count": summary.get(
                    "valid_width_measurement_count"
                ),
                "total_crack_area_px": summary.get("total_crack_area_px"),
                "total_crack_length_px": summary.get("total_crack_length_px"),
                "mean_of_crack_medians_px": summary.get("mean_of_crack_medians_px"),
                "median_of_crack_medians_px": summary.get(
                    "median_of_crack_medians_px"
                ),
                "red_count": trigger_counts.get("ROT"),
                "orange_count": trigger_counts.get("ORANGE"),
                "green_count": trigger_counts.get("GRUEN"),
                "invalid_count": trigger_counts.get("UNGUELTIG"),
                "segmentation_threshold": summary.get("segmentation_threshold"),
                "best_epoch": summary.get("best_epoch"),
                "model_file": summary.get("model_file"),
                "output_dir": summary.get("output_dir"),
                "error": summary.get("error"),
            }
            writer.writerow(row)


# =============================================================================
# 14. MAIN
# =============================================================================


def main() -> int:
    validate_user_configuration()
    thread_config = configure_threads()

    if MODEL_PATH is not None:
        model_path = Path(MODEL_PATH).expanduser().resolve()
        print("\nDirekter .keras-Ensemble-Modellpfad ...")
        print(f"  Lade Modell:          {model_path}")
        model = load_model(model_path)
        auto = discover_direct_model_info(model_path, model)
        _metrics_data = {}
    else:
        print("\nAutomatische RUN-Erkennung ...")
        auto, _metrics_data = discover_run_info()
        print("\nLade bestes Modell einmalig ...")
        model = load_model(Path(auto.model_file))

    print(f"  Modus:                {auto.source_mode}")
    print(f"  RUNNAME:              {auto.run_name}")
    print(f"  Best Epoch:           {auto.best_epoch}")
    print(f"  Modell:               {auto.model_file}")
    print(f"  Patchgröße:           {auto.patch_size} px")
    if auto.model_output_mode == "binary_mask":
        print("  Segment.-Threshold:   keiner extern (fertiger binary_mask-Ausgang)")
    elif auto.model_output_mode == "decision_score":
        print("  Finalentscheidung:    decision_score >= 0.5 (Old-Fusion-Exportsemantik)")
    elif auto.segmentation_threshold is None:
        print("  Segment.-Threshold:   keiner")
    else:
        print(f"  Segment.-Threshold:   {auto.segmentation_threshold:.10g}")
    print(f"  Modell-Ausgang:       {auto.model_output_name or auto.model_output_mode}")
    print(f"  Threshold-Regel:      {auto.threshold_selection_rule}")
    print(f"  Threshold-Datei:      {auto.threshold_source_file}")
    print(f"  CPU-Worker max.:      {thread_config['max_workers']}")

    output_root = Path(auto.run_dir) / OUTPUT_ROOT_NAME
    output_root.mkdir(parents=True, exist_ok=True)

    # RUN-weite Konfiguration bereits vor Bildverarbeitung speichern.
    root_config = build_configuration_log(
        auto=auto,
        thread_config=thread_config,
    )
    write_json(output_root / "run_configuration.json", root_config)
    write_txt_dict(
        output_root / "run_configuration.txt",
        "MODELL-/RUN-KONFIGURATION RISSBREITE IN PX",
        root_config,
    )

    images = find_input_images(IMAGE_DIR)
    print(f"\nGefundene Bilder: {len(images)}")

    summaries: list[dict[str, Any]] = []

    # Modellinferenz bewusst sequenziell: ein Modell, kein mehrfacher GPU-Speicher.
    for index, image_path in enumerate(images, start=1):
        print(f"\n[{index}/{len(images)}] {image_path.name}")

        # Anforderung: Unterordner mit Namen des untersuchten Bildes.
        # Der Stem ist der Dateiname ohne Endung.
        image_output_dir = output_root / image_path.stem

        try:
            summary = process_one_image(
                model=model,
                image_path=image_path,
                image_output_dir=image_output_dir,
                auto=auto,
                thread_config=thread_config,
            )
        except Exception as exc:
            error_text = "".join(
                traceback.format_exception(type(exc), exc, exc.__traceback__)
            )

            image_output_dir.mkdir(parents=True, exist_ok=True)
            (image_output_dir / "ERROR.txt").write_text(error_text, encoding="utf-8")

            summary = {
                "image_name": image_path.name,
                "status": "error",
                "error": str(exc),
                "output_dir": str(image_output_dir),
                "segmentation_threshold": auto.segmentation_threshold,
                "best_epoch": auto.best_epoch,
                "model_file": auto.model_file,
                "trigger_counts": {},
            }

            print(f"  FEHLER bei {image_path.name}: {exc}")

        summaries.append(summary)
        write_batch_summary(output_root, summaries)

    ok_count = sum(s.get("status") == "ok" for s in summaries)
    error_count = len(summaries) - ok_count

    print("\n" + "=" * 100)
    print("BATCH FERTIG")
    print("=" * 100)
    print(f"RUNNAME:      {auto.run_name}")
    print(f"Bilder:       {len(summaries)}")
    print(f"Erfolgreich:  {ok_count}")
    print(f"Fehler:       {error_count}")
    print(f"Output:       {output_root}")

    return 0 if error_count == 0 else 1


if __name__ == "__main__":
    raise SystemExit(main())
