# MA_Codebase – Risserkennung, Risssegmentierung und Rissbreitenanalyse

## Überblick

Der Code begleitet die Masterarbeit zur bildbasierten Erkennung, Segmentierung und Vermessung von Betonrissen. Er umfasst Dataset-Aufbereitung, Modelltraining, Threshold-Optimierung, Einzelmodell- und Ensemble-Auswertung sowie Rissbreitenmessung. Diese README beschreibt die praktische Zuordnung von Skripten, Daten und Ergebnissen; die methodischen Grundlagen werden in der Masterarbeit erläutert.

## Projektstruktur

Die öffentliche Fassung enthält Skripte, Dataset-Verweise und Testberichte:

```text
MA_Codebase_Public/
├── datasets/
│   └── datasets.txt
├── src/
│   └── dataset_herstellung_und_augmentation/
├── training_models/
│   ├── crack_pipeline_blocks_1_to_9.ipynb
│   └── README_crack_pipeline.md
├── modellmetrics_of_best_epoche_on_testdataset/
├── ensemblemetrics_on_testdataset/
└── README.md
```

Die vollständige Projektablage umfasst zusätzlich `outputs/`, `output_classifier/` und `test_images/`. Diese sind in der öffentlichen Fassung nicht enthalten. `datasets/datasets.txt` nennt die Quellen; die Bilddaten müssen separat bereitgestellt werden.

## Ausführung

Die Skripte werden überwiegend über Konstanten im jeweiligen Konfigurationsblock gesteuert. Vor dem Start sind Projektwurzel, Dataset-, Modell- und Ausgabepfade anzupassen. Die gespeicherten Laufmetadaten dokumentieren die Einstellungen abgeschlossener Experimente.

Zentrale Abhängigkeiten sind TensorFlow/Keras, NumPy, Pillow, OpenCV, Matplotlib, SciPy, scikit-image und tqdm; einzelne Skripte benötigen keras-unet-collection oder ReportLab. Für ArUco muss `cv2.aruco` verfügbar sein, für Architekturzeichnungen die Keras-Plot-Infrastruktur.

## Dataset-Erstellung

### Ausgangsdaten

Quellen und Downloadlinks stehen in `datasets/datasets.txt`.

| Bezeichnung | Quelle | In Trainingskonfigurationen verwendeter Pfad |
| --- | --- | --- |
| A / BetterDataset / Präzisions-Set | Multi-temporal Crack Segmentation Dataset | `datasets/better_dataset_evtl` |
| B / BaselineDataset / Volumen-Set | SegCODEBRIM und Concrete Crack Segmentation Dataset | `datasets/baseline_dataset/uncolored_set` |

### `full_dataset_prep.py`

**Zweck:** Bereitet die verwendeten Datasets **1:1 in der Form auf, wie sie für die Masterarbeit verwendet wurden**. **Verwendet:** Konfigurierte Bild-Masken-Quellen. **Erzeugt:** Original- und Patch-Datensätze mit Herkunftsmanifest unter `datasets/`.

Das Skript liegt in `src/dataset_herstellung_und_augmentation/`. `DATASET_PATHS` ist zunächst leer, `DATASET_NAME = "mydataset"` ein Platzhalter; für die Reproduktion sind die ursprünglichen Quellen und Einstellungen einzutragen.

1. Bild-Masken-Paare anhand ihrer Dateistämme zuordnen und auf Vollständigkeit, Lesbarkeit und gleiche Abmessungen prüfen. Vorhandene Quellsplits werden zusammengeführt; quellübergreifende Namenskollisionen führen zur Neunummerierung.
2. Originalpaare mit Seed 42 in Training, Validation und Test aufteilen, standardmäßig 70/15/15. Bilder werden EXIF-korrigiert als RGB-PNG, Masken ohne EXIF-Rotation als Graustufen-PNG gespeichert.
3. `datasets/<DATASET_NAME>_original/{train,val,test}/{images,masks}` und `manifest.csv` mit Herkunft, Split und Umbenennungen erzeugen.
4. Je Split 512×512-Patches mit Schrittweite 256 ausschneiden, Bild und Maske gemeinsam um 0°, 90°, 180° und 270° drehen und unter `datasets/<DATASET_NAME>_512` speichern. Kleinere Originalbilder werden übersprungen.

Die Aufteilung erfolgt vor dem Zuschneiden; Patches und Rotationen eines Originalpaares bleiben im selben Split. Patches mit vollständig schwarzer Maske werden bei `WHITE_THRESHOLD = 0` als Hard Negatives abgelegt:

```text
datasets/<DATASET_NAME>_512/
├── train/
│   ├── images/
│   ├── masks/
│   ├── images_hard_negatives/
│   └── masks_hard_negatives/
├── val/                            # gleiche Unterordner
└── test/                           # gleiche Unterordner
```

Trainingsskripte erwarten häufig `train_512`, `val_512`, `test_512` sowie `images_512px_hard_negatives` und `masks_512px_hard_negatives`. Ordnernamen und Konfiguration müssen daher vor dem Training abgeglichen werden. `RECREATE_OUTPUT = True` löscht bestehende Zielinhalte; standardmäßig ist dies deaktiviert.

### `training_models/crack_pipeline_blocks_1_to_9.ipynb`

Das Notebook ist ein älterer Versuch, nahezu die gesamte Pipeline in einer Datei zusammenzuführen. **Block 1 entspricht der Dataset-Aufbereitung in `full_dataset_prep.py` und ist die Referenz für die in der Masterarbeit verwendete Datenform.** Die späteren Blöcke behandeln Batchgrößen, Training, Thresholds, Ensembles, Vorhersagen und Rissmessung; für den getrennten Workflow sind die nachfolgend beschriebenen Skripte maßgeblich. Die ältere Ensemble-Auswahl in Block 6 verwendet unter anderem Testmetriken.

## Augmentierung und Label-Noise

`full_dataset_prep.py` erzeugt die gemeinsamen Patch-Rotationen offline. `rotate_images_and_masks.py` bietet die Rotation separat, `create_patches_512.py` das Zuschneiden ohne Rotation.

Zusätzliche Online-Augmentierung enthalten die Trainingsvarianten `unetpp_dice_f2_distance_dataaugmentation.py`, `unetpp_dice_f2_distance_multicolor_dataaugmentation.py` und `unetpp_dice_f2_distance_combined_dataaugmentation.py`.

Die `generate_labelnoise_*`-Skripte verändern ausschließlich Trainingsmasken in separaten Dataset-Kopien. Trainingsbilder, Validation und Test bleiben unverändert; `label_noise_manifest.csv` und `label_noise_summary.json` protokollieren die Änderungen.

## Weitere Dataset-Werkzeuge unter `src`

Alle folgenden Dateien liegen in `src/dataset_herstellung_und_augmentation/`. Sie ergänzen die zentrale Aufbereitung und werden nach Bedarf eingesetzt.

### `check_for_mismatch_and_size.py`

**Zweck:** Prüft Paarung, Lesbarkeit und Bildgrößen. **Verwendet:** `train|val|test/images|masks`, Zuordnung nach vollständigem Dateinamen. **Erzeugt:** Konsolenberichte.

### `to_png.py`

**Zweck:** Konvertiert Bilder und Masken nach PNG, mit EXIF-Korrektur nur für Bilder. **Verwendet:** Konfigurierte Dataset-Ordner. **Erzeugt:** PNG-Dateien; bei `DELETE_ORIGINAL = False` bleiben die Quellen erhalten.

### `nummerierung_aendern.py`

**Zweck:** Nummeriert Dateien eines Ordners um. **Verwendet:** `FOLDER_PATH` und `START_NUMBER`. **Erzeugt:** Umbenannte Dateien im selben Ordner.

### `copy_images.py`

**Zweck:** Kopiert oder verschiebt Dataset-Dateien. **Verwendet:** `INPUT_BASE`, `OUTPUT_BASE` und ausgewählte Splits. **Erzeugt:** Entsprechende Zielordner.

### `move_images_with_prefix.py`

**Zweck:** Sortiert Dateien mit Präfix `hn` aus. **Verwendet:** Konfigurierte `images/masks`-Ordner. **Erzeugt:** Dateien in `images_512px_hard_negatives` und `masks_512px_hard_negatives`.

### `create_patches_512.py`

**Zweck:** Erzeugt 512-Pixel-Patches mit Schrittweite 256 und trennt leere Masken ab. **Verwendet:** `INPUT_DIR/{train,val,test}`. **Erzeugt:** `images_512px`, `masks_512px` und zugehörige `*_hard_negatives`-Ordner.

### `rotate_images_and_masks.py`

**Zweck:** Rotiert Bild-Masken-Paare gemeinsam um Vielfache von 90°. **Verwendet:** Konfigurierte Dataset-Splits. **Erzeugt:** PNG-Paare mit Namen `<stem>_<hash>_<winkel>_grad.png`.

### `find_broekn_pngs.py`

**Zweck:** Sucht nicht dekodierbare PNGs. **Verwendet:** Reguläre und Hard-Negative-Ordner eines Splits. **Erzeugt:** `<SPLIT>_invalid_png_files.txt` im Dataset-Root.

### `generate_labelnoise_dilation_3px_multithread_copy.py`

**Zweck:** Dilatiert Trainingsmasken um drei Pixel. **Verwendet:** `datasets/better_dataset_evtl`. **Erzeugt:** `datasets/better_dataset_labelnoise_dilation_3px` samt Änderungsprotokollen.

### `generate_labelnoise_omission_20pct_multithread_copy.py`

**Zweck:** Entfernt zusammenhängende Rissabschnitte; 20 % beziehen sich auf die projizierte Hauptachsenlänge. **Verwendet:** BetterDataset-Trainingsmasken. **Erzeugt:** `datasets/better_dataset_labelnoise_omission_20pct` samt Protokollen.

### `generate_labelnoise_translation_1to4px_multithread_copy.py`

**Zweck:** Verschiebt Trainingsmasken zufällig in acht Richtungen mit Schrittbetrag 1–4 Pixel. **Verwendet:** BetterDataset-Trainingsmasken. **Erzeugt:** `datasets/better_dataset_labelnoise_translation_1to4px` samt Protokollen.

### `generate_labelnoise_translation_4px_rechts.py`

**Zweck:** Verschiebt Trainingsmasken vier Pixel nach rechts. **Verwendet:** BetterDataset-Trainingsmasken. **Erzeugt:** `datasets/better_dataset_labelnoise_translation_4px_right` samt Protokollen.

### `delete_identifier_files.py`

**Zweck:** Entfernt `:Zone.Identifier`-Dateien. **Verwendet:** `ROOT_DIR` und `DRY_RUN`. **Erzeugt:** Bereinigte Ordner oder eine Vorschau.

### `delete_files_with_suffix_xx.py`

**Zweck:** Entfernt Dateien ausgewählter Endungen. **Verwendet:** Konfigurierte Dataset-Ordner und `DRY_RUN`. **Erzeugt:** Bereinigte Ordner oder eine Vorschau.

### `delete_folder.py`

**Zweck:** Löscht einen Verzeichnisbaum nach Bestätigung. **Verwendet:** `ROOT_FOLDER`. **Erzeugt:** Lösch- und Fehlerausgaben.

### `delete_folder_in_all_subfolders.py`

**Zweck:** Entfernt einen benannten Unterordner aus mehreren Läufen. **Verwendet:** `OUTPUTS_DIR`, `TARGET_FOLDER_NAME` und `DRY_RUN`. **Erzeugt:** Bereinigte Laufordner oder eine Vorschau.

## Training und Modellauswahl

Die Segmentierung verwendet gleichnamige PNG-Bild-Masken-Paare. Das zentrale Trainingsskript normiert Bilder auf `[0,1]` und binarisiert Masken mit `>127`, passt Bildgrößen jedoch nicht an. Dataset-Variante und Hard-Negative-Anteil werden je Experiment konfiguriert.

### `src/dataset_herstellung_und_augmentation/Batchsize_test.py`

**Zweck:** Vergleicht Laufzeit, Durchsatz und GPU-Speicherbedarf verschiedener Batchgrößen. **Verwendet:** Patch-Dataset und U-Net++-Modell. **Erzeugt:** Konsolentabellen und `BENCHMARK_RESULT_JSON`-Ausgaben.

### `training_models/run_trainings_sequentially.py`

Startet die Einträge aus `TRAINING_SCRIPTS` nacheinander mit demselben Python-Interpreter, sodass die Läufe nicht gleichzeitig GPU-Speicher belegen. Die Skriptliste ist vorab anzupassen. Der Launcher protokolliert Zeitstempel, Laufzeiten und Rückgabecodes; Modelle und Trainingslogs schreiben die aufgerufenen Skripte.

### `training_models/classifier_multi_dataset_full_logging.py`

Trainiert ein ImageNet-vortrainiertes EfficientNetB0 zur Unterscheidung von Riss- und Hintergrundpatches. Verwendet werden BetterDataset und BaselineDataset mit `train_512`, `val_512` und `test_512`; positive Bilder stammen aus `images`, negative aus `images_512px_hard_negatives`. Im Training werden beide Klassen gleich häufig gesampelt.

Auf das Training des Klassifikationskopfs folgt Fine-Tuning. Die Epochenauswahl minimiert die F1/F2-Idealpunktdistanz; der anschließende Sweep wählt den Bildthreshold nach maximalem F1 auf der vollständigen Validation und übernimmt ihn für Test.

Unter `output_classifier/classifier_multi_dataset_optimized/` entstehen Modelle, Architekturberichte, Epochenlogs, Kurven, Threshold-Tabellen und Testmetriken. Der Classifier dient später als Gate der Ensembles.

### `training_models/unetpp_dice_f2_distance.py`

Zentrales U-Net++-Trainingsskript und Ausgangspunkt der meisten Varianten. Es verwendet aktuell BetterDataset mit 512-Pixel-Patches und Soft-Dice-Loss. F2 dient der Validierung und Epochenauswahl; „distance“ bezeichnet die Distanz zum idealen Dice/F2-Metrikpunkt.

Die vollständige Validation bestimmt die beste Epoche. Lernratenreduktion und Early Stopping überwachen separat `val_loss`. Gespeichert werden Epochenmodelle, `*_best_dice_f2_distance.keras`, Auswahl- und Trainingsprotokolle sowie Kurven unter `outputs/<RUN>/`. Die finale Testauswertung erfolgt separat.

### Weitere Trainingsvarianten und Experimente

Die übrigen U-Net++-Skripte variieren insbesondere Loss-Funktionen, Attention-/ViT-Komponenten, Encoder, Deep Supervision, Patchgrößen, Augmentierung und Dataset-Zusammensetzung. `labelnoise_tversky_*` und `self_training_*` untersuchen gestörte Labels beziehungsweise Teacher-/Pseudo-Label-Verfahren. `baseline_*`, `benchmark_*` und `deeplabv3plus_*` ergänzen Architekturvergleiche, unter anderem mit DeepLabV3+ und SegFormer. Die Dateinamen kennzeichnen die jeweiligen Experimente.

## Vorhersagen und Threshold-Sweeps

Die Auswertung erzeugt Modellwahrscheinlichkeiten direkt während der Inferenz. Pixelschwellen werden auf Validation bestimmt und anschließend für Test und Ensembles übernommen. GLOBAL verwendet alle Pixel; BALANCED CRACK ROI verwendet alle positiven und gleich viele negative Pixel, bevorzugt aus der Rissumgebung.

### `src/Threshold_sweep_all_outputs.py`

**Zweck:** Bestimmt Pixelschwellen für GLOBAL und BALANCED CRACK ROI. **Verwendet:** Laufmetadaten, gewählte Checkpoints und Validierungsdaten. **Erzeugt:** `outputs/<RUN>/threshold_results2/` mit Sweep-CSVs, Empfehlungen und Diagnostik.

Die nachgelagerten Skripte lesen die Empfehlung `ROI minimaler Balanced Error`. Weitere Optima betreffen Dice/F1, IoU, F2 sowie FPR/FNR. Bereits vorhandene Ergebnisordner werden übersprungen.

### `src/test_classifier_two_thresholds.py`

**Zweck:** Vergleicht die festen Bildschwellen `0.094` und `0.000044` auf Testdaten. **Verwendet:** Classifier und `better_dataset_evtl/test_512`. **Erzeugt:** Vorhersage-CSV, TXT-/JSON-Berichte und FP-/FN-Listen neben dem Modell.

Der reguläre Classifier-Sweep ist im Trainingsskript enthalten. Der nachfolgend beschriebene Ensemble-Sweep optimiert dagegen Modellgewichte bei festgelegten Schwellen.

## Einzelmodell-Auswertung

### `src/alle_modelle_auf_testdataset_GLOBAL_sicher.py`

**Zweck:** Bewertet Modelle über sämtliche Testpixel und erstellt ein Ranking. **Verwendet:** Best-Epoch-Metadaten, Checkpoints, ROI-Thresholds und Testsplit. **Erzeugt:** Einzel- und Sammelberichte unter `modellmetrics_of_best_epoche_on_testdataset/global_full_testset/`.

### `src/alle_modelle_auf_testdataset_SAMPLE_sicher.py`

**Zweck:** Bewertet Modelle innerhalb der BALANCED CRACK ROI. **Verwendet:** Testsplit, Modelle, gespeicherte Schwellen und ROI-Einstellungen. **Erzeugt:** Berichte unter `modellmetrics_of_best_epoche_on_testdataset/sample_balanced_crack_roi/`.

### `src/einzelnes_modell_auf_testdataset_testen.py`

**Zweck:** Bewertet ein explizit angegebenes Segmentierungsmodell. **Verwendet:** `MODEL_PATH`, Dataset und manuellen Threshold; `TEST_STEPS` begrenzt die Auswertung. **Erzeugt:** TXT-/JSON-Metriken unter `modellmetrics_einzelmodelle/<MODELLNAME>/`.

### `src/rank_test_metrics_from_folder.py`

**Zweck:** Sortiert gespeicherte Testresultate nach Dice/F2-Distanz. **Verwendet:** Metrik-JSONs, ohne erneute Inferenz. **Erzeugt:** `all_modells_common_test_metrics.txt` und `all_modells_common_sample_test_metrics.txt`.

### `src/perfect_label_test.py`

**Zweck:** Bewertet Best-Epoch-Modelle auf sorgfältig gelabelten Referenzbildern. **Verwendet:** Bild-Masken-Paare, Laufmetadaten und Thresholds. **Erzeugt:** `outputs/<RUN>/perfect_labels_test/` mit GLOBAL-/ROI-Metriken, Masken und FP/FN-Bildern.

### `src/maskenvergleich_fp_fn.py`

**Zweck:** Vergleicht zwei binäre Masken. **Verwendet:** `MASK_PRED_PATH` und `MASK_GT_PATH`. **Erzeugt:** Farbige Differenzmaske sowie GLOBAL-/ROI-Berichte als `*_metrics.txt` und `*_metrics.json`.

### `src/label_noise_verlauf_multi_run_patches.py`

**Zweck:** Vergleicht Vorhersagen über gespeicherte Epochen. **Verwendet:** Runs, Epochen-Checkpoints und Analysebilder, optional Referenzmasken. **Erzeugt:** `label_noise_verlauf/epoch_*/` je Lauf sowie `outputs/_label_noise_verlauf_summary/` mit Masken, Visualisierungen und Metriken.

## Ensemble-Verfahren

### `training_models/ensemble_oldfusion_thresholdcentered_test.py`

Kombiniert zwei Segmentierungsmodelle mit einem Classifier-Gate. Individuelle Thresholds aus `threshold_results2/` werden auf 0,5 zentriert; die Classifier-Wahrscheinlichkeit steuert anschließend FINE/PRECISE-Gewichtung und Pixelthreshold. `oldfusion` bezeichnet die beibehaltene dynamische Fusion mit ergänzter Schwellenzentrierung.

Erzeugt unter `outputs/<RUN_NAME>/` Architekturdateien, Classifier-FN-Listen und `*_ensemble.keras`. Testberichte werden als TXT/CSV/JSON unter `ensemblemetrics_on_testdataset/` abgelegt.

### `training_models/ensemble_validation_sweep_test_metrics.py`

Kombiniert individuell binarisierte Segmentierungen durch gewichtetes Voting. Auf 200 fest ausgewählten Validierungsbildern werden Gewichte in 0,01-Schritten mit Summe 1 untersucht; zwei bis fünf Modelle erhalten positives Gewicht. Gewählt wird die kleinste Dice/F2-Distanz.

`modellverteilung_sweep/` speichert Sweep, beste Verteilung und Bildauswahl. Anschließend werden die Gewichte fixiert, das Ensemble exportiert und GLOBAL-/ROI-Testmetriken sowie Classifier-FN-Listen erzeugt. Classifier-, Segmentierungs- und Vote-Thresholds bleiben während der Gewichtssuche fest.

## Rissbreitenmessung und Kalibrierung

Die Messskripte verarbeiten Anwendungsbilder und Bildserien, in der vollständigen Ablage unter `test_images/`. Maßstab beziehungsweise Kalibrierung sind passend zur Aufnahme zu konfigurieren.

### `src/rissmaske_auswerten.py`

**Zweck:** Bestimmt Rissfläche, Skelettlänge und Breiten aus einer Binärmaske. **Verwendet:** Maske und Bereinigungsparameter. **Erzeugt:** `*_crack_measurements.csv`, `*_crack_measurements.json` und Visualisierungen.

### `src/Rissbreite_in_px_batch_auto_mit_direktem_ensemble.py`

**Zweck:** Segmentiert Bildserien und vermisst Risse in Pixeln. **Verwendet:** Bilder und Trainingslauf oder direktes Modell. **Erzeugt:** `rissbreite_in_px/` mit Masken, `crack_report.*` und `batch_summary.*`.

### `src/rissmessung_fester_skalierungsfaktor.py`

**Zweck:** Rechnet Rissmaße mit konstantem Faktor in Millimeter um. **Verwendet:** Bilder, Modell und `MM_PER_PX`. **Erzeugt:** Berichte und Visualisierungen unter `rissbreite_metrisch_faktor/`.

### `src/rissmessung_aruco_konstanter_faktor_ensemble.py`

**Zweck:** Vermisst Risse mit einem bildweisen ArUco-Maßstab. **Verwendet:** Bilder, Markergröße und Modell/Ensemble. **Erzeugt:** `rissbreite_aruco_mm_constant/` mit Pixel-/Millimeterberichten und Markerdiagnostik.

### `src/rissmessung_aruco_homographie_beide_ensemble_varianten.py`

**Zweck:** Ergänzt die ArUco-Rissmessung um projektive Entzerrung. **Verwendet:** Bilder, Markergröße und Modell/Ensemble. **Erzeugt:** Berichte und entzerrte Darstellungen, aktuell unter `rissbreite_aruco_mm_homography_cropped/`.

### `src/rissmessung_kamerainfos_und_distanz_beide_ensemble_varianten.py`

**Zweck:** Ermittelt metrische Rissmaße aus Kameraangaben und Aufnahmeabstand. **Verwendet:** Bild, Brennweite, Sensorabmessungen, Abstand und Modell/Ensemble. **Erzeugt:** Masken, Berichte und Konfiguration unter `OUTPUT_PARENT_DIR/<Bildname>/`.

### `src/generate_aruco_marker_pdf.py`

**Zweck:** Erstellt einen druckbaren ArUco-Marker. **Verwendet:** Dictionary, ID und Kantenlänge. **Erzeugt:** `aruco_marker.png` und `aruco_marker.pdf`.

### `src/aruco_3punkt_skalenanalyse.py`

**Zweck:** Vergleicht Maßstäbe an drei Markerpositionen. **Verwendet:** Markerbilder, IDs und reale Kantenlängen. **Erzeugt:** `aruco_scale_report.json` und `aruco_scale_report.txt`.

### `src/aruco_auto_spacing_calibration.py`

**Zweck:** Schätzt Kameramodell und Markerpositionen gemeinsam. **Verwendet:** Mindestens drei koplanare Marker, Markergröße und Kamera-Wand-Abstand. **Erzeugt:** `camera_calibration.npz`, `camera_calibration.yaml`, `calibration_report.json` und Diagnosebilder.

### `src/apply_camera_calibration.py`

**Zweck:** Entzerrt ein Bild mit gespeicherter Kalibrierung. **Verwendet:** `camera_calibration.npz` und Eingabebild. **Erzeugt:** Entzerrtes Bild, optional auf die gültige ROI zugeschnitten.

### `src/aruco_geometric_distortion_rectification_v5.py`

**Zweck:** Bestimmt eine geometrische Korrektur aus Marker-Kontrollpunkten. **Verwendet:** Kalibrierungsbild, Markergröße und reale Mittelpunktkoordinaten. **Erzeugt:** `geometric_warp_calibration_v5*.npz`, `calibration_report_v5.*` und korrigierte Bilder.

## Output-Struktur

### Trainingsläufe

Die folgenden Modell- und Bildausgaben gehören zur vollständigen Projektablage und sind nicht Teil dieser öffentlichen Fassung:

```text
outputs/<RUN>/
├── architecture/                  # Modellaufbau und Konfiguration
├── metrics/                       # Epochenmetriken, Auswahl, Laufmetadaten
│   └── plots/                     # Trainings- und Validierungskurven
├── models/                        # Keras-Checkpoints
└── threshold_results2/            # nachgelagerte Sweeps und Empfehlungen
```

Im vollständigen Archiv sind überwiegend nur `*_best_dice_f2_distance.keras` und `*_best_val_loss.keras` erhalten; einzelne Modellordner sind leer. Skripte mit expliziten `EpocheXX.keras`-Pfaden müssen daher mit den verfügbaren Checkpoints abgeglichen werden.

### FAV-Lauf

`outputs/unetpp_512px_f16-256_BetterDataset_focal_attention_vit/` enthält im vollständigen Archiv alle 40 Epochenmodelle und beide Best-Checkpoints; ausgewählt ist Epoche 28 mit ROI-Threshold 0,4.

Zusätzlich vorhanden sind `label_noise_verlauf/`, `perfect_labels_test/`, `rissbreite_aruco_mm_constant/`, `rissbreite_aruco_mm_homography/` und `rissbreite_kamerainfos_und_distanz/`.

### T-Lauf

`outputs/unetpp_512px_f16-256_BetterDataset_tversky/` enthält ebenfalls 40 Epochenmodelle und zwei Best-Checkpoints; ausgewählt ist Epoche 36 mit ROI-Threshold `0.000033`. Gegenüber FAV kommt `rissbreite_in_px/` hinzu.

### Weitere Ergebnisablagen

| Ablage | Inhalt / Erzeuger |
| --- | --- |
| `output_classifier/classifier_multi_dataset_optimized/` | Classifier-Training, Checkpoints, Thresholds und Testberichte |
| `outputs/<Ensemble-Lauf>/` | Ensemble-Export, `architecture/`, `models/`, `Classifier_FN/`; beim Gewichtssweep zusätzlich `modellverteilung_sweep/` |
| `modellmetrics_of_best_epoche_on_testdataset/` | Einzelmodell-Testberichte, getrennt nach GLOBAL und ROI |
| `ensemblemetrics_on_testdataset/` | Ensemble-Testberichte als TXT/CSV/JSON |
| `test_images/` | Analysebilder, Referenzmasken und Kalibrierungsdaten der vollständigen Ablage |

## Typischer Ablauf

1. Quellen aus `datasets/datasets.txt` bereitstellen und Pfade in `full_dataset_prep.py` setzen.
2. Originalsplits, PNG-Paare, Patches, Rotationen und Hard Negatives erzeugen; Ordnernamen mit den Trainingsskripten abgleichen.
3. Dataset-Variante, gegebenenfalls Label-Noise und Online-Augmentierung wählen.
4. Classifier und Segmentierungsmodelle trainieren; Checkpoints anhand der Validierung auswählen.
5. Bild- und Pixelschwellen auf Validation bestimmen; Einzelmodelle damit auf Test auswerten.
6. Ensembles konfigurieren beziehungsweise Gewichte auf Validation optimieren und anschließend auf Test bewerten.
7. Anwendungsbilder segmentieren, Rissmaße bestimmen und Berichte in den jeweiligen Ergebnisordnern ablegen.
