#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Classifier-gesteuertes 2-Modell-Ensemble auf einem Crack-Testdataset.

Diese Version behaelt die LOGIK DER ALTEN FUSION bei:

    1) Classifier als Gate
    2) Classifier steuert dynamisch das Gewicht von FINE vs. PRECISE
    3) Classifier steuert dynamisch den finalen Pixel-Threshold

Neu gegenueber der alten Fusion:

    - Strikt genau 2 Segmentierungsmodelle.
    - Fuer jedes Segmentierungsmodell wird der individuelle optimale Threshold
      "ROI minimaler Balanced Error" automatisch aus threshold_results2 geladen.
    - Weil Thresholds extrem unterschiedlich sein koennen (z.B. 3.3e-05 vs. 0.4),
      werden die rohen Modellwahrscheinlichkeiten VOR der alten Fusion
      threshold-zentriert auf eine gemeinsame Skala gebracht.
    - Der individuelle Modellthreshold wird dabei exakt auf 0.5 abgebildet.
    - Danach laeuft wieder die alte classifier-gesteuerte Fine/Precise-Fusion.
    - Keine Prediction-/Overlay-Bilder werden gespeichert.
    - Final werden dieselben Testmetriken wie im beigefuegten Testdataset-Code
      berechnet und als TXT/CSV/JSON geloggt.
    - Gesamtarchitektur + alle Variablen werden unter
      outputs/RUN_NAME/architecture als PNG/JSON/Keras-JSON/TXT gespeichert.
    - Das komplette Ensemble wird zusaetzlich als einzelnes ladbares .keras-Modell
      unter outputs/RUN_NAME/models gespeichert. Der Modellausgang ist der
      kontinuierliche finale Decision-Score; binarisiert wird bei 0.5.
    - Neben den globalen Testmetriken werden BALANCED-CRACK-ROI-Sample-Metriken
      in einer separaten zweiten Ergebnisdatei geloggt.
    - Bei HARD_NEGATIVE_SHARE == 0.0 werden alle vom Classifier negativ
      bewerteten Bilder in outputs/RUN_NAME/Classifier_FN als TXT/CSV geloggt.

THRESHOLD-ZENTRIERUNG
---------------------
Die Transformation ist eine Verschiebung im Odds-/Logit-Raum, algebraisch ohne
Logarithmus implementiert:

    q = p*(1-t) / (p*(1-t) + (1-p)*t)

mit
    p = rohe Modellwahrscheinlichkeit
    t = individueller optimaler Modellthreshold
    q = threshold-zentrierter Score

Eigenschaften:
    p = 0  -> q = 0
    p = t  -> q = 0.5
    p = 1  -> q = 1

Damit sind Modelle mit t=3.3e-05 und t=0.4 vor der Fusion auf derselben
Entscheidungsskala, ohne die kontinuierliche Information zu binarisieren.

ALTE ADAPTIVE FUSION NACH DER ZENTRIERUNG
-----------------------------------------
    fine_weight    = FINE_BASE_WEIGHT + FINE_EXTRA_WEIGHT * classifier_probability
    precise_weight = 1 - fine_weight

    fused_score = fine_weight * fine_centered + precise_weight * precise_centered

    dynamic_threshold = PIXEL_THRESHOLD_HIGH
                        - (PIXEL_THRESHOLD_HIGH - PIXEL_THRESHOLD_LOW)
                          * classifier_probability

    binary = fused_score >= dynamic_threshold

Fuer die AP-Berechnung wird die dynamische finale Entscheidung noch einmal
threshold-zentriert, sodass fuer jedes Bild der tatsaechliche dynamische
Endthreshold auf 0.5 liegt. Die binaere Entscheidung bleibt dadurch exakt
identisch, AP kann aber wie im Testskript ueber ein einheitliches 0..1-Raster
berechnet werden.
"""

from __future__ import annotations

import csv
import json
import os
import random
import re
from datetime import datetime
from pathlib import Path
from typing import Any

# Environment vor TensorFlow setzen.
os.environ.setdefault("PYTHONHASHSEED", "42")
os.environ.setdefault("TF_GPU_ALLOCATOR", "cuda_malloc_async")
os.environ.setdefault("TF_FORCE_GPU_ALLOW_GROWTH", "true")
os.environ.setdefault("KERAS_BACKEND", "tensorflow")

import cv2
import numpy as np
import tensorflow as tf
from keras import mixed_precision
from keras.utils import plot_model

from keras.applications.mobilenet_v2 import preprocess_input as mobilenet_v2_preprocess_input
from keras.applications.resnet50 import preprocess_input as resnet50_preprocess_input
from keras.applications.efficientnet import preprocess_input as efficientnet_preprocess_input
from keras.applications.xception import preprocess_input as xception_preprocess_input
from keras.applications.vgg16 import preprocess_input as vgg16_preprocess_input
from keras.applications.vgg19 import preprocess_input as vgg19_preprocess_input
from keras.applications.densenet import preprocess_input as densenet_preprocess_input


# =============================================================================
# 1. KONFIGURATION - HIER ANPASSEN
# =============================================================================

RUN_NAME = "ensemble_dynamic_finefocal_precisetversky_lowclassifierthreshold"

CRACK_PROJECT_ROOT = Path("/home/mitte/crack_project")
OUTPUT_ROOT = CRACK_PROJECT_ROOT / "outputs"
RUN_DIR = OUTPUT_ROOT / RUN_NAME

# Frei im Code einstellbarer Zielordner fuer die finalen Testmetriken.
TEST_METRICS_DIR = CRACK_PROJECT_ROOT / "ensemblemetrics_on_testdataset"

# Erwartete Struktur:
#   TEST_DATASET_DIR/test_512/images
#   TEST_DATASET_DIR/test_512/masks
TEST_DATASET_DIR = CRACK_PROJECT_ROOT / "datasets/better_dataset_evtl"
IMG_SIZE = 512

# -----------------------------------------------------------------------------
# CLASSIFIER
# -----------------------------------------------------------------------------

CLASSIFIER_MODEL_PATH = (
    CRACK_PROJECT_ROOT
    / "output_classifier/classifier_multi_dataset_optimized/models/classifier_multi_dataset_optimized_best_f1_f2_distance.keras"
)

# Wie in der alten Fusion: darunter werden die Segmentierungsmodelle nicht benutzt.
CLASSIFIER_GATE_THRESHOLD = 0.000044
CLASSIFIER_POSITIVE_CLASS_INDEX = 1
CLASSIFIER_OUTPUT_IS_LOGITS = False

# -----------------------------------------------------------------------------
# STRIKT GENAU 2 SEGMENTIERUNGSMODELLE
# -----------------------------------------------------------------------------

# Modell 1 = FINE-Rolle der alten Fusion.
PRECISE_MODEL_PATH = (
    CRACK_PROJECT_ROOT
    / "outputs/unetpp_512px_f16-256_BetterDataset_tversky/models/"
      "unetpp_512px_f16-256_BetterDataset_tversky_Epoche36.keras"
)

# Modell 2 = PRECISE-Rolle der alten Fusion.
FINE_MODEL_PATH = (
    CRACK_PROJECT_ROOT
    / "outputs/unetpp_512px_f16-256_BetterDataset_focal_attention_vit/models/"
      "unetpp_512px_f16-256_BetterDataset_focal_attention_vit_Epoche28.keras"
)

SEGMENTATION_OUTPUTS_ARE_LOGITS = False

# Zuerst wird exakt <model.stem> + Suffix gesucht, danach robuster Fallback.
THRESHOLD_FILENAME_SUFFIX = "_threshold_search_GLOBAL_and_BALANCED_CRACK_ROI_FINE.txt"

# -----------------------------------------------------------------------------
# ALTE CLASSIFIER-GESTEUERTE FUSION
# -----------------------------------------------------------------------------

# Fine-Gewicht:
#   FINE_BASE_WEIGHT + FINE_EXTRA_WEIGHT * classifier_probability
# Bei den alten Werten also 0.25 .. 0.60.
FINE_BASE_WEIGHT = 0.25
FINE_EXTRA_WEIGHT = 0.35

# Precise-Gewicht = 1 - Fine-Gewicht.

# Dynamischer Endthreshold auf der NEU threshold-zentrierten gemeinsamen Skala.
# Bei classifier=0 -> HIGH; classifier=1 -> LOW.
PIXEL_THRESHOLD_HIGH = 0.60
PIXEL_THRESHOLD_LOW = 0.35

# Die finale dynamische Entscheidung wird fuer die Metrikberechnung auf eine
# gemeinsame Score-Skala gebracht; dort entspricht der Endthreshold immer 0.5.
METRIC_DECISION_THRESHOLD = 0.50

# -----------------------------------------------------------------------------
# TESTDATEN / HARD NEGATIVES
# -----------------------------------------------------------------------------

# 0.0 = nur regulaere Testbilder. Dann wird jedes Classifier-Negativ im
# Classifier_FN-Ordner protokolliert.
# Beispiel: 0.20 = zusaetzliche HNs so samplen, dass sie ~20 % ausmachen.
HARD_NEGATIVE_SHARE = 0.0
HARD_NEGATIVE_RANDOM_SEED = 42

# -----------------------------------------------------------------------------
# INFERENZ / METRIKEN
# -----------------------------------------------------------------------------

BATCH_SIZE = 8
BATCH_SIZE_1024 = 2
SEED = 42
XLA_JIT = True
MIXED_PRECISION_POLICY = "mixed_float16"

# Exakt wie im Testdataset-Skript.
AP_THRESHOLDS = np.linspace(1.0, 0.0, 101, dtype=np.float64)
EPS = 1e-7

# BALANCED CRACK ROI fuer die separate Sample-Test-Auswertung.
# Exakt dieselbe Grundlogik wie im beigefuegten Sample-Testcode:
# alle GT-Risspixel + bevorzugt rissnahe negative Pixel bis N_neg ~= N_pos.
ROI_RING_RADIUS_PX = 10
ROI_NEGATIVE_TO_POSITIVE_RATIO = 1.0
ROI_RANDOM_SEED = 42

# Architektur-Logging.
ARCHITECTURE_EXPAND_NESTED_PNG = True
ARCHITECTURE_DPI = 200


# =============================================================================
# 2. AUSGABEPFADE
# =============================================================================

ARCH_DIR = RUN_DIR / "architecture"
MODEL_DIR = RUN_DIR / "models"
CLASSIFIER_FN_DIR = RUN_DIR / "Classifier_FN"

ENSEMBLE_MODEL_PATH = MODEL_DIR / f"{RUN_NAME}_ensemble.keras"

ARCHITECTURE_TXT_FILE = ARCH_DIR / f"{RUN_NAME}_architecture_detailed.txt"
ARCHITECTURE_JSON_FILE = ARCH_DIR / f"{RUN_NAME}_architecture_config.json"
ARCHITECTURE_KERAS_JSON_FILE = ARCH_DIR / f"{RUN_NAME}_architecture_keras.json"
ARCHITECTURE_PNG_FILE = ARCH_DIR / f"{RUN_NAME}_architecture.png"

FINAL_METRICS_TXT_FILE = TEST_METRICS_DIR / f"{RUN_NAME}_test_metrics.txt"
FINAL_METRICS_CSV_FILE = TEST_METRICS_DIR / f"{RUN_NAME}_test_metrics.csv"
FINAL_METRICS_JSON_FILE = TEST_METRICS_DIR / f"{RUN_NAME}_test_metrics.json"

SAMPLED_METRICS_TXT_FILE = TEST_METRICS_DIR / f"{RUN_NAME}_sample_test_metrics.txt"
SAMPLED_METRICS_CSV_FILE = TEST_METRICS_DIR / f"{RUN_NAME}_sample_test_metrics.csv"
SAMPLED_METRICS_JSON_FILE = TEST_METRICS_DIR / f"{RUN_NAME}_sample_test_metrics.json"

CLASSIFIER_FN_TXT_FILE = CLASSIFIER_FN_DIR / f"{RUN_NAME}_classifier_false_negatives.txt"
CLASSIFIER_FN_CSV_FILE = CLASSIFIER_FN_DIR / f"{RUN_NAME}_classifier_false_negatives.csv"


# =============================================================================
# 3. REPRODUZIERBARKEIT / TENSORFLOW
# =============================================================================

random.seed(SEED)
np.random.seed(SEED)
tf.random.set_seed(SEED)

try:
    for gpu in tf.config.list_physical_devices("GPU"):
        tf.config.experimental.set_memory_growth(gpu, True)
except RuntimeError:
    pass

if XLA_JIT:
    tf.config.optimizer.set_jit("autoclustering")
else:
    tf.config.optimizer.set_jit(False)

mixed_precision.set_global_policy(MIXED_PRECISION_POLICY)


# =============================================================================
# 4. CUSTOM OBJECTS FUER ROBUSTES MODELL-LADEN
# =============================================================================

@tf.keras.utils.register_keras_serializable(package="crack_segmentation")
class AddPositionEmbedding(tf.keras.layers.Layer):
    def __init__(self, num_tokens, embed_dim, **kwargs):
        super().__init__(**kwargs)
        self.num_tokens = int(num_tokens)
        self.embed_dim = int(embed_dim)

    def build(self, input_shape):
        self.pos_embedding = self.add_weight(
            name="pos_embedding",
            shape=(1, self.num_tokens, self.embed_dim),
            initializer="random_normal",
            trainable=True,
            dtype=self.dtype,
        )
        super().build(input_shape)

    def call(self, x):
        return x + tf.cast(self.pos_embedding, x.dtype)

    def get_config(self):
        config = super().get_config()
        config.update({"num_tokens": self.num_tokens, "embed_dim": self.embed_dim})
        return config


CUSTOM_OBJECTS = {
    "AddPositionEmbedding": AddPositionEmbedding,
    "crack_segmentation>AddPositionEmbedding": AddPositionEmbedding,
    "preprocess_input": mobilenet_v2_preprocess_input,
    "mobilenetv2_preprocess_input": mobilenet_v2_preprocess_input,
    "mobilenet_v2_preprocess_input": mobilenet_v2_preprocess_input,
    "resnet50_preprocess_input": resnet50_preprocess_input,
    "efficientnet_preprocess_input": efficientnet_preprocess_input,
    "xception_preprocess_input": xception_preprocess_input,
    "vgg16_preprocess_input": vgg16_preprocess_input,
    "vgg19_preprocess_input": vgg19_preprocess_input,
    "densenet_preprocess_input": densenet_preprocess_input,
}


# =============================================================================
# 5. CUSTOM LAYER FUER ARCHITEKTURDARSTELLUNG
# =============================================================================

@tf.keras.utils.register_keras_serializable(package="crack_ensemble")
class EnsureOneChannel(tf.keras.layers.Layer):
    def call(self, x):
        x = tf.cast(x, tf.float32)
        if x.shape.rank == 3:
            x = x[..., tf.newaxis]
        if x.shape.rank != 4:
            raise ValueError(f"Unerwarteter Segmentierungsoutput: {x.shape}")
        return x[..., :1]


@tf.keras.utils.register_keras_serializable(package="crack_ensemble")
class ThresholdCenteredOdds(tf.keras.layers.Layer):
    """Mappt den individuellen Threshold auf 0.5, ohne zu binarisieren."""

    def __init__(self, threshold: float, **kwargs):
        super().__init__(**kwargs)
        self.threshold = float(threshold)

    def call(self, x):
        p = tf.clip_by_value(tf.cast(x, tf.float32), 0.0, 1.0)
        t = tf.cast(self.threshold, tf.float32)
        numerator = p * (1.0 - t)
        denominator = numerator + (1.0 - p) * t
        return tf.math.divide_no_nan(numerator, denominator)

    def get_config(self):
        config = super().get_config()
        config.update({"threshold": self.threshold})
        return config


@tf.keras.utils.register_keras_serializable(package="crack_ensemble")
class ClassifierProbability(tf.keras.layers.Layer):
    def __init__(
        self,
        positive_class_index: int = 1,
        output_is_logits: bool = False,
        **kwargs,
    ):
        super().__init__(**kwargs)
        self.positive_class_index = int(positive_class_index)
        self.output_is_logits = bool(output_is_logits)

    def call(self, x):
        x = tf.cast(x, tf.float32)
        if x.shape.rank == 1:
            prob = x
            if self.output_is_logits:
                prob = tf.math.sigmoid(prob)
        elif x.shape.rank == 2:
            if x.shape[-1] == 1:
                prob = x[:, 0]
                if self.output_is_logits:
                    prob = tf.math.sigmoid(prob)
            else:
                if self.output_is_logits:
                    x = tf.nn.softmax(x, axis=-1)
                prob = x[:, self.positive_class_index]
        else:
            raise ValueError(f"Classifier-Ausgabe muss Rang 1 oder 2 haben: {x.shape}")
        prob = tf.clip_by_value(prob, 0.0, 1.0)
        return tf.reshape(prob, (-1, 1, 1, 1))

    def get_config(self):
        config = super().get_config()
        config.update(
            {
                "positive_class_index": self.positive_class_index,
                "output_is_logits": self.output_is_logits,
            }
        )
        return config


@tf.keras.utils.register_keras_serializable(package="crack_ensemble")
class FineDynamicWeight(tf.keras.layers.Layer):
    def __init__(self, base_weight: float, extra_weight: float, **kwargs):
        super().__init__(**kwargs)
        self.base_weight = float(base_weight)
        self.extra_weight = float(extra_weight)

    def call(self, classifier_probability):
        c = tf.cast(classifier_probability, tf.float32)
        w = self.base_weight + self.extra_weight * c
        return tf.clip_by_value(w, 0.0, 1.0)

    def get_config(self):
        config = super().get_config()
        config.update(
            {
                "base_weight": self.base_weight,
                "extra_weight": self.extra_weight,
            }
        )
        return config


@tf.keras.utils.register_keras_serializable(package="crack_ensemble")
class OneMinus(tf.keras.layers.Layer):
    def call(self, x):
        return 1.0 - tf.cast(x, tf.float32)


@tf.keras.utils.register_keras_serializable(package="crack_ensemble")
class WeightedBlend(tf.keras.layers.Layer):
    def call(self, inputs):
        fine, precise, fine_weight, precise_weight = inputs
        return (
            tf.cast(fine, tf.float32) * tf.cast(fine_weight, tf.float32)
            + tf.cast(precise, tf.float32) * tf.cast(precise_weight, tf.float32)
        )


@tf.keras.utils.register_keras_serializable(package="crack_ensemble")
class ClassifierDynamicThreshold(tf.keras.layers.Layer):
    def __init__(self, high: float, low: float, **kwargs):
        super().__init__(**kwargs)
        self.high = float(high)
        self.low = float(low)

    def call(self, classifier_probability):
        c = tf.cast(classifier_probability, tf.float32)
        return self.high - (self.high - self.low) * c

    def get_config(self):
        config = super().get_config()
        config.update({"high": self.high, "low": self.low})
        return config


@tf.keras.utils.register_keras_serializable(package="crack_ensemble")
class DynamicThresholdCenteredOdds(tf.keras.layers.Layer):
    """Mappt einen dynamischen Threshold tensorweise auf 0.5."""

    def call(self, inputs):
        score, threshold = inputs
        p = tf.clip_by_value(tf.cast(score, tf.float32), 0.0, 1.0)
        t = tf.clip_by_value(tf.cast(threshold, tf.float32), 0.0, 1.0)
        numerator = p * (1.0 - t)
        denominator = numerator + (1.0 - p) * t
        return tf.math.divide_no_nan(numerator, denominator)


@tf.keras.utils.register_keras_serializable(package="crack_ensemble")
class ClassifierGateScore(tf.keras.layers.Layer):
    def __init__(self, threshold: float, **kwargs):
        super().__init__(**kwargs)
        self.threshold = float(threshold)

    def call(self, inputs):
        score, classifier_probability = inputs
        gate = tf.cast(
            tf.cast(classifier_probability, tf.float32) >= self.threshold,
            tf.float32,
        )
        return tf.cast(score, tf.float32) * gate

    def get_config(self):
        config = super().get_config()
        config.update({"threshold": self.threshold})
        return config


@tf.keras.utils.register_keras_serializable(package="crack_ensemble")
class FixedThreshold(tf.keras.layers.Layer):
    def __init__(self, threshold: float, **kwargs):
        super().__init__(**kwargs)
        self.threshold = float(threshold)

    def call(self, x):
        return tf.cast(tf.cast(x, tf.float32) >= self.threshold, tf.float32)

    def get_config(self):
        config = super().get_config()
        config.update({"threshold": self.threshold})
        return config


# =============================================================================
# 6. ALLGEMEINE HILFSFUNKTIONEN
# =============================================================================

def json_safe(value: Any) -> Any:
    if isinstance(value, dict):
        return {str(k): json_safe(v) for k, v in value.items()}
    if isinstance(value, (list, tuple, set)):
        return [json_safe(v) for v in value]
    if isinstance(value, Path):
        return str(value)
    if isinstance(value, np.ndarray):
        return value.tolist()
    if isinstance(value, np.generic):
        return value.item()
    if isinstance(value, datetime):
        return value.isoformat()
    if isinstance(value, bytes):
        return value.decode("utf-8", errors="replace")
    try:
        json.dumps(value)
        return value
    except TypeError:
        return str(value)


def write_json_atomic(path: Path, data: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + ".tmp")
    with tmp.open("w", encoding="utf-8") as f:
        json.dump(json_safe(data), f, indent=2, ensure_ascii=False, allow_nan=False)
    tmp.replace(path)


def safe_div(num, den):
    return float(num / (den + EPS))


def round_for_output(value):
    if isinstance(value, (float, np.floating)):
        if not np.isfinite(value):
            return None
        return round(float(value), 6)
    if isinstance(value, np.integer):
        return int(value)
    return value


def sanitize_name(text: str) -> str:
    value = re.sub(r"[^A-Za-z0-9._-]+", "_", str(text)).strip("._")
    return value or "ensemble"


def resolve_run_dir_from_model(model_path: Path) -> Path:
    model_path = model_path.expanduser().resolve()
    if model_path.parent.name.lower() == "models":
        return model_path.parent.parent
    for parent in model_path.parents:
        if (parent / "threshold_results2").is_dir() or (parent / "metrics").is_dir():
            return parent
    raise ValueError(
        f"Trainingslauf zu Modell konnte nicht ermittelt werden: {model_path}. "
        "Erwartet wird normalerweise <run>/models/<modell>.keras."
    )


def infer_square_input_size(model: tf.keras.Model) -> int:
    shape = model.input_shape
    if isinstance(shape, list):
        shape = shape[0]
    if len(shape) < 4:
        raise ValueError(f"Unerwartete Modell-Inputshape: {shape}")
    h, w = shape[1], shape[2]
    if h is None or w is None:
        return IMG_SIZE
    if int(h) != int(w):
        raise ValueError(f"Nur quadratische Modellinputs werden unterstuetzt: {shape}")
    return int(h)


def load_model_robust(model_path: Path) -> tf.keras.Model:
    model_path = Path(model_path).expanduser().resolve()
    if not model_path.is_file():
        raise FileNotFoundError(f"Modelldatei fehlt: {model_path}")

    attempts = [
        {"compile": False, "safe_mode": False},
        {"compile": False},
    ]
    last_exc = None
    for kwargs in attempts:
        try:
            return tf.keras.models.load_model(
                model_path,
                custom_objects=CUSTOM_OBJECTS,
                **kwargs,
            )
        except TypeError:
            # Aeltere Keras-Version ohne safe_mode.
            try:
                return tf.keras.models.load_model(
                    model_path,
                    custom_objects=CUSTOM_OBJECTS,
                    compile=False,
                )
            except Exception as exc:
                last_exc = exc
        except Exception as exc:
            last_exc = exc
    raise RuntimeError(f"Modell konnte nicht geladen werden: {model_path}\n{last_exc}")


# =============================================================================
# 7. INDIVIDUELLE THRESHOLDS LADEN
# =============================================================================

def find_threshold_txt_for_model(model_path: Path) -> Path:
    run_dir = resolve_run_dir_from_model(model_path)
    threshold_dir = run_dir / "threshold_results2"
    if not threshold_dir.is_dir():
        raise FileNotFoundError(f"Threshold-Ordner fehlt: {threshold_dir}")

    exact = threshold_dir / f"{model_path.stem}{THRESHOLD_FILENAME_SUFFIX}"
    if exact.is_file():
        return exact

    same_model = sorted(threshold_dir.glob(f"{model_path.stem}*.txt"))
    candidates = same_model + [
        p for p in sorted(threshold_dir.glob("*.txt")) if p not in same_model
    ]

    pattern = re.compile(
        r"ROI\s+minimaler\s+Balanced\s+Error\s*:\s*"
        r"Threshold\s*=\s*([0-9.eE+-]+)",
        re.IGNORECASE,
    )
    for path in candidates:
        try:
            text = path.read_text(encoding="utf-8", errors="replace")
        except OSError:
            continue
        if pattern.search(text):
            return path

    raise FileNotFoundError(
        f"Keine Threshold-TXT mit 'ROI minimaler Balanced Error' fuer "
        f"{model_path.name} in {threshold_dir} gefunden."
    )


def read_individual_threshold(model_path: Path) -> dict[str, Any]:
    txt_path = find_threshold_txt_for_model(model_path)
    text = txt_path.read_text(encoding="utf-8", errors="replace")

    final_section = text
    section_match = re.search(
        r"FINALE\s+THRESHOLD-EMPFEHLUNGEN",
        text,
        re.IGNORECASE,
    )
    if section_match is not None:
        final_section = text[section_match.end():]

    match = re.search(
        r"ROI\s+minimaler\s+Balanced\s+Error\s*:\s*"
        r"Threshold\s*=\s*([0-9.eE+-]+)",
        final_section,
        re.IGNORECASE,
    )
    if match is None:
        raise ValueError(f"Threshold nicht lesbar: {txt_path}")

    threshold = float(match.group(1))
    # Exakt 0 oder 1 waeren fuer die Odds-Zentrierung degeneriert.
    if not 0.0 < threshold < 1.0:
        raise ValueError(
            f"Threshold muss fuer die threshold-zentrierte Fusion strikt in (0,1) liegen, "
            f"gefunden: {threshold} in {txt_path}"
        )

    return {
        "threshold": threshold,
        "threshold_file": txt_path,
    }


# =============================================================================
# 8. TESTDATEN
# =============================================================================

def get_valid_pairs(images_dir: Path, masks_dir: Path) -> list[dict[str, Any]]:
    if not images_dir.is_dir() or not masks_dir.is_dir():
        return []

    images = sorted(
        p for p in images_dir.iterdir()
        if p.is_file() and not p.name.startswith(".")
    )
    masks_by_stem = {
        p.stem.casefold(): p
        for p in masks_dir.iterdir()
        if p.is_file() and not p.name.startswith(".")
    }

    records = []
    for image in images:
        mask = masks_by_stem.get(image.stem.casefold())
        if mask is not None:
            records.append(
                {
                    "image_path": image,
                    "mask_path": mask,
                    "is_hard_negative": False,
                }
            )
    return records


def build_test_records() -> list[dict[str, Any]]:
    split = TEST_DATASET_DIR / f"test_{IMG_SIZE}"
    regular = get_valid_pairs(split / "images", split / "masks")
    if not regular:
        raise RuntimeError(f"Keine regulaeren Testpaare in {split} gefunden.")

    if HARD_NEGATIVE_SHARE <= 0.0:
        return regular

    hn = get_valid_pairs(
        split / f"images_{IMG_SIZE}px_hard_negatives",
        split / f"masks_{IMG_SIZE}px_hard_negatives",
    )
    for row in hn:
        row["is_hard_negative"] = True

    if not hn:
        raise RuntimeError(
            f"HARD_NEGATIVE_SHARE={HARD_NEGATIVE_SHARE}, aber keine Hard-Negatives "
            f"in {split} gefunden."
        )

    share = float(HARD_NEGATIVE_SHARE)
    if not 0.0 <= share <= 1.0:
        raise ValueError("HARD_NEGATIVE_SHARE muss zwischen 0 und 1 liegen.")

    if share >= 1.0:
        selected = hn
    else:
        target_hn = int(round(len(regular) * share / max(1.0 - share, EPS)))
        target_hn = min(target_hn, len(hn))
        rng = np.random.default_rng(HARD_NEGATIVE_RANDOM_SEED)
        if target_hn > 0:
            indices = np.sort(rng.choice(len(hn), size=target_hn, replace=False))
            selected = [hn[int(i)] for i in indices]
        else:
            selected = []

    records = regular + selected
    records.sort(key=lambda r: str(r["image_path"]).casefold())
    return records


def load_and_preprocess(img_path, mask_path, sample_index):
    img = tf.io.read_file(img_path)
    img = tf.image.decode_image(img, channels=3, expand_animations=False)
    img = tf.image.convert_image_dtype(img, tf.float32)
    img = tf.image.resize(
        img,
        [IMG_SIZE, IMG_SIZE],
        method="bilinear",
        antialias=True,
    )
    img.set_shape([IMG_SIZE, IMG_SIZE, 3])

    mask = tf.io.read_file(mask_path)
    mask = tf.image.decode_image(mask, channels=1, expand_animations=False)
    mask = tf.image.resize(mask, [IMG_SIZE, IMG_SIZE], method="nearest")
    if mask.dtype.is_integer:
        mask = tf.cast(mask > 127, tf.float32)
    else:
        mask = tf.cast(mask > 0.5, tf.float32)
    mask.set_shape([IMG_SIZE, IMG_SIZE, 1])

    return img, mask, sample_index


def make_test_dataset(records: list[dict[str, Any]]):
    image_paths = [str(r["image_path"]) for r in records]
    mask_paths = [str(r["mask_path"]) for r in records]
    indices = np.arange(len(records), dtype=np.int64)

    ds = tf.data.Dataset.from_tensor_slices((image_paths, mask_paths, indices))
    options = tf.data.Options()
    options.experimental_deterministic = True
    ds = ds.with_options(options)
    ds = ds.map(load_and_preprocess, num_parallel_calls=tf.data.AUTOTUNE)
    batch = BATCH_SIZE_1024 if IMG_SIZE == 1024 else BATCH_SIZE
    ds = ds.batch(batch, drop_remainder=False)
    ds = ds.prefetch(tf.data.AUTOTUNE)
    return ds


# =============================================================================
# 9. INFERENZ-HILFSFUNKTIONEN
# =============================================================================

def build_inference_function(model: tf.keras.Model, jit_compile: bool):
    @tf.function(jit_compile=jit_compile, reduce_retracing=True)
    def infer(images):
        return model(images, training=False)
    return infer


def make_runner(model: tf.keras.Model, name: str) -> dict[str, Any]:
    return {
        "model": model,
        "name": name,
        "fn": build_inference_function(model, XLA_JIT),
        "xla_failed": False,
    }


def run_runner(runner: dict[str, Any], images: tf.Tensor):
    try:
        return runner["fn"](images)
    except Exception as exc:
        if XLA_JIT and not runner["xla_failed"]:
            print(
                f"\n[WARNUNG] XLA fuer {runner['name']} fehlgeschlagen; "
                f"tf.function ohne XLA wird verwendet: {exc}"
            )
            runner["fn"] = build_inference_function(runner["model"], False)
            runner["xla_failed"] = True
            return runner["fn"](images)
        raise


def first_output(preds):
    if isinstance(preds, (list, tuple)):
        if not preds:
            raise ValueError("Leere Modellausgabe.")
        return preds[0]
    return preds


def ensure_segmentation_prediction(preds, target_size: int) -> tf.Tensor:
    preds = first_output(preds)
    preds = tf.cast(preds, tf.float32)
    if preds.shape.rank == 3:
        preds = preds[..., tf.newaxis]
    if preds.shape.rank != 4:
        raise ValueError(f"Unerwartete Prediction-Shape: {preds.shape}")
    if preds.shape[-1] != 1:
        preds = preds[..., :1]
    if SEGMENTATION_OUTPUTS_ARE_LOGITS:
        preds = tf.math.sigmoid(preds)
    if preds.shape[1] != target_size or preds.shape[2] != target_size:
        preds = tf.image.resize(preds, [target_size, target_size], method="bilinear")
    return tf.clip_by_value(preds, 0.0, 1.0)


def classifier_probabilities(preds) -> np.ndarray:
    preds = first_output(preds)
    arr = np.asarray(tf.cast(preds, tf.float32).numpy())

    if arr.ndim == 1:
        values = arr
        if CLASSIFIER_OUTPUT_IS_LOGITS:
            values = 1.0 / (1.0 + np.exp(-values))
    elif arr.ndim == 2:
        if arr.shape[1] == 1:
            values = arr[:, 0]
            if CLASSIFIER_OUTPUT_IS_LOGITS:
                values = 1.0 / (1.0 + np.exp(-values))
        else:
            if CLASSIFIER_OUTPUT_IS_LOGITS:
                shifted = arr - np.max(arr, axis=1, keepdims=True)
                exp = np.exp(shifted)
                arr = exp / np.sum(exp, axis=1, keepdims=True)
            if not 0 <= CLASSIFIER_POSITIVE_CLASS_INDEX < arr.shape[1]:
                raise ValueError(
                    f"CLASSIFIER_POSITIVE_CLASS_INDEX={CLASSIFIER_POSITIVE_CLASS_INDEX} "
                    f"passt nicht zu Classifier-Shape {arr.shape}."
                )
            values = arr[:, CLASSIFIER_POSITIVE_CLASS_INDEX]
    else:
        raise ValueError(f"Unerwartete Classifier-Ausgabe: {arr.shape}")

    return np.clip(np.asarray(values, dtype=np.float32).reshape(-1), 0.0, 1.0)


def threshold_center_odds_np(prob: np.ndarray, threshold: float) -> np.ndarray:
    """
    Threshold-zentrierte Odds-Transformation.

    Der optimale Einzelmodellthreshold wird auf 0.5 abgebildet. Das ist besonders
    wichtig, wenn z.B. FINE t~3.3e-05 und PRECISE t~0.4 haben.
    """
    p = np.clip(np.asarray(prob, dtype=np.float32), 0.0, 1.0)
    t = np.float32(threshold)
    numerator = p * (np.float32(1.0) - t)
    denominator = numerator + (np.float32(1.0) - p) * t
    out = np.divide(
        numerator,
        denominator,
        out=np.zeros_like(numerator, dtype=np.float32),
        where=denominator != 0,
    )
    return np.clip(out, 0.0, 1.0)


def dynamic_threshold_center_odds_np(
    score: np.ndarray,
    threshold: np.ndarray,
) -> np.ndarray:
    p = np.clip(np.asarray(score, dtype=np.float32), 0.0, 1.0)
    t = np.clip(np.asarray(threshold, dtype=np.float32), 0.0, 1.0)
    numerator = p * (np.float32(1.0) - t)
    denominator = numerator + (np.float32(1.0) - p) * t
    out = np.divide(
        numerator,
        denominator,
        out=np.zeros_like(numerator, dtype=np.float32),
        where=denominator != 0,
    )
    return np.clip(out, 0.0, 1.0)


# =============================================================================
# 10. METRIKEN - GLEICHE DEFINITIONEN WIE TESTDATASET-SKRIPT
# =============================================================================

def confusion_counts_for_thresholds(y_true_flat, y_prob_flat, thresholds):
    y_true_bool = y_true_flat.astype(bool, copy=False)
    probs = y_prob_flat.astype(np.float32, copy=False)
    pos = np.sort(probs[y_true_bool])
    neg = np.sort(probs[~y_true_bool])
    thresholds = np.asarray(thresholds, dtype=np.float64)
    tp = pos.size - np.searchsorted(pos, thresholds, side="left")
    fp = neg.size - np.searchsorted(neg, thresholds, side="left")
    fn = pos.size - tp
    tn = neg.size - fp
    return tp, fp, fn, tn


def compute_ap_from_threshold_confusions(tp, fp, fn):
    total_pos = float(np.max(tp + fn)) if len(tp) else 0.0
    if total_pos <= 0:
        return float("nan")
    pred_pos = tp + fp
    precision = np.divide(
        tp,
        pred_pos,
        out=np.ones_like(tp, dtype=np.float64),
        where=pred_pos > 0,
    )
    recall = tp / total_pos
    order = np.argsort(recall)
    recall = recall[order]
    precision = precision[order]
    recall = np.concatenate(([0.0], recall, [1.0]))
    precision = np.concatenate(
        ([precision[0] if precision.size else 0.0], precision, [0.0])
    )
    for i in range(len(precision) - 2, -1, -1):
        precision[i] = max(precision[i], precision[i + 1])
    return float(np.sum((recall[1:] - recall[:-1]) * precision[1:]))



def build_balanced_crack_roi_sample(
    y_true_2d: np.ndarray,
    y_prob_2d: np.ndarray,
    rng: np.random.Generator,
    ring_radius_px: int,
    negative_to_positive_ratio: float,
):
    """Erzeugt dieselbe BALANCED CRACK ROI wie der separate Sample-Testcode."""
    y_true_bool = np.asarray(y_true_2d).astype(bool)
    y_prob = np.asarray(y_prob_2d, dtype=np.float32)
    if y_true_bool.shape != y_prob.shape:
        raise ValueError(
            f"ROI: GT-Shape {y_true_bool.shape} passt nicht zu "
            f"Prediction-Shape {y_prob.shape}."
        )

    positive_flat = np.flatnonzero(y_true_bool.reshape(-1))
    n_pos = int(positive_flat.size)
    stats = {
        "positive_pixels": n_pos,
        "ring_pixels_available": 0,
        "ring_pixels_sampled": 0,
        "far_background_available": 0,
        "far_background_sampled": 0,
        "negative_pixels_sampled": 0,
        "ring_was_downsampled": False,
        "skipped_no_positive": False,
        "negative_shortfall": 0,
    }
    if n_pos == 0:
        stats["skipped_no_positive"] = True
        return (
            np.empty(0, dtype=np.uint8),
            np.empty(0, dtype=np.float32),
            stats,
        )

    radius = int(ring_radius_px)
    if radius < 0:
        raise ValueError("ROI_RING_RADIUS_PX darf nicht negativ sein.")
    if radius == 0:
        dilated = y_true_bool.copy()
    else:
        kernel_size = 2 * radius + 1
        kernel = cv2.getStructuringElement(
            cv2.MORPH_ELLIPSE,
            (kernel_size, kernel_size),
        )
        dilated = cv2.dilate(
            y_true_bool.astype(np.uint8),
            kernel,
            iterations=1,
        ).astype(bool)

    ring_flat = np.flatnonzero(np.logical_and(dilated, ~y_true_bool).reshape(-1))
    far_flat = np.flatnonzero((~dilated).reshape(-1))
    stats["ring_pixels_available"] = int(ring_flat.size)
    stats["far_background_available"] = int(far_flat.size)

    target_neg = max(0, int(round(n_pos * float(negative_to_positive_ratio))))
    sampled_ring = np.empty(0, dtype=np.int64)
    sampled_far = np.empty(0, dtype=np.int64)

    if target_neg > 0 and ring_flat.size >= target_neg:
        if ring_flat.size == target_neg:
            sampled_ring = ring_flat
        else:
            sampled_ring = rng.choice(ring_flat, size=target_neg, replace=False)
            stats["ring_was_downsampled"] = True
    elif target_neg > 0:
        sampled_ring = ring_flat
        remaining = target_neg - int(ring_flat.size)
        if remaining > 0 and far_flat.size > 0:
            n_far = min(remaining, int(far_flat.size))
            sampled_far = (
                far_flat
                if n_far == far_flat.size
                else rng.choice(far_flat, size=n_far, replace=False)
            )

    negative_flat = np.concatenate(
        [
            np.asarray(sampled_ring, dtype=np.int64),
            np.asarray(sampled_far, dtype=np.int64),
        ]
    )
    stats["ring_pixels_sampled"] = int(sampled_ring.size)
    stats["far_background_sampled"] = int(sampled_far.size)
    stats["negative_pixels_sampled"] = int(negative_flat.size)
    stats["negative_shortfall"] = max(0, target_neg - int(negative_flat.size))

    flat_prob = y_prob.reshape(-1)
    sampled_true = np.concatenate(
        [
            np.ones(n_pos, dtype=np.uint8),
            np.zeros(negative_flat.size, dtype=np.uint8),
        ]
    )
    sampled_prob = np.concatenate(
        [flat_prob[positive_flat], flat_prob[negative_flat]]
    ).astype(np.float32, copy=False)
    return sampled_true, sampled_prob, stats


def make_empty_roi_sampling_stats() -> dict[str, int]:
    return {
        "images_total": 0,
        "images_used": 0,
        "images_skipped_no_positive": 0,
        "images_ring_downsampled": 0,
        "positive_pixels": 0,
        "negative_pixels_sampled": 0,
        "ring_pixels_available": 0,
        "ring_pixels_sampled": 0,
        "far_background_available": 0,
        "far_background_sampled": 0,
        "negative_shortfall": 0,
    }


def accumulate_roi_sampling_stats(total: dict[str, int], sample: dict[str, Any]) -> None:
    total["images_total"] += 1
    if sample["skipped_no_positive"]:
        total["images_skipped_no_positive"] += 1
        return
    total["images_used"] += 1
    if sample["ring_was_downsampled"]:
        total["images_ring_downsampled"] += 1
    for key in (
        "positive_pixels",
        "negative_pixels_sampled",
        "ring_pixels_available",
        "ring_pixels_sampled",
        "far_background_available",
        "far_background_sampled",
        "negative_shortfall",
    ):
        total[key] += int(sample[key])

def metrics_from_confusions(
    tp_all: np.ndarray,
    fp_all: np.ndarray,
    fn_all: np.ndarray,
    tn_all: np.ndarray,
    metric_thresholds: np.ndarray,
) -> dict[str, Any]:
    selected_idx = int(np.argmin(np.abs(metric_thresholds - METRIC_DECISION_THRESHOLD)))
    tp = int(tp_all[selected_idx])
    fp = int(fp_all[selected_idx])
    fn = int(fn_all[selected_idx])
    tn = int(tn_all[selected_idx])

    precision = safe_div(tp, tp + fp)
    recall = safe_div(tp, tp + fn)
    dice = safe_div(2 * tp, 2 * tp + fp + fn)
    iou = safe_div(tp, tp + fp + fn)
    f1 = safe_div(2 * precision * recall, precision + recall)
    beta2 = 4.0
    f2 = safe_div((1.0 + beta2) * precision * recall, beta2 * precision + recall)
    accuracy_pct = safe_div(tp + tn, tp + tn + fp + fn) * 100.0
    fpr = safe_div(fp, fp + tn)
    fnr = safe_div(fn, fn + tp)
    bal_err = 0.5 * (fpr + fnr)
    bal_acc = 1.0 - bal_err

    ap_idx = np.array(
        [int(np.argmin(np.abs(metric_thresholds - t))) for t in AP_THRESHOLDS]
    )
    test_ap = compute_ap_from_threshold_confusions(
        tp_all[ap_idx],
        fp_all[ap_idx],
        fn_all[ap_idx],
    )

    d_score = float(
        np.sqrt(0.5 * (1.0 - dice) ** 2 + 0.5 * (1.0 - f2) ** 2)
    )

    return {
        "test_dice_fg": dice,
        "test_iou_fg": iou,
        "test_precision_fg": precision,
        "test_recall_fg": recall,
        "test_f1_fg": f1,
        "test_f2": f2,
        "test_ap": test_ap,
        "test_accuracy_pct": accuracy_pct,
        "balanced_error": bal_err,
        "balanced_accuracy": bal_acc,
        "fpr": fpr,
        "fnr": fnr,
        "tp": tp,
        "fp": fp,
        "fn": fn,
        "tn": tn,
        "D": d_score,
    }


# =============================================================================
# 11. ALTE ADAPTIVE FUSION + TESTAUSWERTUNG
# =============================================================================

def evaluate_old_adaptive_fusion(
    test_ds,
    records: list[dict[str, Any]],
    classifier_info: dict[str, Any],
    fine_info: dict[str, Any],
    precise_info: dict[str, Any],
) -> tuple[dict[str, Any], dict[str, Any], list[dict[str, Any]], dict[str, Any]]:
    """
    Fuehrt genau einen Testlauf durch.

    Wichtig:
      - Classifier zuerst.
      - Nur aktive Bilder werden durch FINE und PRECISE geschickt.
      - Beide Modelloutputs werden mit ihrem eigenen Threshold kontinuierlich
        threshold-zentriert.
      - Danach alte classifier-gesteuerte Gewichtung + alter dynamischer Threshold.
      - Kein Verteilungssweep.
    """
    metric_thresholds = np.unique(
        np.concatenate(
            (
                np.asarray([METRIC_DECISION_THRESHOLD], dtype=np.float64),
                AP_THRESHOLDS,
            )
        )
    )
    tp_all = np.zeros(len(metric_thresholds), dtype=np.int64)
    fp_all = np.zeros(len(metric_thresholds), dtype=np.int64)
    fn_all = np.zeros(len(metric_thresholds), dtype=np.int64)
    tn_all = np.zeros(len(metric_thresholds), dtype=np.int64)

    # Separate BALANCED-CRACK-ROI-Akkumulatoren; werden im selben Inferenzlauf
    # gefuellt und beeinflussen die normalen Vollbildmetriken nicht.
    sample_tp_all = np.zeros(len(metric_thresholds), dtype=np.int64)
    sample_fp_all = np.zeros(len(metric_thresholds), dtype=np.int64)
    sample_fn_all = np.zeros(len(metric_thresholds), dtype=np.int64)
    sample_tn_all = np.zeros(len(metric_thresholds), dtype=np.int64)
    sample_rng = np.random.default_rng(int(ROI_RANDOM_SEED))
    sampling_stats = make_empty_roi_sampling_stats()
    total_sampled_pixels = 0

    classifier_runner = make_runner(classifier_info["model"], "classifier")
    fine_runner = make_runner(fine_info["model"], "fine_model")
    precise_runner = make_runner(precise_info["model"], "precise_model")

    classifier_fn_rows: list[dict[str, Any]] = []

    # Diagnosewerte ueber den Lauf, ohne Pixelmaps zu speichern.
    diag = {
        "images_total": 0,
        "images_classifier_active": 0,
        "images_classifier_negative": 0,
        "classifier_probability_sum": 0.0,
        "fine_weight_sum": 0.0,
        "precise_weight_sum": 0.0,
        "dynamic_threshold_sum": 0.0,
        "min_classifier_probability": 1.0,
        "max_classifier_probability": 0.0,
        "min_fine_weight": 1.0,
        "max_fine_weight": 0.0,
        "min_dynamic_threshold": 1.0,
        "max_dynamic_threshold": 0.0,
    }

    processed = 0

    for batch_index, (images, masks, sample_indices) in enumerate(test_ds, start=1):
        batch_size = int(tf.shape(images)[0].numpy())
        sample_indices_np = sample_indices.numpy().astype(np.int64)

        # ------------------------------------------------------------------
        # 1) CLASSIFIER ZUERST
        # ------------------------------------------------------------------
        cls_images = images
        if classifier_info["input_size"] != IMG_SIZE:
            cls_images = tf.image.resize(
                images,
                [classifier_info["input_size"], classifier_info["input_size"]],
                method="bilinear",
                antialias=True,
            )

        cls_preds = run_runner(classifier_runner, cls_images)
        cls_probs = classifier_probabilities(cls_preds)
        active_mask = cls_probs >= CLASSIFIER_GATE_THRESHOLD
        active_indices = np.flatnonzero(active_mask)

        diag["images_total"] += batch_size
        diag["images_classifier_active"] += int(active_mask.sum())
        diag["images_classifier_negative"] += int((~active_mask).sum())
        diag["classifier_probability_sum"] += float(cls_probs.sum())
        if cls_probs.size:
            diag["min_classifier_probability"] = min(
                diag["min_classifier_probability"], float(cls_probs.min())
            )
            diag["max_classifier_probability"] = max(
                diag["max_classifier_probability"], float(cls_probs.max())
            )

        mask_np = masks.numpy()[..., 0] >= 0.5

        # ------------------------------------------------------------------
        # 2) CLASSIFIER-FN LOGGING BEI HN=0
        # ------------------------------------------------------------------
        if float(HARD_NEGATIVE_SHARE) == 0.0:
            gt_pos_per_image = mask_np.reshape(batch_size, -1).sum(axis=1)
            for local_idx in np.flatnonzero(~active_mask):
                global_idx = int(sample_indices_np[local_idx])
                rec = records[global_idx]
                classifier_fn_rows.append(
                    {
                        "sample_index": global_idx,
                        "image_name": Path(rec["image_path"]).name,
                        "image_path": str(Path(rec["image_path"]).resolve()),
                        "mask_path": str(Path(rec["mask_path"]).resolve()),
                        "classifier_probability": float(cls_probs[local_idx]),
                        "classifier_gate_threshold": float(CLASSIFIER_GATE_THRESHOLD),
                        "gt_positive_pixels": int(gt_pos_per_image[local_idx]),
                        "decision": "negative -> Classifier_FN (HARD_NEGATIVE_SHARE=0)",
                    }
                )

        # Einheitlicher finaler Decision-Score in [0,1].
        # Inaktive Bilder bleiben 0 und sind damit final negativ.
        decision_score = np.zeros(
            (batch_size, IMG_SIZE, IMG_SIZE),
            dtype=np.float32,
        )

        # ------------------------------------------------------------------
        # 3) NUR CLASSIFIER-AKTIVE BILDER SEGMENTIEREN
        # ------------------------------------------------------------------
        if active_indices.size > 0:
            active_images = tf.gather(images, active_indices)

            fine_images = active_images
            if fine_info["input_size"] != IMG_SIZE:
                fine_images = tf.image.resize(
                    active_images,
                    [fine_info["input_size"], fine_info["input_size"]],
                    method="bilinear",
                    antialias=True,
                )

            precise_images = active_images
            if precise_info["input_size"] != IMG_SIZE:
                precise_images = tf.image.resize(
                    active_images,
                    [precise_info["input_size"], precise_info["input_size"]],
                    method="bilinear",
                    antialias=True,
                )

            fine_raw = ensure_segmentation_prediction(
                run_runner(fine_runner, fine_images),
                IMG_SIZE,
            ).numpy()[..., 0]
            precise_raw = ensure_segmentation_prediction(
                run_runner(precise_runner, precise_images),
                IMG_SIZE,
            ).numpy()[..., 0]

            # --------------------------------------------------------------
            # 4) NEU: JE MODELL EIGENEN OPTIMALEN THRESHOLD ZENTRIEREN
            # --------------------------------------------------------------
            fine_centered = threshold_center_odds_np(
                fine_raw,
                fine_info["threshold"],
            )
            precise_centered = threshold_center_odds_np(
                precise_raw,
                precise_info["threshold"],
            )

            # --------------------------------------------------------------
            # 5) ALTE CLASSIFIER-GESTEUERTE GEWICHTUNG
            # --------------------------------------------------------------
            active_cls = cls_probs[active_indices].astype(np.float32)
            fine_weight = (
                np.float32(FINE_BASE_WEIGHT)
                + np.float32(FINE_EXTRA_WEIGHT) * active_cls
            )
            fine_weight = np.clip(fine_weight, 0.0, 1.0)
            precise_weight = np.float32(1.0) - fine_weight

            fw = fine_weight[:, None, None]
            pw = precise_weight[:, None, None]

            fused_score = (
                fw * fine_centered
                + pw * precise_centered
            ).astype(np.float32, copy=False)

            # --------------------------------------------------------------
            # 6) ALTER DYNAMISCHER PIXELTHRESHOLD, WEITER CLASSIFIER-GESTEUERT
            # --------------------------------------------------------------
            dynamic_threshold = (
                np.float32(PIXEL_THRESHOLD_HIGH)
                - np.float32(PIXEL_THRESHOLD_HIGH - PIXEL_THRESHOLD_LOW)
                * active_cls
            )
            dynamic_threshold = np.clip(dynamic_threshold, 0.0, 1.0)

            # Diese Transformation aendert die binaere Entscheidung nicht:
            # fused >= dynamic_threshold <=> metric_score >= 0.5.
            metric_score_active = dynamic_threshold_center_odds_np(
                fused_score,
                dynamic_threshold[:, None, None],
            )
            decision_score[active_indices] = metric_score_active

            # Diagnose der alten dynamischen Steuerung.
            diag["fine_weight_sum"] += float(fine_weight.sum())
            diag["precise_weight_sum"] += float(precise_weight.sum())
            diag["dynamic_threshold_sum"] += float(dynamic_threshold.sum())
            diag["min_fine_weight"] = min(
                diag["min_fine_weight"], float(fine_weight.min())
            )
            diag["max_fine_weight"] = max(
                diag["max_fine_weight"], float(fine_weight.max())
            )
            diag["min_dynamic_threshold"] = min(
                diag["min_dynamic_threshold"], float(dynamic_threshold.min())
            )
            diag["max_dynamic_threshold"] = max(
                diag["max_dynamic_threshold"], float(dynamic_threshold.max())
            )

            del (
                fine_raw,
                precise_raw,
                fine_centered,
                precise_centered,
                fused_score,
                metric_score_active,
            )

        # ------------------------------------------------------------------
        # 7) METRIKEN EXAKT WIE TESTCODE UEBER CONFUSION COUNTS
        # ------------------------------------------------------------------
        y_true = mask_np.reshape(-1)
        y_prob = decision_score.reshape(-1)
        btp, bfp, bfn, btn = confusion_counts_for_thresholds(
            y_true,
            y_prob,
            metric_thresholds,
        )
        tp_all += btp
        fp_all += bfp
        fn_all += bfn
        tn_all += btn

        # --------------------------------------------------------------
        # 8) BALANCED CRACK ROI SAMPLE-METRIKEN IM SELBEN INFERENZLAUF
        # --------------------------------------------------------------
        for image_index in range(batch_size):
            sampled_true, sampled_prob, sample_stats = build_balanced_crack_roi_sample(
                mask_np[image_index],
                decision_score[image_index],
                sample_rng,
                ROI_RING_RADIUS_PX,
                ROI_NEGATIVE_TO_POSITIVE_RATIO,
            )
            accumulate_roi_sampling_stats(sampling_stats, sample_stats)
            if sampled_true.size == 0:
                continue
            total_sampled_pixels += int(sampled_true.size)
            stp, sfp, sfn, stn = confusion_counts_for_thresholds(
                sampled_true,
                sampled_prob,
                metric_thresholds,
            )
            sample_tp_all += stp
            sample_fp_all += sfp
            sample_fn_all += sfn
            sample_tn_all += stn

        processed += batch_size
        print(
            f"\rBatch {batch_index} | Bilder {processed}/{len(records)} | "
            f"Classifier aktiv {int(active_mask.sum())}/{batch_size}",
            end="",
            flush=True,
        )

        del images, masks, decision_score

    print()

    if diag["images_total"] <= 0:
        raise RuntimeError("Das Testset enthaelt keine auswertbaren Bilder.")

    active_count = int(diag["images_classifier_active"])
    total_count = int(diag["images_total"])

    diag["classifier_probability_mean"] = (
        diag["classifier_probability_sum"] / total_count
    )
    if active_count > 0:
        diag["fine_weight_mean_active"] = diag["fine_weight_sum"] / active_count
        diag["precise_weight_mean_active"] = diag["precise_weight_sum"] / active_count
        diag["dynamic_threshold_mean_active"] = (
            diag["dynamic_threshold_sum"] / active_count
        )
    else:
        diag["fine_weight_mean_active"] = None
        diag["precise_weight_mean_active"] = None
        diag["dynamic_threshold_mean_active"] = None
        diag["min_fine_weight"] = None
        diag["max_fine_weight"] = None
        diag["min_dynamic_threshold"] = None
        diag["max_dynamic_threshold"] = None

    diag["classifier_active_share"] = active_count / total_count

    metrics = metrics_from_confusions(
        tp_all,
        fp_all,
        fn_all,
        tn_all,
        metric_thresholds,
    )

    if total_sampled_pixels <= 0:
        raise RuntimeError(
            "Das Testset enthaelt keine Maske mit positiven Risspixeln; "
            "die BALANCED CRACK ROI ist leer."
        )

    sampled_metrics = metrics_from_confusions(
        sample_tp_all,
        sample_fp_all,
        sample_fn_all,
        sample_tn_all,
        metric_thresholds,
    )
    sampled_metrics.update(
        {
            "sampled_pixels_total": int(total_sampled_pixels),
            "sample_images_total": int(sampling_stats["images_total"]),
            "sample_images_used": int(sampling_stats["images_used"]),
            "sample_images_skipped_no_positive": int(sampling_stats["images_skipped_no_positive"]),
            "sample_images_ring_downsampled": int(sampling_stats["images_ring_downsampled"]),
            "sample_positive_pixels": int(sampling_stats["positive_pixels"]),
            "sample_negative_pixels": int(sampling_stats["negative_pixels_sampled"]),
            "sample_ring_pixels_available": int(sampling_stats["ring_pixels_available"]),
            "sample_ring_pixels_sampled": int(sampling_stats["ring_pixels_sampled"]),
            "sample_far_background_available": int(sampling_stats["far_background_available"]),
            "sample_far_background_sampled": int(sampling_stats["far_background_sampled"]),
            "sample_negative_shortfall": int(sampling_stats["negative_shortfall"]),
        }
    )

    return metrics, sampled_metrics, classifier_fn_rows, diag


# =============================================================================
# 12. CLASSIFIER-FN LOGGING
# =============================================================================

def save_classifier_false_negatives(rows: list[dict[str, Any]]) -> None:
    CLASSIFIER_FN_DIR.mkdir(parents=True, exist_ok=True)

    fields = [
        "sample_index",
        "image_name",
        "image_path",
        "mask_path",
        "classifier_probability",
        "classifier_gate_threshold",
        "gt_positive_pixels",
        "decision",
    ]

    with CLASSIFIER_FN_CSV_FILE.open("w", encoding="utf-8", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=fields)
        writer.writeheader()
        for row in rows:
            writer.writerow(
                {
                    **row,
                    "classifier_probability": f"{row['classifier_probability']:.10g}",
                    "classifier_gate_threshold": f"{row['classifier_gate_threshold']:.10g}",
                }
            )

    with CLASSIFIER_FN_TXT_FILE.open("w", encoding="utf-8") as f:
        f.write("=" * 120 + "\n")
        f.write(f"Run: {RUN_NAME}\n")
        f.write("Classifier-negativ bewertete Testbilder bei HARD_NEGATIVE_SHARE == 0.0\n")
        f.write(f"Classifier gate threshold: {CLASSIFIER_GATE_THRESHOLD:.10g}\n")
        f.write(f"Anzahl: {len(rows)}\n")
        f.write("=" * 120 + "\n\n")
        for i, row in enumerate(rows, start=1):
            f.write(f"[{i}] {row['image_name']}\n")
            f.write(f"  sample_index: {row['sample_index']}\n")
            f.write(f"  image_path: {row['image_path']}\n")
            f.write(f"  mask_path: {row['mask_path']}\n")
            f.write(
                f"  classifier_probability: {row['classifier_probability']:.10g}\n"
            )
            f.write(
                f"  classifier_gate_threshold: {row['classifier_gate_threshold']:.10g}\n"
            )
            f.write(f"  gt_positive_pixels: {row['gt_positive_pixels']}\n")
            f.write(f"  decision: {row['decision']}\n\n")


# =============================================================================
# 13. FINALE TESTMETRIKEN LOGGEN
# =============================================================================

SUMMARY_FIELDS = [
    "rank_d",
    "run_name",
    "model_name",
    "model_id",
    "best_epoch",
    "img_size",
    "threshold",
    "best_val_dice_fg",
    "test_dice_fg",
    "test_iou_fg",
    "test_precision_fg",
    "test_recall_fg",
    "test_f1_fg",
    "test_f2",
    "test_ap",
    "test_accuracy_pct",
    "balanced_error",
    "balanced_accuracy",
    "fpr",
    "fnr",
    "tp",
    "fp",
    "fn",
    "tn",
    "D",
]


def ensemble_metadata(
    classifier_info: dict[str, Any],
    fine_info: dict[str, Any],
    precise_info: dict[str, Any],
    records: list[dict[str, Any]],
    classifier_fn_count: int,
    diagnostics: dict[str, Any],
) -> dict[str, Any]:
    hard_negative_count = sum(bool(r["is_hard_negative"]) for r in records)
    return {
        "evaluated_at": datetime.now().isoformat(timespec="seconds"),
        "test_dataset_dir": TEST_DATASET_DIR,
        "test_image_count": len(records),
        "hard_negative_share_configured": HARD_NEGATIVE_SHARE,
        "hard_negative_count_effective": hard_negative_count,
        "classifier_fn_count": classifier_fn_count,
        "saved_ensemble_model": ENSEMBLE_MODEL_PATH,
        "saved_ensemble_output": "continuous decision_score; binary decision at 0.5",
        "sample_evaluation": {
            "type": "BALANCED CRACK ROI",
            "ring_radius_px": ROI_RING_RADIUS_PX,
            "negative_to_positive_ratio": ROI_NEGATIVE_TO_POSITIVE_RATIO,
            "random_seed": ROI_RANDOM_SEED,
        },
        "classifier": {
            "model_path": classifier_info["model_path"],
            "input_size": classifier_info["input_size"],
            "gate_threshold": CLASSIFIER_GATE_THRESHOLD,
            "positive_class_index": CLASSIFIER_POSITIVE_CLASS_INDEX,
            "output_is_logits": CLASSIFIER_OUTPUT_IS_LOGITS,
        },
        "fine_model": {
            "run_name": fine_info["run_name"],
            "model_name": fine_info["model_name"],
            "model_path": fine_info["model_path"],
            "input_size": fine_info["input_size"],
            "individual_threshold": fine_info["threshold"],
            "threshold_file": fine_info["threshold_file"],
        },
        "precise_model": {
            "run_name": precise_info["run_name"],
            "model_name": precise_info["model_name"],
            "model_path": precise_info["model_path"],
            "input_size": precise_info["input_size"],
            "individual_threshold": precise_info["threshold"],
            "threshold_file": precise_info["threshold_file"],
        },
        "old_fusion_parameters": {
            "fine_base_weight": FINE_BASE_WEIGHT,
            "fine_extra_weight": FINE_EXTRA_WEIGHT,
            "precise_weight_formula": "1 - fine_weight",
            "pixel_threshold_high": PIXEL_THRESHOLD_HIGH,
            "pixel_threshold_low": PIXEL_THRESHOLD_LOW,
            "metric_decision_threshold": METRIC_DECISION_THRESHOLD,
        },
        "threshold_centering": {
            "enabled": True,
            "formula": "q=p*(1-t)/(p*(1-t)+(1-p)*t)",
            "meaning": "individual model threshold t maps to q=0.5",
            "preserves_continuous_scores": True,
        },
        "fusion_semantics": (
            "Classifier steuert weiterhin Gate, Fine/Precise-Gewichte und dynamischen "
            "Endthreshold. Neu werden die beiden rohen Segmentierungsoutputs vor der "
            "alten Fusion jeweils um ihren individuellen ROI-minimal-Balanced-Error-"
            "Threshold auf eine gemeinsame Entscheidungsskala zentriert."
        ),
        "ap_semantics": (
            "Der classifier-dynamische Endthreshold wird fuer die gemeinsame AP-Skala "
            "threshold-zentriert auf 0.5. Die binaere Entscheidung bleibt identisch."
        ),
        "diagnostics": diagnostics,
    }


def format_table_value(value: Any) -> str:
    if value is None:
        return "n/a"
    if isinstance(value, (float, np.floating)):
        if not np.isfinite(float(value)):
            return "n/a"
        return f"{float(value):.6f}"
    return str(value)


def write_horizontal_metrics_table(
    file,
    fields: list[str],
    result: dict[str, Any],
) -> None:
    """Schreibt die Metriken als echte horizontale Tabelle: Header + eine Datenzeile."""
    file.write("\t".join(fields) + "\n")
    file.write("\t".join(format_table_value(result.get(key)) for key in fields) + "\n")


def save_final_metrics(
    metrics: dict[str, Any],
    metadata: dict[str, Any],
) -> dict[str, Any]:
    TEST_METRICS_DIR.mkdir(parents=True, exist_ok=True)

    result = {
        "rank_d": 1,
        "run_name": RUN_NAME,
        "model_name": f"{RUN_NAME}_ensemble",
        "model_id": sanitize_name(RUN_NAME).casefold(),
        "best_epoch": None,
        "img_size": IMG_SIZE,
        "threshold": float(METRIC_DECISION_THRESHOLD),
        "best_val_dice_fg": None,
        **metrics,
    }

    with FINAL_METRICS_TXT_FILE.open("w", encoding="utf-8") as f:
        f.write("=" * 180 + "\n")
        f.write("VOLLSTAENDIGE TESTAUSWERTUNG - GLOBALE PIXELMETRIKEN\n")
        f.write(f"Training: {RUN_NAME}\n")
        f.write("Typ: classifier-gesteuertes 2-Modell-Ensemble\n")
        f.write(f"Ranking-Metrik: D = {float(result['D']):.6f} (kleiner = besser)\n")
        f.write("=" * 180 + "\n")
        write_horizontal_metrics_table(f, SUMMARY_FIELDS, result)
        f.write("\n" + "=" * 180 + "\n")
        f.write("ENSEMBLE-METADATEN\n")
        f.write("=" * 180 + "\n")
        f.write(json.dumps(json_safe(metadata), indent=2, ensure_ascii=False) + "\n")

    with FINAL_METRICS_CSV_FILE.open("w", encoding="utf-8", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=SUMMARY_FIELDS)
        writer.writeheader()
        writer.writerow({key: round_for_output(result.get(key)) for key in SUMMARY_FIELDS})

    payload = {key: round_for_output(result.get(key)) for key in SUMMARY_FIELDS}
    payload["ensemble_metadata"] = metadata
    write_json_atomic(FINAL_METRICS_JSON_FILE, payload)
    return payload


SAMPLED_SUMMARY_FIELDS = [
    *SUMMARY_FIELDS,
    "roi_ring_radius_px",
    "roi_negative_to_positive_ratio",
    "roi_random_seed",
    "sampled_pixels_total",
    "sample_images_total",
    "sample_images_used",
    "sample_images_skipped_no_positive",
    "sample_images_ring_downsampled",
    "sample_positive_pixels",
    "sample_negative_pixels",
    "sample_ring_pixels_available",
    "sample_ring_pixels_sampled",
    "sample_far_background_available",
    "sample_far_background_sampled",
    "sample_negative_shortfall",
]


def save_sampled_metrics(
    metrics: dict[str, Any],
    metadata: dict[str, Any],
) -> dict[str, Any]:
    TEST_METRICS_DIR.mkdir(parents=True, exist_ok=True)
    result = {
        "rank_d": 1,
        "run_name": RUN_NAME,
        "model_name": f"{RUN_NAME}_ensemble",
        "model_id": sanitize_name(RUN_NAME).casefold(),
        "best_epoch": None,
        "img_size": IMG_SIZE,
        "threshold": float(METRIC_DECISION_THRESHOLD),
        "best_val_dice_fg": None,
        **metrics,
        "roi_ring_radius_px": int(ROI_RING_RADIUS_PX),
        "roi_negative_to_positive_ratio": float(ROI_NEGATIVE_TO_POSITIVE_RATIO),
        "roi_random_seed": int(ROI_RANDOM_SEED),
    }

    with SAMPLED_METRICS_TXT_FILE.open("w", encoding="utf-8") as f:
        f.write("=" * 180 + "\n")
        f.write("SAMPLE-TEST-AUSWERTUNG - BALANCED CRACK ROI\n")
        f.write(f"Training: {RUN_NAME}\n")
        f.write(
            f"Sampling: alle GT-Risspixel + N_neg/N_pos={ROI_NEGATIVE_TO_POSITIVE_RATIO:.6g}; "
            f"Ringradius={ROI_RING_RADIUS_PX} px; Seed={ROI_RANDOM_SEED}\n"
        )
        f.write(f"Ranking-Metrik: D = {float(result['D']):.6f} (kleiner = besser)\n")
        f.write("=" * 180 + "\n")
        write_horizontal_metrics_table(f, SAMPLED_SUMMARY_FIELDS, result)
        f.write("\n" + "=" * 180 + "\n")
        f.write("ENSEMBLE-METADATEN\n")
        f.write("=" * 180 + "\n")
        f.write(json.dumps(json_safe(metadata), indent=2, ensure_ascii=False) + "\n")

    with SAMPLED_METRICS_CSV_FILE.open("w", encoding="utf-8", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=SAMPLED_SUMMARY_FIELDS)
        writer.writeheader()
        writer.writerow({key: round_for_output(result.get(key)) for key in SAMPLED_SUMMARY_FIELDS})

    payload = {key: round_for_output(result.get(key)) for key in SAMPLED_SUMMARY_FIELDS}
    payload["ensemble_metadata"] = metadata
    write_json_atomic(SAMPLED_METRICS_JSON_FILE, payload)
    return payload


# =============================================================================
# 14. ARCHITEKTUR-EXPORT WIE IM U-NET++-TRAINING
# =============================================================================

def clone_model_shell(model: tf.keras.Model, name: str) -> tf.keras.Model:
    return tf.keras.Model(inputs=model.inputs, outputs=model.outputs, name=name)


def build_architecture_model(
    classifier_info: dict[str, Any],
    fine_info: dict[str, Any],
    precise_info: dict[str, Any],
) -> tf.keras.Model:
    ensemble_input = tf.keras.Input(
        shape=(IMG_SIZE, IMG_SIZE, 3),
        dtype=tf.float32,
        name="test_image",
    )

    # ------------------------------------------------------------------
    # CLASSIFIER-BRANCH
    # ------------------------------------------------------------------
    cls_x = ensemble_input
    if classifier_info["input_size"] != IMG_SIZE:
        cls_x = tf.keras.layers.Resizing(
            classifier_info["input_size"],
            classifier_info["input_size"],
            interpolation="bilinear",
            name="classifier_input_resize",
        )(cls_x)

    classifier_branch = clone_model_shell(
        classifier_info["model"],
        name="classifier_model",
    )
    cls_raw = classifier_branch(cls_x)
    if isinstance(cls_raw, (list, tuple)):
        cls_raw = cls_raw[0]
    cls_prob = ClassifierProbability(
        positive_class_index=CLASSIFIER_POSITIVE_CLASS_INDEX,
        output_is_logits=CLASSIFIER_OUTPUT_IS_LOGITS,
        name="classifier_probability",
    )(cls_raw)

    # ------------------------------------------------------------------
    # FINE-BRANCH
    # ------------------------------------------------------------------
    fine_x = ensemble_input
    if fine_info["input_size"] != IMG_SIZE:
        fine_x = tf.keras.layers.Resizing(
            fine_info["input_size"],
            fine_info["input_size"],
            interpolation="bilinear",
            name="fine_input_resize",
        )(fine_x)

    fine_branch = clone_model_shell(
        fine_info["model"],
        name=f"fine_model_{sanitize_name(fine_info['run_name'])}",
    )
    fine_raw = fine_branch(fine_x)
    if isinstance(fine_raw, (list, tuple)):
        fine_raw = fine_raw[0]
    fine_raw = EnsureOneChannel(name="fine_one_channel")(fine_raw)
    if SEGMENTATION_OUTPUTS_ARE_LOGITS:
        fine_raw = tf.keras.layers.Activation("sigmoid", name="fine_logits_to_probability")(fine_raw)
    if fine_info["input_size"] != IMG_SIZE:
        fine_raw = tf.keras.layers.Resizing(
            IMG_SIZE,
            IMG_SIZE,
            interpolation="bilinear",
            name="fine_output_resize",
        )(fine_raw)
    fine_centered = ThresholdCenteredOdds(
        threshold=fine_info["threshold"],
        name="fine_individual_threshold_centering",
    )(fine_raw)

    # ------------------------------------------------------------------
    # PRECISE-BRANCH
    # ------------------------------------------------------------------
    precise_x = ensemble_input
    if precise_info["input_size"] != IMG_SIZE:
        precise_x = tf.keras.layers.Resizing(
            precise_info["input_size"],
            precise_info["input_size"],
            interpolation="bilinear",
            name="precise_input_resize",
        )(precise_x)

    precise_branch = clone_model_shell(
        precise_info["model"],
        name=f"precise_model_{sanitize_name(precise_info['run_name'])}",
    )
    precise_raw = precise_branch(precise_x)
    if isinstance(precise_raw, (list, tuple)):
        precise_raw = precise_raw[0]
    precise_raw = EnsureOneChannel(name="precise_one_channel")(precise_raw)
    if SEGMENTATION_OUTPUTS_ARE_LOGITS:
        precise_raw = tf.keras.layers.Activation("sigmoid", name="precise_logits_to_probability")(precise_raw)
    if precise_info["input_size"] != IMG_SIZE:
        precise_raw = tf.keras.layers.Resizing(
            IMG_SIZE,
            IMG_SIZE,
            interpolation="bilinear",
            name="precise_output_resize",
        )(precise_raw)
    precise_centered = ThresholdCenteredOdds(
        threshold=precise_info["threshold"],
        name="precise_individual_threshold_centering",
    )(precise_raw)

    # ------------------------------------------------------------------
    # ALTE CLASSIFIER-GESTEUERTE FUSION
    # ------------------------------------------------------------------
    fine_weight = FineDynamicWeight(
        base_weight=FINE_BASE_WEIGHT,
        extra_weight=FINE_EXTRA_WEIGHT,
        name="classifier_controlled_fine_weight",
    )(cls_prob)
    precise_weight = OneMinus(name="precise_weight_1_minus_fine")(
        fine_weight
    )

    fused_score = WeightedBlend(name="old_weighted_probability_fusion")(
        [fine_centered, precise_centered, fine_weight, precise_weight]
    )

    dynamic_threshold = ClassifierDynamicThreshold(
        high=PIXEL_THRESHOLD_HIGH,
        low=PIXEL_THRESHOLD_LOW,
        name="classifier_controlled_dynamic_pixel_threshold",
    )(cls_prob)

    # Gemeinsame 0..1-Metrikskala, Entscheidung bleibt mathematisch identisch.
    decision_score = DynamicThresholdCenteredOdds(
        name="dynamic_threshold_to_metric_score_0p5"
    )([fused_score, dynamic_threshold])

    # Classifier-Gate. Runtime spart bei negativem Gate die beiden U-Nets komplett.
    # Im Architekturwrapper wird das Gate algebraisch dargestellt.
    gated_decision_score = ClassifierGateScore(
        threshold=CLASSIFIER_GATE_THRESHOLD,
        name="classifier_gate",
    )([decision_score, cls_prob])

    binary_mask = FixedThreshold(
        threshold=METRIC_DECISION_THRESHOLD,
        name="final_binary_mask_threshold_0p5",
    )(gated_decision_score)

    return tf.keras.Model(
        inputs=ensemble_input,
        outputs={
            "classifier_probability": cls_prob,
            "fine_centered_score": fine_centered,
            "precise_centered_score": precise_centered,
            "fine_weight": fine_weight,
            "precise_weight": precise_weight,
            "fused_score": fused_score,
            "dynamic_threshold": dynamic_threshold,
            "decision_score": gated_decision_score,
            "binary_mask": binary_mask,
        },
        name=f"{sanitize_name(RUN_NAME)}_old_adaptive_ensemble",
    )



def save_deployable_ensemble_model(
    classifier_info: dict[str, Any],
    fine_info: dict[str, Any],
    precise_info: dict[str, Any],
) -> dict[str, Any]:
    """
    Speichert das komplette Ensemble als EIN .keras-Modell.

    Output ist der kontinuierliche finale Decision-Score in [0,1]. Der gesamte
    classifier-gesteuerte Endthreshold ist darin bereits auf 0.5 zentriert;
    die finale Binaermaske ist daher schlicht output >= 0.5.

    Hinweis: Im gespeicherten Functional-Graph werden beide Segmentierungszweige
    fuer jedes Bild ausgefuehrt. Die separate Runtime-Testfunktion spart bei
    classifier-negativen Bildern weiterhin Rechenzeit und ueberspringt dort FINE/PRECISE.
    Die mathematische Endentscheidung ist identisch.
    """
    MODEL_DIR.mkdir(parents=True, exist_ok=True)
    diagnostic_wrapper = build_architecture_model(classifier_info, fine_info, precise_info)
    decision_tensor = diagnostic_wrapper.get_layer("classifier_gate").output
    deployable = tf.keras.Model(
        inputs=diagnostic_wrapper.input,
        outputs=decision_tensor,
        name=f"{sanitize_name(RUN_NAME)}_deployable_ensemble",
    )
    deployable.trainable = False
    deployable.save(ENSEMBLE_MODEL_PATH)
    return {
        "model_path": str(ENSEMBLE_MODEL_PATH),
        "output_semantics": "continuous decision_score in [0,1]; binary mask = score >= 0.5",
        "decision_threshold": float(METRIC_DECISION_THRESHOLD),
        "total_parameters": int(deployable.count_params()),
        "output_shape": str(deployable.output_shape),
    }

def iter_layers_recursive(model: tf.keras.Model, prefix: str = ""):
    for index, layer in enumerate(model.layers):
        path = f"{prefix}{index:03d}:{layer.name}"
        yield path, layer
        if isinstance(layer, tf.keras.Model):
            yield from iter_layers_recursive(layer, prefix=path + "/")


def write_model_summary(file, model: tf.keras.Model, title: str) -> None:
    file.write("=" * 200 + "\n")
    file.write(title + "\n")
    file.write("=" * 200 + "\n\n")
    model.summary(
        expand_nested=True,
        line_length=200,
        print_fn=lambda line: file.write(line + "\n"),
    )
    file.write("\n\n")


def architecture_variables(
    classifier_info: dict[str, Any],
    fine_info: dict[str, Any],
    precise_info: dict[str, Any],
) -> dict[str, Any]:
    return {
        "RUN_NAME": RUN_NAME,
        "CRACK_PROJECT_ROOT": CRACK_PROJECT_ROOT,
        "OUTPUT_ROOT": OUTPUT_ROOT,
        "RUN_DIR": RUN_DIR,
        "MODEL_DIR": MODEL_DIR,
        "ENSEMBLE_MODEL_PATH": ENSEMBLE_MODEL_PATH,
        "TEST_METRICS_DIR": TEST_METRICS_DIR,
        "TEST_DATASET_DIR": TEST_DATASET_DIR,
        "IMG_SIZE": IMG_SIZE,
        "CLASSIFIER_MODEL_PATH": CLASSIFIER_MODEL_PATH,
        "CLASSIFIER_GATE_THRESHOLD": CLASSIFIER_GATE_THRESHOLD,
        "CLASSIFIER_POSITIVE_CLASS_INDEX": CLASSIFIER_POSITIVE_CLASS_INDEX,
        "CLASSIFIER_OUTPUT_IS_LOGITS": CLASSIFIER_OUTPUT_IS_LOGITS,
        "FINE_MODEL_PATH": FINE_MODEL_PATH,
        "PRECISE_MODEL_PATH": PRECISE_MODEL_PATH,
        "SEGMENTATION_OUTPUTS_ARE_LOGITS": SEGMENTATION_OUTPUTS_ARE_LOGITS,
        "THRESHOLD_FILENAME_SUFFIX": THRESHOLD_FILENAME_SUFFIX,
        "FINE_BASE_WEIGHT": FINE_BASE_WEIGHT,
        "FINE_EXTRA_WEIGHT": FINE_EXTRA_WEIGHT,
        "PRECISE_WEIGHT_FORMULA": "1.0 - fine_weight",
        "PIXEL_THRESHOLD_HIGH": PIXEL_THRESHOLD_HIGH,
        "PIXEL_THRESHOLD_LOW": PIXEL_THRESHOLD_LOW,
        "METRIC_DECISION_THRESHOLD": METRIC_DECISION_THRESHOLD,
        "HARD_NEGATIVE_SHARE": HARD_NEGATIVE_SHARE,
        "HARD_NEGATIVE_RANDOM_SEED": HARD_NEGATIVE_RANDOM_SEED,
        "BATCH_SIZE": BATCH_SIZE,
        "BATCH_SIZE_1024": BATCH_SIZE_1024,
        "SEED": SEED,
        "XLA_JIT": XLA_JIT,
        "MIXED_PRECISION_POLICY": MIXED_PRECISION_POLICY,
        "AP_THRESHOLDS": AP_THRESHOLDS,
        "ROI_RING_RADIUS_PX": ROI_RING_RADIUS_PX,
        "ROI_NEGATIVE_TO_POSITIVE_RATIO": ROI_NEGATIVE_TO_POSITIVE_RATIO,
        "ROI_RANDOM_SEED": ROI_RANDOM_SEED,
        "threshold_centering_formula": "q=p*(1-t)/(p*(1-t)+(1-p)*t)",
        "classifier": {
            "model_path": classifier_info["model_path"],
            "input_size": classifier_info["input_size"],
        },
        "fine_model": {
            "run_name": fine_info["run_name"],
            "model_name": fine_info["model_name"],
            "model_path": fine_info["model_path"],
            "input_size": fine_info["input_size"],
            "individual_threshold": fine_info["threshold"],
            "threshold_file": fine_info["threshold_file"],
        },
        "precise_model": {
            "run_name": precise_info["run_name"],
            "model_name": precise_info["model_name"],
            "model_path": precise_info["model_path"],
            "input_size": precise_info["input_size"],
            "individual_threshold": precise_info["threshold"],
            "threshold_file": precise_info["threshold_file"],
        },
        "runtime_gate_semantics": (
            "Classifier wird zuerst ausgefuehrt. Bei probability < "
            "CLASSIFIER_GATE_THRESHOLD werden FINE und PRECISE fuer dieses Bild "
            "nicht ausgefuehrt; finaler Decision-Score = 0."
        ),
        "fusion_semantics": (
            "FINE und PRECISE bleiben kontinuierliche Scores. Jeder Score wird zuerst "
            "um den individuellen optimalen Einzelmodellthreshold auf 0.5 zentriert. "
            "Danach steuert der Classifier wie in der alten Fusion sowohl die "
            "Fine/Precise-Gewichtung als auch den dynamischen Endthreshold."
        ),
    }


def export_architecture(
    classifier_info: dict[str, Any],
    fine_info: dict[str, Any],
    precise_info: dict[str, Any],
) -> dict[str, Any]:
    ARCH_DIR.mkdir(parents=True, exist_ok=True)
    wrapper = build_architecture_model(classifier_info, fine_info, precise_info)
    variables = architecture_variables(classifier_info, fine_info, precise_info)

    payload = {
        "variables": variables,
        "ensemble_keras_config": wrapper.get_config(),
        "classifier_config": classifier_info["model"].get_config(),
        "fine_model_config": fine_info["model"].get_config(),
        "precise_model_config": precise_info["model"].get_config(),
    }
    write_json_atomic(ARCHITECTURE_JSON_FILE, payload)

    try:
        ARCHITECTURE_KERAS_JSON_FILE.write_text(
            wrapper.to_json(),
            encoding="utf-8",
        )
    except Exception as exc:
        ARCHITECTURE_KERAS_JSON_FILE.write_text(
            json.dumps({"error": str(exc)}, indent=2, ensure_ascii=False),
            encoding="utf-8",
        )

    all_layers = list(iter_layers_recursive(wrapper))

    with ARCHITECTURE_TXT_FILE.open("w", encoding="utf-8") as f:
        f.write(f"Run: {RUN_NAME}\n")
        f.write(
            "Architecture: alte classifier-gesteuerte 2-Modell-Fusion + "
            "individuelle Threshold-Zentrierung\n"
        )
        f.write(f"Input: ({IMG_SIZE}, {IMG_SIZE}, 3)\n")
        f.write("Segmentierungsmodelle: exakt 2 (FINE + PRECISE)\n")
        f.write(f"FINE individual threshold: {fine_info['threshold']:.12g}\n")
        f.write(f"PRECISE individual threshold: {precise_info['threshold']:.12g}\n")
        f.write(
            "Threshold centering: q=p*(1-t)/(p*(1-t)+(1-p)*t), daher p=t -> q=0.5\n"
        )
        f.write(
            f"Fine weight: {FINE_BASE_WEIGHT} + {FINE_EXTRA_WEIGHT} * classifier_probability\n"
        )
        f.write("Precise weight: 1 - fine_weight\n")
        f.write(
            f"Dynamic threshold: {PIXEL_THRESHOLD_HIGH} - "
            f"({PIXEL_THRESHOLD_HIGH}-{PIXEL_THRESHOLD_LOW}) * classifier_probability\n"
        )
        f.write(f"Classifier gate threshold: {CLASSIFIER_GATE_THRESHOLD}\n")
        f.write(f"Metric decision threshold: {METRIC_DECISION_THRESHOLD}\n")
        f.write(f"Mixed precision: {mixed_precision.global_policy().name}\n")
        f.write(f"Gesamtparameter Wrapper: {wrapper.count_params():,}\n")
        f.write(f"Rekursiv gefundene Layer: {len(all_layers)}\n\n")

        f.write("=" * 200 + "\n")
        f.write("0. VOLLSTAENDIGE ENSEMBLE-VARIABLEN\n")
        f.write("=" * 200 + "\n\n")
        f.write(json.dumps(json_safe(variables), indent=2, ensure_ascii=False) + "\n\n")

        write_model_summary(
            f,
            wrapper,
            "1. VOLLSTAENDIGE ENSEMBLE-MODELLZUSAMMENFASSUNG",
        )
        write_model_summary(
            f,
            classifier_info["model"],
            "2. CLASSIFIER-MODELLZUSAMMENFASSUNG",
        )
        write_model_summary(
            f,
            fine_info["model"],
            f"3. FINE-MODELL: {fine_info['model_name']}",
        )
        write_model_summary(
            f,
            precise_info["model"],
            f"4. PRECISE-MODELL: {precise_info['model_name']}",
        )

        f.write("=" * 200 + "\n")
        f.write("5. REKURSIVE LAYERLISTE\n")
        f.write("=" * 200 + "\n\n")
        for path, layer in all_layers:
            try:
                params = int(layer.count_params())
            except Exception:
                params = -1
            f.write(f"Pfad: {path}\n")
            f.write(f"  Klasse: {layer.__class__.__name__}\n")
            f.write(f"  Trainable: {layer.trainable}\n")
            f.write(f"  dtype: {getattr(layer, 'dtype', 'n/a')}\n")
            f.write(f"  Parameter: {params}\n")
            try:
                f.write(
                    "  Konfiguration: "
                    + json.dumps(
                        json_safe(layer.get_config()),
                        ensure_ascii=False,
                        sort_keys=True,
                    )
                    + "\n"
                )
            except Exception as exc:
                f.write(f"  Konfiguration nicht verfuegbar: {exc}\n")
            f.write("\n")

        f.write("=" * 200 + "\n")
        f.write("6. VOLLSTAENDIGE ENSEMBLE-KONFIGURATION ALS JSON\n")
        f.write("=" * 200 + "\n\n")
        json.dump(json_safe(payload), f, indent=2, ensure_ascii=False)
        f.write("\n")

    plot_error = None
    try:
        plot_model(
            wrapper,
            to_file=str(ARCHITECTURE_PNG_FILE),
            show_shapes=True,
            show_layer_names=True,
            expand_nested=ARCHITECTURE_EXPAND_NESTED_PNG,
            dpi=ARCHITECTURE_DPI,
            rankdir="TB",
        )
    except Exception as exc:
        plot_error = str(exc)
        (ARCH_DIR / f"{RUN_NAME}_architecture_plot_error.txt").write_text(
            "Die PNG-Architektur konnte nicht erstellt werden.\n"
            f"Fehler: {exc}\n"
            "Pruefe insbesondere pydot und Graphviz.\n",
            encoding="utf-8",
        )

    return {
        "architecture_txt": str(ARCHITECTURE_TXT_FILE),
        "architecture_json": str(ARCHITECTURE_JSON_FILE),
        "architecture_keras_json": str(ARCHITECTURE_KERAS_JSON_FILE),
        "architecture_png": str(ARCHITECTURE_PNG_FILE),
        "plot_error": plot_error,
        "total_parameters": int(wrapper.count_params()),
        "recursive_layer_count": len(all_layers),
    }


# =============================================================================
# 15. KONFIGURATION / MODELLE LADEN
# =============================================================================

def validate_configuration() -> None:
    if not 0.0 <= CLASSIFIER_GATE_THRESHOLD <= 1.0:
        raise ValueError("CLASSIFIER_GATE_THRESHOLD muss in [0,1] liegen.")
    if not 0.0 <= FINE_BASE_WEIGHT <= 1.0:
        raise ValueError("FINE_BASE_WEIGHT muss in [0,1] liegen.")
    if FINE_EXTRA_WEIGHT < 0.0:
        raise ValueError("FINE_EXTRA_WEIGHT darf nicht negativ sein.")
    if FINE_BASE_WEIGHT + FINE_EXTRA_WEIGHT > 1.0 + 1e-12:
        raise ValueError(
            "FINE_BASE_WEIGHT + FINE_EXTRA_WEIGHT darf nicht groesser als 1 sein."
        )
    if not 0.0 < PIXEL_THRESHOLD_LOW < 1.0:
        raise ValueError("PIXEL_THRESHOLD_LOW muss in (0,1) liegen.")
    if not 0.0 < PIXEL_THRESHOLD_HIGH < 1.0:
        raise ValueError("PIXEL_THRESHOLD_HIGH muss in (0,1) liegen.")
    if PIXEL_THRESHOLD_LOW > PIXEL_THRESHOLD_HIGH:
        raise ValueError("PIXEL_THRESHOLD_LOW darf nicht groesser als HIGH sein.")
    if abs(METRIC_DECISION_THRESHOLD - 0.5) > 1e-12:
        raise ValueError(
            "METRIC_DECISION_THRESHOLD muss fuer die dynamische Threshold-Zentrierung 0.5 sein."
        )
    if not 0.0 <= HARD_NEGATIVE_SHARE <= 1.0:
        raise ValueError("HARD_NEGATIVE_SHARE muss in [0,1] liegen.")
    if ROI_RING_RADIUS_PX < 0:
        raise ValueError("ROI_RING_RADIUS_PX darf nicht negativ sein.")
    if ROI_NEGATIVE_TO_POSITIVE_RATIO < 0.0:
        raise ValueError("ROI_NEGATIVE_TO_POSITIVE_RATIO darf nicht negativ sein.")

    fine_path = Path(FINE_MODEL_PATH).expanduser().resolve()
    precise_path = Path(PRECISE_MODEL_PATH).expanduser().resolve()
    if fine_path == precise_path:
        raise ValueError("FINE_MODEL_PATH und PRECISE_MODEL_PATH muessen verschieden sein.")


def load_segmentation_info(model_path: Path, role: str) -> dict[str, Any]:
    model_path = Path(model_path).expanduser().resolve()
    threshold_info = read_individual_threshold(model_path)
    model = load_model_robust(model_path)
    run_dir = resolve_run_dir_from_model(model_path)
    return {
        "role": role,
        "model": model,
        "model_path": model_path,
        "model_name": model_path.name,
        "run_dir": run_dir,
        "run_name": run_dir.name,
        "input_size": infer_square_input_size(model),
        **threshold_info,
    }


def load_all_models():
    print("Lade Classifier ...")
    classifier_model = load_model_robust(CLASSIFIER_MODEL_PATH)
    classifier_info = {
        "model": classifier_model,
        "model_path": Path(CLASSIFIER_MODEL_PATH).expanduser().resolve(),
        "input_size": infer_square_input_size(classifier_model),
    }

    print("Lade FINE-Segmentierungsmodell ...")
    fine_info = load_segmentation_info(FINE_MODEL_PATH, "fine")
    print(
        f"  Run={fine_info['run_name']} | Input={fine_info['input_size']} | "
        f"Threshold={fine_info['threshold']:.12g} | Quelle={fine_info['threshold_file']}"
    )

    print("Lade PRECISE-Segmentierungsmodell ...")
    precise_info = load_segmentation_info(PRECISE_MODEL_PATH, "precise")
    print(
        f"  Run={precise_info['run_name']} | Input={precise_info['input_size']} | "
        f"Threshold={precise_info['threshold']:.12g} | Quelle={precise_info['threshold_file']}"
    )

    return classifier_info, fine_info, precise_info


# =============================================================================
# 16. MAIN
# =============================================================================

def main():
    validate_configuration()

    RUN_DIR.mkdir(parents=True, exist_ok=True)
    ARCH_DIR.mkdir(parents=True, exist_ok=True)
    MODEL_DIR.mkdir(parents=True, exist_ok=True)
    TEST_METRICS_DIR.mkdir(parents=True, exist_ok=True)

    print("=" * 110)
    print(f"ENSEMBLE TESTRUN: {RUN_NAME}")
    print("Fusion: alte classifier-gesteuerte 2-Modell-Fusion + Threshold-Zentrierung")
    print(f"Run-Ordner:         {RUN_DIR}")
    print(f"Testmetrics-Ordner: {TEST_METRICS_DIR}")
    print(f"Testdataset:        {TEST_DATASET_DIR}")
    print("=" * 110)

    classifier_info, fine_info, precise_info = load_all_models()

    print("\nSpeichere komplettes Ensemble als einzelnes .keras-Modell ...")
    saved_model_info = save_deployable_ensemble_model(
        classifier_info,
        fine_info,
        precise_info,
    )
    print(f"  Ensemble-Modell: {saved_model_info['model_path']}")
    print("  Output: kontinuierlicher Decision-Score; finale Maske = output >= 0.5")

    print("\nGeladene Einzelmodellthresholds:")
    print(f"  FINE:    {fine_info['threshold']:.12g}")
    print(f"  PRECISE: {precise_info['threshold']:.12g}")
    print(
        "  Beide werden vor der alten Fusion so zentriert, dass ihr jeweiliger "
        "Threshold -> 0.5 wird."
    )

    records = build_test_records()
    hard_negative_count = sum(bool(r["is_hard_negative"]) for r in records)
    print(
        f"\nTestbilder gesamt: {len(records)} | Hard-Negatives: {hard_negative_count} | "
        f"HN-Anteil effektiv: {hard_negative_count / max(len(records), 1):.4f}"
    )

    test_ds = make_test_dataset(records)

    print("\nStarte classifier-gesteuerte Ensemble-Inferenz ...")
    metrics, sampled_metrics, classifier_fn_rows, diagnostics = evaluate_old_adaptive_fusion(
        test_ds,
        records,
        classifier_info,
        fine_info,
        precise_info,
    )

    if HARD_NEGATIVE_SHARE == 0.0:
        save_classifier_false_negatives(classifier_fn_rows)
        print(
            f"Classifier_FN geloggt: {len(classifier_fn_rows)} | "
            f"{CLASSIFIER_FN_DIR}"
        )

    metadata = ensemble_metadata(
        classifier_info,
        fine_info,
        precise_info,
        records,
        classifier_fn_count=len(classifier_fn_rows),
        diagnostics=diagnostics,
    )
    save_final_metrics(metrics, metadata)
    save_sampled_metrics(sampled_metrics, metadata)

    print("\nExportiere Gesamtarchitektur ...")
    architecture_info = export_architecture(
        classifier_info,
        fine_info,
        precise_info,
    )

    print("\n" + "=" * 110)
    print("FERTIG")
    print("=" * 110)
    print(f"Ensemble-Modell:   {ENSEMBLE_MODEL_PATH}")
    print(f"Testmetrics TXT:   {FINAL_METRICS_TXT_FILE}")
    print(f"Testmetrics CSV:   {FINAL_METRICS_CSV_FILE}")
    print(f"Testmetrics JSON:  {FINAL_METRICS_JSON_FILE}")
    print(f"Samplemetrics TXT: {SAMPLED_METRICS_TXT_FILE}")
    print(f"Samplemetrics CSV: {SAMPLED_METRICS_CSV_FILE}")
    print(f"Samplemetrics JSON:{SAMPLED_METRICS_JSON_FILE}")
    if HARD_NEGATIVE_SHARE == 0.0:
        print(f"Classifier_FN:     {CLASSIFIER_FN_DIR}")
    print(f"Architecture:      {ARCH_DIR}")
    print(f"Architecture PNG:  {ARCHITECTURE_PNG_FILE}")
    if architecture_info["plot_error"]:
        print(f"[WARNUNG] Architektur-PNG fehlgeschlagen: {architecture_info['plot_error']}")

    print("\nFinale Testmetriken:")
    for key in [
        "test_dice_fg",
        "test_iou_fg",
        "test_precision_fg",
        "test_recall_fg",
        "test_f1_fg",
        "test_f2",
        "test_ap",
        "test_accuracy_pct",
        "balanced_error",
        "balanced_accuracy",
        "fpr",
        "fnr",
        "tp",
        "fp",
        "fn",
        "tn",
        "D",
    ]:
        print(f"  {key}: {metrics[key]}")

    print("\nGesampelte Testmetriken / BALANCED CRACK ROI:")
    for key in [
        "test_dice_fg",
        "test_iou_fg",
        "test_precision_fg",
        "test_recall_fg",
        "test_f1_fg",
        "test_f2",
        "test_ap",
        "test_accuracy_pct",
        "balanced_error",
        "balanced_accuracy",
        "fpr",
        "fnr",
        "tp",
        "fp",
        "fn",
        "tn",
        "D",
        "sampled_pixels_total",
    ]:
        print(f"  {key}: {sampled_metrics[key]}")


if __name__ == "__main__":
    main()
