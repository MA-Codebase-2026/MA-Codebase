from __future__ import annotations

from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path


# =========================
# EINSTELLUNGEN
# =========================
BASE_DIR = Path("/home/mitte/crack_project/datasets/better_dataset_evtl")

SPLITS = ["train_1024", "val_1024", "test_1024"]
SUBFOLDERS = ["images", "masks"]

PATCH_SIZE = 1024

MAX_WORKERS = 16

# Zuerst True lassen und prüfen.
# Erst danach auf False setzen, damit wirklich gelöscht wird.
DRY_RUN = False

TARGET_SUFFIXES = {".tif", ".tiff"}


# =========================
# LOGIK
# =========================
def should_delete(path: Path) -> bool:
    return (
        path.is_file()
        and path.suffix.lower() in TARGET_SUFFIXES
    )


def delete_file(path: Path):
    try:
        if DRY_RUN:
            return "dry", str(path)

        path.unlink()
        return "deleted", str(path)

    except Exception as exc:
        return "error", f"{path} -> {exc}"


def main():
    target_dirs = []

    for split in SPLITS:
        patch_split_dir = BASE_DIR / split

        for subfolder in SUBFOLDERS:
            folder = patch_split_dir / subfolder

            if folder.exists():
                target_dirs.append(folder)
            else:
                print(f"[WARNUNG] Ordner nicht gefunden: {folder}")

    if not target_dirs:
        print("Keine gültigen Zielordner gefunden. Abbruch.")
        return

    print("=== ZIELORDNER ===")
    for folder in target_dirs:
        print(f"  - {folder}")

    files = []
    for folder in target_dirs:
        files.extend(
            path
            for path in folder.rglob("*")
            if should_delete(path)
        )

    print("\n=== ÜBERSICHT ===")
    print(f"Gefundene .tif/.tiff-Dateien: {len(files)}")
    print(f"Modus: {'DRY RUN – nichts wird gelöscht' if DRY_RUN else 'DELETE – Dateien werden gelöscht'}")

    if not files:
        print("Keine passenden Dateien gefunden.")
        return

    deleted = 0
    errors = 0

    with ThreadPoolExecutor(max_workers=MAX_WORKERS) as executor:
        futures = [executor.submit(delete_file, path) for path in files]

        for future in as_completed(futures):
            status, message = future.result()

            if status == "dry":
                print(f"[TEST] {message}")

            elif status == "deleted":
                deleted += 1

            elif status == "error":
                errors += 1
                print(f"[FEHLER] {message}")

    print("\n=== FERTIG ===")

    if DRY_RUN:
        print(f"Im Testmodus gefunden: {len(files)} Dateien")
        print("Setze DRY_RUN = False, wenn sie wirklich gelöscht werden sollen.")
    else:
        print(f"Gelöscht: {deleted}")
        print(f"Fehler:   {errors}")


if __name__ == "__main__":
    main()