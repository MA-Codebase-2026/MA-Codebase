#!/usr/bin/env python3
from pathlib import Path
from concurrent.futures import ProcessPoolExecutor
import os

from PIL import Image

# ============================================================
# EINSTELLUNGEN
# ============================================================

SEG_DIR = Path("/home/mitte/crack_project/datasets/better_dataset_evtl")

# Der Fehler kam aus _evaluate_validation() -> zuerst nur val_512 prüfen.
SPLIT = "train_512"

FOLDER_NAMES = [
    "images",
    "masks",
    "images_512px_hard_negatives",
    "masks_512px_hard_negatives",
]

# 16 logische Threads / Prozesse deines 8-Core-16-Thread-Prozessors.
MAX_WORKERS = min(16, os.cpu_count() or 1)

# ============================================================
# BILDPRÜFUNG
# ============================================================

def check_image(path_str: str):
    """
    Öffnet und dekodiert das gesamte Bild.
    Das ist zuverlässiger als nur Dateigröße oder Endung zu prüfen.
    """
    path = Path(path_str)

    try:
        with Image.open(path) as image:
            image.load()  # vollständige Dekodierung erzwingen

        return str(path), True, ""

    except Exception as error:
        return str(path), False, repr(error)


def get_all_files():
    files = []

    for folder_name in FOLDER_NAMES:
        folder = SEG_DIR / SPLIT / folder_name

        if not folder.exists():
            print(f"Nicht gefunden, übersprungen: {folder}")
            continue

        folder_files = [
            str(path)
            for path in folder.iterdir()
            if path.is_file() and not path.name.startswith(".")
        ]

        print(f"{folder}: {len(folder_files)} Dateien")
        files.extend(folder_files)

    return files


def main():
    files = get_all_files()

    if not files:
        raise RuntimeError("Keine Dateien zum Prüfen gefunden.")

    print("\n" + "=" * 80)
    print(f"Zu prüfende Dateien: {len(files)}")
    print(f"Prozesse: {MAX_WORKERS}")
    print("=" * 80)

    invalid_files = []
    checked = 0

    # chunksize reduziert Overhead deutlich bei vielen kleinen PNG-Dateien.
    chunk_size = max(20, len(files) // (MAX_WORKERS * 20))

    with ProcessPoolExecutor(max_workers=MAX_WORKERS) as executor:
        results = executor.map(
            check_image,
            files,
            chunksize=chunk_size,
        )

        for path, valid, error in results:
            checked += 1

            if not valid:
                invalid_files.append((path, error))
                print(f"\nUNGÜLTIG: {path}")
                print(f"Fehler: {error}")

            if checked % 1000 == 0 or checked == len(files):
                print(f"Fortschritt: {checked}/{len(files)}")

    print("\n" + "=" * 80)
    print(f"Geprüfte Dateien: {checked}")
    print(f"Ungültige Dateien: {len(invalid_files)}")

    output_file = SEG_DIR / f"{SPLIT}_invalid_png_files.txt"

    with open(output_file, "w", encoding="utf-8") as file:
        if invalid_files:
            for path, error in invalid_files:
                file.write(f"{path}\n")
                file.write(f"  Fehler: {error}\n\n")
        else:
            file.write("Keine ungültigen Dateien gefunden.\n")

    print(f"Ergebnis gespeichert: {output_file}")

    if invalid_files:
        print("\nDiese Dateien ersetzen, neu exportieren oder entfernen.")
    else:
        print("\nPillow konnte alle Dateien dekodieren.")
        print(
            "Falls TensorFlow trotzdem erneut abstürzt, ist wahrscheinlich eine "
            "Datei nicht wirklich PNG-kompatibel, obwohl Pillow sie akzeptiert."
        )


if __name__ == "__main__":
    main()
