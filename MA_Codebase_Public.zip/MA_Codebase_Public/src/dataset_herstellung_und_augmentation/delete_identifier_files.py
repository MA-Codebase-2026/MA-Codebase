from __future__ import annotations

from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path

# =========================
# EINSTELLUNGEN
# =========================
ROOT_DIR = Path("/home/mitte/crack_project/datasets/Testset_for_coloring_differences/uncolored_set_10_hardnegatives/train/masks")  # anpassen
MAX_WORKERS = 16
DRY_RUN = False   # erst testen!

TARGET_SUFFIX = ":Zone.Identifier"


# =========================
# LOGIK
# =========================
def should_delete(path: Path) -> bool:
    return path.is_file() and path.name.endswith(TARGET_SUFFIX)


def delete_file(path: Path):
    try:
        if DRY_RUN:
            return ("dry", str(path))

        path.unlink()
        return ("deleted", str(path))

    except Exception as e:
        return ("error", f"{path} -> {e}")


def main():
    if not ROOT_DIR.exists():
        raise FileNotFoundError(ROOT_DIR)

    files = [p for p in ROOT_DIR.rglob("*") if should_delete(p)]

    print(f"Gefunden: {len(files)} Dateien")
    print(f"Modus: {'DRY RUN' if DRY_RUN else 'DELETE'}")

    with ThreadPoolExecutor(max_workers=MAX_WORKERS) as executor:
        futures = [executor.submit(delete_file, f) for f in files]

        for future in as_completed(futures):
            status, msg = future.result()

            if status == "dry":
                print(msg)
            elif status == "error":
                print(f"[FEHLER] {msg}")

    print("Fertig.")


if __name__ == "__main__":
    main()