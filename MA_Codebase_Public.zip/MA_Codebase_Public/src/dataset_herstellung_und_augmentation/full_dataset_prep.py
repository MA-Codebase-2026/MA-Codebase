from __future__ import annotations

from pathlib import Path
import os

# ============================================================
# KONFIGURATION – normalerweise nur diesen Block anpassen
# ============================================================

# Crack-Projektordner
CRACKS_DIR = Path("/home/mitte/crack_project")

# Beliebig viele Dataset-Wurzeln.
# Unterstützte Strukturen pro Eintrag:
#
#   dataset/
#       images/
#       masks/
#
# oder:
#
#   dataset/
#       train/images, train/masks
#       val/images,   val/masks
#       test/images,  test/masks
#
DATASET_PATHS = [
    # Path("/pfad/zum/dataset_1"),
    # Path("/pfad/zum/dataset_2"),
]

DATASET_NAME = "mydataset"

# Ziel 1:
#   /home/mitte/crack_project/datasets/mydataset_original
#
# Ziel 2:
#   /home/mitte/crack_project/datasets/mydataset_<IMAGE_SIZE>
# Die konkreten Zielpfade werden weiter unten aus DATASET_NAME und IMAGE_SIZE gebaut.

# Split
TRAIN_RATIO = 0.70
VAL_RATIO   = 0.15
TEST_RATIO  = 0.15
RANDOM_SEED = 42

# Patches
IMAGE_SIZE = 512

# None = automatisch IMAGE_SIZE // 2
STRIDE = None

# Hard Negative:
# Patch ist Hard Negative, wenn mask.max() <= WHITE_THRESHOLD.
# Default 0 => nur komplett schwarze Maskenpatches sind Hard Negatives.
WHITE_THRESHOLD = 0

# Es werden immer Original + drei 90°-Rotationen erzeugt.
ROTATIONS = (0, 90, 180, 270)

# PNG: 0 = schnell / groß, 9 = langsam / klein
PNG_COMPRESSION = 1

# Alle logischen CPUs verwenden; kein künstliches 16-Worker-Limit.
MAX_WORKERS = max(1, os.cpu_count() or 1)

# Sicherheitsoption:
# False => Abbruch, falls Zielordner schon existiert und nicht leer ist.
# True  => vorhandene Zielordner werden vor dem Neuaufbau gelöscht.
RECREATE_OUTPUT = False

# Akzeptierte Eingabeformate
IMAGE_EXTENSIONS = {
    ".png", ".jpg", ".jpeg", ".bmp", ".tif", ".tiff", ".webp"
}

# ------------------------------------------------------------
# Abgeleitete Werte
# ------------------------------------------------------------
if STRIDE is None:
    STRIDE = max(1, IMAGE_SIZE // 2)

ORIGINAL_DATASET_DIR = CRACKS_DIR / "datasets" / f"{DATASET_NAME}_original"
PATCH_DATASET_DIR    = CRACKS_DIR / "datasets" / f"{DATASET_NAME}_{IMAGE_SIZE}"

assert DATASET_PATHS, "Bitte mindestens einen Pfad in DATASET_PATHS eintragen."
assert IMAGE_SIZE > 0, "IMAGE_SIZE muss > 0 sein."
assert STRIDE > 0, "STRIDE muss > 0 sein."
assert 0 <= WHITE_THRESHOLD <= 255, "WHITE_THRESHOLD muss zwischen 0 und 255 liegen."
assert abs(TRAIN_RATIO + VAL_RATIO + TEST_RATIO - 1.0) < 1e-9, \
    "TRAIN_RATIO + VAL_RATIO + TEST_RATIO müssen zusammen 1.0 ergeben."

print("Konfiguration:")
print(f"  Quellen:           {len(DATASET_PATHS)}")
print(f"  Original-Ziel:     {ORIGINAL_DATASET_DIR}")
print(f"  Patch-Ziel:        {PATCH_DATASET_DIR}")
print(f"  Split:             {TRAIN_RATIO:.0%} / {VAL_RATIO:.0%} / {TEST_RATIO:.0%}")
print(f"  IMAGE_SIZE:        {IMAGE_SIZE}")
print(f"  STRIDE:            {STRIDE}")
print(f"  WHITE_THRESHOLD:   {WHITE_THRESHOLD}")
print(f"  MAX_WORKERS:       {MAX_WORKERS}")


import csv
import random
import shutil
from collections import Counter
from concurrent.futures import ProcessPoolExecutor, ThreadPoolExecutor, as_completed
from dataclasses import dataclass
from pathlib import Path
from typing import Iterable

import numpy as np
from PIL import Image, ImageOps
from tqdm.auto import tqdm


SPLITS = ("train", "val", "test")


@dataclass(frozen=True)
class SourcePair:
    dataset_root: str
    group: str
    stem: str
    image_path: str
    mask_path: str


@dataclass(frozen=True)
class OutputPair:
    split: str
    output_stem: str
    image_path: str
    mask_path: str
    source_root: str
    source_group: str
    source_stem: str


def _image_files(folder: Path) -> list[Path]:
    return sorted(
        p for p in folder.iterdir()
        if p.is_file() and p.suffix.lower() in IMAGE_EXTENSIONS
    )


def _build_unique_stem_map(folder: Path, kind: str) -> dict[str, Path]:
    """stem.casefold() -> path; doppelte Stems innerhalb EINES Ordners sind ein Fehler."""
    files = _image_files(folder)
    stem_map: dict[str, Path] = {}
    duplicate_map: dict[str, list[str]] = {}

    for p in files:
        key = p.stem.casefold()
        if key in stem_map:
            duplicate_map.setdefault(key, [str(stem_map[key])]).append(str(p))
        else:
            stem_map[key] = p

    if duplicate_map:
        examples = []
        for _, paths in list(duplicate_map.items())[:10]:
            examples.append("  - " + " | ".join(paths))
        raise RuntimeError(
            f"Doppelte {kind}-Stems innerhalb von {folder}.\n"
            "Ein eindeutiges 1:1-Matching ist dort nicht möglich.\n"
            + "\n".join(examples)
        )

    return stem_map


def _discover_groups(root: Path) -> list[tuple[str, Path, Path]]:
    """
    Unterstützt:
      root/images + root/masks
    oder:
      root/train|val|test/images + masks
    Vorhandene alte Splits werden nur als Quellen zusammengeführt;
    der neue Split wird später komplett neu erzeugt.
    """
    direct_images = root / "images"
    direct_masks = root / "masks"

    if direct_images.is_dir() or direct_masks.is_dir():
        if not (direct_images.is_dir() and direct_masks.is_dir()):
            raise FileNotFoundError(
                f"{root}: images und masks müssen beide vorhanden sein."
            )
        return [("root", direct_images, direct_masks)]

    groups = []
    for split in SPLITS:
        images = root / split / "images"
        masks = root / split / "masks"
        if images.is_dir() or masks.is_dir():
            if not (images.is_dir() and masks.is_dir()):
                raise FileNotFoundError(
                    f"{root}/{split}: images und masks müssen beide vorhanden sein."
                )
            groups.append((split, images, masks))

    if not groups:
        raise FileNotFoundError(
            f"Keine unterstützte Dataset-Struktur gefunden: {root}\n"
            "Erwartet werden images/masks oder train|val|test/images|masks."
        )

    return groups


def _collect_pairs_without_size_check(dataset_paths: Iterable[Path]) -> list[SourcePair]:
    """
    Prüft zunächst das reine Namens-Matching.
    Bei EINEM fehlenden Image oder einer fehlenden Maske wird abgebrochen.
    """
    all_pairs: list[SourcePair] = []
    matching_errors: list[str] = []

    for raw_root in dataset_paths:
        root = Path(raw_root).expanduser().resolve()
        if not root.is_dir():
            matching_errors.append(f"Dataset-Pfad fehlt oder ist kein Ordner: {root}")
            continue

        for group_name, images_dir, masks_dir in _discover_groups(root):
            img_map = _build_unique_stem_map(images_dir, "Image")
            mask_map = _build_unique_stem_map(masks_dir, "Mask")

            img_keys = set(img_map)
            mask_keys = set(mask_map)

            missing_masks = sorted(img_keys - mask_keys)
            missing_images = sorted(mask_keys - img_keys)

            if missing_masks:
                sample = ", ".join(img_map[k].name for k in missing_masks[:10])
                matching_errors.append(
                    f"{root} [{group_name}]: {len(missing_masks)} Images ohne Maske. "
                    f"Beispiele: {sample}"
                )

            if missing_images:
                sample = ", ".join(mask_map[k].name for k in missing_images[:10])
                matching_errors.append(
                    f"{root} [{group_name}]: {len(missing_images)} Masken ohne Image. "
                    f"Beispiele: {sample}"
                )

            if not missing_masks and not missing_images:
                for key in sorted(img_keys):
                    img_path = img_map[key]
                    mask_path = mask_map[key]
                    all_pairs.append(
                        SourcePair(
                            dataset_root=str(root),
                            group=group_name,
                            stem=img_path.stem,
                            image_path=str(img_path),
                            mask_path=str(mask_path),
                        )
                    )

    if matching_errors:
        raise RuntimeError(
            "NAMENS-MATCHING FEHLGESCHLAGEN.\n"
            "Es wurde noch kein Output-Dataset erzeugt.\n\n"
            + "\n".join(f"- {e}" for e in matching_errors)
        )

    if not all_pairs:
        raise RuntimeError("Keine Image-/Mask-Paare gefunden.")

    return all_pairs


def _validate_one_pair(pair: SourcePair):
    """
    Vollständiges Dekodieren + Größenvergleich.
    Image: EXIF-Orientierung wird so berücksichtigt, wie sie später in PNG eingebrannt wird.
    Mask: keine EXIF-Rotation.
    """
    try:
        with Image.open(pair.image_path) as img_in:
            img = ImageOps.exif_transpose(img_in)
            img.load()
            img_size = img.size

        with Image.open(pair.mask_path) as mask:
            mask.load()
            mask_size = mask.size

        if img_size != mask_size:
            return (
                False,
                pair,
                f"SIZE_MISMATCH image={img_size}, mask={mask_size}"
            )

        return (True, pair, "")

    except Exception as exc:
        return (False, pair, f"DECODE_ERROR: {exc!r}")


def validate_all_sources(dataset_paths: Iterable[Path]) -> list[SourcePair]:
    """
    Stufe 1:
      1) Namen 1:1 prüfen.
      2) Alle Dateien vollständig dekodieren.
      3) Größen prüfen.
    Erst wenn ALLES gültig ist, darf das Dataset geschrieben werden.
    """
    pairs = _collect_pairs_without_size_check(dataset_paths)

    errors = []
    validated = []

    with ThreadPoolExecutor(max_workers=MAX_WORKERS) as ex:
        futures = [ex.submit(_validate_one_pair, pair) for pair in pairs]

        for fut in tqdm(
            as_completed(futures),
            total=len(futures),
            desc="Validiere Image/Mask-Paare",
            unit="Paar",
        ):
            ok, pair, msg = fut.result()
            if ok:
                validated.append(pair)
            else:
                errors.append(
                    f"{pair.dataset_root} [{pair.group}] / {pair.stem}: {msg}"
                )

    if errors:
        preview = "\n".join(f"- {e}" for e in errors[:30])
        more = "" if len(errors) <= 30 else f"\n... und {len(errors)-30} weitere Fehler."
        raise RuntimeError(
            f"VALIDIERUNG FEHLGESCHLAGEN: {len(errors)} fehlerhafte Paare.\n"
            "Es wurde noch kein Output-Dataset erzeugt.\n\n"
            + preview + more
        )

    validated.sort(
        key=lambda p: (
            p.dataset_root.casefold(),
            p.group.casefold(),
            p.stem.casefold(),
            p.image_path.casefold(),
        )
    )

    global_counts = Counter(p.stem.casefold() for p in validated)
    duplicate_stems = sorted(k for k, count in global_counts.items() if count > 1)

    print("\nVALIDIERUNG ERFOLGREICH")
    print(f"  Gültige Paare:             {len(validated)}")
    print(f"  Globale doppelte Stems:    {len(duplicate_stems)}")

    if duplicate_stems:
        print("  => Wegen Namenskollisionen werden ALLE Paare fortlaufend neu nummeriert.")
        print("  Beispiele:", ", ".join(duplicate_stems[:10]))
    else:
        print("  => Keine Namenskollisionen; Original-Stems können erhalten bleiben.")

    return validated


def _prepare_empty_output_dir(path: Path):
    if path.exists() and any(path.iterdir()):
        if not RECREATE_OUTPUT:
            raise FileExistsError(
                f"Zielordner existiert bereits und ist nicht leer:\n{path}\n\n"
                "Entweder Zielordner manuell prüfen/löschen oder "
                "RECREATE_OUTPUT = True setzen."
            )
        shutil.rmtree(path)

    path.mkdir(parents=True, exist_ok=True)


def _split_pairs(pairs: list[SourcePair]) -> dict[str, list[SourcePair]]:
    shuffled = list(pairs)
    random.Random(RANDOM_SEED).shuffle(shuffled)

    n = len(shuffled)
    n_train = int(n * TRAIN_RATIO)
    n_val = int(n * VAL_RATIO)

    return {
        "train": shuffled[:n_train],
        "val": shuffled[n_train:n_train + n_val],
        "test": shuffled[n_train + n_val:],
    }


def _normalize_rgb(img: Image.Image) -> Image.Image:
    """Transparenz sauber gegen weißen Hintergrund compositen, sonst RGB."""
    if img.mode in ("RGBA", "LA") or (
        img.mode == "P" and "transparency" in img.info
    ):
        rgba = img.convert("RGBA")
        bg = Image.new("RGBA", rgba.size, (255, 255, 255, 255))
        return Image.alpha_composite(bg, rgba).convert("RGB")
    return img.convert("RGB")


def _write_pair_as_png(task):
    (
        image_src,
        mask_src,
        image_dst,
        mask_dst,
        png_compression,
    ) = task

    image_dst = Path(image_dst)
    mask_dst = Path(mask_dst)

    try:
        image_dst.parent.mkdir(parents=True, exist_ok=True)
        mask_dst.parent.mkdir(parents=True, exist_ok=True)

        with Image.open(image_src) as img_in:
            img = ImageOps.exif_transpose(img_in)
            img = _normalize_rgb(img)
            img.save(
                image_dst,
                format="PNG",
                compress_level=png_compression,
                optimize=False,
            )

        # Absichtlich KEIN ImageOps.exif_transpose() bei Masken.
        with Image.open(mask_src) as mask_in:
            mask = mask_in.convert("L")
            mask.save(
                mask_dst,
                format="PNG",
                compress_level=png_compression,
                optimize=False,
            )

        return (True, str(image_dst), "")

    except Exception as exc:
        return (False, str(image_dst), repr(exc))


def build_original_dataset(validated_pairs: list[SourcePair]) -> list[OutputPair]:
    """
    Stufe 2:
      - logisch zusammenführen
      - globale Namenskollisionen erkennen
      - ggf. ALLE Paare fortlaufend nummerieren
      - 70/15/15 (oder Config) splitten
      - immer als PNG speichern
    """
    _prepare_empty_output_dir(ORIGINAL_DATASET_DIR)

    global_counts = Counter(p.stem.casefold() for p in validated_pairs)
    has_global_duplicates = any(count > 1 for count in global_counts.values())

    ordered = sorted(
        validated_pairs,
        key=lambda p: (
            p.dataset_root.casefold(),
            p.group.casefold(),
            p.stem.casefold(),
            p.image_path.casefold(),
        ),
    )

    output_stem_by_pair: dict[tuple[str, str, str, str], str] = {}

    if has_global_duplicates:
        width = max(6, len(str(len(ordered))))
        for idx, pair in enumerate(ordered, start=1):
            key = (pair.dataset_root, pair.group, pair.stem, pair.image_path)
            output_stem_by_pair[key] = f"{idx:0{width}d}"
    else:
        for pair in ordered:
            key = (pair.dataset_root, pair.group, pair.stem, pair.image_path)
            output_stem_by_pair[key] = pair.stem

    split_map = _split_pairs(validated_pairs)

    tasks = []
    output_pairs: list[OutputPair] = []

    for split, pairs in split_map.items():
        image_dir = ORIGINAL_DATASET_DIR / split / "images"
        mask_dir = ORIGINAL_DATASET_DIR / split / "masks"
        image_dir.mkdir(parents=True, exist_ok=True)
        mask_dir.mkdir(parents=True, exist_ok=True)

        for pair in pairs:
            key = (pair.dataset_root, pair.group, pair.stem, pair.image_path)
            output_stem = output_stem_by_pair[key]

            image_dst = image_dir / f"{output_stem}.png"
            mask_dst = mask_dir / f"{output_stem}.png"

            tasks.append(
                (
                    pair.image_path,
                    pair.mask_path,
                    str(image_dst),
                    str(mask_dst),
                    PNG_COMPRESSION,
                )
            )

            output_pairs.append(
                OutputPair(
                    split=split,
                    output_stem=output_stem,
                    image_path=str(image_dst),
                    mask_path=str(mask_dst),
                    source_root=pair.dataset_root,
                    source_group=pair.group,
                    source_stem=pair.stem,
                )
            )

    errors = []
    with ProcessPoolExecutor(max_workers=MAX_WORKERS) as ex:
        results = ex.map(
            _write_pair_as_png,
            tasks,
            chunksize=max(1, len(tasks) // max(1, MAX_WORKERS * 8)),
        )
        for ok, dst, msg in tqdm(
            results,
            total=len(tasks),
            desc="Schreibe mydataset_original",
            unit="Paar",
        ):
            if not ok:
                errors.append(f"{dst}: {msg}")

    if errors:
        preview = "\n".join(f"- {e}" for e in errors[:30])
        raise RuntimeError(
            f"Fehler beim Schreiben des Original-Datasets: {len(errors)}\n{preview}"
        )

    # Mapping/Provenienz als CSV – nützlich, falls wegen Duplikaten neu nummeriert wurde.
    manifest_path = ORIGINAL_DATASET_DIR / "manifest.csv"
    with manifest_path.open("w", encoding="utf-8", newline="") as f:
        writer = csv.writer(f)
        writer.writerow(
            [
                "split",
                "output_stem",
                "output_image",
                "output_mask",
                "source_root",
                "source_group",
                "source_stem",
            ]
        )
        for row in sorted(
            output_pairs,
            key=lambda x: (SPLITS.index(x.split), x.output_stem.casefold()),
        ):
            writer.writerow(
                [
                    row.split,
                    row.output_stem,
                    row.image_path,
                    row.mask_path,
                    row.source_root,
                    row.source_group,
                    row.source_stem,
                ]
            )

    print("\nORIGINAL-DATASET ERSTELLT")
    for split in SPLITS:
        count = sum(1 for p in output_pairs if p.split == split)
        print(f"  {split:5s}: {count}")
    print(f"  Gesamt: {len(output_pairs)}")
    print(f"  Ziel:   {ORIGINAL_DATASET_DIR}")
    print(f"  Manifest: {manifest_path}")
    print(f"  Neu nummeriert: {'JA' if has_global_duplicates else 'NEIN'}")

    return output_pairs


def _window_positions(length: int, window: int, stride: int) -> list[int]:
    """
    Sliding-window Positionen mit Randabdeckung ohne Padding.
    Ist das Original kleiner als das Fenster, gibt es keine gültige Position.
    """
    if length < window:
        return []

    last = length - window
    positions = list(range(0, last + 1, stride))

    if not positions:
        positions = [0]

    if positions[-1] != last:
        positions.append(last)

    return positions


def _rotate_array_exact_90(arr: np.ndarray, deg: int) -> np.ndarray:
    if deg == 0:
        return np.ascontiguousarray(arr)
    k = {90: 1, 180: 2, 270: 3}[deg]
    return np.ascontiguousarray(np.rot90(arr, k=k))


def _save_png_array(arr: np.ndarray, path: Path, mode: str):
    path.parent.mkdir(parents=True, exist_ok=True)
    Image.fromarray(arr, mode=mode).save(
        path,
        format="PNG",
        compress_level=PNG_COMPRESSION,
        optimize=False,
    )


def _process_patch_pair(task):
    (
        split,
        image_path_str,
        mask_path_str,
        out_split_dir_str,
        image_size,
        stride,
        white_threshold,
        rotations,
    ) = task

    image_path = Path(image_path_str)
    mask_path = Path(mask_path_str)
    out_split_dir = Path(out_split_dir_str)

    try:
        with Image.open(image_path) as img_in:
            image = img_in.convert("RGB")
            image.load()

        with Image.open(mask_path) as mask_in:
            mask = mask_in.convert("L")
            mask.load()

        if image.size != mask.size:
            return (
                False,
                split,
                image_path.name,
                0, 0, 0, 0,
                f"SIZE_MISMATCH image={image.size} mask={mask.size}",
            )

        image_np = np.asarray(image)
        mask_np = np.asarray(mask)

        height, width = mask_np.shape
        xs = _window_positions(width, image_size, stride)
        ys = _window_positions(height, image_size, stride)

        if not xs or not ys:
            return (
                True,
                split,
                image_path.name,
                0, 0, 0, 1,
                "",
            )

        normal_windows = 0
        hard_negative_windows = 0
        generated_pairs = 0

        for y in ys:
            for x in xs:
                image_patch = image_np[y:y + image_size, x:x + image_size, :]
                mask_patch = mask_np[y:y + image_size, x:x + image_size]

                has_crack = bool(mask_patch.max() > white_threshold)
                category = "normal" if has_crack else "hard_negative"

                if has_crack:
                    normal_windows += 1
                    image_out_dir = out_split_dir / "images"
                    mask_out_dir = out_split_dir / "masks"
                else:
                    hard_negative_windows += 1
                    image_out_dir = out_split_dir / "images_hard_negatives"
                    mask_out_dir = out_split_dir / "masks_hard_negatives"

                for deg in rotations:
                    img_rot = _rotate_array_exact_90(image_patch, deg)
                    mask_rot = _rotate_array_exact_90(mask_patch, deg)

                    name = (
                        f"{image_path.stem}"
                        f"_x{x}_y{y}"
                        f"_r{deg:03d}.png"
                    )

                    _save_png_array(img_rot, image_out_dir / name, "RGB")
                    _save_png_array(mask_rot, mask_out_dir / name, "L")
                    generated_pairs += 1

        return (
            True,
            split,
            image_path.name,
            normal_windows,
            hard_negative_windows,
            generated_pairs,
            0,
            "",
        )

    except Exception as exc:
        return (
            False,
            split,
            image_path.name,
            0, 0, 0, 0,
            repr(exc),
        )


def build_patch_dataset():
    """
    Stufe 3:
      mydataset_original/{train,val,test}
          -> mydataset_<IMAGE_SIZE>/{train,val,test}

    Pro Split:
      images/
      masks/
      images_hard_negatives/
      masks_hard_negatives/
    """
    _prepare_empty_output_dir(PATCH_DATASET_DIR)

    tasks = []
    missing = []

    for split in SPLITS:
        images_dir = ORIGINAL_DATASET_DIR / split / "images"
        masks_dir = ORIGINAL_DATASET_DIR / split / "masks"
        out_split_dir = PATCH_DATASET_DIR / split

        for folder in (
            out_split_dir / "images",
            out_split_dir / "masks",
            out_split_dir / "images_hard_negatives",
            out_split_dir / "masks_hard_negatives",
        ):
            folder.mkdir(parents=True, exist_ok=True)

        if not images_dir.is_dir() or not masks_dir.is_dir():
            raise FileNotFoundError(
                f"Original-Split unvollständig: {images_dir} / {masks_dir}"
            )

        image_paths = sorted(images_dir.glob("*.png"))

        for image_path in image_paths:
            mask_path = masks_dir / image_path.name
            if not mask_path.exists():
                missing.append(str(mask_path))
                continue

            tasks.append(
                (
                    split,
                    str(image_path),
                    str(mask_path),
                    str(out_split_dir),
                    IMAGE_SIZE,
                    STRIDE,
                    WHITE_THRESHOLD,
                    tuple(ROTATIONS),
                )
            )

    if missing:
        preview = "\n".join(f"- {p}" for p in missing[:30])
        raise RuntimeError(
            f"{len(missing)} Masken im Original-Dataset fehlen.\n{preview}"
        )

    if not tasks:
        raise RuntimeError("Keine Original-Paare für die Patch-Erzeugung gefunden.")

    stats = {
        split: {
            "source_pairs": 0,
            "normal_windows": 0,
            "hard_negative_windows": 0,
            "generated_pairs_after_rotation": 0,
            "too_small": 0,
            "errors": 0,
        }
        for split in SPLITS
    }

    errors = []

    with ProcessPoolExecutor(max_workers=MAX_WORKERS) as ex:
        results = ex.map(
            _process_patch_pair,
            tasks,
            chunksize=max(1, len(tasks) // max(1, MAX_WORKERS * 4)),
        )

        for result in tqdm(
            results,
            total=len(tasks),
            desc=f"Erzeuge {IMAGE_SIZE}x{IMAGE_SIZE}-Patches",
            unit="Originalpaar",
        ):
            (
                ok,
                split,
                image_name,
                normal_windows,
                hard_negative_windows,
                generated_pairs,
                too_small,
                error,
            ) = result

            s = stats[split]
            s["source_pairs"] += 1
            s["normal_windows"] += normal_windows
            s["hard_negative_windows"] += hard_negative_windows
            s["generated_pairs_after_rotation"] += generated_pairs
            s["too_small"] += too_small

            if not ok:
                s["errors"] += 1
                errors.append(f"{split}/{image_name}: {error}")

    if errors:
        preview = "\n".join(f"- {e}" for e in errors[:30])
        raise RuntimeError(
            f"Patch-Erzeugung hatte {len(errors)} Fehler.\n{preview}"
        )

    print("\nPATCH-DATASET ERSTELLT")
    print(f"  IMAGE_SIZE:      {IMAGE_SIZE}")
    print(f"  STRIDE:          {STRIDE}")
    print(f"  WHITE_THRESHOLD: {WHITE_THRESHOLD}")
    print(f"  ROTATIONS:       {ROTATIONS}")
    print(f"  Ziel:            {PATCH_DATASET_DIR}\n")

    for split in SPLITS:
        s = stats[split]
        print(
            f"{split:5s} | "
            f"Quellpaare={s['source_pairs']:6d} | "
            f"normal windows={s['normal_windows']:8d} | "
            f"hard neg windows={s['hard_negative_windows']:8d} | "
            f"Output-Paare inkl. Rotation={s['generated_pairs_after_rotation']:9d} | "
            f"zu klein={s['too_small']:4d}"
        )

    return stats


def _is_identifier_file(path: Path) -> bool:
    return (
        path.is_file()
        and (
            path.name.endswith(":Zone.Identifier")
            or path.name == "Zone.Identifier"
        )
    )


def delete_identifier_files(*roots: Path) -> int:
    """
    Löscht nur Identifier-Dateien in den ERZEUGTEN Dataset-Ordnern.
    Die Input-Datasets bleiben unangetastet.
    """
    files = []
    for root in roots:
        if root.exists():
            files.extend(p for p in root.rglob("*") if _is_identifier_file(p))

    if not files:
        print("Keine Identifier-Dateien in den Output-Datasets gefunden.")
        return 0

    def _delete(path: Path):
        try:
            path.unlink()
            return None
        except Exception as exc:
            return f"{path}: {exc!r}"

    errors = []
    with ThreadPoolExecutor(max_workers=MAX_WORKERS) as ex:
        for error in tqdm(
            ex.map(_delete, files),
            total=len(files),
            desc="Lösche Identifier-Dateien",
            unit="Datei",
        ):
            if error:
                errors.append(error)

    if errors:
        preview = "\n".join(f"- {e}" for e in errors[:30])
        raise RuntimeError(
            f"{len(errors)} Identifier-Dateien konnten nicht gelöscht werden.\n{preview}"
        )

    print(f"Identifier-Dateien gelöscht: {len(files)}")
    return len(files)


def print_tree_hint():
    print(
        f"""
Erwartete Ausgabe:

{ORIGINAL_DATASET_DIR}/
  manifest.csv
  train/
    images/*.png
    masks/*.png
  val/
    images/*.png
    masks/*.png
  test/
    images/*.png
    masks/*.png

{PATCH_DATASET_DIR}/
  train/
    images/*.png
    masks/*.png
    images_hard_negatives/*.png
    masks_hard_negatives/*.png
  val/
    ...
  test/
    ...
"""
    )


def main():
    # ============================================================
    # SCHRITT 1 – NUR VALIDIEREN
    # ============================================================
    # Dieser Schritt schreibt noch KEIN Dataset.
    # Bei Namens-, Decode- oder Größenfehlern bricht er mit einer Liste ab.

    validated_pairs = validate_all_sources(DATASET_PATHS)

    # ============================================================
    # SCHRITT 2 – ZUSAMMENFÜHREN, ggf. NEUNUMMERIEREN, PNG, SPLIT
    # ============================================================

    original_pairs = build_original_dataset(validated_pairs)

    # ============================================================
    # SCHRITT 3 – PATCHES + 0/90/180/270° + HARD NEGATIVES
    # ============================================================

    patch_stats = build_patch_dataset()

    # ============================================================
    # SCHRITT 4 – IDENTIFIER-DATEIEN LÖSCHEN + STRUKTUR ANZEIGEN
    # ============================================================

    deleted_identifiers = delete_identifier_files(
        ORIGINAL_DATASET_DIR,
        PATCH_DATASET_DIR,
    )

    print_tree_hint()
    print("FERTIG ✅")


if __name__ == "__main__":
    main()
