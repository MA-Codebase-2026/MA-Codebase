#!/usr/bin/env python3
import os
import csv
import json
import math
import random
import importlib.metadata
import platform
import shutil
import subprocess
import sys
from datetime import datetime
from pathlib import Path
from typing import Any

import tensorflow as tf
import numpy as np
import matplotlib.pyplot as plt

from keras import mixed_precision
policy = mixed_precision.Policy('mixed_float16')
mixed_precision.set_global_policy(policy)

# --- Muss pro Lauf angepasst werden ---
RUN_NAME = "deeplabv3plus_better_dataset_dice_loss_256filter"
SEG_DIR = "/home/mitte/crack_project/datasets/better_dataset_evtl" # <- anpassen

# --- Training-Konfiguration ---
SEED = 42
IMG_SIZE = 512
BATCH = 8
LR = 1e-4
STEPS_PER_EPOCH = 1000
VALIDATION_STEPS = 250
EPOCHS = 40
THRESHOLD = 0.5

# --- Verzeichnisse --- ds
OUTPUT_ROOT = Path("/home/mitte/crack_project/outputs")
RUN_DIR = OUTPUT_ROOT / RUN_NAME
MODEL_DIR = RUN_DIR / "models"
METRICS_DIR = RUN_DIR / "metrics"
PLOT_DIR = METRICS_DIR / "plots"
LOG_FILE = METRICS_DIR / f"{RUN_NAME}_epoch_metrics.txt"
CSV_FILE = METRICS_DIR / f"{RUN_NAME}_epoch_metrics.csv"
JSON_FILE = METRICS_DIR / f"{RUN_NAME}_epoch_metrics.json"
RUN_CONFIG_FILE = METRICS_DIR / f"{RUN_NAME}_run_configuration.txt"
ARCH_DIR = RUN_DIR / "architecture"
ARCHITECTURE_TXT_FILE = ARCH_DIR / f"{RUN_NAME}_architecture_detailed.txt"
ARCHITECTURE_JSON_FILE = ARCH_DIR / f"{RUN_NAME}_architecture_config.json"

TRAIN_SPLIT = "train_512"
VAL_SPLIT = "val_512"
TEST_SPLIT = "test_512"
MASK_FORMAT_DESCRIPTION = "PNG, 1 Kanal; Pixel > 127 werden als Rissklasse 1, sonst als 0 eingelesen"
LOSS_NAME = "Dice Loss"
OPTIMIZER_NAME = "Adam"
MIXED_PRECISION_POLICY = "mixed_float16"
XLA_JIT = False
STEPS_PER_EXECUTION = 1
CACHE_VALIDATION = False
SAVE_ALL_EPOCH_MODELS = True
PLOTS_EVERY_N_EPOCHS = 5
AP_THRESHOLDS = np.linspace(1.0, 0.0, 21, dtype=np.float64)
AUC_NUM_THRESHOLDS = 101
CURVE_GRID_MAX_INDEX = AUC_NUM_THRESHOLDS - 1
AP_GRID_INDICES = np.rint(AP_THRESHOLDS * CURVE_GRID_MAX_INDEX).astype(np.int32)

# --- Reproduzierbarkeit / Seed ---
os.environ["PYTHONHASHSEED"] = str(SEED)
os.environ["TF_GPU_ALLOCATOR"] = "cuda_malloc_async"
os.environ["KERAS_BACKEND"] = "tensorflow"

random.seed(SEED)
np.random.seed(SEED)
tf.random.set_seed(SEED)

tf.config.optimizer.set_jit(False)

# --- Pipeline mit tf.data ---
def load_and_preprocess(img_path, msk_path):
    img = tf.io.read_file(img_path)
    img = tf.image.decode_png(img, channels=3)
    img = tf.image.convert_image_dtype(img, tf.float32)
    img.set_shape([IMG_SIZE, IMG_SIZE, 3])

    msk = tf.io.read_file(msk_path)
    msk = tf.image.decode_png(msk, channels=1)
    msk = tf.cast(msk > 127, tf.float32)
    msk.set_shape([IMG_SIZE, IMG_SIZE, 1])

    return img, msk

def get_dataset(split):
    img_dir = Path(SEG_DIR) / split / "images"
    msk_dir = Path(SEG_DIR) / split / "masks"

    img_paths = sorted([str(p) for p in img_dir.glob("*") if not p.name.startswith(".")])
    msk_map = {p.stem.lower(): str(p) for p in msk_dir.glob("*") if not p.name.startswith(".")}

    valid_imgs, valid_msks = [], []
    for p in img_paths:
        stem = Path(p).stem.lower()
        if stem in msk_map:
            valid_imgs.append(p)
            valid_msks.append(msk_map[stem])

    ds = tf.data.Dataset.from_tensor_slices((valid_imgs, valid_msks))

    if split == "train_512":
        ds = ds.shuffle(len(valid_imgs), seed=SEED, reshuffle_each_iteration=True)
        ds = ds.repeat()

    ds = ds.map(load_and_preprocess, num_parallel_calls=tf.data.AUTOTUNE)

    ds = ds.batch(BATCH)
    ds = ds.prefetch(tf.data.AUTOTUNE)
    return ds, len(valid_imgs)

# --- Modell: DeepLabV3+ ---
# DeepLabV3+ ersetzt hier U-Net++.
# Der Rest des Codes bleibt gleich: gleiche Datenpipeline, gleicher Dice Loss,
# gleiche Validierungsmetriken, gleiche Checkpoints.
#
# Backbone:
# MobileNetV2 mit ImageNet-Gewichten. Das ist deutlich leichter als Xception
# und damit fuer eine RTX 2070 Super mit 8 GB VRAM realistischer.
#
# Wichtig:
# Die Bilder werden in load_and_preprocess bereits auf [0, 1] skaliert.
# MobileNetV2-preprocess_input erwartet jedoch Werte im Bereich [0, 255] und
# skaliert intern auf [-1, 1]. Deshalb wird im Modell zuerst wieder mit 255
# multipliziert und danach preprocess_input angewandt.

BACKBONE_WEIGHTS = "imagenet"
BACKBONE_TRAINABLE = False

ASPP_FILTERS = 128
DECODER_FILTERS = 128
LOW_LEVEL_FILTERS = 32
DROPOUT_RATE = 0.10
USE_BATCH_NORM = True


def bn_relu(x, name):
    if USE_BATCH_NORM:
        x = tf.keras.layers.BatchNormalization(name=f"{name}_bn")(x)
    x = tf.keras.layers.Activation("relu", name=f"{name}_relu")(x)
    return x


def conv_bn_relu(x, filters, kernel_size=3, dilation_rate=1, name="conv"):
    x = tf.keras.layers.Conv2D(
        filters,
        kernel_size=kernel_size,
        padding="same",
        dilation_rate=dilation_rate,
        use_bias=not USE_BATCH_NORM,
        kernel_initializer="he_normal",
        name=f"{name}_conv",
    )(x)
    x = bn_relu(x, name=name)
    return x


def aspp_branch(x, filters, dilation_rate, name):
    return conv_bn_relu(
        x,
        filters=filters,
        kernel_size=3,
        dilation_rate=dilation_rate,
        name=name,
    )


def atrous_spatial_pyramid_pooling(x):
    """
    ASPP-Modul von DeepLabV3+.
    Bei Output-Stride 16 sind die klassischen Dilation-Raten 6, 12, 18.
    Fuer 512x512 und MobileNetV2-Bottleneck auf 16x16 ist das ein sinnvoller
    Kompromiss aus grossem Kontext und Speicherbedarf.
    """
    shape = tf.keras.backend.int_shape(x)
    if shape[1] is None or shape[2] is None:
        raise ValueError("ASPP erwartet feste raeumliche Featuregroessen.")

    # Image-level pooling branch
    pooled = tf.keras.layers.GlobalAveragePooling2D(name="aspp_image_pool_gap")(x)
    pooled = tf.keras.layers.Reshape((1, 1, shape[-1]), name="aspp_image_pool_reshape")(pooled)
    pooled = conv_bn_relu(
        pooled,
        filters=ASPP_FILTERS,
        kernel_size=1,
        name="aspp_image_pool_project",
    )
    pooled = tf.keras.layers.UpSampling2D(
        size=(shape[1], shape[2]),
        interpolation="bilinear",
        name="aspp_image_pool_upsample",
    )(pooled)

    # 1x1 branch
    branch_1 = conv_bn_relu(
        x,
        filters=ASPP_FILTERS,
        kernel_size=1,
        name="aspp_branch_1x1",
    )

    # Atrous branches
    branch_6 = aspp_branch(x, ASPP_FILTERS, dilation_rate=6, name="aspp_branch_rate6")
    branch_12 = aspp_branch(x, ASPP_FILTERS, dilation_rate=12, name="aspp_branch_rate12")
    branch_18 = aspp_branch(x, ASPP_FILTERS, dilation_rate=18, name="aspp_branch_rate18")

    x = tf.keras.layers.Concatenate(name="aspp_concat")(
        [pooled, branch_1, branch_6, branch_12, branch_18]
    )

    x = conv_bn_relu(
        x,
        filters=ASPP_FILTERS,
        kernel_size=1,
        name="aspp_project",
    )
    x = tf.keras.layers.Dropout(DROPOUT_RATE, name="aspp_dropout")(x)
    return x


def build_optimized_model():
    """
    DeepLabV3+ fuer binaere Crack-Segmentierung.

    Verwendete MobileNetV2-Featureebenen bei 512x512 Input:
    - low-level feature: block_3_expand_relu, ca. 128x128
    - high-level feature: out_relu, ca. 16x16

    Decoder:
    - ASPP auf 16x16
    - Upsampling auf 128x128
    - Fusion mit Low-Level-Features
    - finales Upsampling auf 512x512
    """
    inputs = tf.keras.Input(shape=(IMG_SIZE, IMG_SIZE, 3), name="image")

    # [0, 1] -> [0, 255] -> MobileNetV2 preprocess -> [-1, 1]
    x_in = tf.keras.layers.Lambda(
        lambda z: z * 255.0,
        name="scale_0_1_to_0_255",
    )(inputs)

    x_in = tf.keras.layers.Lambda(
        tf.keras.applications.mobilenet_v2.preprocess_input,
        name="mobilenetv2_preprocess",
    )(x_in)

    backbone = tf.keras.applications.MobileNetV2(
        input_tensor=x_in,
        include_top=False,
        weights=BACKBONE_WEIGHTS,
        alpha=1.0,
    )
    backbone.trainable = BACKBONE_TRAINABLE

    low_level = backbone.get_layer("block_3_expand_relu").output
    high_level = backbone.get_layer("out_relu").output

    x = atrous_spatial_pyramid_pooling(high_level)

    low_shape = tf.keras.backend.int_shape(low_level)
    x_shape = tf.keras.backend.int_shape(x)
    up_factor_to_low = (
        low_shape[1] // x_shape[1],
        low_shape[2] // x_shape[2],
    )

    x = tf.keras.layers.UpSampling2D(
        size=up_factor_to_low,
        interpolation="bilinear",
        name="decoder_aspp_to_low_upsample",
    )(x)

    low_level = conv_bn_relu(
        low_level,
        filters=LOW_LEVEL_FILTERS,
        kernel_size=1,
        name="decoder_low_level_project",
    )

    x = tf.keras.layers.Concatenate(name="decoder_concat")([x, low_level])

    x = conv_bn_relu(
        x,
        filters=DECODER_FILTERS,
        kernel_size=3,
        name="decoder_conv1",
    )
    x = conv_bn_relu(
        x,
        filters=DECODER_FILTERS,
        kernel_size=3,
        name="decoder_conv2",
    )
    x = tf.keras.layers.Dropout(DROPOUT_RATE, name="decoder_dropout")(x)

    x_shape = tf.keras.backend.int_shape(x)
    final_up_factor = (
        IMG_SIZE // x_shape[1],
        IMG_SIZE // x_shape[2],
    )

    x = tf.keras.layers.UpSampling2D(
        size=final_up_factor,
        interpolation="bilinear",
        name="decoder_final_upsample",
    )(x)

    logits = tf.keras.layers.Conv2D(
        1,
        kernel_size=1,
        padding="same",
        kernel_initializer="he_normal",
        name="segmentation_logits",
    )(x)

    outputs = tf.keras.layers.Activation(
        "sigmoid",
        dtype="float32",
        name="predictions",
    )(logits)

    return tf.keras.Model(
        inputs=inputs,
        outputs=outputs,
        name="deeplabv3plus_mobilenetv2_crack_segmentation",
    )


# --- Loss & Soft Dice ---
def dice_coef_soft(y_true, y_pred, smooth=1e-7):
    y_true = tf.cast(y_true, tf.float32)
    y_pred = tf.cast(y_pred, tf.float32)

    intersection = tf.reduce_sum(y_true * y_pred, axis=[1, 2, 3])
    union = tf.reduce_sum(y_true + y_pred, axis=[1, 2, 3])

    return tf.reduce_mean((2.0 * intersection + smooth) / (union + smooth))

def dice_loss(y_true, y_pred):
    return 1.0 - dice_coef_soft(y_true, y_pred)

# =============================================================================
# Hilfsfunktionen / System-, Datensatz- und Architekturinformationen
# =============================================================================

def json_safe(value: Any) -> Any:
    if isinstance(value, dict):
        return {str(k): json_safe(v) for k, v in value.items()}
    if isinstance(value, (list, tuple, set)):
        return [json_safe(v) for v in value]
    if isinstance(value, Path):
        return str(value)
    if isinstance(value, np.ndarray):
        return value.tolist()
    if isinstance(value, np.generic):
        return value.item()
    if isinstance(value, datetime):
        return value.isoformat()
    if isinstance(value, bytes):
        return value.decode("utf-8", errors="replace")
    try:
        json.dumps(value)
        return value
    except TypeError:
        return str(value)


def write_json_atomic(path: Path, data: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temp_path = path.with_suffix(path.suffix + ".tmp")
    with temp_path.open("w", encoding="utf-8") as file:
        json.dump(json_safe(data), file, indent=2, ensure_ascii=False)
    temp_path.replace(path)


def package_version(*package_names: str) -> str:
    for package_name in package_names:
        try:
            return importlib.metadata.version(package_name)
        except importlib.metadata.PackageNotFoundError:
            continue
        except Exception as exc:
            return f"Fehler beim Auslesen: {exc}"
    return "nicht gefunden"


def run_command(command: list[str], timeout: int = 15) -> str:
    try:
        result = subprocess.run(command, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                                text=True, timeout=timeout, check=False)
        if result.returncode == 0 and result.stdout.strip():
            return result.stdout.strip()
        error = result.stderr.strip() or f"Returncode {result.returncode}"
        return f"nicht verfügbar ({error})"
    except FileNotFoundError:
        return "nicht verfügbar (Befehl nicht gefunden)"
    except subprocess.TimeoutExpired:
        return "nicht verfügbar (Timeout)"
    except Exception as exc:
        return f"nicht verfügbar ({exc})"


def find_nvidia_smi() -> str | None:
    for candidate in (shutil.which("nvidia-smi"), "/usr/lib/wsl/lib/nvidia-smi", "/usr/bin/nvidia-smi"):
        if candidate and Path(candidate).exists():
            return str(candidate)
    return None


def get_current_learning_rate(optimizer: tf.keras.optimizers.Optimizer) -> float:
    try:
        lr = optimizer.learning_rate
        if callable(lr):
            lr = lr(optimizer.iterations)
        return float(tf.keras.backend.get_value(lr))
    except Exception:
        return float("nan")


def safe_div(numerator: float, denominator: float, eps: float = 1e-7) -> float:
    return float((numerator + eps) / (denominator + eps))


def collect_environment_info() -> dict[str, Any]:
    try:
        tf_build_info = dict(tf.sysconfig.get_build_info())
    except Exception as exc:
        tf_build_info = {"error": str(exc)}
    nvidia_smi = find_nvidia_smi()
    if nvidia_smi:
        gpu_query = run_command([nvidia_smi, "--query-gpu=name,driver_version,memory.total", "--format=csv,noheader"])
        driver_query = run_command([nvidia_smi, "--query-gpu=driver_version", "--format=csv,noheader"])
        nvidia_smi_full = run_command([nvidia_smi])
    else:
        gpu_query = driver_query = nvidia_smi_full = "nicht verfügbar"
    physical_gpus = tf.config.list_physical_devices("GPU")
    gpu_details = []
    for gpu in physical_gpus:
        details = {"name": gpu.name, "device_type": gpu.device_type}
        try:
            details.update(tf.config.experimental.get_device_details(gpu))
        except Exception as exc:
            details["details_error"] = str(exc)
        gpu_details.append(details)
    keras_version = getattr(tf.keras, "__version__", None) or package_version("keras")
    cuda_build = tf_build_info.get("cuda_version", "nicht angegeben")
    cudnn_build = tf_build_info.get("cudnn_version", "nicht angegeben")
    cuda_runtime_pkg = package_version("nvidia-cuda-runtime-cu12", "nvidia-cuda-runtime-cu11")
    cudnn_runtime_pkg = package_version("nvidia-cudnn-cu12", "nvidia-cudnn-cu11")
    return {
        "timestamp_start": datetime.now().astimezone().isoformat(),
        "python_version": sys.version.replace("\n", " "),
        "python_executable": sys.executable,
        "platform": platform.platform(), "system": platform.system(), "release": platform.release(),
        "machine": platform.machine(), "tensorflow_version": tf.__version__, "keras_version": keras_version,
        "keras_unet_collection_version": package_version("keras-unet-collection"),
        "numpy_version": np.__version__, "matplotlib_version": package_version("matplotlib"),
        "mixed_precision_policy": mixed_precision.global_policy().name,
        "tensorflow_built_with_cuda": bool(tf.test.is_built_with_cuda()),
        "tensorflow_build_info": json_safe(tf_build_info),
        "cuda_runtime": f"TensorFlow-Build: {cuda_build}; Python-Paket nvidia-cuda-runtime: {cuda_runtime_pkg}",
        "cudnn_version": f"TensorFlow-Build: {cudnn_build}; Python-Paket nvidia-cudnn: {cudnn_runtime_pkg}",
        "nvidia_windows_driver": driver_query, "nvidia_gpu_query": gpu_query,
        "nvidia_smi_full": nvidia_smi_full, "tensorflow_visible_gpus": json_safe(gpu_details),
        "cuda_visible_devices": os.environ.get("CUDA_VISIBLE_DEVICES", "nicht gesetzt"),
    }


def collect_split_info(split: str) -> dict[str, Any]:
    image_dir = Path(SEG_DIR) / split / "images"
    mask_dir = Path(SEG_DIR) / split / "masks"
    image_paths = sorted(p for p in image_dir.glob("*") if p.is_file() and not p.name.startswith("."))
    mask_paths = sorted(p for p in mask_dir.glob("*") if p.is_file() and not p.name.startswith("."))
    mask_map = {p.stem.lower(): p for p in mask_paths}
    matched = [p for p in image_paths if p.stem.lower() in mask_map]
    image_stems = {p.stem.lower() for p in image_paths}
    return {
        "label": split, "split": split, "image_dir": str(image_dir), "mask_dir": str(mask_dir),
        "images_found": len(image_paths), "masks_found": len(mask_paths), "matched_pairs": len(matched),
        "images_without_mask_count": sum(p.stem.lower() not in mask_map for p in image_paths),
        "masks_without_image_count": sum(p.stem.lower() not in image_stems for p in mask_paths),
        "image_extensions": sorted({p.suffix.lower() for p in image_paths}),
        "mask_extensions": sorted({p.suffix.lower() for p in mask_paths}),
    }


def compute_confusion_from_binary(y_true_binary, y_pred_binary):
    y_true_bool = y_true_binary.astype(bool); y_pred_bool = y_pred_binary.astype(bool)
    tp = int(np.logical_and(y_true_bool, y_pred_bool).sum())
    fp = int(np.logical_and(~y_true_bool, y_pred_bool).sum())
    fn = int(np.logical_and(y_true_bool, ~y_pred_bool).sum())
    tn = int(np.logical_and(~y_true_bool, ~y_pred_bool).sum())
    return tp, fp, fn, tn


def compute_fg_metrics_from_confusion(tp, fp, fn, tn):
    precision = safe_div(tp, tp + fp); recall = safe_div(tp, tp + fn)
    dice = safe_div(2 * tp, 2 * tp + fp + fn); iou = safe_div(tp, tp + fp + fn)
    f1 = safe_div(2 * precision * recall, precision + recall)
    beta2 = 4.0
    f2 = safe_div((1.0 + beta2) * precision * recall, beta2 * precision + recall)
    fpr = safe_div(fp, fp + tn); fnr = safe_div(fn, fn + tp)
    balanced_error = 0.5 * (fpr + fnr)
    return {"precision_fg": precision, "recall_fg": recall, "dice_fg": dice, "iou_fg": iou,
            "f1_fg": f1, "f2_fg": f2, "false_positive_rate": fpr,
            "false_negative_rate": fnr, "balanced_error": balanced_error,
            "balanced_accuracy": 1.0 - balanced_error}


def compute_ap_from_threshold_confusions(tp, fp, fn):
    total_positives = float(np.max(tp + fn))
    if total_positives <= 0: return float("nan")
    predicted = tp + fp
    precision = np.divide(tp, predicted, out=np.ones_like(tp, dtype=np.float64), where=predicted > 0)
    recall = tp / total_positives
    order = np.argsort(recall); recall = recall[order]; precision = precision[order]
    unique_recall, inverse = np.unique(recall, return_inverse=True)
    max_precision = np.zeros_like(unique_recall, dtype=np.float64)
    for index, pv in zip(inverse, precision): max_precision[index] = max(max_precision[index], pv)
    recall = np.concatenate(([0.0], unique_recall, [1.0]))
    precision = np.concatenate(([max_precision[0] if max_precision.size else 0.0], max_precision, [0.0]))
    for index in range(precision.size - 2, -1, -1): precision[index] = max(precision[index], precision[index + 1])
    return float(np.sum((recall[1:] - recall[:-1]) * precision[1:]))


def save_plot(x_values, y_series, labels, title, y_label, output_path, y_limits=None):
    plt.figure(figsize=(11, 6.5))
    for values, label in zip(y_series, labels): plt.plot(x_values, values, label=label)
    plt.xlabel("Epoche"); plt.ylabel(y_label); plt.title(title); plt.grid(True, alpha=0.3)
    if y_limits is not None: plt.ylim(*y_limits)
    plt.legend(loc="best"); plt.tight_layout(); plt.savefig(output_path, dpi=200); plt.close()


def save_training_plots(history_rows, plot_dir):
    plot_dir = Path(plot_dir); plot_dir.mkdir(parents=True, exist_ok=True)
    if not history_rows: return
    epochs = [int(row["epoch"]) for row in history_rows]
    values = lambda field: [float(row[field]) for row in history_rows]
    save_plot(epochs,[values("train_loss"),values("val_loss")],["train_loss","val_loss"],"Loss-Verlauf","Loss",plot_dir/"loss_curve.png")
    save_plot(epochs,[values("train_dice_soft"),values("val_dice_soft"),values("val_dice_fg")],["train_dice_soft","val_dice_soft","val_dice_fg"],"Dice-Verlauf","Dice",plot_dir/"dice_curve.png",(0,1.02))
    save_plot(epochs,[values("val_iou_fg")],["val_iou_fg"],"IoU-Verlauf","IoU",plot_dir/"iou_curve.png",(0,1.02))
    save_plot(epochs,[values("val_precision_fg"),values("val_recall_fg"),values("val_f1_fg"),values("val_f2_fg")],["val_precision_fg","val_recall_fg","val_f1_fg","val_f2_fg"],"Precision / Recall / F1 / F2","Score",plot_dir/"precision_recall_f1_f2_curve.png",(0,1.02))
    save_plot(epochs,[values("val_balanced_error"),values("val_fpr"),values("val_fnr")],["val_balanced_error","val_fpr","val_fnr"],"Fehlermetriken","Rate",plot_dir/"error_metrics_curve.png",(0,1.02))
    save_plot(epochs,[values("val_balanced_accuracy")],["val_balanced_accuracy"],"Balanced Accuracy","Score",plot_dir/"balanced_accuracy_curve.png",(0,1.02))
    save_plot(epochs,[values("val_ap")],["val_ap_fg"],"Average Precision der Rissklasse","AP",plot_dir/"ap_curve.png",(0,1.02))
    save_plot(epochs,[values("val_selection_distance")],["val_selection_distance"],"Dice-F2-Idealpunkt-Distanz zur Epochenauswahl","D (kleiner ist besser)",plot_dir/"selection_distance_curve.png")
    save_plot(epochs,[values("train_dice_soft"),values("val_dice_soft"),values("val_dice_fg"),values("val_iou_fg"),values("val_precision_fg"),values("val_recall_fg"),values("val_f1_fg"),values("val_f2_fg"),values("val_balanced_accuracy"),values("val_ap")],
              ["train_dice_soft","val_dice_soft","val_dice_fg","val_iou_fg","val_precision_fg","val_recall_fg","val_f1_fg","val_f2_fg","val_balanced_accuracy","val_ap_fg"],
              "Alle vergleichbaren höher-ist-besser-Metriken","Score (0–1)",plot_dir/"all_metrics_same_scale.png",(0,1.02))


def export_architecture(model: tf.keras.Model) -> dict[str, Any]:
    ARCH_DIR.mkdir(parents=True, exist_ok=True)
    with ARCHITECTURE_TXT_FILE.open("w", encoding="utf-8") as file:
        file.write(f"Run: {RUN_NAME}\nArchitecture: DeepLabV3+ with MobileNetV2 backbone\n")
        file.write("="*180+"\nMODELLZUSAMMENFASSUNG\n"+"="*180+"\n")
        model.summary(print_fn=lambda line: file.write(line+"\n"), expand_nested=True, show_trainable=True)
        file.write("\n"+"="*180+"\nLAYERDETAILS\n"+"="*180+"\n")
        for idx, layer in enumerate(model.layers):
            file.write(f"{idx:04d}\t{layer.name}\t{layer.__class__.__name__}\ttrainable={layer.trainable}\tparams={layer.count_params()}\n")
    info = {"model_name": model.name, "parameter_count": int(model.count_params()),
            "trainable_parameter_count": int(sum(np.prod(v.shape) for v in model.trainable_weights)),
            "non_trainable_parameter_count": int(sum(np.prod(v.shape) for v in model.non_trainable_weights)),
            "layer_count": len(model.layers), "architecture": "DeepLabV3+ with MobileNetV2 backbone",
            "backbone_weights": BACKBONE_WEIGHTS, "backbone_trainable": BACKBONE_TRAINABLE,
            "aspp_filters": ASPP_FILTERS, "decoder_filters": DECODER_FILTERS,
            "low_level_filters": LOW_LEVEL_FILTERS, "dropout_rate": DROPOUT_RATE,
            "batch_normalization": USE_BATCH_NORM}
    write_json_atomic(ARCHITECTURE_JSON_FILE, info)
    return info


def build_run_metadata(environment_info, dataset_info, architecture_info):
    train_count = int(dataset_info[TRAIN_SPLIT]["matched_pairs"]); val_count = int(dataset_info[VAL_SPLIT]["matched_pairs"]); test_count = int(dataset_info[TEST_SPLIT]["matched_pairs"])
    return {"run":RUN_NAME,"seed":SEED,"dataset_root":str(SEG_DIR),"dataset_splits":{"train":str(Path(SEG_DIR)/TRAIN_SPLIT),"validation":str(Path(SEG_DIR)/VAL_SPLIT),"test":str(Path(SEG_DIR)/TEST_SPLIT)},
            "output_dir":str(RUN_DIR),"threshold":THRESHOLD,"loss":LOSS_NAME,"optimizer":OPTIMIZER_NAME,"initial_learning_rate":LR,
            "architecture":"DeepLabV3+ with MobileNetV2 backbone","backbone_weights":BACKBONE_WEIGHTS,"backbone_trainable":BACKBONE_TRAINABLE,
            "aspp_filters":ASPP_FILTERS,"decoder_filters":DECODER_FILTERS,"low_level_filters":LOW_LEVEL_FILTERS,"dropout_rate":DROPOUT_RATE,"batch_normalization":USE_BATCH_NORM,
            "patch_resolution":f"{IMG_SIZE} x {IMG_SIZE} px","image_channels":3,"mask_format":MASK_FORMAT_DESCRIPTION,"batch_size":BATCH,
            "steps_per_epoch":STEPS_PER_EPOCH,"images_per_epoch_effective":STEPS_PER_EPOCH*BATCH,"validation_steps":VALIDATION_STEPS,"epochs_planned":EPOCHS,
            "xla_jit":XLA_JIT,"mixed_precision_policy":MIXED_PRECISION_POLICY,"steps_per_execution":STEPS_PER_EXECUTION,"cache_validation":CACHE_VALIDATION,
            "ap_threshold_count":len(AP_THRESHOLDS),"auc_threshold_count":AUC_NUM_THRESHOLDS,"save_all_epoch_models":SAVE_ALL_EPOCH_MODELS,
            "dataset_counts":{"train":train_count,"validation":val_count,"test":test_count,"total":train_count+val_count+test_count},
            "epochs_for_approx_full_train_pass":train_count/(STEPS_PER_EPOCH*BATCH) if STEPS_PER_EPOCH*BATCH else float("inf"),
            "ap_definition":"Single-class pixel-wise AP for the foreground crack class. val_ap is the pixel-wise Average Precision of the crack foreground class.",
            "environment":environment_info,"dataset_details":dataset_info,"architecture_export":architecture_info}


def write_run_configuration_file(metadata):
    env=metadata["environment"]; counts=metadata["dataset_counts"]
    with RUN_CONFIG_FILE.open("w",encoding="utf-8") as file:
        file.write(f"Run: {RUN_NAME}\nZeitpunkt: {env['timestamp_start']}\nSeed: {SEED}\nDataset: {SEG_DIR}\n")
        file.write(f"Train-Split: {Path(SEG_DIR)/TRAIN_SPLIT}\nValidation-Split: {Path(SEG_DIR)/VAL_SPLIT}\nTest-Split: {Path(SEG_DIR)/TEST_SPLIT}\nOutput: {RUN_DIR}\nThreshold: {THRESHOLD}\n")
        file.write(f"Loss: {LOSS_NAME}\nOptimizer: {OPTIMIZER_NAME}\nInitial learning rate: {LR}\nArchitecture: DeepLabV3+ with MobileNetV2 backbone\n")
        file.write(f"Backbone weights: {BACKBONE_WEIGHTS}\nBackbone trainable: {BACKBONE_TRAINABLE}\nASPP filters: {ASPP_FILTERS}\nDecoder filters: {DECODER_FILTERS}\nLow-level filters: {LOW_LEVEL_FILTERS}\nDropout: {DROPOUT_RATE}\nBatch normalization: {USE_BATCH_NORM}\n")
        file.write(f"Patch resolution: {IMG_SIZE} x {IMG_SIZE} px\nMask format: {MASK_FORMAT_DESCRIPTION}\nBatch size: {BATCH}\nSteps per epoch: {STEPS_PER_EPOCH}\nEffective images per epoch: {STEPS_PER_EPOCH*BATCH}\nValidation steps: {VALIDATION_STEPS}\nPlanned epochs: {EPOCHS}\n")
        file.write(f"XLA/JIT: {XLA_JIT}\nMixed precision policy: {MIXED_PRECISION_POLICY}\nSteps per execution: {STEPS_PER_EXECUTION}\nAP threshold count: {len(AP_THRESHOLDS)}\nAUC threshold count: {AUC_NUM_THRESHOLDS}\n")
        file.write(f"Train images: {counts['train']}\nValidation images: {counts['validation']}\nTest images: {counts['test']}\nDataset total: {counts['total']}\n")
        file.write(f"Epochs for approximately one complete train-set pass: {metadata['epochs_for_approx_full_train_pass']:.4f}\n")
        file.write(f"Python version: {env['python_version']}\nPython executable: {env['python_executable']}\nTensorFlow version: {env['tensorflow_version']}\nKeras version: {env['keras_version']}\nNVIDIA Windows driver: {env['nvidia_windows_driver']}\nCUDA runtime: {env['cuda_runtime']}\ncuDNN version: {env['cudnn_version']}\nPlatform: {env['platform']}\nGPU: {env['nvidia_gpu_query']}\n")
        file.write("AP definition: val_ap ist die pixelweise Average Precision der Rissklasse.\n"+"="*180+"\nVOLLSTÄNDIGE METADATEN ALS JSON\n"+"="*180+"\n")
        json.dump(json_safe(metadata), file, indent=2, ensure_ascii=False); file.write("\n")


class ValidationMetricsLogger(tf.keras.callbacks.Callback):
    FIELDNAMES = ["epoch","train_loss","val_loss","train_dice_soft","val_dice_soft","val_dice_fg","val_iou_fg","val_precision_fg","val_recall_fg","val_f1_fg","val_f2_fg","val_balanced_error","val_balanced_accuracy","val_fpr","val_fnr","val_ap","val_selection_distance"]
    def __init__(self, validation_dataset, validation_steps, metrics_txt_path, metrics_csv_path, metrics_json_path, run_metadata, threshold=0.5, plot_dir=None):
        super().__init__(); self.validation_dataset=validation_dataset; self.validation_steps=validation_steps
        self.metrics_txt_path=Path(metrics_txt_path); self.metrics_csv_path=Path(metrics_csv_path); self.metrics_json_path=Path(metrics_json_path)
        self.run_metadata=run_metadata; self.threshold=threshold; self.plot_dir=Path(plot_dir) if plot_dir is not None else self.metrics_txt_path.parent/"plots"
        self.best_epoch=None; self.best_selection_distance=None; self.epoch_history=[]; self.training_started_at=datetime.now().astimezone()
        self._initialize_log_files(); self._write_json("initialized")
    def _initialize_log_files(self):
        for p in (self.metrics_txt_path.parent,self.metrics_csv_path.parent,self.metrics_json_path.parent,self.plot_dir): p.mkdir(parents=True,exist_ok=True)
        env=self.run_metadata["environment"]; counts=self.run_metadata["dataset_counts"]
        with self.metrics_txt_path.open("w",encoding="utf-8") as f:
            f.write(f"Run: {RUN_NAME}\nSeed: {SEED}\nDataset: {SEG_DIR}\nOutput: {RUN_DIR}\nThreshold: {self.threshold}\nLoss: {LOSS_NAME}\nArchitecture: DeepLabV3+ with MobileNetV2 backbone\n")
            f.write(f"Backbone weights: {BACKBONE_WEIGHTS}\nBackbone trainable: {BACKBONE_TRAINABLE}\nASPP filters: {ASPP_FILTERS}\nDecoder filters: {DECODER_FILTERS}\nPatch resolution: {IMG_SIZE} x {IMG_SIZE} px\nMask format: {MASK_FORMAT_DESCRIPTION}\nBatch size: {BATCH}\nOptimizer: {OPTIMIZER_NAME}\nInitial learning rate: {LR}\nSteps per epoch: {STEPS_PER_EPOCH}\nValidation steps: {VALIDATION_STEPS}\nPlanned epochs: {EPOCHS}\nXLA/JIT: {XLA_JIT}\nMixed precision policy: {MIXED_PRECISION_POLICY}\nSteps per execution: {STEPS_PER_EXECUTION}\nAP threshold count: {len(AP_THRESHOLDS)}\nAUC threshold count: {AUC_NUM_THRESHOLDS}\nSave all epoch models: {SAVE_ALL_EPOCH_MODELS}\n")
            f.write(f"Train images: {counts['train']}\nValidation images: {counts['validation']}\nTest images: {counts['test']}\nDataset total: {counts['total']}\nPython version: {env['python_version']}\nKeras version: {env['keras_version']}\nNVIDIA Windows driver: {env['nvidia_windows_driver']}\nCUDA runtime: {env['cuda_runtime']}\ncuDNN version: {env['cudnn_version']}\n")
            f.write("val_ap: pixelweise Average Precision der Rissklasse.\nval_f2_fg: F2-Score der Rissklasse; Recall wird stärker als Precision gewichtet.\n")
            f.write("Finale Epochenauswahl: euklidische Idealpunkt-Distanz aus val_dice_fg und val_f2_fg: D = sqrt(0.5*(1-Dice)^2 + 0.5*(1-F2)^2). Kleinster D-Wert gewinnt.\n")
            f.write("val_selection_distance wird in jeder Epoche direkt aus val_dice_fg und val_f2_fg berechnet und protokolliert.\nAlle Validierungsmetriken werden in jeder Epoche berechnet.\n"+"="*180+"\n"+"\t".join(self.FIELDNAMES)+"\n")
        with self.metrics_csv_path.open("w",encoding="utf-8",newline="") as f: csv.DictWriter(f,fieldnames=self.FIELDNAMES).writeheader()
    def _evaluate_validation(self):
        total_loss=total_dice=0.0; total_samples=0; tp=fp=fn=tn=0
        curve_tp=np.zeros(AUC_NUM_THRESHOLDS,dtype=np.float64); curve_fp=np.zeros_like(curve_tp); curve_fn=np.zeros_like(curve_tp)
        iterator=self.validation_dataset if self.validation_steps is None else self.validation_dataset.take(self.validation_steps)
        thresholds=np.linspace(0.0,1.0,AUC_NUM_THRESHOLDS,dtype=np.float32)
        for images,masks in iterator:
            preds=self.model(images,training=False); bs=int(images.shape[0]);
            if bs==0: continue
            pn=preds.numpy().astype(np.float32); mn=masks.numpy().astype(np.float32); yt=(mn>=0.5).astype(np.uint8); yp=(pn>=self.threshold).astype(np.uint8)
            batch_dice=float(dice_coef_soft(masks,preds).numpy()); total_dice+=batch_dice*bs; total_loss+=(1.0-batch_dice)*bs; total_samples+=bs
            a,b,c,d=compute_confusion_from_binary(yt,yp); tp+=a; fp+=b; fn+=c; tn+=d
            flat_t=yt.reshape(-1).astype(bool); flat_s=pn.reshape(-1)
            pos=np.sort(flat_s[flat_t]); neg=np.sort(flat_s[~flat_t]); npos=pos.size
            tpc=npos-np.searchsorted(pos,thresholds,side="left"); fpc=neg.size-np.searchsorted(neg,thresholds,side="left")
            curve_tp+=tpc; curve_fp+=fpc; curve_fn+=(npos-tpc)
        if total_samples==0: return {k:float("nan") for k in self.FIELDNAMES if k not in {"epoch","train_loss","train_dice_soft","val_selection_distance"}}
        fg=compute_fg_metrics_from_confusion(tp,fp,fn,tn)
        ap=compute_ap_from_threshold_confusions(curve_tp[AP_GRID_INDICES],curve_fp[AP_GRID_INDICES],curve_fn[AP_GRID_INDICES])
        return {"val_loss":total_loss/total_samples,"val_dice_soft":total_dice/total_samples,"val_dice_fg":fg["dice_fg"],"val_iou_fg":fg["iou_fg"],"val_precision_fg":fg["precision_fg"],"val_recall_fg":fg["recall_fg"],"val_f1_fg":fg["f1_fg"],"val_f2_fg":fg["f2_fg"],"val_balanced_error":fg["balanced_error"],"val_balanced_accuracy":fg["balanced_accuracy"],"val_fpr":fg["false_positive_rate"],"val_fnr":fg["false_negative_rate"],"val_ap":ap}
    def _append_epoch_row(self,row):
        with self.metrics_txt_path.open("a",encoding="utf-8") as f: f.write("\t".join([str(int(row["epoch"]))]+[f"{float(row[k]):.6f}" for k in self.FIELDNAMES[1:]])+"\n")
        with self.metrics_csv_path.open("a",encoding="utf-8",newline="") as f: csv.DictWriter(f,fieldnames=self.FIELDNAMES).writerow(row)
    def _write_json(self,status):
        elapsed=(datetime.now().astimezone()-self.training_started_at).total_seconds()
        write_json_atomic(self.metrics_json_path,{"status":status,"run_metadata":self.run_metadata,"best_epoch":self.best_epoch,"best_selection_distance":self.best_selection_distance,"epochs_completed":len(self.epoch_history),"elapsed_seconds":elapsed,"history":self.epoch_history})
    def on_epoch_end(self,epoch,logs=None):
        if logs is None: logs={}
        v=self._evaluate_validation(); row={"epoch":float(epoch+1),"train_loss":float(logs.get("loss",np.nan)),"val_loss":float(v["val_loss"]),"train_dice_soft":float(logs.get("dice_coef_soft",np.nan)),"val_dice_soft":float(v["val_dice_soft"]),"val_dice_fg":float(v["val_dice_fg"]),"val_iou_fg":float(v["val_iou_fg"]),"val_precision_fg":float(v["val_precision_fg"]),"val_recall_fg":float(v["val_recall_fg"]),"val_f1_fg":float(v["val_f1_fg"]),"val_f2_fg":float(v["val_f2_fg"]),"val_balanced_error":float(v["val_balanced_error"]),"val_balanced_accuracy":float(v["val_balanced_accuracy"]),"val_fpr":float(v["val_fpr"]),"val_fnr":float(v["val_fnr"]),"val_ap":float(v["val_ap"])}
        row["val_selection_distance"]=math.sqrt(0.5*(1-row["val_dice_fg"])**2+0.5*(1-row["val_f2_fg"])**2); self.epoch_history.append(row)
        for k,val in row.items():
            if k!="epoch": logs[k]=val
        logs["loss"]=row["train_loss"]; logs["dice_coef_soft"]=row["train_dice_soft"]; logs["learning_rate"]=get_current_learning_rate(self.model.optimizer)
        self._append_epoch_row(row); self._write_json("training")
        if PLOTS_EVERY_N_EPOCHS>0 and (epoch+1)%PLOTS_EVERY_N_EPOCHS==0: save_training_plots(self.epoch_history,self.plot_dir)
        print("\nVALIDIERUNG: "+f"loss={row['val_loss']:.6f} | dice_soft={row['val_dice_soft']:.6f} | dice_fg={row['val_dice_fg']:.6f} | iou={row['val_iou_fg']:.6f} | precision={row['val_precision_fg']:.6f} | recall={row['val_recall_fg']:.6f} | f1={row['val_f1_fg']:.6f} | f2={row['val_f2_fg']:.6f} | bal_err={row['val_balanced_error']:.6f} | bal_acc={row['val_balanced_accuracy']:.6f} | fpr={row['val_fpr']:.6f} | fnr={row['val_fnr']:.6f} | ap_fg={row['val_ap']:.6f} | D={row['val_selection_distance']:.6f} | lr={logs['learning_rate']:.8g}")
    def on_train_end(self,logs=None):
        valid=[r for r in self.epoch_history if np.isfinite(r["val_dice_fg"]) and np.isfinite(r["val_f2_fg"]) and np.isfinite(r["val_selection_distance"])]
        if valid:
            best=min(valid,key=lambda r:(float(r["val_selection_distance"]),-float(r["val_dice_fg"]),-float(r["val_f2_fg"]),int(r["epoch"])))
            self.best_epoch=int(best["epoch"]); self.best_selection_distance=float(best["val_selection_distance"])
            selection_path=self.metrics_txt_path.parent/f"{RUN_NAME}_epoch_selection_dice_f2_distance.csv"
            fields=["epoch","val_dice_fg","val_f2_fg","val_selection_distance"]
            with selection_path.open("w",encoding="utf-8",newline="") as f:
                w=csv.DictWriter(f,fieldnames=fields); w.writeheader(); [w.writerow({k:r[k] for k in fields}) for r in sorted(valid,key=lambda x:int(x["epoch"]))]
            with self.metrics_txt_path.open("a",encoding="utf-8") as f:
                f.write("="*180+"\nFINALE EPOCHENAUSWAHL\n"+"="*180+"\nFormel: D = sqrt(0.5*(1-Dice)^2 + 0.5*(1-F2)^2); Dice=val_dice_fg, F2=val_f2_fg; kleiner ist besser.\n")
                f.write(f"Best selection distance: {self.best_selection_distance:.8f}\nBest val_dice_fg: {float(best['val_dice_fg']):.8f}\nBest val_f2_fg: {float(best['val_f2_fg']):.8f}\nBest epoch: {self.best_epoch}\n")
        else:
            with self.metrics_txt_path.open("a",encoding="utf-8") as f: f.write("="*180+"\nFINALE EPOCHENAUSWAHL\n"+"="*180+"\nKeine gültige Epochenauswahl möglich.\nBest epoch: nicht verfügbar\n")
        save_training_plots(self.epoch_history,self.plot_dir); self._write_json("completed")
        print(f"\nMetrik-TXT:  {self.metrics_txt_path}\nMetrik-CSV:  {self.metrics_csv_path}\nMetrik-JSON: {self.metrics_json_path}\nPlots:       {self.plot_dir}")
        if self.best_epoch is not None: print(f"Beste Epoche nach Dice-F2-Idealpunkt-Distanz: {self.best_epoch} | D={self.best_selection_distance:.8f}")


# --- Main ---
def main():
    for directory in (RUN_DIR, MODEL_DIR, METRICS_DIR, PLOT_DIR, ARCH_DIR): directory.mkdir(parents=True, exist_ok=True)
    gpus=tf.config.list_physical_devices("GPU")
    if gpus:
        for gpu in gpus:
            try: tf.config.experimental.set_memory_growth(gpu,True)
            except RuntimeError as exc: print(f"Hinweis: GPU memory growth konnte nicht gesetzt werden: {exc}")
    environment_info=collect_environment_info()
    train_ds,train_count=get_dataset(TRAIN_SPLIT); val_ds,val_count=get_dataset(VAL_SPLIT); _test_ds,test_count=get_dataset(TEST_SPLIT)
    dataset_info={TRAIN_SPLIT:collect_split_info(TRAIN_SPLIT),VAL_SPLIT:collect_split_info(VAL_SPLIT),TEST_SPLIT:collect_split_info(TEST_SPLIT)}
    print(f"Seed:          {SEED}\nTrain samples: {train_count}\nVal samples:   {val_count}\nTest samples:  {test_count}\nVal batches:   {math.ceil(val_count/BATCH)}")
    images_per_epoch=STEPS_PER_EPOCH*BATCH; epochs_for_full_pass=train_count/images_per_epoch if images_per_epoch>0 else float("inf")
    print(f"Bilder pro Epoche (effektiv): {images_per_epoch}\nEpochen fuer ~1 kompletten Durchlauf durchs Train-Set: {epochs_for_full_pass:.2f}\nValidation steps pro Epoche: {VALIDATION_STEPS} -> {VALIDATION_STEPS*BATCH} Bilder")
    model=build_optimized_model(); architecture_info=export_architecture(model)
    run_metadata=build_run_metadata(environment_info,dataset_info,architecture_info); write_run_configuration_file(run_metadata)
    model.compile(optimizer=tf.keras.optimizers.Adam(learning_rate=LR),loss=dice_loss,metrics=[dice_coef_soft],jit_compile=False)
    metrics_logger=ValidationMetricsLogger(val_ds,VALIDATION_STEPS,LOG_FILE,CSV_FILE,JSON_FILE,run_metadata,THRESHOLD,PLOT_DIR)
    callbacks=[metrics_logger,
        tf.keras.callbacks.ModelCheckpoint(filepath=str(MODEL_DIR/f"{RUN_NAME}_Epoche{{epoch:02d}}.keras"),save_best_only=False,save_weights_only=False,verbose=1),
        tf.keras.callbacks.ModelCheckpoint(filepath=str(MODEL_DIR/f"{RUN_NAME}_best_checkpoint.keras"),monitor="val_dice_fg",mode="max",save_best_only=True,verbose=1),
        tf.keras.callbacks.ReduceLROnPlateau(monitor="val_dice_fg",mode="max",patience=10,factor=0.5,verbose=1),
        tf.keras.callbacks.EarlyStopping(monitor="val_dice_fg",mode="max",patience=25,restore_best_weights=True,verbose=1)]
    print(f"Start: Kurze Epochen mit {STEPS_PER_EPOCH} Schritten.")
    model.fit(train_ds,epochs=EPOCHS,steps_per_epoch=STEPS_PER_EPOCH,callbacks=callbacks,verbose=1)

if __name__ == "__main__": main()
