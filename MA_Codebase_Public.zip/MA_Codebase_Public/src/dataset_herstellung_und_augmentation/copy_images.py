import os
import shutil
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
from tqdm import tqdm

# =========================
# EINSTELLUNGEN
# =========================
INPUT_BASE = "/home/mitte/crack_project/datasets/Testset_for_coloring_differences/uncolored_set_20_hardnegatives"
OUTPUT_BASE = "/home/mitte/crack_project/datasets/Testset_for_coloring_differences/uncolored_set_30_hardnegatives"

# True  = Dateien verschieben
# False = Dateien kopieren
MOVE_FILES = False

# maximale Anzahl paralleler Threads
MAX_WORKERS = min(16, os.cpu_count() or 1)

# vorhandene Dateien im Ziel überschreiben?
OVERWRITE = False

# zu verarbeitende Ordner
SPLITS = ["train"] #"train", "val", "test"
TYPES = ["images", "masks"]


def prepare_target_folders(output_base: Path):
    for split in SPLITS:
        for folder_type in TYPES:
            target_dir = output_base / split / folder_type
            target_dir.mkdir(parents=True, exist_ok=True)


def collect_file_tasks(input_base: Path, output_base: Path):
    tasks = []

    for split in SPLITS:
        for folder_type in TYPES:
            src_dir = input_base / split / folder_type
            dst_dir = output_base / split / folder_type

            if not src_dir.exists():
                print(f"[WARN] Ordner nicht gefunden, überspringe: {src_dir}")
                continue

            if not src_dir.is_dir():
                print(f"[WARN] Kein Verzeichnis, überspringe: {src_dir}")
                continue

            for file_path in src_dir.iterdir():
                if file_path.is_file():
                    target_path = dst_dir / file_path.name
                    tasks.append((file_path, target_path))

    return tasks


def process_file(task):
    src, dst = task

    try:
        if dst.exists():
            if OVERWRITE:
                if dst.is_file():
                    dst.unlink()
                else:
                    return f"Übersprungen (Ziel ist keine Datei): {dst}"
            else:
                return f"Übersprungen (existiert schon): {dst}"

        dst.parent.mkdir(parents=True, exist_ok=True)

        if MOVE_FILES:
            shutil.move(str(src), str(dst))
            return f"Verschoben: {src} -> {dst}"
        else:
            shutil.copy2(src, dst)
            return f"Kopiert: {src} -> {dst}"

    except Exception as e:
        return f"Fehler bei {src}: {e}"


def main():
    input_base = Path(INPUT_BASE)
    output_base = Path(OUTPUT_BASE)

    if not input_base.exists():
        print(f"[FEHLER] Input-Pfad existiert nicht: {input_base}")
        return

    if not input_base.is_dir():
        print(f"[FEHLER] Input-Pfad ist kein Verzeichnis: {input_base}")
        return

    prepare_target_folders(output_base)
    tasks = collect_file_tasks(input_base, output_base)

    if not tasks:
        print("Keine Dateien gefunden.")
        return

    print(f"Gefundene Dateien: {len(tasks)}")
    print(f"Modus: {'Verschieben' if MOVE_FILES else 'Kopieren'}")
    print(f"MAX_WORKERS: {MAX_WORKERS}")

    results = []
    with ThreadPoolExecutor(max_workers=MAX_WORKERS) as executor:
        for result in tqdm(
            executor.map(process_file, tasks),
            total=len(tasks),
            desc="Verarbeite Dateien",
            unit="Datei"
        ):
            results.append(result)

    errors = [r for r in results if r.startswith("Fehler")]
    skipped = [r for r in results if r.startswith("Übersprungen")]
    success = len(results) - len(errors) - len(skipped)

    print("\n===== FERTIG =====")
    print(f"Erfolgreich: {success}")
    print(f"Übersprungen: {len(skipped)}")
    print(f"Fehler: {len(errors)}")

    if errors:
        print("\nEinige Fehler:")
        for err in errors[:10]:
            print(err)


if __name__ == "__main__":
    main()