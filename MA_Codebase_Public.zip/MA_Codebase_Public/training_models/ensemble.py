#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import os
from pathlib import Path
import cv2
import numpy as np
import tensorflow as tf


# ============================================================
# EINSTELLUNGEN
# ============================================================

RUN_NAME = "ensemble_test_01"

IMAGE_DIR = "/home/mitte/crack_project/test_image/6_Bilder_test"

CLASSIFIER_MODEL_PATH = "/home/mitte/crack_project/models/classifier_baseline/classifier_epoch_40.keras"
UNET_FINE_MODEL_PATH = "/home/mitte/crack_project/outputs/unetpp_baseline_dataset_dice_loss/models/unetpp_baseline_dataset_dice_loss_Epoche40.keras"
UNET_PRECISE_MODEL_PATH = "/home/mitte/crack_project/outputs/unetpp_better_dataset_filter_from128to256/models/unetpp_better_dataset_filter_from128to256_Epoche40.keras"

OUTPUT_BASE_DIR = f"/home/mitte/crack_project/ensemble_results/{RUN_NAME}"

PATCH_SIZE = 512
OVERLAP = 64
BATCH_SIZE = 8

# Classifier-Gate: darunter wird kein U-Net++ ausgeführt
CLASSIFIER_GATE_THRESHOLD = 0.10

# Dynamischer Pixel-Threshold
PIXEL_THRESHOLD_HIGH = 0.60
PIXEL_THRESHOLD_LOW = 0.35

# Gewichtung der beiden U-Net++ Modelle
# Modell fein: erkennt feine Risse besser, aber ungenauer
# Modell präzise: markiert genauer, aber übersieht feine Risse eher
FINE_BASE_WEIGHT = 0.25
FINE_EXTRA_WEIGHT = 0.35

# Overlay-Stärke
OVERLAY_ALPHA = 0.45

VALID_EXTENSIONS = [".jpg", ".jpeg", ".png", ".tif", ".tiff", ".bmp"]


# ============================================================
# HILFSFUNKTIONEN
# ============================================================

def load_image_rgb(path):
    img_bgr = cv2.imread(str(path), cv2.IMREAD_COLOR)
    if img_bgr is None:
        raise ValueError(f"Bild konnte nicht gelesen werden: {path}")
    return cv2.cvtColor(img_bgr, cv2.COLOR_BGR2RGB)


def preprocess_patch(patch, target_size):
    patch_resized = cv2.resize(patch, target_size, interpolation=cv2.INTER_AREA)
    patch_resized = patch_resized.astype(np.float32) / 255.0
    return patch_resized


def get_model_input_size(model):
    shape = model.input_shape

    if isinstance(shape, list):
        shape = shape[0]

    h = shape[1]
    w = shape[2]

    if h is None or w is None:
        return PATCH_SIZE, PATCH_SIZE

    return int(w), int(h)


def extract_patches(image, patch_size, overlap):
    h, w, _ = image.shape
    stride = patch_size - overlap

    patches = []
    positions = []

    y_positions = list(range(0, max(h - patch_size + 1, 1), stride))
    x_positions = list(range(0, max(w - patch_size + 1, 1), stride))

    if len(y_positions) == 0 or y_positions[-1] != h - patch_size:
        y_positions.append(max(h - patch_size, 0))

    if len(x_positions) == 0 or x_positions[-1] != w - patch_size:
        x_positions.append(max(w - patch_size, 0))

    for y in y_positions:
        for x in x_positions:
            patch = image[y:y + patch_size, x:x + patch_size]

            ph, pw = patch.shape[:2]

            if ph < patch_size or pw < patch_size:
                padded = np.zeros((patch_size, patch_size, 3), dtype=image.dtype)
                padded[:ph, :pw] = patch
                patch = padded

            patches.append(patch)
            positions.append((x, y, pw, ph))

    return patches, positions


def predict_classifier(model, patches, input_size, batch_size):
    probs = []

    for i in range(0, len(patches), batch_size):
        batch = patches[i:i + batch_size]
        batch_input = np.array(
            [preprocess_patch(p, input_size) for p in batch],
            dtype=np.float32
        )

        pred = model.predict(batch_input, verbose=0)

        pred = np.array(pred)

        if pred.ndim == 2 and pred.shape[1] > 1:
            batch_probs = pred[:, 1]
        else:
            batch_probs = pred.reshape(-1)

        probs.extend(batch_probs.tolist())

    return np.array(probs, dtype=np.float32)


def predict_unet(model, patches, input_size, batch_size):
    outputs = []

    for i in range(0, len(patches), batch_size):
        batch = patches[i:i + batch_size]
        batch_input = np.array(
            [preprocess_patch(p, input_size) for p in batch],
            dtype=np.float32
        )

        pred = model.predict(batch_input, verbose=0)
        pred = np.array(pred)

        if pred.ndim == 4:
            pred = pred[..., 0]

        for p in pred:
            p = cv2.resize(
                p,
                (PATCH_SIZE, PATCH_SIZE),
                interpolation=cv2.INTER_LINEAR
            )
            outputs.append(p.astype(np.float32))

    return outputs


def stitch_predictions(pred_patches, positions, image_shape):
    h, w = image_shape[:2]

    prob_sum = np.zeros((h, w), dtype=np.float32)
    weight_sum = np.zeros((h, w), dtype=np.float32)

    for pred, (x, y, pw, ph) in zip(pred_patches, positions):
        pred_crop = pred[:ph, :pw]

        prob_sum[y:y + ph, x:x + pw] += pred_crop
        weight_sum[y:y + ph, x:x + pw] += 1.0

    weight_sum[weight_sum == 0] = 1.0
    return prob_sum / weight_sum


def create_classifier_patch_map(classifier_probs, positions, image_shape):
    h, w = image_shape[:2]

    prob_sum = np.zeros((h, w), dtype=np.float32)
    weight_sum = np.zeros((h, w), dtype=np.float32)

    for prob, (x, y, pw, ph) in zip(classifier_probs, positions):
        prob_sum[y:y + ph, x:x + pw] += prob
        weight_sum[y:y + ph, x:x + pw] += 1.0

    weight_sum[weight_sum == 0] = 1.0
    return prob_sum / weight_sum


def apply_colormap(prob_map):
    prob_uint8 = np.clip(prob_map * 255, 0, 255).astype(np.uint8)
    heatmap_bgr = cv2.applyColorMap(prob_uint8, cv2.COLORMAP_JET)
    heatmap_rgb = cv2.cvtColor(heatmap_bgr, cv2.COLOR_BGR2RGB)
    return heatmap_rgb


def create_overlay(image_rgb, mask_or_heatmap, alpha=0.45):
    overlay = cv2.addWeighted(
        image_rgb.astype(np.uint8),
        1.0 - alpha,
        mask_or_heatmap.astype(np.uint8),
        alpha,
        0
    )
    return overlay


def create_binary_overlay(image_rgb, binary_mask, alpha=0.45):
    red_mask = np.zeros_like(image_rgb, dtype=np.uint8)
    red_mask[..., 0] = 255

    mask_3c = np.stack([binary_mask] * 3, axis=-1).astype(bool)

    overlay = image_rgb.copy()
    blended = cv2.addWeighted(image_rgb, 1.0 - alpha, red_mask, alpha, 0)

    overlay[mask_3c] = blended[mask_3c]
    return overlay


def save_rgb(path, image_rgb):
    path = str(path)
    image_bgr = cv2.cvtColor(image_rgb.astype(np.uint8), cv2.COLOR_RGB2BGR)
    cv2.imwrite(path, image_bgr)


def save_gray(path, image):
    image_uint8 = np.clip(image * 255, 0, 255).astype(np.uint8)
    cv2.imwrite(str(path), image_uint8)


# ============================================================
# ENSEMBLE-FUSION
# ============================================================

def ensemble_fusion(prob_fine, prob_precise, classifier_patch_map):
    fine_weight = FINE_BASE_WEIGHT + FINE_EXTRA_WEIGHT * classifier_patch_map
    fine_weight = np.clip(fine_weight, 0.0, 1.0)

    precise_weight = 1.0 - fine_weight

    final_prob = fine_weight * prob_fine + precise_weight * prob_precise

    dynamic_threshold = (
        PIXEL_THRESHOLD_HIGH
        - (PIXEL_THRESHOLD_HIGH - PIXEL_THRESHOLD_LOW) * classifier_patch_map
    )

    binary_mask = final_prob >= dynamic_threshold

    return final_prob, binary_mask.astype(np.uint8), dynamic_threshold


# ============================================================
# HAUPTVERARBEITUNG PRO BILD
# ============================================================

def process_image(
    image_path,
    classifier_model,
    unet_fine_model,
    unet_precise_model,
    classifier_input_size,
    unet_fine_input_size,
    unet_precise_input_size
):
    image_path = Path(image_path)
    image_rgb = load_image_rgb(image_path)

    image_name = image_path.stem
    output_dir = Path(OUTPUT_BASE_DIR) / image_name
    output_dir.mkdir(parents=True, exist_ok=True)

    patches, positions = extract_patches(image_rgb, PATCH_SIZE, OVERLAP)

    classifier_probs = predict_classifier(
        classifier_model,
        patches,
        classifier_input_size,
        BATCH_SIZE
    )

    classifier_patch_map = create_classifier_patch_map(
        classifier_probs,
        positions,
        image_rgb.shape
    )

    active_indices = np.where(classifier_probs >= CLASSIFIER_GATE_THRESHOLD)[0]

    fine_pred_patches = [
        np.zeros((PATCH_SIZE, PATCH_SIZE), dtype=np.float32)
        for _ in patches
    ]

    precise_pred_patches = [
        np.zeros((PATCH_SIZE, PATCH_SIZE), dtype=np.float32)
        for _ in patches
    ]

    if len(active_indices) > 0:
        active_patches = [patches[i] for i in active_indices]

        fine_outputs = predict_unet(
            unet_fine_model,
            active_patches,
            unet_fine_input_size,
            BATCH_SIZE
        )

        precise_outputs = predict_unet(
            unet_precise_model,
            active_patches,
            unet_precise_input_size,
            BATCH_SIZE
        )

        for idx, fine_pred, precise_pred in zip(
            active_indices,
            fine_outputs,
            precise_outputs
        ):
            fine_pred_patches[idx] = fine_pred
            precise_pred_patches[idx] = precise_pred

    prob_fine = stitch_predictions(
        fine_pred_patches,
        positions,
        image_rgb.shape
    )

    prob_precise = stitch_predictions(
        precise_pred_patches,
        positions,
        image_rgb.shape
    )

    final_prob, binary_mask, dynamic_threshold = ensemble_fusion(
        prob_fine,
        prob_precise,
        classifier_patch_map
    )

    classifier_heatmap = apply_colormap(classifier_patch_map)
    classifier_overlay = create_overlay(
        image_rgb,
        classifier_heatmap,
        alpha=OVERLAY_ALPHA
    )

    pixel_heatmap = apply_colormap(final_prob)

    segmentation_overlay = create_binary_overlay(
        image_rgb,
        binary_mask,
        alpha=OVERLAY_ALPHA
    )

    save_rgb(output_dir / "01_classifier_patch_probability_overlay.png", classifier_overlay)
    save_gray(output_dir / "02_binary_mask.png", binary_mask)
    save_rgb(output_dir / "03_pixel_probability_heatmap.png", pixel_heatmap)
    save_rgb(output_dir / "04_segmentation_overlay.png", segmentation_overlay)

    save_gray(output_dir / "05_classifier_patch_probability_map.png", classifier_patch_map)
    save_gray(output_dir / "06_final_probability_map.png", final_prob)
    save_gray(output_dir / "07_dynamic_threshold_map.png", dynamic_threshold)

    print(f"[OK] {image_path.name}")
    print(f"     aktive Patches: {len(active_indices)} / {len(patches)}")
    print(f"     max classifier prob: {classifier_probs.max():.3f}")
    print(f"     max pixel prob: {final_prob.max():.3f}")
    print(f"     output: {output_dir}")


# ============================================================
# MAIN
# ============================================================

def main():
    print("Lade Modelle...")

    classifier_model = tf.keras.models.load_model(
        CLASSIFIER_MODEL_PATH,
        compile=False,
        safe_mode=False
    )

    unet_fine_model = tf.keras.models.load_model(
        UNET_FINE_MODEL_PATH,
        compile=False
    )

    unet_precise_model = tf.keras.models.load_model(
        UNET_PRECISE_MODEL_PATH,
        compile=False
    )

    classifier_input_size = get_model_input_size(classifier_model)
    unet_fine_input_size = get_model_input_size(unet_fine_model)
    unet_precise_input_size = get_model_input_size(unet_precise_model)

    print(f"Classifier Input Size: {classifier_input_size}")
    print(f"U-Net++ fein Input Size: {unet_fine_input_size}")
    print(f"U-Net++ präzise Input Size: {unet_precise_input_size}")

    image_dir = Path(IMAGE_DIR)

    image_paths = [
        p for p in image_dir.iterdir()
        if p.suffix.lower() in VALID_EXTENSIONS
    ]

    if len(image_paths) == 0:
        raise ValueError(f"Keine Bilder gefunden in: {IMAGE_DIR}")

    Path(OUTPUT_BASE_DIR).mkdir(parents=True, exist_ok=True)

    print(f"Gefundene Bilder: {len(image_paths)}")
    print(f"Output: {OUTPUT_BASE_DIR}")

    for image_path in image_paths:
        process_image(
            image_path=image_path,
            classifier_model=classifier_model,
            unet_fine_model=unet_fine_model,
            unet_precise_model=unet_precise_model,
            classifier_input_size=classifier_input_size,
            unet_fine_input_size=unet_fine_input_size,
            unet_precise_input_size=unet_precise_input_size
        )


if __name__ == "__main__":
    main()