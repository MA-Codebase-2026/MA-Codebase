#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Gemeinsame Sample-Test-Auswertung fuer Crack-Segmentierungsmodelle.

Funktionen:
- EVALUATION_MODE = "all": alle Trainingslaeufe unter OUTPUT_ROOT pruefen.
- EVALUATION_MODE = "models": nur die unter MODEL_PATHS eingetragenen Modelle pruefen.
- Die beste Epoche wird bevorzugt aus metrics/*.json (best_epoch) gelesen;
  metrics/*.txt ("Best epoch: N") dient als robuster Fallback.
- Ein Modell wird anhand seines Dateinamens (case-insensitive, ohne Endung)
  nur einmal ausgewertet, auch ueber mehrere Programmstarts hinweg.
- Ausgewertet wird ausschliesslich die BALANCED CRACK ROI des Threshold-Sweeps:
  alle GT-Risspixel plus gleich viele gesampelte negative Pixel, bevorzugt
  aus dem rissnahen Ring.
- Pro neu bewertetem Modell werden
  RUNNAME_EpocheN_sample_test_metrics.txt und .json geschrieben.
- Die globale All-Models-Datei wird aus ALLEN jemals erfolgreich gespeicherten
  Einzel-JSONs neu aufgebaut.
- Threshold: "ROI minimaler Balanced Error" aus threshold_results2/*.txt.
- Ranking: D = sqrt(0.5*(1-Dice)^2 + 0.5*(1-F2)^2); kleiner ist besser.
- Beschleunigter direkter tf.function/XLA-Inferenzpfad analog zum Threshold-Sweep.
"""

from __future__ import annotations

import csv
import gc
import json
import os
import random
import re
from datetime import datetime
from pathlib import Path

import cv2
import numpy as np
import tensorflow as tf
from keras import mixed_precision

# ============================================================
# EINSTELLUNGEN
# ============================================================

OUTPUT_ROOT = Path("/home/mitte/crack_project/outputs")
TEST_DATASET_DIR = Path("/home/mitte/crack_project/datasets/better_dataset_evtl")
EVALUATION_BASE_DIR = Path("/home/mitte/crack_project/modellmetrics_of_best_epoche_on_testdataset")
EVALUATION_SCOPE = "sample_balanced_crack_roi"
EVALUATION_REGION = "balanced_crack_roi_sample"
EVALUATION_DIR = EVALUATION_BASE_DIR / EVALUATION_SCOPE

# Alte Sample-Ergebnisse aus dem frueher gemeinsam genutzten Ordner duerfen
# optional weiterverwendet werden. Es werden ausschliesslich eindeutig als
# Sample-Dateien erkennbare *_sample_test_metrics.json akzeptiert.
LOAD_LEGACY_COMPATIBLE_RESULTS = True

# ------------------------------------------------------------
# WAS SOLL GETESTET WERDEN?
# ------------------------------------------------------------
# "all"    = alle Trainingslaeufe unter OUTPUT_ROOT. Pro Run wird automatisch
#            das Modell der besten Epoche ermittelt.
# "models" = nur die unten in MODEL_PATHS eingetragenen konkreten Modellpfade.
EVALUATION_MODE = "all"

# Nur relevant bei EVALUATION_MODE = "models".
# Beliebig viele Modelle eintragen, z.B.:
# MODEL_PATHS = [
#     Path("/home/mitte/crack_project/outputs/run_a/models/run_a_Epoche16.keras"),
#     Path("/home/mitte/crack_project/outputs/run_b/models/run_b_Epoche22.keras"),
# ]
MODEL_PATHS = [
    # Path("/home/mitte/crack_project/outputs/DEIN_RUN/models/DEIN_MODELL.keras"),
]

# False = bereits erfolgreich getestete Modelle anhand des Modellnamens überspringen.
# True  = die ausgewählten Modelle absichtlich erneut testen.
FORCE_REEVALUATE = False

INCLUDE_HARD_NEGATIVES = False
DEFAULT_BATCH_SIZE = 8
BATCH_SIZE_1024 = 2
SEED = 42
TEST_STEPS = None  # None = komplettes Testset; Integer = maximal so viele Batches
MODEL_SUFFIXES = {".keras", ".h5", ".hdf5"}

# Metrik-Raster wie im bisherigen All-Models-Skript.
AP_THRESHOLDS = np.linspace(1.0, 0.0, 101, dtype=np.float64)

# Fallbacks entsprechend dem Threshold-Sweep. Wenn die Werte in dessen
# Ergebnisdateien protokolliert sind, werden die run-spezifischen Werte genutzt.
ROI_RING_RADIUS_PX = 10
ROI_NEGATIVE_TO_POSITIVE_RATIO = 1.0
ROI_RANDOM_SEED = 42

# Speed-Optionen analog Threshold-Sweep.
XLA_JIT = True
MIXED_PRECISION_POLICY = "mixed_float16"

# ============================================================
# TENSORFLOW / REPRODUZIERBARKEIT
# ============================================================

os.environ.setdefault("PYTHONHASHSEED", str(SEED))
os.environ.setdefault("TF_GPU_ALLOCATOR", "cuda_malloc_async")
os.environ.setdefault("TF_FORCE_GPU_ALLOW_GROWTH", "true")
os.environ.setdefault("KERAS_BACKEND", "tensorflow")

random.seed(SEED)
np.random.seed(SEED)
tf.random.set_seed(SEED)

tf.config.optimizer.set_jit("autoclustering" if XLA_JIT else False)
mixed_precision.set_global_policy(MIXED_PRECISION_POLICY)

EPS = 1e-7


# ============================================================
# OPTIONALES CUSTOM OBJECT (wie Threshold-Sweep)
# ============================================================

@tf.keras.utils.register_keras_serializable(package="crack_segmentation")
class AddPositionEmbedding(tf.keras.layers.Layer):
    def __init__(self, num_tokens, embed_dim, **kwargs):
        super().__init__(**kwargs)
        self.num_tokens = int(num_tokens)
        self.embed_dim = int(embed_dim)

    def build(self, input_shape):
        self.pos_embedding = self.add_weight(
            name="pos_embedding",
            shape=(1, self.num_tokens, self.embed_dim),
            initializer="random_normal",
            trainable=True,
            dtype=self.dtype,
        )
        super().build(input_shape)

    def call(self, x):
        return x + tf.cast(self.pos_embedding, x.dtype)

    def get_config(self):
        config = super().get_config()
        config.update({"num_tokens": self.num_tokens, "embed_dim": self.embed_dim})
        return config


CUSTOM_OBJECTS = {
    "AddPositionEmbedding": AddPositionEmbedding,
    "crack_segmentation>AddPositionEmbedding": AddPositionEmbedding,
}


# ============================================================
# HILFSFUNKTIONEN
# ============================================================

def safe_float(value, default=float("nan")):
    try:
        return float(value)
    except (TypeError, ValueError):
        return default


def safe_div(num, den):
    return float(num / (den + EPS))


def is_finite_number(value) -> bool:
    try:
        return bool(np.isfinite(float(value)))
    except (TypeError, ValueError):
        return False


def round_for_output(value):
    """Rundet Floats fuer TXT/CSV/JSON einheitlich auf 6 Nachkommastellen."""
    if isinstance(value, (float, np.floating)):
        if not np.isfinite(value):
            return None
        return round(float(value), 6)
    if isinstance(value, (np.integer,)):
        return int(value)
    return value


def extract_val_dice_from_json(data, best_epoch: int) -> float:
    """Findet ValDice auch bei abweichenden/nesteten JSON-Strukturen robust."""
    preferred_keys = {
        'best_val_dice_fg', 'best_val_dice', 'val_dice', 'val_dice_fg',
        'best_validation_dice', 'validation_dice', 'val_dice_coef',
        'best_val_dice_coef', 'val_dice_coefficient', 'best_val_dice_coefficient',
    }

    # 1) Rekursiv nach expliziten Best-/ValDice-Skalarwerten suchen.
    def walk(obj):
        if isinstance(obj, dict):
            for key, value in obj.items():
                k = str(key).strip().casefold()
                if k in preferred_keys and not isinstance(value, (dict, list, tuple)):
                    v = safe_float(value)
                    if is_finite_number(v):
                        return v
            for value in obj.values():
                found = walk(value)
                if is_finite_number(found):
                    return found
        return float('nan')

    found = walk(data)
    if is_finite_number(found):
        return found

    # 2) History-Arrays: Wert der BestEpoch verwenden (Epoch 1 -> Index 0).
    history_keys = {
        'val_dice', 'val_dice_fg', 'val_dice_coef', 'val_dice_coefficient',
        'validation_dice', 'validation_dice_fg',
    }
    idx = max(0, int(best_epoch) - 1)

    def walk_history(obj):
        if isinstance(obj, dict):
            for key, value in obj.items():
                if str(key).strip().casefold() in history_keys and isinstance(value, (list, tuple)):
                    if idx < len(value):
                        v = safe_float(value[idx])
                        if is_finite_number(v):
                            return v
            for value in obj.values():
                found = walk_history(value)
                if is_finite_number(found):
                    return found
        return float('nan')

    return walk_history(data)


def extract_val_dice_from_text(text: str, best_epoch: int) -> float:
    """Liest ValDice aus Metrics-TXT mit mehreren gaengigen Schreibweisen."""
    scalar_patterns = [
        r'^\s*Best\s*val[_ \-]?dice(?:[_ \-]?fg|[_ \-]?coef(?:ficient)?)?\s*[:=]\s*([0-9.eE+-]+)',
        r'^\s*Val(?:idation)?[_ \-]?Dice(?:[_ \-]?fg|[_ \-]?coef(?:ficient)?)?\s*[:=]\s*([0-9.eE+-]+)',
        r'^\s*best_val_dice_fg\s*[:=]\s*([0-9.eE+-]+)',
    ]
    for pattern in scalar_patterns:
        m = re.search(pattern, text, re.I | re.M)
        if m:
            v = safe_float(m.group(1))
            if is_finite_number(v):
                return v

    # Epochenzeile, z.B. "Epoch 16 ... val_dice_fg: 0.91".
    epoch_pattern = re.compile(
        rf'^.*(?:Epoch|Epoche)\s*[:#-]?\s*0*{int(best_epoch)}\b.*$', re.I | re.M
    )
    for em in epoch_pattern.finditer(text):
        line = em.group(0)
        vm = re.search(
            r'val(?:idation)?[_ \-]?dice(?:[_ \-]?fg|[_ \-]?coef(?:ficient)?)?\s*[:=]\s*([0-9.eE+-]+)',
            line, re.I
        )
        if vm:
            v = safe_float(vm.group(1))
            if is_finite_number(v):
                return v
    return float('nan')


def model_identity(model_path: Path) -> str:
    """Deduplizierung ausschliesslich anhand des Modellnamens, ohne Dateiendung."""
    return model_path.stem.strip().casefold()


def result_basename(model_path: Path) -> str:
    name = re.sub(r"[^A-Za-z0-9._-]+", "_", model_path.stem).strip("._")
    return name or "model"


def resolve_run_dir_from_model(model_path: Path) -> Path:
    """Erwartet typischerweise <run>/models/model.keras; faellt robust zurueck."""
    model_path = model_path.expanduser().resolve()
    if model_path.parent.name.lower() == "models":
        return model_path.parent.parent
    for parent in model_path.parents:
        if (parent / "metrics").is_dir() or (parent / "threshold_results2").is_dir():
            return parent
    raise ValueError(
        f"Trainingslauf zu Modell konnte nicht ermittelt werden: {model_path}. "
        "Erwartet wird normalerweise <run>/models/<modell>.keras."
    )


def find_txt_containing(folder: Path, pattern: str) -> Path | None:
    if not folder.is_dir():
        return None
    rx = re.compile(pattern, re.IGNORECASE | re.MULTILINE)
    for path in sorted(folder.glob("*.txt")):
        try:
            if rx.search(path.read_text(encoding="utf-8", errors="replace")):
                return path
        except OSError:
            pass
    return None


# ============================================================
# METRICS / THRESHOLD METADATEN
# ============================================================

def read_metrics_config(run_dir: Path) -> dict:
    """
    Liest BestEpoch bevorzugt strukturiert aus JSON. ValDice wird unabhaengig
    davon aus JSON UND TXT gesucht, damit unterschiedliche Logger-Versionen
    keine ``nan``-Werte verursachen.
    """
    metrics_dir = run_dir / "metrics"
    if not metrics_dir.is_dir():
        raise FileNotFoundError(f"Metrics-Ordner fehlt: {metrics_dir}")

    best_epoch = None
    epoch_source = None
    json_candidates = []

    # 1) BestEpoch bevorzugt aus JSON.
    for json_path in sorted(metrics_dir.glob("*.json")):
        try:
            data = json.loads(json_path.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError):
            continue
        json_candidates.append((json_path, data))
        if best_epoch is None and data.get("best_epoch") is not None:
            try:
                best_epoch = int(data["best_epoch"])
                epoch_source = json_path
            except (TypeError, ValueError):
                pass

    # 2) Falls notwendig BestEpoch aus beliebiger Metrics-TXT.
    txt_candidates = []
    for txt_path in sorted(metrics_dir.glob("*.txt")):
        try:
            text = txt_path.read_text(encoding="utf-8", errors="replace")
        except OSError:
            continue
        txt_candidates.append((txt_path, text))
        if best_epoch is None:
            m = re.search(r"^\s*Best\s*epoch\s*:\s*(\d+)\s*$", text, re.I | re.M)
            if m:
                best_epoch = int(m.group(1))
                epoch_source = txt_path

    if best_epoch is None:
        raise FileNotFoundError(
            f"Weder metrics-JSON mit 'best_epoch' noch Metrics-TXT mit "
            f"'Best epoch: ...' in {metrics_dir} gefunden."
        )

    # ValDice zuerst in allen JSONs, danach in allen TXTs suchen.
    val_dice = float("nan")
    val_source = None
    for json_path, data in json_candidates:
        val_dice = extract_val_dice_from_json(data, best_epoch)
        if is_finite_number(val_dice):
            val_source = json_path
            break

    if not is_finite_number(val_dice):
        for txt_path, text in txt_candidates:
            val_dice = extract_val_dice_from_text(text, best_epoch)
            if is_finite_number(val_dice):
                val_source = txt_path
                break

    if not is_finite_number(val_dice):
        print(f"[WARNUNG] ValDice konnte fuer {run_dir.name} trotz JSON/TXT-Fallback nicht gefunden werden.")

    return {
        "best_epoch": int(best_epoch),
        "best_val_dice_fg": val_dice,
        "metrics_file": epoch_source,
        "val_dice_file": val_source,
        "metrics_source": "json" if epoch_source and epoch_source.suffix.lower() == '.json' else "txt_fallback",
    }

def find_threshold_txt(run_dir: Path) -> Path:
    threshold_dir = run_dir / "threshold_results2"
    txt_path = find_txt_containing(
        threshold_dir,
        r"ROI\s+minimaler\s+Balanced\s+Error\s*:\s*Threshold\s*=",
    )
    if txt_path is None:
        raise FileNotFoundError(
            f"Keine Threshold-TXT mit 'ROI minimaler Balanced Error' in {threshold_dir} gefunden."
        )
    return txt_path


def read_threshold_config(run_dir: Path) -> dict:
    txt_path = find_threshold_txt(run_dir)
    text = txt_path.read_text(encoding="utf-8", errors="replace")

    # Exakt die Empfehlung unter FINALE THRESHOLD-EMPFEHLUNGEN / ROI minimaler BalError.
    threshold_match = re.search(
        r"ROI\s+minimaler\s+Balanced\s+Error\s*:\s*"
        r"Threshold\s*=\s*([0-9.eE+-]+)",
        text,
        re.I,
    )
    if threshold_match is None:
        raise ValueError(f"ROI-Balanced-Error-Threshold konnte aus {txt_path} nicht gelesen werden.")
    threshold = float(threshold_match.group(1))
    if not 0.0 <= threshold <= 1.0:
        raise ValueError(f"Ungueltiger Threshold {threshold} in {txt_path}.")

    size_match = re.search(
        r"IMG(?:AGE)?[_ ]?SIZE\s*[:=]\s*(256|512|1024)", text, re.I
    )
    img_size = int(size_match.group(1)) if size_match else None

    radius_match = re.search(r"Ringradius\s*:\s*(\d+)\s*px", text, re.I)
    ratio_match = re.search(
        r"Ziel\s+N_neg/N_pos\s*:\s*([0-9.eE+-]+)", text, re.I
    )
    roi_ring_radius_px = (
        int(radius_match.group(1)) if radius_match else ROI_RING_RADIUS_PX
    )
    roi_negative_to_positive_ratio = (
        float(ratio_match.group(1))
        if ratio_match
        else ROI_NEGATIVE_TO_POSITIVE_RATIO
    )
    roi_random_seed = ROI_RANDOM_SEED

    # Der Threshold-Sweep protokolliert den Seed in einer separaten Sampling-CSV.
    for stats_path in sorted(
        (run_dir / "threshold_results2").glob("*_balanced_crack_roi_sampling_stats.csv")
    ):
        try:
            with stats_path.open("r", encoding="utf-8", newline="") as file:
                values = {
                    str(row.get("metric", "")).strip(): str(row.get("value", "")).strip()
                    for row in csv.DictReader(file)
                }
            if "ring_radius_px" in values:
                roi_ring_radius_px = int(float(values["ring_radius_px"]))
            if "negative_to_positive_ratio" in values:
                roi_negative_to_positive_ratio = float(
                    values["negative_to_positive_ratio"]
                )
            if "random_seed" in values:
                roi_random_seed = int(float(values["random_seed"]))
            break
        except (OSError, TypeError, ValueError):
            continue

    if roi_ring_radius_px < 0:
        raise ValueError(f"Ungueltiger ROI-Ringradius: {roi_ring_radius_px}")
    if roi_negative_to_positive_ratio < 0.0:
        raise ValueError(
            "Ungueltiges ROI-Negativverhaeltnis: "
            f"{roi_negative_to_positive_ratio}"
        )

    return {
        "threshold": threshold,
        "img_size": img_size,
        "threshold_file": txt_path,
        "roi_ring_radius_px": roi_ring_radius_px,
        "roi_negative_to_positive_ratio": roi_negative_to_positive_ratio,
        "roi_random_seed": roi_random_seed,
    }


def find_model_for_epoch(models_dir: Path, best_epoch: int) -> Path | None:
    if not models_dir.is_dir():
        return None
    candidates = [
        p for p in sorted(models_dir.iterdir())
        if p.is_file() and p.suffix.lower() in MODEL_SUFFIXES
    ]
    if not candidates:
        return None

    # Zahlenbegrenzung verhindert z.B. Epoche1 -> Epoche10.
    rx = re.compile(rf"(?:epoche|epoch)[_ -]*0*{best_epoch}(?!\d)", re.I)
    matches = [p for p in candidates if rx.search(p.stem)]
    return matches[0] if matches else None


def infer_model_img_size(model) -> int:
    shape = model.input_shape
    if isinstance(shape, list):
        if len(shape) != 1:
            raise ValueError(f"Mehrere Modelleingaenge nicht unterstuetzt: {shape}")
        shape = shape[0]
    if len(shape) != 4 or shape[1] is None or shape[2] is None or shape[1] != shape[2]:
        raise ValueError(f"IMG_SIZE konnte nicht robust aus Modellinput ermittelt werden: {shape}")
    return int(shape[1])


def make_run_record(model_path: Path, exact_model: bool) -> dict:
    model_path = model_path.expanduser().resolve()
    if not model_path.is_file() or model_path.suffix.lower() not in MODEL_SUFFIXES:
        raise FileNotFoundError(f"Kein gueltiger Modellpfad: {model_path}")

    run_dir = resolve_run_dir_from_model(model_path)
    metrics = read_metrics_config(run_dir)
    threshold = read_threshold_config(run_dir)

    if exact_model:
        chosen_model = model_path
    else:
        chosen_model = find_model_for_epoch(run_dir / "models", metrics["best_epoch"])
        if chosen_model is None:
            raise FileNotFoundError(
                f"Kein Modell fuer Best epoch {metrics['best_epoch']} in {run_dir / 'models'} gefunden."
            )

    return {
        "run_name": run_dir.name,
        "run_dir": run_dir,
        "model_path": chosen_model.resolve(),
        "model_name": chosen_model.name,
        "model_id": model_identity(chosen_model),
        **metrics,
        **threshold,
    }


def find_all_runs() -> list[dict]:
    if not OUTPUT_ROOT.is_dir():
        raise FileNotFoundError(f"OUTPUT_ROOT existiert nicht: {OUTPUT_ROOT}")

    records = []
    seen_model_ids = set()
    for run_dir in sorted(OUTPUT_ROOT.iterdir()):
        if not run_dir.is_dir() or run_dir.name.startswith("_"):
            continue
        try:
            metrics = read_metrics_config(run_dir)
            model_path = find_model_for_epoch(run_dir / "models", metrics["best_epoch"])
            if model_path is None:
                continue
            record = make_run_record(model_path, exact_model=False)
            if record["model_id"] in seen_model_ids:
                print(f"[DUPLIKAT UEBERSPRUNGEN] {record['model_name']}")
                continue
            seen_model_ids.add(record["model_id"])
            records.append(record)
        except Exception as exc:
            print(f"[UEBERSPRUNGEN] {run_dir.name}: {exc}")
    return records


# ============================================================
# TEST-DATEN
# ============================================================

def get_valid_pairs(images_dir: Path, masks_dir: Path):
    if not images_dir.is_dir() or not masks_dir.is_dir():
        return [], []
    imgs = sorted(p for p in images_dir.iterdir() if p.is_file() and not p.name.startswith("."))
    masks = {
        p.stem.casefold(): p
        for p in masks_dir.iterdir()
        if p.is_file() and not p.name.startswith(".")
    }
    valid_imgs, valid_masks = [], []
    for img in imgs:
        mask = masks.get(img.stem.casefold())
        if mask is not None:
            valid_imgs.append(str(img))
            valid_masks.append(str(mask))
    return valid_imgs, valid_masks


def load_and_preprocess(img_path, mask_path, img_size: int):
    img = tf.io.read_file(img_path)
    img = tf.image.decode_image(img, channels=3, expand_animations=False)
    img = tf.image.convert_image_dtype(img, tf.float32)
    img = tf.image.resize(img, [img_size, img_size], method="bilinear", antialias=True)
    img.set_shape([img_size, img_size, 3])

    mask = tf.io.read_file(mask_path)
    mask = tf.image.decode_image(mask, channels=1, expand_animations=False)
    mask = tf.image.resize(mask, [img_size, img_size], method="nearest")
    mask = tf.cast(mask > 127, tf.float32) if mask.dtype.is_integer else tf.cast(mask > 0.5, tf.float32)
    mask.set_shape([img_size, img_size, 1])
    return img, mask


def get_test_dataset(img_size: int, batch_size: int):
    split_name = f"test_{img_size}"
    base = TEST_DATASET_DIR / split_name
    images, masks = get_valid_pairs(base / "images", base / "masks")

    if INCLUDE_HARD_NEGATIVES:
        hni, hnm = get_valid_pairs(
            base / f"images_{img_size}px_hard_negatives",
            base / f"masks_{img_size}px_hard_negatives",
        )
        images.extend(hni)
        masks.extend(hnm)

    if not images:
        raise RuntimeError(f"Keine Bild-Masken-Paare in {base} gefunden.")

    def loader(i, m):
        return load_and_preprocess(i, m, img_size)

    ds = tf.data.Dataset.from_tensor_slices((images, masks))
    options = tf.data.Options()
    # Feste Bildreihenfolge ist wichtig, damit der seeded ROI-Zufallsgenerator
    # fuer jedes Modell exakt dieselben Samplepositionen erzeugt.
    options.experimental_deterministic = True
    ds = ds.with_options(options)
    ds = ds.map(loader, num_parallel_calls=tf.data.AUTOTUNE)
    ds = ds.batch(batch_size, drop_remainder=False)
    ds = ds.prefetch(tf.data.AUTOTUNE)
    return ds, len(images), split_name


# ============================================================
# SCHNELLE METRIKEN
# ============================================================

def build_inference_function(model, jit_compile=True):
    @tf.function(jit_compile=jit_compile, reduce_retracing=True)
    def infer(images):
        return model(images, training=False)
    return infer


def ensure_prediction_tensor(preds, masks):
    if isinstance(preds, (list, tuple)):
        preds = preds[0]
    preds = tf.cast(preds, tf.float32)
    if preds.shape.rank == 3:
        preds = preds[..., tf.newaxis]
    if preds.shape.rank != 4:
        raise ValueError(f"Unerwartete Prediction-Shape: {preds.shape}")
    if preds.shape[-1] != 1:
        preds = preds[..., :1]
    if preds.shape[1:3] != masks.shape[1:3]:
        preds = tf.image.resize(preds, tf.shape(masks)[1:3], method="bilinear")
    return preds


def confusion_counts_for_thresholds(y_true_flat, y_prob_flat, thresholds):
    """Wie Threshold-Sweep: pro Batch sortieren + searchsorted statt Threshold-Schleifen."""
    y_true_bool = y_true_flat.astype(bool, copy=False)
    probs = y_prob_flat.astype(np.float32, copy=False)
    pos = np.sort(probs[y_true_bool])
    neg = np.sort(probs[~y_true_bool])
    thresholds = np.asarray(thresholds, dtype=np.float64)
    tp = pos.size - np.searchsorted(pos, thresholds, side="left")
    fp = neg.size - np.searchsorted(neg, thresholds, side="left")
    fn = pos.size - tp
    tn = neg.size - fp
    return tp, fp, fn, tn


def compute_ap_from_threshold_confusions(tp, fp, fn):
    total_pos = float(np.max(tp + fn)) if len(tp) else 0.0
    if total_pos <= 0:
        return float("nan")
    pred_pos = tp + fp
    precision = np.divide(tp, pred_pos, out=np.ones_like(tp, dtype=np.float64), where=pred_pos > 0)
    recall = tp / total_pos
    order = np.argsort(recall)
    recall = recall[order]
    precision = precision[order]
    recall = np.concatenate(([0.0], recall, [1.0]))
    precision = np.concatenate(([precision[0] if precision.size else 0.0], precision, [0.0]))
    for i in range(len(precision) - 2, -1, -1):
        precision[i] = max(precision[i], precision[i + 1])
    return float(np.sum((recall[1:] - recall[:-1]) * precision[1:]))


def build_balanced_crack_roi_sample(
    y_true_2d: np.ndarray,
    y_prob_2d: np.ndarray,
    rng: np.random.Generator,
    ring_radius_px: int,
    negative_to_positive_ratio: float,
):
    """Erzeugt exakt die gesampelte BALANCED CRACK ROI des Threshold-Sweeps."""
    y_true_bool = np.asarray(y_true_2d).astype(bool)
    y_prob = np.asarray(y_prob_2d, dtype=np.float32)
    if y_true_bool.shape != y_prob.shape:
        raise ValueError(
            f"ROI: GT-Shape {y_true_bool.shape} passt nicht zu "
            f"Prediction-Shape {y_prob.shape}."
        )

    positive_flat = np.flatnonzero(y_true_bool.reshape(-1))
    n_pos = int(positive_flat.size)
    stats = {
        "positive_pixels": n_pos,
        "ring_pixels_available": 0,
        "ring_pixels_sampled": 0,
        "far_background_available": 0,
        "far_background_sampled": 0,
        "negative_pixels_sampled": 0,
        "ring_was_downsampled": False,
        "skipped_no_positive": False,
        "negative_shortfall": 0,
    }
    if n_pos == 0:
        stats["skipped_no_positive"] = True
        return (
            np.empty(0, dtype=np.uint8),
            np.empty(0, dtype=np.float32),
            stats,
        )

    radius = int(ring_radius_px)
    if radius < 0:
        raise ValueError("ring_radius_px darf nicht negativ sein.")
    if radius == 0:
        dilated = y_true_bool.copy()
    else:
        kernel_size = 2 * radius + 1
        kernel = cv2.getStructuringElement(
            cv2.MORPH_ELLIPSE, (kernel_size, kernel_size)
        )
        dilated = cv2.dilate(
            y_true_bool.astype(np.uint8), kernel, iterations=1
        ).astype(bool)

    ring_flat = np.flatnonzero(np.logical_and(dilated, ~y_true_bool).reshape(-1))
    far_flat = np.flatnonzero((~dilated).reshape(-1))
    stats["ring_pixels_available"] = int(ring_flat.size)
    stats["far_background_available"] = int(far_flat.size)

    target_neg = max(0, int(round(n_pos * float(negative_to_positive_ratio))))
    sampled_ring = np.empty(0, dtype=np.int64)
    sampled_far = np.empty(0, dtype=np.int64)

    if target_neg > 0 and ring_flat.size >= target_neg:
        if ring_flat.size == target_neg:
            sampled_ring = ring_flat
        else:
            sampled_ring = rng.choice(ring_flat, size=target_neg, replace=False)
            stats["ring_was_downsampled"] = True
    elif target_neg > 0:
        sampled_ring = ring_flat
        remaining = target_neg - int(ring_flat.size)
        if remaining > 0 and far_flat.size > 0:
            n_far = min(remaining, int(far_flat.size))
            sampled_far = (
                far_flat
                if n_far == far_flat.size
                else rng.choice(far_flat, size=n_far, replace=False)
            )

    negative_flat = np.concatenate(
        [
            np.asarray(sampled_ring, dtype=np.int64),
            np.asarray(sampled_far, dtype=np.int64),
        ]
    )
    stats["ring_pixels_sampled"] = int(sampled_ring.size)
    stats["far_background_sampled"] = int(sampled_far.size)
    stats["negative_pixels_sampled"] = int(negative_flat.size)
    stats["negative_shortfall"] = max(0, target_neg - int(negative_flat.size))

    flat_prob = y_prob.reshape(-1)
    sampled_true = np.concatenate(
        [
            np.ones(n_pos, dtype=np.uint8),
            np.zeros(negative_flat.size, dtype=np.uint8),
        ]
    )
    sampled_prob = np.concatenate(
        [flat_prob[positive_flat], flat_prob[negative_flat]]
    ).astype(np.float32, copy=False)
    return sampled_true, sampled_prob, stats


def make_empty_roi_sampling_stats():
    return {
        "images_total": 0,
        "images_used": 0,
        "images_skipped_no_positive": 0,
        "images_ring_downsampled": 0,
        "positive_pixels": 0,
        "negative_pixels_sampled": 0,
        "ring_pixels_available": 0,
        "ring_pixels_sampled": 0,
        "far_background_available": 0,
        "far_background_sampled": 0,
        "negative_shortfall": 0,
    }


def accumulate_roi_sampling_stats(total: dict, sample: dict):
    total["images_total"] += 1
    if sample["skipped_no_positive"]:
        total["images_skipped_no_positive"] += 1
        return
    total["images_used"] += 1
    if sample["ring_was_downsampled"]:
        total["images_ring_downsampled"] += 1
    for key in (
        "positive_pixels",
        "negative_pixels_sampled",
        "ring_pixels_available",
        "ring_pixels_sampled",
        "far_background_available",
        "far_background_sampled",
        "negative_shortfall",
    ):
        total[key] += int(sample[key])


def evaluate_model_on_sampled_testset(
    model,
    test_ds,
    threshold: float,
    ring_radius_px: int,
    negative_to_positive_ratio: float,
    random_seed: int,
):
    # Nur Threshold fuer die finalen Pixelmetriken + AP-Raster.
    # AUC, MSE, mAP und F0.5 werden bewusst nicht mehr berechnet.
    metric_thresholds = np.unique(np.concatenate((
        np.asarray([threshold], dtype=np.float64), AP_THRESHOLDS
    )))
    tp_all = np.zeros(len(metric_thresholds), dtype=np.int64)
    fp_all = np.zeros(len(metric_thresholds), dtype=np.int64)
    fn_all = np.zeros(len(metric_thresholds), dtype=np.int64)
    tn_all = np.zeros(len(metric_thresholds), dtype=np.int64)

    total_sampled_pixels = 0
    sampling_stats = make_empty_roi_sampling_stats()
    rng = np.random.default_rng(int(random_seed))
    inference_fn = build_inference_function(model, jit_compile=XLA_JIT)
    xla_failed = False

    iterator = test_ds if TEST_STEPS is None else test_ds.take(TEST_STEPS)
    for batch_index, (images, masks) in enumerate(iterator, start=1):
        try:
            preds = inference_fn(images)
        except Exception as exc:
            if XLA_JIT and not xla_failed:
                print(f"\n  [WARNUNG] XLA fuer dieses Modell fehlgeschlagen; tf.function ohne XLA wird verwendet: {exc}")
                inference_fn = build_inference_function(model, jit_compile=False)
                xla_failed = True
                preds = inference_fn(images)
            else:
                raise

        preds = ensure_prediction_tensor(preds, masks)
        masks_np = tf.cast(masks, tf.float32).numpy()
        preds_np = preds.numpy().astype(np.float32, copy=False)

        # Pro Bild sampeln, damit Ring und Hintergrundauswahl immer zur
        # jeweiligen Ground-Truth-Geometrie gehoeren.
        for image_index in range(masks_np.shape[0]):
            sampled_true, sampled_prob, sample_stats = (
                build_balanced_crack_roi_sample(
                    masks_np[image_index, ..., 0] >= 0.5,
                    preds_np[image_index, ..., 0],
                    rng,
                    ring_radius_px,
                    negative_to_positive_ratio,
                )
            )
            accumulate_roi_sampling_stats(sampling_stats, sample_stats)
            if sampled_true.size == 0:
                continue
            total_sampled_pixels += int(sampled_true.size)
            btp, bfp, bfn, btn = confusion_counts_for_thresholds(
                sampled_true, sampled_prob, metric_thresholds
            )
            tp_all += btp
            fp_all += bfp
            fn_all += bfn
            tn_all += btn

        print(f"\r  Batch {batch_index}", end="", flush=True)
    print()

    if total_sampled_pixels == 0:
        raise RuntimeError(
            "Das Testset enthaelt keine Maske mit positiven Risspixeln; "
            "die BALANCED CRACK ROI ist leer."
        )

    selected_idx = int(np.argmin(np.abs(metric_thresholds - threshold)))
    tp = int(tp_all[selected_idx]); fp = int(fp_all[selected_idx])
    fn = int(fn_all[selected_idx]); tn = int(tn_all[selected_idx])

    precision = safe_div(tp, tp + fp)
    recall = safe_div(tp, tp + fn)
    dice = safe_div(2 * tp, 2 * tp + fp + fn)
    iou = safe_div(tp, tp + fp + fn)
    f1 = safe_div(2 * precision * recall, precision + recall)
    beta2 = 4.0
    f2 = safe_div((1.0 + beta2) * precision * recall, beta2 * precision + recall)
    accuracy_pct = safe_div(tp + tn, tp + tn + fp + fn) * 100.0
    fpr = safe_div(fp, fp + tn)
    fnr = safe_div(fn, fn + tp)
    bal_err = 0.5 * (fpr + fnr)
    bal_acc = 1.0 - bal_err

    ap_idx = np.array([int(np.argmin(np.abs(metric_thresholds - t))) for t in AP_THRESHOLDS])
    test_ap = compute_ap_from_threshold_confusions(tp_all[ap_idx], fp_all[ap_idx], fn_all[ap_idx])

    # Euklidische Distanz im gleich gewichteten Dice/F2-Fehlerraum.
    # Dice und F2 liegen bereits in [0,1]. Kleinere Distanz ist besser.
    d_score = float(np.sqrt(0.5 * (1.0 - dice) ** 2 + 0.5 * (1.0 - f2) ** 2))

    return {
        "test_dice_fg": dice,
        "test_iou_fg": iou,
        "test_precision_fg": precision,
        "test_recall_fg": recall,
        "test_f1_fg": f1,
        "test_f2": f2,
        "test_ap": test_ap,
        "test_accuracy_pct": accuracy_pct,
        "balanced_error": bal_err,
        "balanced_accuracy": bal_acc,
        "fpr": fpr,
        "fnr": fnr,
        "tp": tp,
        "fp": fp,
        "fn": fn,
        "tn": tn,
        "D": d_score,
        "sampled_pixels_total": total_sampled_pixels,
        "sample_images_total": sampling_stats["images_total"],
        "sample_images_used": sampling_stats["images_used"],
        "sample_images_skipped_no_positive": sampling_stats[
            "images_skipped_no_positive"
        ],
        "sample_images_ring_downsampled": sampling_stats[
            "images_ring_downsampled"
        ],
        "sample_positive_pixels": sampling_stats["positive_pixels"],
        "sample_negative_pixels": sampling_stats["negative_pixels_sampled"],
        "sample_ring_pixels_available": sampling_stats["ring_pixels_available"],
        "sample_ring_pixels_sampled": sampling_stats["ring_pixels_sampled"],
        "sample_far_background_available": sampling_stats[
            "far_background_available"
        ],
        "sample_far_background_sampled": sampling_stats[
            "far_background_sampled"
        ],
        "sample_negative_shortfall": sampling_stats["negative_shortfall"],
    }


# ============================================================
# ERGEBNISDATEIEN
# ============================================================

SUMMARY_FIELDS = [
    "rank_d", "run_name", "model_name", "model_id", "best_epoch",
    "img_size", "threshold", "best_val_dice_fg",
    "roi_ring_radius_px", "roi_negative_to_positive_ratio", "roi_random_seed",
    "test_dice_fg", "test_iou_fg", "test_precision_fg", "test_recall_fg",
    "test_f1_fg", "test_f2", "test_ap", "test_accuracy_pct",
    "balanced_error", "balanced_accuracy", "fpr", "fnr",
    "tp", "fp", "fn", "tn", "D",
    "sampled_pixels_total", "sample_images_total", "sample_images_used",
    "sample_images_skipped_no_positive", "sample_images_ring_downsampled",
    "sample_positive_pixels", "sample_negative_pixels",
    "sample_ring_pixels_available", "sample_ring_pixels_sampled",
    "sample_far_background_available", "sample_far_background_sampled",
    "sample_negative_shortfall",
]

# Metadaten, die fuer Nachvollziehbarkeit/Deduplizierung in Einzel-JSONs bleiben,
# aber NICHT als Metrik-Spalten geloggt werden.
INTERNAL_RESULT_FIELDS = [
    "metrics_file", "val_dice_file", "threshold_file",
    "metrics_source", "evaluated_at", "model_path", "batch_size",
    "test_split", "test_image_count", "evaluation_scope", "evaluation_region",
]



def validate_result_scope(result: dict):
    scope = str(result.get("evaluation_scope", "")).strip()
    region = str(result.get("evaluation_region", "")).strip()
    if scope != EVALUATION_SCOPE or region != EVALUATION_REGION:
        raise ValueError(
            "SAMPLE-Auswertung verweigert Ergebnis mit falschem Scope/Region: "
            f"scope={scope!r}, region={region!r}; erwartet "
            f"{EVALUATION_SCOPE!r}/{EVALUATION_REGION!r}."
        )


def validate_sample_pixel_accounting(metrics: dict):
    """Prueft, dass die Confusion-Matrix exakt auf dem Sample und nicht global berechnet wurde."""
    observed = sum(int(metrics[k]) for k in ("tp", "fp", "fn", "tn"))
    sampled_total = int(metrics.get("sampled_pixels_total", -1))
    positive = int(metrics.get("sample_positive_pixels", -1))
    negative = int(metrics.get("sample_negative_pixels", -1))
    if observed != sampled_total:
        raise RuntimeError(
            "SAMPLE-Pixelabrechnung verletzt: Confusion-Matrix enthaelt "
            f"{observed:,} Pixel, sampled_pixels_total={sampled_total:,}."
        )
    if int(metrics["tp"]) + int(metrics["fn"]) != positive:
        raise RuntimeError("SAMPLE-Pixelabrechnung verletzt: TP+FN != sample_positive_pixels.")
    if int(metrics["fp"]) + int(metrics["tn"]) != negative:
        raise RuntimeError("SAMPLE-Pixelabrechnung verletzt: FP+TN != sample_negative_pixels.")


def single_result_paths(result: dict):
    run_name = re.sub(
        r"[^A-Za-z0-9._-]+", "_", str(result["run_name"])
    ).strip("._") or "run"
    base = f"{run_name}_Epoche{int(result['best_epoch'])}"
    return (
        EVALUATION_DIR / f"{base}_sample_test_metrics.txt",
        EVALUATION_DIR / f"{base}_sample_test_metrics.json",
    )


def save_single_result(result: dict):
    validate_result_scope(result)
    txt_path, json_path = single_result_paths(result)
    with open(txt_path, "w", encoding="utf-8") as f:
        f.write("=" * 120 + "\n")
        f.write("SAMPLE-TEST-AUSWERTUNG / BALANCED CRACK ROI\n")
        f.write(f"Evaluation-Scope: {EVALUATION_SCOPE}\n")
        f.write(f"Training: {result['run_name']}\n")
        f.write(f"Best epoch: {result['best_epoch']} (Quelle: {result.get('metrics_source', 'unknown')})\n")
        f.write(
            f"Sampling: alle GT-Risspixel + N_neg/N_pos="
            f"{result['roi_negative_to_positive_ratio']:.6g}; "
            f"Ringradius={result['roi_ring_radius_px']} px; "
            f"Seed={result['roi_random_seed']}\n"
        )
        f.write(f"Ranking-Metrik: D = {round_for_output(result['D']):.6f} (kleiner = besser)\n")
        f.write("=" * 120 + "\n")
        for key in SUMMARY_FIELDS:
            if key not in result:
                continue
            value = round_for_output(result[key])
            if value is None:
                f.write(f"{key}: nan\n")
            elif isinstance(value, float):
                f.write(f"{key}: {value:.6f}\n")
            else:
                f.write(f"{key}: {value}\n")

    payload = {}
    for key in SUMMARY_FIELDS + INTERNAL_RESULT_FIELDS:
        if key in result:
            value = result[key]
            if isinstance(value, Path):
                value = str(value)
            payload[key] = round_for_output(value)
    with open(json_path, "w", encoding="utf-8") as f:
        json.dump(payload, f, indent=2, ensure_ascii=False, allow_nan=False)


def normalize_loaded_result(data: dict, source_path: Path, *, allow_legacy_sample: bool = False) -> dict | None:
    data = dict(data)

    scope = str(data.get("evaluation_scope", "")).strip()
    region = str(data.get("evaluation_region", "")).strip()
    if scope:
        if scope != EVALUATION_SCOPE:
            return None
    elif region:
        if region != EVALUATION_REGION:
            return None
    elif not allow_legacy_sample:
        # Neue Dateien muessen ihren Scope explizit tragen.
        return None

    data["evaluation_scope"] = EVALUATION_SCOPE
    data["evaluation_region"] = EVALUATION_REGION

    model_path = data.get("model_path")
    model_name = data.get("model_name")
    model_id = data.get("model_id")

    if model_path:
        p = Path(model_path)
        data.setdefault("model_name", p.name)
        data.setdefault("model_id", model_identity(p))
    elif model_name:
        data.setdefault("model_id", Path(str(model_name)).stem.strip().casefold())
    elif not model_id:
        return None

    data.setdefault("evaluated_at", datetime.fromtimestamp(source_path.stat().st_mtime).isoformat(timespec="seconds"))
    data.pop("dap_dice", None)
    data.pop("rank_dap_dice", None)

    # Fehlenden/alten nan-ValDice ohne erneute Modellinferenz aus dem Run nachladen.
    if not is_finite_number(data.get("best_val_dice_fg")) and data.get("run_name"):
        try:
            metrics = read_metrics_config(OUTPUT_ROOT / str(data["run_name"]))
            if is_finite_number(metrics.get("best_val_dice_fg")):
                data["best_val_dice_fg"] = metrics["best_val_dice_fg"]
                data["metrics_file"] = str(metrics.get("metrics_file", ""))
                data["val_dice_file"] = str(metrics.get("val_dice_file", "")) if metrics.get("val_dice_file") else None
        except Exception as exc:
            print(f"[WARNUNG] ValDice-Fallback fuer Alt-Ergebnis {data.get('run_name')} fehlgeschlagen: {exc}")

    # F2 kann auch fuer alte Ergebnisdateien ohne erneute Inferenz rekonstruiert werden.
    if "test_f2" not in data and all(k in data for k in ("test_precision_fg", "test_recall_fg")):
        pr = safe_float(data["test_precision_fg"]); rc = safe_float(data["test_recall_fg"])
        data["test_f2"] = safe_div(5.0 * pr * rc, 4.0 * pr + rc)
    if "fpr" not in data and all(k in data for k in ("fp", "tn")):
        data["fpr"] = safe_div(data["fp"], data["fp"] + data["tn"])
    if "fnr" not in data and all(k in data for k in ("fn", "tp")):
        data["fnr"] = safe_div(data["fn"], data["fn"] + data["tp"])
    if "balanced_error" not in data and "fpr" in data and "fnr" in data:
        data["balanced_error"] = 0.5 * (safe_float(data["fpr"]) + safe_float(data["fnr"]))
    if "balanced_accuracy" not in data and "balanced_error" in data:
        data["balanced_accuracy"] = 1.0 - safe_float(data["balanced_error"])
    # D immer aus Dice und F2 neu berechnen. So werden auch alte Ergebnis-JSONs
    # automatisch auf die aktuelle Ranking-Definition migriert.
    if "test_dice_fg" in data and "test_f2" in data:
        dice = safe_float(data["test_dice_fg"]); f2 = safe_float(data["test_f2"])
        data["D"] = float(np.sqrt(0.5 * (1.0 - dice) ** 2 + 0.5 * (1.0 - f2) ** 2))
    return data


def load_existing_results() -> list[dict]:
    """Laedt ausschliesslich SAMPLE-ROI-Ergebnisse; GLOBAL-Dateien sind ausgeschlossen."""
    by_model = {}

    # 1) Neue, strikt getrennte SAMPLE-Dateien.
    if EVALUATION_DIR.is_dir():
        for path in sorted(EVALUATION_DIR.glob("*_sample_test_metrics.json")):
            if path.name == "all_models_common_SAMPLE_test_metrics.json":
                continue
            try:
                raw = json.loads(path.read_text(encoding="utf-8"))
                row = normalize_loaded_result(raw, path, allow_legacy_sample=False)
                if row is None:
                    print(f"[SCOPE-IGNORIERT] Kein SAMPLE-Ergebnis: {path}")
                    continue
                key = row["model_id"]
                old = by_model.get(key)
                if old is None or row.get("evaluated_at", "") >= old.get("evaluated_at", ""):
                    by_model[key] = row
            except Exception as exc:
                print(f"[WARNUNG] SAMPLE-Ergebnis nicht lesbar: {path}: {exc}")

    # 2) Kompatibilitaet mit dem alten gemeinsamen Ordner.
    if LOAD_LEGACY_COMPATIBLE_RESULTS and EVALUATION_BASE_DIR.is_dir():
        for path in sorted(EVALUATION_BASE_DIR.glob("*_sample_test_metrics.json")):
            if path.name == "all_modells_common_sample_test_metrics.json":
                continue
            try:
                raw = json.loads(path.read_text(encoding="utf-8"))
                scope = str(raw.get("evaluation_scope", "")).strip()
                region = str(raw.get("evaluation_region", "")).strip()
                if scope and scope != EVALUATION_SCOPE:
                    print(f"[SCOPE-IGNORIERT] Fremder Scope im Legacy-Ordner: {path}")
                    continue
                # Alte Sample-Dateien aus diesem Skript besitzen evaluation_region.
                # Ohne Scope/Region akzeptieren wir Legacy nur wegen des eindeutigen
                # Dateisuffixes *_sample_test_metrics.json.
                if region and region != EVALUATION_REGION:
                    print(f"[SCOPE-IGNORIERT] Fremde Region im Legacy-Ordner: {path}")
                    continue
                row = normalize_loaded_result(raw, path, allow_legacy_sample=True)
                if row is None:
                    continue
                key = row["model_id"]
                old = by_model.get(key)
                if old is None or row.get("evaluated_at", "") >= old.get("evaluated_at", ""):
                    by_model[key] = row
            except Exception as exc:
                print(f"[WARNUNG] Legacy-SAMPLE-Ergebnis nicht lesbar: {path}: {exc}")

    return list(by_model.values())

def save_global_summary(results: list[dict]):
    for row in results:
        validate_result_scope(row)
    EVALUATION_DIR.mkdir(parents=True, exist_ok=True)
    # Ranking-Metrik fuer jeden Datensatz aus den aktuellen Grundmetriken neu bestimmen.
    for row in results:
        if is_finite_number(row.get("test_dice_fg")) and is_finite_number(row.get("test_f2")):
            dice = safe_float(row["test_dice_fg"])
            f2 = safe_float(row["test_f2"])
            row["D"] = float(np.sqrt(0.5 * (1.0 - dice) ** 2 + 0.5 * (1.0 - f2) ** 2))
    results = sorted(results, key=lambda r: safe_float(r.get("D"), float("inf")))
    for rank, row in enumerate(results, 1):
        row["rank_d"] = rank

    txt_path = EVALUATION_DIR / "all_models_common_SAMPLE_test_metrics.txt"
    csv_path = EVALUATION_DIR / "all_models_common_SAMPLE_test_metrics.csv"
    json_path = EVALUATION_DIR / "all_models_common_SAMPLE_test_metrics.json"

    with open(txt_path, "w", encoding="utf-8") as f:
        f.write("=" * 190 + "\n")
        f.write("GEMEINSAME SAMPLE-TEST-AUSWERTUNG ALLER MODELLE\n")
        f.write(f"Evaluation-Scope: {EVALUATION_SCOPE}\n")
        f.write(
            "Bereich: BALANCED CRACK ROI (alle GT-Risspixel + gesampelte Negative)\n"
        )
        f.write("Ranking: D = sqrt(0.5*(1-Dice)^2 + 0.5*(1-F2)^2) | kleiner = besser\n")
        f.write(f"Anzahl eindeutige Modelle: {len(results)}\n")
        f.write("=" * 190 + "\n")
        f.write(
            "Rang\tTraining\tBestEpoch\tIMG_SIZE\tThreshold\tValDice\tSampleTestDice\tSampleTestIoU\t"
            "Precision\tRecall\tF1\tF2\tAP\tAccuracy(%)\tBalErr\tBalAcc\tFPR\tFNR\t"
            "TP\tFP\tFN\tTN\tD\tSamplePixel\tBilderVerwendet\tBilderOhneRiss\n"
        )
        for r in results:
            vals = [
                r.get("rank_d", ""), r.get("run_name", ""), r.get("best_epoch", ""),
                r.get("img_size", ""), r.get("threshold", ""), r.get("best_val_dice_fg", ""),
                r.get("test_dice_fg", ""), r.get("test_iou_fg", ""),
                r.get("test_precision_fg", ""), r.get("test_recall_fg", ""),
                r.get("test_f1_fg", ""), r.get("test_f2", ""), r.get("test_ap", ""),
                r.get("test_accuracy_pct", ""), r.get("balanced_error", ""),
                r.get("balanced_accuracy", ""), r.get("fpr", ""), r.get("fnr", ""),
                r.get("tp", ""), r.get("fp", ""), r.get("fn", ""), r.get("tn", ""),
                r.get("D", ""),
                r.get("sampled_pixels_total", ""), r.get("sample_images_used", ""),
                r.get("sample_images_skipped_no_positive", ""),
            ]
            formatted = []
            for value in vals:
                value = round_for_output(value)
                if value is None:
                    formatted.append("nan")
                elif isinstance(value, float):
                    formatted.append(f"{value:.6f}")
                else:
                    formatted.append(str(value))
            f.write("\t".join(formatted) + "\n")

    with open(csv_path, "w", encoding="utf-8", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=SUMMARY_FIELDS, extrasaction="ignore")
        writer.writeheader()
        for row in results:
            writer.writerow({k: round_for_output(row.get(k, "")) for k in SUMMARY_FIELDS})

    payload = {
        "created_at": datetime.now().isoformat(timespec="seconds"),
        "evaluation_scope": EVALUATION_SCOPE,
        "evaluation_region": EVALUATION_REGION,
        "ranking_metric": "D = sqrt(0.5*(1-Dice)^2 + 0.5*(1-F2)^2); lower is better",
        "number_of_models": len(results),
        "results": [
            {k: round_for_output(row.get(k, "")) for k in SUMMARY_FIELDS}
            for row in results
        ],
    }
    with open(json_path, "w", encoding="utf-8") as f:
        json.dump(payload, f, indent=2, ensure_ascii=False, allow_nan=False)
    return txt_path, csv_path, json_path


# ============================================================
# MAIN
# ============================================================

def load_model(model_path: Path):
    try:
        return tf.keras.models.load_model(model_path, compile=False, custom_objects=CUSTOM_OBJECTS)
    except TypeError:
        return tf.keras.models.load_model(
            model_path, compile=False, safe_mode=False, custom_objects=CUSTOM_OBJECTS
        )


def main():
    EVALUATION_DIR.mkdir(parents=True, exist_ok=True)

    mode = str(EVALUATION_MODE).strip().lower()
    if mode not in {"all", "models"}:
        raise ValueError(
            f"EVALUATION_MODE muss 'all' oder 'models' sein, ist aber: {EVALUATION_MODE!r}"
        )

    try:
        for gpu in tf.config.list_physical_devices("GPU"):
            tf.config.experimental.set_memory_growth(gpu, True)
    except RuntimeError:
        pass

    existing = load_existing_results()
    completed_ids = {r["model_id"] for r in existing}
    print(f"Evaluation-Scope: {EVALUATION_SCOPE}")
    print(f"Ergebnisordner:   {EVALUATION_DIR}")
    print(f"Bereits eindeutig im Samplebereich getestete Modelle: {len(completed_ids)}")

    if mode == "models":
        if not MODEL_PATHS:
            raise RuntimeError(
                "EVALUATION_MODE='models', aber MODEL_PATHS ist leer. "
                "Trage oben im Konfigurationsbereich mindestens einen Modellpfad ein."
            )
        records = []
        seen = set()
        for raw in MODEL_PATHS:
            try:
                record = make_run_record(Path(raw), exact_model=True)
                if record["model_id"] in seen:
                    print(f"[DUPLIKAT IN MODEL_PATHS] {record['model_name']}")
                    continue
                seen.add(record["model_id"])
                records.append(record)
            except Exception as exc:
                print(f"[UEBERSPRUNGEN] {raw}: {exc}")
    else:
        records = find_all_runs()

    if not FORCE_REEVALUATE:
        before = len(records)
        records = [r for r in records if r["model_id"] not in completed_ids]
        skipped = before - len(records)
        if skipped:
            print(f"Bereits getestete Modelle uebersprungen: {skipped}")

    if not records:
        print(
            "Keine neuen Modelle zu testen. Die gemeinsamen Sample-Test-Dateien "
            "werden aus dem bisherigen Verlauf aktualisiert."
        )
        if not existing:
            raise RuntimeError("Es wurden weder neue noch bestehende gueltige Ergebnisse gefunden.")
        paths = save_global_summary(existing)
        print("\n".join(f"{label}: {path}" for label, path in zip(("TXT", "CSV", "JSON"), paths)))
        return

    print(f"Neu zu testen: {len(records)}")
    for r in records:
        print(
            f"  - {r['model_name']} | Run={r['run_name']} | BestEpoch={r['best_epoch']} | "
            f"Threshold={r['threshold']:.8g} | Ring={r['roi_ring_radius_px']} px | "
            f"N_neg/N_pos={r['roi_negative_to_positive_ratio']:.4g} | "
            f"Seed={r['roi_random_seed']}"
        )

    dataset_cache = {}
    new_results = []

    for idx, record in enumerate(records, 1):
        tf.keras.backend.clear_session()
        gc.collect()
        print("\n" + "=" * 110)
        print(f"[{idx}/{len(records)}] {record['model_name']}")
        print(f"Run:       {record['run_name']}")
        print(f"BestEpoch: {record['best_epoch']} (aus {record['metrics_source']}: {record['metrics_file']})")
        print(f"Threshold: {record['threshold']:.10g} (ROI minimaler Balanced Error)")

        try:
            model = load_model(record["model_path"])
            model_img_size = infer_model_img_size(model)
            if record["img_size"] is not None and record["img_size"] != model_img_size:
                print(
                    f"[WARNUNG] IMG_SIZE in Threshold-Datei={record['img_size']}, "
                    f"Modellinput={model_img_size}; Modellinput wird verwendet."
                )
            img_size = model_img_size
            batch_size = BATCH_SIZE_1024 if img_size == 1024 else DEFAULT_BATCH_SIZE

            cache_key = (img_size, batch_size)
            if cache_key not in dataset_cache:
                dataset_cache[cache_key] = get_test_dataset(img_size, batch_size)
            test_ds, test_count, test_split = dataset_cache[cache_key]
            print(f"TestSplit: {test_split} | Bilder={test_count} | IMG_SIZE={img_size} | Batch={batch_size}")

            metrics = evaluate_model_on_sampled_testset(
                model,
                test_ds,
                record["threshold"],
                record["roi_ring_radius_px"],
                record["roi_negative_to_positive_ratio"],
                record["roi_random_seed"],
            )
            validate_sample_pixel_accounting(metrics)
            result = {
                "run_name": record["run_name"],
                "model_name": record["model_name"],
                "model_id": record["model_id"],
                "best_epoch": record["best_epoch"],
                "best_val_dice_fg": float(record["best_val_dice_fg"]),
                "model_path": str(record["model_path"]),
                "metrics_file": str(record["metrics_file"]),
                "metrics_source": record.get("metrics_source", "unknown"),
                "threshold_file": str(record["threshold_file"]),
                "img_size": img_size,
                "batch_size": batch_size,
                "threshold": float(record["threshold"]),
                "roi_ring_radius_px": int(record["roi_ring_radius_px"]),
                "roi_negative_to_positive_ratio": float(
                    record["roi_negative_to_positive_ratio"]
                ),
                "roi_random_seed": int(record["roi_random_seed"]),
                "test_split": test_split,
                "test_image_count": test_count,
                "evaluation_scope": EVALUATION_SCOPE,
                "evaluation_region": EVALUATION_REGION,
                "evaluated_at": datetime.now().isoformat(timespec="seconds"),
                **metrics,
            }
            save_single_result(result)
            new_results.append(result)
            print(
                f"Fertig: Dice={result['test_dice_fg']:.6f} | AP={result['test_ap']:.6f} | "
                f"D={result['D']:.6f}"
            )
            del model
        except Exception as exc:
            print(f"[FEHLER] {record['model_name']}: {exc}")
        finally:
            tf.keras.backend.clear_session()
            gc.collect()

    # Neu geladene Daten + neue Ergebnisse; Deduplizierung anhand Modellname.
    by_model = {r["model_id"]: r for r in existing}
    for r in new_results:
        by_model[r["model_id"]] = r
    all_results = list(by_model.values())
    if not all_results:
        raise RuntimeError("Kein Modell konnte erfolgreich ausgewertet werden.")

    txt_path, csv_path, json_path = save_global_summary(all_results)
    best = min(all_results, key=lambda r: safe_float(r.get("D"), float("inf")))

    print("\n" + "=" * 110)
    print("SAMPLE-TEST-AUSWERTUNG ABGESCHLOSSEN")
    print(f"Neu getestet:       {len(new_results)}")
    print(f"Insgesamt erfasst:  {len(all_results)} eindeutige Modelle")
    print(f"Bestes Modell:      {best.get('model_name')} | D={safe_float(best.get('D')):.6f}")
    print(f"TXT:  {txt_path}")
    print(f"CSV:  {csv_path}")
    print(f"JSON: {json_path}")


if __name__ == "__main__":
    main()
