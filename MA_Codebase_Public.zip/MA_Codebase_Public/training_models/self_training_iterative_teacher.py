#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
U-Net++ iteratives Online-Self-Training ohne vortrainierten Teacher.

Enthalten:
- beste Epoche nach euklidischer Idealpunkt-Distanz aus val_dice_fg und val_f2_fg
  D = sqrt(0.5 * (1 - Dice)^2 + 0.5 * (1 - F2)^2)
- optional vollständiges Modell jeder Epoche
- ReduceLROnPlateau und EarlyStopping nach val_loss
- TXT-, CSV- und JSON-Protokoll
- vollständige Plot-Sammlung plus gemeinsamer 0-1-Metrikplot
- ausführlicher Architekturbericht inklusive Konnektivitäts-/Concat-Audit
- Lauf-, Hardware-, Software- und Datensatzmetadaten
- Keras-Standardfortschrittsanzeige über model.fit(verbose=1)

"""

from __future__ import annotations

import csv
import importlib.metadata
import json
import math
import os
import hashlib

import cv2

# WSL-stabile TensorFlow-GPU-Initialisierung. Diese Variablen MUESSEN vor
# dem TensorFlow-Import gesetzt werden. cuda_malloc_async wird bewusst nicht
# erzwungen, da es unter WSL/verschiedenen Treiberversionen harte Prozessabbrueche
# verursachen kann.
os.environ["KERAS_BACKEND"] = "tensorflow"
os.environ.setdefault("TF_CUDNN_USE_AUTOTUNE", "1")
os.environ.setdefault("TF_FORCE_GPU_ALLOW_GROWTH", "true")

import tensorflow as tf

import platform
import random
import shutil
import subprocess
import sys
from datetime import datetime
from pathlib import Path
from typing import Any, Iterable

import matplotlib.pyplot as plt
import numpy as np
from keras import mixed_precision
from keras.utils import plot_model



# =============================================================================
# 1. KONFIGURATION – HIER ANPASSEN
# =============================================================================

RUN_NAME = "unetpp_iterative_online_selftraining"
SEG_DIR = Path("/home/mitte/crack_project/datasets/better_dataset_evtl")
OUTPUT_ROOT = Path("/home/mitte/crack_project/outputs")

TRAIN_SPLIT = "train_512"
VAL_SPLIT = "val_512"
TEST_SPLIT = "test_512"

SEED = 42
IMG_SIZE = 512
BATCH = 8
INITIAL_LR = 1e-4
STEPS_PER_EPOCH = 1000
VALIDATION_STEPS = None  # None = komplettes Validation-Set verwenden
EPOCHS = 40
THRESHOLD = 0.5

# U-Net++-Architektur
# Fünf Encoderstufen und vier vollständig verschachtelte Decoderstufen.
# Jeder Knoten X_i_j erhält alle vorherigen Knoten derselben Auflösung sowie
# den hochskalierten Knoten aus der nächsttieferen Ebene.
FILTER_NUM = [ 16, 32, 64, 128, 256] # , 512
CONVS_PER_BLOCK = 2
ACTIVATION = "relu"
BATCH_NORM = True
KERNEL_INITIALIZER = "he_normal"
DEEP_SUPERVISION = False

# Hard-Negatives liegen innerhalb des Trainingssplits parallel zu images/masks:
#   images_512px_hard_negatives / masks_512px_hard_negatives
# Bei > 0 wird per sample_from_datasets ein Zielanteil im Trainingsstrom erzeugt.
HARD_NEGATIVE_TARGET_SHARE = 0.00  # 0.0 = 0 %, 0.20 = 20 %
HN_IMAGE_DIRNAME = f"images_{IMG_SIZE}px_hard_negatives"
HN_MASK_DIRNAME = f"masks_{IMG_SIZE}px_hard_negatives"

MASK_FORMAT_DESCRIPTION = (
    "PNG, 1 Kanal; Pixel > 127 werden als Rissklasse 1, sonst als 0 eingelesen"
)
LOSS_NAME = "Iterative Online Self-Training: GT Tversky + confidence-weighted Previous-Epoch Pseudo Tversky"
OPTIMIZER_NAME = "Adam"

# =============================================================================
# SELF-TRAINING / PSEUDO-LABEL-KONFIGURATION
# =============================================================================

# Separat vorbereitetes Pseudo-Label-Dataset. Jedes Bild ist bereits exakt 512x512 px
# (inkl. vorherigem Overlap-Cropping/Rotationen) und wird hier NICHT erneut gepatcht.
# Nach Datensatzkenntnis enthalten praktisch alle Samples einen Riss.
# WICHTIG: Validation und Test bleiben ausschließlich im better_dataset und dürfen hier nicht enthalten sein.
UNLABELED_DIR = Path("/home/mitte/crack_project/datasets/baseline_dataset/uncolored_set/train_512/images")
UNLABELED_EXTENSIONS = {".png", ".jpg", ".jpeg", ".tif", ".tiff", ".bmp"}

# Online-Pseudo-Labeling: Es gibt KEIN vortrainiertes Teacher-Modell.
# Nach drei reinen GT-Epochen dient jeweils der Student vom Ende der letzten Epoche
# als Teacher fuer die naechste Epoche. Nur die in dieser Epoche benoetigten
# Unlabeled-Samples werden neu inferiert.
PSEUDO_INFERENCE_BATCH_SIZE = 8
PSEUDO_START_EPOCH = 4
PSEUDO_START_SHARE = 0.05
PSEUDO_SHARE_INCREMENT = 0.02
PSEUDO_MAX_SAMPLING_SHARE = 0.50
PSEUDO_LOSS_WEIGHT = 1.0
SAMPLES_PER_EPOCH = STEPS_PER_EPOCH * BATCH
PSEUDO_RAMP_EPOCHS = int(math.ceil((PSEUDO_MAX_SAMPLING_SHARE - PSEUDO_START_SHARE) / PSEUDO_SHARE_INCREMENT)) + 1
REUSE_PSEUDO_CACHE = False

# Decision-aware Confidence: Confidence wird relativ zur tatsächlichen
# Segmentierungs-Entscheidungsgrenze berechnet, NICHT relativ zu 0.5.
# Ein Pixel erreicht Confidence=1.0, sobald seine Odds mindestens um den
# angegebenen Faktor auf einer Seite der Entscheidungsgrenze liegen.
PSEUDO_CONFIDENCE_ODDS_RATIO = 4.0
PSEUDO_PATCH_CONFIDENCE_THRESHOLD = 0.75
PSEUDO_PIXEL_CONFIDENCE_THRESHOLD = 0.75
PSEUDO_MIN_CONFIDENT_PIXEL_FRACTION = 0.80

# Der separate Unlabeled-Pool ist nahezu vollständig risspositiv. Deshalb werden
# Teacher-Ausgaben ohne erkannten Riss NICHT als Hard-Negatives benutzt, sondern verworfen.
# So können Teacher-False-Negatives keine falschen Hintergrundtargets in Self-Training einspeisen.
PSEUDO_MIN_POSITIVE_PIXELS = 8

# Die ersten drei Epochen trainieren ausschließlich auf Ground Truth. Ab Epoche 4
# steigt der exakte Pseudo-Anteil um 2 Prozentpunkte pro Epoche bis maximal 50 %.
PSEUDO_WARMUP_EPOCHS = PSEUDO_START_EPOCH - 1
PSEUDO_MAX_LOSS_WEIGHT = PSEUDO_LOSS_WEIGHT
# Keine tf.Variable auf Modulebene: Eine solche Variable kann den CUDA-Kontext
# bereits waehrend des Imports initialisieren, bevor GPU memory growth gesetzt ist.
# Der Pseudo-Anteil wird in diesem Skript ohnehin exakt ueber die Anzahl Samples
# pro Epoche gesteuert; der Loss-Weight ist konstant.

TEACHER_TYPE = "previous_epoch_student_online"

# Start-Arbeitspunkt fuer die Pseudomaske. Die Confidence wird relativ zu dieser
# Entscheidungsgrenze bewertet. Dieser Wert stammt aus der vorhandenen
# BALANCED-CRACK-ROI-Auswertung und kann spaeter separat validiert werden.
SINGLE_TEACHER_MASK_THRESHOLD = 3.3e-05

LR_REDUCE_PATIENCE = 5
LR_REDUCE_FACTOR = 0.5
EARLY_STOPPING_PATIENCE = 10
MIN_DELTA = 0.0

# Geschwindigkeitsoptionen. Alle Optionen verändern nur die Ausführung bzw.
# Protokollierung, nicht die U-Net++-Architektur oder die Trainingsdaten.
XLA_JIT = False  # WSL-sicherer Default; erst nach stabilem Lauf optional aktivieren
MIXED_PRECISION_POLICY = "mixed_float16"
STEPS_PER_EXECUTION = 16
# Begrenzte tf.data-Parallelitaet verhindert RAM-Spitzen unter WSL.
DATA_NUM_PARALLEL_CALLS = 2
DATA_PREFETCH_BATCHES = 2
# WICHTIG: Der Shuffle findet nach dem Decodieren statt. 8000 dekodierte
# 512x512-Tensoren wuerden zig GB RAM benoetigen. Ein kleiner Puffer reicht,
# da GT/Pseudo zuvor bereits zufaellig/zyklisch zusammengestellt werden.
EPOCH_SHUFFLE_BUFFER = 32

# Das komplette Validation-Set wird ausgewertet. VALIDATION_STEPS=None bedeutet,
# dass kein kuenstliches Limit auf die ersten Batches/Samples angewendet wird.
# Optional kann weiterhin ein fester Batch-Limitwert gesetzt werden.
CACHE_VALIDATION = False #True

# Das Speichern eines vollständigen .keras-Modells nach jeder Epoche verursacht
# deutlichen I/O-Overhead. False speichert während des Trainings nur neue Bestwerte.
# Nach Trainingsende wird zusätzlich eine Datei mit dem Namen der besten Epoche erzeugt.
SAVE_ALL_EPOCH_MODELS = True

# Plots nicht nach jeder Epoche neu rendern. Bei 0 nur am Trainingsende.
PLOTS_EVERY_N_EPOCHS = 5

# 21 Schwellen reichen für die laufende AP-Näherung aus. Die spätere genaue
# Threshold-Suche bleibt davon unberührt und kann separat fein aufgelöst erfolgen.
AP_THRESHOLDS = np.linspace(1.0, 0.0, 21, dtype=np.float64)
AUC_NUM_THRESHOLDS = 101
CURVE_GRID_MAX_INDEX = AUC_NUM_THRESHOLDS - 1
AP_GRID_INDICES = np.rint(AP_THRESHOLDS * CURVE_GRID_MAX_INDEX).astype(np.int32)

# Unterstützte Dateien. Die TensorFlow-Decodierung unten ist bewusst auf PNG
# ausgelegt, damit Masken exakt und ohne verlustbehaftete JPEG-Artefakte bleiben.
SUPPORTED_EXTENSIONS = {".png"}


# =============================================================================
# 2. AUSGABEPFADE
# =============================================================================

RUN_DIR = OUTPUT_ROOT / RUN_NAME
MODEL_DIR = RUN_DIR / "models"
METRICS_DIR = RUN_DIR / "metrics"
PLOT_DIR = METRICS_DIR / "plots"
ARCH_DIR = RUN_DIR / "architecture"

METRICS_TXT_FILE = METRICS_DIR / f"{RUN_NAME}_epoch_metrics.txt"
METRICS_CSV_FILE = METRICS_DIR / f"{RUN_NAME}_epoch_metrics.csv"
METRICS_JSON_FILE = METRICS_DIR / f"{RUN_NAME}_epoch_metrics.json"
RUN_CONFIG_FILE = METRICS_DIR / f"{RUN_NAME}_run_configuration.txt"

ARCHITECTURE_TXT_FILE = ARCH_DIR / f"{RUN_NAME}_architecture_detailed.txt"
ARCHITECTURE_JSON_FILE = ARCH_DIR / f"{RUN_NAME}_architecture_config.json"
ARCHITECTURE_KERAS_JSON_FILE = ARCH_DIR / f"{RUN_NAME}_architecture_keras.json"
ARCHITECTURE_PNG_FILE = ARCH_DIR / f"{RUN_NAME}_architecture.png"

PSEUDO_CACHE_DIR = RUN_DIR / "pseudo_cache"
PSEUDO_TARGET_DIR = PSEUDO_CACHE_DIR / "targets"
PSEUDO_CONFIDENCE_DIR = PSEUDO_CACHE_DIR / "confidence"
PSEUDO_MANIFEST_FILE = PSEUDO_CACHE_DIR / "pseudo_manifest.csv"
PSEUDO_CACHE_SIGNATURE_FILE = PSEUDO_CACHE_DIR / "pseudo_cache_signature.json"
SELF_TRAINING_CONFIG_FILE = METRICS_DIR / f"{RUN_NAME}_self_training_config.json"
CURRICULUM_LOG_FILE = METRICS_DIR / f"{RUN_NAME}_curriculum.csv"


# =============================================================================
# 3. REPRODUZIERBARKEIT / MIXED PRECISION
# =============================================================================

os.environ["PYTHONHASHSEED"] = str(SEED)

random.seed(SEED)
np.random.seed(SEED)
tf.random.set_seed(SEED)

if XLA_JIT:
    tf.config.optimizer.set_jit("autoclustering")
else:
    tf.config.optimizer.set_jit(False)

# Convolutionen laufen in float16 auf den Tensor Cores. Der finale Sigmoid-Output
# des Modells bleibt explizit float32, sodass Loss und Metriken stabil bleiben.
mixed_precision.set_global_policy(MIXED_PRECISION_POLICY)

# Auf NVIDIA-GPUs kann TensorFloat-32 zusätzliche float32-Operationen beschleunigen.
try:
    tf.config.experimental.enable_tensor_float_32_execution(True)
except AttributeError:
    pass

# Keras-Standardausgabe/Progbar im Terminal aktivieren.
try:
    tf.keras.utils.enable_interactive_logging()
except AttributeError:
    pass


# =============================================================================
# 4. ALLGEMEINE HILFSFUNKTIONEN
# =============================================================================

def json_safe(value: Any) -> Any:
    """Konvertiert typische Python-/NumPy-/TensorFlow-Werte JSON-sicher."""
    if isinstance(value, dict):
        return {str(k): json_safe(v) for k, v in value.items()}
    if isinstance(value, (list, tuple, set)):
        return [json_safe(v) for v in value]
    if isinstance(value, Path):
        return str(value)
    if isinstance(value, np.ndarray):
        return value.tolist()
    if isinstance(value, np.generic):
        return value.item()
    if isinstance(value, (datetime,)):
        return value.isoformat()
    if isinstance(value, bytes):
        return value.decode("utf-8", errors="replace")
    try:
        json.dumps(value)
        return value
    except TypeError:
        return str(value)


def write_json_atomic(path: Path, data: dict[str, Any]) -> None:
    """Schreibt JSON atomar, damit bei einem Abbruch keine halbe Datei bleibt."""
    path.parent.mkdir(parents=True, exist_ok=True)
    temp_path = path.with_suffix(path.suffix + ".tmp")
    with temp_path.open("w", encoding="utf-8") as file:
        json.dump(json_safe(data), file, indent=2, ensure_ascii=False)
    temp_path.replace(path)


def package_version(*package_names: str) -> str:
    """Liefert die erste gefundene Paketversion."""
    for package_name in package_names:
        try:
            return importlib.metadata.version(package_name)
        except importlib.metadata.PackageNotFoundError:
            continue
        except Exception as exc:  # pragma: no cover - reine Diagnose
            return f"Fehler beim Auslesen: {exc}"
    return "nicht gefunden"


def run_command(command: list[str], timeout: int = 15) -> str:
    """Führt einen Diagnosebefehl aus und gibt dessen Ausgabe zurück."""
    try:
        result = subprocess.run(
            command,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True,
            timeout=timeout,
            check=False,
        )
        if result.returncode == 0 and result.stdout.strip():
            return result.stdout.strip()
        error = result.stderr.strip() or f"Returncode {result.returncode}"
        return f"nicht verfügbar ({error})"
    except FileNotFoundError:
        return "nicht verfügbar (Befehl nicht gefunden)"
    except subprocess.TimeoutExpired:
        return "nicht verfügbar (Timeout)"
    except Exception as exc:  # pragma: no cover - reine Diagnose
        return f"nicht verfügbar ({exc})"


def find_nvidia_smi() -> str | None:
    candidates = [
        shutil.which("nvidia-smi"),
        "/usr/lib/wsl/lib/nvidia-smi",
        "/usr/bin/nvidia-smi",
    ]
    for candidate in candidates:
        if candidate and Path(candidate).exists():
            return str(candidate)
    return None


def get_current_learning_rate(optimizer: tf.keras.optimizers.Optimizer) -> float:
    try:
        lr = optimizer.learning_rate
        if callable(lr):
            lr = lr(optimizer.iterations)
        return float(tf.keras.backend.get_value(lr))
    except Exception:
        return float("nan")


def safe_div(numerator: float, denominator: float, eps: float = 1e-7) -> float:
    return float((numerator + eps) / (denominator + eps))


# =============================================================================
# 5. SYSTEM- UND SOFTWAREINFORMATIONEN
# =============================================================================

def collect_environment_info() -> dict[str, Any]:
    tf_build_info = {}
    try:
        tf_build_info = dict(tf.sysconfig.get_build_info())
    except Exception as exc:
        tf_build_info = {"error": str(exc)}

    nvidia_smi = find_nvidia_smi()
    if nvidia_smi:
        gpu_query = run_command(
            [
                nvidia_smi,
                "--query-gpu=name,driver_version,memory.total",
                "--format=csv,noheader",
            ]
        )
        driver_query = run_command(
            [nvidia_smi, "--query-gpu=driver_version", "--format=csv,noheader"]
        )
        nvidia_smi_full = run_command([nvidia_smi])
    else:
        gpu_query = "nicht verfügbar"
        driver_query = "nicht verfügbar"
        nvidia_smi_full = "nicht verfügbar"

    physical_gpus = tf.config.list_physical_devices("GPU")
    tensorflow_gpu_details: list[dict[str, Any]] = []
    for gpu in physical_gpus:
        details: dict[str, Any] = {"name": gpu.name, "device_type": gpu.device_type}
        try:
            details.update(tf.config.experimental.get_device_details(gpu))
        except Exception as exc:
            details["details_error"] = str(exc)
        tensorflow_gpu_details.append(details)

    keras_version = getattr(tf.keras, "__version__", None)
    if not keras_version:
        keras_version = package_version("keras")

    cuda_build = tf_build_info.get("cuda_version", "nicht angegeben")
    cudnn_build = tf_build_info.get("cudnn_version", "nicht angegeben")

    cuda_runtime_pkg = package_version(
        "nvidia-cuda-runtime-cu12",
        "nvidia-cuda-runtime-cu11",
    )
    cudnn_runtime_pkg = package_version(
        "nvidia-cudnn-cu12",
        "nvidia-cudnn-cu11",
    )

    return {
        "timestamp_start": datetime.now().astimezone().isoformat(),
        "python_version": sys.version.replace("\n", " "),
        "python_executable": sys.executable,
        "platform": platform.platform(),
        "system": platform.system(),
        "release": platform.release(),
        "machine": platform.machine(),
        "tensorflow_version": tf.__version__,
        "keras_version": keras_version,
        "keras_unet_collection_version": package_version("keras-unet-collection"),
        "numpy_version": np.__version__,
        "matplotlib_version": package_version("matplotlib"),
        "mixed_precision_policy": mixed_precision.global_policy().name,
        "tensorflow_built_with_cuda": bool(tf.test.is_built_with_cuda()),
        "tensorflow_build_info": json_safe(tf_build_info),
        "cuda_runtime": (
            f"TensorFlow-Build: {cuda_build}; "
            f"Python-Paket nvidia-cuda-runtime: {cuda_runtime_pkg}"
        ),
        "cudnn_version": (
            f"TensorFlow-Build: {cudnn_build}; "
            f"Python-Paket nvidia-cudnn: {cudnn_runtime_pkg}"
        ),
        "nvidia_windows_driver": driver_query,
        "nvidia_gpu_query": gpu_query,
        "nvidia_smi_full": nvidia_smi_full,
        "tensorflow_visible_gpus": json_safe(tensorflow_gpu_details),
        "cuda_visible_devices": os.environ.get("CUDA_VISIBLE_DEVICES", "nicht gesetzt"),
    }


# =============================================================================
# 6. DATENSATZ UND TF.DATA-PIPELINE
# =============================================================================

def collect_pairs_from_directories(
    image_dir: Path,
    mask_dir: Path,
    label: str,
) -> tuple[list[str], list[str], dict[str, Any]]:
    if not image_dir.is_dir():
        raise FileNotFoundError(f"Bilderordner fehlt: {image_dir}")
    if not mask_dir.is_dir():
        raise FileNotFoundError(f"Maskenordner fehlt: {mask_dir}")

    image_paths = sorted(
        p for p in image_dir.iterdir()
        if p.is_file() and not p.name.startswith(".") and p.suffix.lower() in SUPPORTED_EXTENSIONS
    )
    mask_paths = sorted(
        p for p in mask_dir.iterdir()
        if p.is_file() and not p.name.startswith(".") and p.suffix.lower() in SUPPORTED_EXTENSIONS
    )

    mask_map: dict[str, Path] = {}
    duplicate_mask_stems: list[str] = []
    for mask_path in mask_paths:
        stem = mask_path.stem.lower()
        if stem in mask_map:
            duplicate_mask_stems.append(stem)
        mask_map[stem] = mask_path

    valid_images: list[str] = []
    valid_masks: list[str] = []
    images_without_mask: list[str] = []
    for image_path in image_paths:
        mask_path = mask_map.get(image_path.stem.lower())
        if mask_path is None:
            images_without_mask.append(str(image_path))
            continue
        valid_images.append(str(image_path))
        valid_masks.append(str(mask_path))

    image_stems = {p.stem.lower() for p in image_paths}
    masks_without_image = [
        str(mask_path) for mask_path in mask_paths
        if mask_path.stem.lower() not in image_stems
    ]

    info = {
        "label": label,
        "image_dir": str(image_dir),
        "mask_dir": str(mask_dir),
        "images_found": len(image_paths),
        "masks_found": len(mask_paths),
        "matched_pairs": len(valid_images),
        "images_without_mask_count": len(images_without_mask),
        "masks_without_image_count": len(masks_without_image),
        "duplicate_mask_stems_count": len(duplicate_mask_stems),
        "image_extensions": sorted({p.suffix.lower() for p in image_paths}),
        "mask_extensions": sorted({p.suffix.lower() for p in mask_paths}),
        "images_without_mask_examples": images_without_mask[:20],
        "masks_without_image_examples": masks_without_image[:20],
        "duplicate_mask_stems_examples": duplicate_mask_stems[:20],
    }
    return valid_images, valid_masks, info


def collect_image_mask_pairs(split: str) -> tuple[list[str], list[str], dict[str, Any]]:
    split_dir = SEG_DIR / split
    image_dir = split_dir / "images"
    mask_dir = split_dir / "masks"
    images, masks, info = collect_pairs_from_directories(image_dir, mask_dir, split)
    info["split"] = split
    if not images:
        raise RuntimeError(f"Keine passenden Bild-Masken-Paare in Split '{split}' gefunden.")
    return images, masks, info


def collect_hard_negative_pairs(split: str) -> tuple[list[str], list[str], dict[str, Any]]:
    split_dir = SEG_DIR / split
    image_dir = split_dir / HN_IMAGE_DIRNAME
    mask_dir = split_dir / HN_MASK_DIRNAME

    if not image_dir.is_dir() or not mask_dir.is_dir():
        return [], [], {
            "label": "hard_negatives",
            "image_dir": str(image_dir),
            "mask_dir": str(mask_dir),
            "matched_pairs": 0,
            "available": False,
        }

    images, masks, info = collect_pairs_from_directories(image_dir, mask_dir, "hard_negatives")
    info["available"] = True
    return images, masks, info


def load_and_preprocess(
    image_path: tf.Tensor,
    mask_path: tf.Tensor,
) -> tuple[tf.Tensor, tf.Tensor]:
    image = tf.io.read_file(image_path)
    image = tf.image.decode_png(image, channels=3)
    image = tf.image.convert_image_dtype(image, tf.float32)
    image.set_shape([IMG_SIZE, IMG_SIZE, 3])

    mask = tf.io.read_file(mask_path)
    mask = tf.image.decode_png(mask, channels=1)
    mask = tf.cast(mask > 127, tf.float32)
    mask.set_shape([IMG_SIZE, IMG_SIZE, 1])
    return image, mask


def _dataset_from_paths(
    image_paths: list[str],
    mask_paths: list[str],
    *,
    shuffle_and_repeat: bool,
) -> tf.data.Dataset:
    dataset = tf.data.Dataset.from_tensor_slices((image_paths, mask_paths))
    if shuffle_and_repeat:
        dataset = dataset.shuffle(
            buffer_size=len(image_paths), seed=SEED, reshuffle_each_iteration=True
        ).repeat()
    dataset = dataset.map(
        load_and_preprocess,
        num_parallel_calls=DATA_NUM_PARALLEL_CALLS,
        deterministic=True,
    )
    return dataset


def build_dataset(
    split: str,
) -> tuple[tf.data.Dataset, int, dict[str, Any]]:
    image_paths, mask_paths, info = collect_image_mask_pairs(split)
    total_pairs = len(image_paths)

    if split == TRAIN_SPLIT:
        regular_dataset = _dataset_from_paths(
            image_paths, mask_paths, shuffle_and_repeat=True
        )
        hn_images, hn_masks, hn_info = collect_hard_negative_pairs(split)
        info["hard_negatives"] = hn_info
        info["hard_negative_target_share"] = HARD_NEGATIVE_TARGET_SHARE

        if HARD_NEGATIVE_TARGET_SHARE > 0.0:
            if not 0.0 < HARD_NEGATIVE_TARGET_SHARE < 1.0:
                raise ValueError("HARD_NEGATIVE_TARGET_SHARE muss zwischen 0 und 1 liegen.")
            if not hn_images:
                raise RuntimeError(
                    f"HARD_NEGATIVE_TARGET_SHARE={HARD_NEGATIVE_TARGET_SHARE:.3f}, "
                    f"aber keine HN-Paare in {SEG_DIR / split / HN_IMAGE_DIRNAME} und "
                    f"{SEG_DIR / split / HN_MASK_DIRNAME} gefunden."
                )
            hn_dataset = _dataset_from_paths(hn_images, hn_masks, shuffle_and_repeat=True)
            dataset = tf.data.Dataset.sample_from_datasets(
                [regular_dataset, hn_dataset],
                weights=[1.0 - HARD_NEGATIVE_TARGET_SHARE, HARD_NEGATIVE_TARGET_SHARE],
                seed=SEED,
                stop_on_empty_dataset=False,
            )
            info["hard_negative_sampling_active"] = True
        else:
            dataset = regular_dataset
            info["hard_negative_sampling_active"] = False

        info["regular_matched_pairs"] = total_pairs
        info["hard_negative_matched_pairs"] = len(hn_images)
        info["effective_training_pool_pairs"] = total_pairs + len(hn_images)
    else:
        dataset = _dataset_from_paths(
            image_paths, mask_paths, shuffle_and_repeat=False
        )

    if split == VAL_SPLIT:
        # Standardmaessig das komplette Validation-Set verwenden. Nur wenn
        # VALIDATION_STEPS explizit gesetzt ist, wird die Anzahl der Samples begrenzt.
        if VALIDATION_STEPS is None:
            validation_samples = total_pairs
        else:
            validation_samples = min(total_pairs, int(VALIDATION_STEPS) * BATCH)
            dataset = dataset.take(validation_samples)
        info["effective_validation_samples"] = validation_samples
        info["validation_cached"] = bool(CACHE_VALIDATION)
        if CACHE_VALIDATION:
            dataset = dataset.cache()

    drop_remainder = split == TRAIN_SPLIT
    dataset = dataset.batch(BATCH, drop_remainder=drop_remainder)
    dataset = dataset.prefetch(DATA_PREFETCH_BATCHES)

    options = tf.data.Options()
    options.experimental_deterministic = True
    options.experimental_optimization.apply_default_optimizations = True
    options.experimental_optimization.map_parallelization = True
    options.experimental_optimization.map_and_batch_fusion = True
    dataset = dataset.with_options(options)

    return dataset, total_pairs, info


# =============================================================================
# 7. MODELL: VOLLSTÄNDIGES U-NET++ MIT DICHTEN SKIP-CONNECTIONS
# =============================================================================

def conv_block(
    inputs: tf.Tensor,
    filters: int,
    name: str,
    n_convs: int = CONVS_PER_BLOCK,
) -> tf.Tensor:
    """Conv2D -> BatchNorm -> ReLU, standardmäßig zweimal pro Knoten."""
    x = inputs
    for conv_index in range(1, n_convs + 1):
        x = tf.keras.layers.Conv2D(
            filters=filters,
            kernel_size=3,
            padding="same",
            use_bias=not BATCH_NORM,
            kernel_initializer=KERNEL_INITIALIZER,
            name=f"{name}_conv{conv_index}",
        )(x)
        if BATCH_NORM:
            x = tf.keras.layers.BatchNormalization(
                name=f"{name}_bn{conv_index}"
            )(x)
        x = tf.keras.layers.Activation(
            ACTIVATION,
            name=f"{name}_{ACTIVATION}{conv_index}",
        )(x)
    return x


def upsample_to_level(
    inputs: tf.Tensor,
    filters: int,
    name: str,
) -> tf.Tensor:
    """Lernbares 2x-Upsampling in die nächsthöhere U-Net++-Ebene."""
    return tf.keras.layers.Conv2DTranspose(
        filters=filters,
        kernel_size=2,
        strides=2,
        padding="same",
        kernel_initializer=KERNEL_INITIALIZER,
        name=f"{name}_up",
    )(inputs)


def dense_decoder_node(
    same_level_nodes: list[tf.Tensor],
    deeper_node: tf.Tensor,
    filters: int,
    name: str,
) -> tf.Tensor:
    """Erzeugt X_i_j aus allen X_i_0...X_i_(j-1) und Up(X_(i+1)_(j-1))."""
    upsampled = upsample_to_level(deeper_node, filters, name)
    merged = tf.keras.layers.Concatenate(
        axis=-1,
        name=f"{name}_concat",
    )([*same_level_nodes, upsampled])
    return conv_block(merged, filters, name)


def build_unetplusplus_base() -> tf.keras.Model:
    """Vollständiges U-Net++ mit Knoten X0_0 bis X0_4."""
    inputs = tf.keras.Input(
        shape=(IMG_SIZE, IMG_SIZE, 3),
        name="unetpp_input",
    )

    # Encoderpfad X_i_0
    x0_0 = conv_block(inputs, FILTER_NUM[0], "X0_0")
    p0 = tf.keras.layers.MaxPooling2D(pool_size=2, name="pool0")(x0_0)

    x1_0 = conv_block(p0, FILTER_NUM[1], "X1_0")
    p1 = tf.keras.layers.MaxPooling2D(pool_size=2, name="pool1")(x1_0)

    x2_0 = conv_block(p1, FILTER_NUM[2], "X2_0")
    p2 = tf.keras.layers.MaxPooling2D(pool_size=2, name="pool2")(x2_0)

    x3_0 = conv_block(p2, FILTER_NUM[3], "X3_0")
    p3 = tf.keras.layers.MaxPooling2D(pool_size=2, name="pool3")(x3_0)

    x4_0 = conv_block(p3, FILTER_NUM[4], "X4_0")

    # Verschachtelte Decoderstufe j=1
    x0_1 = dense_decoder_node([x0_0], x1_0, FILTER_NUM[0], "X0_1")
    x1_1 = dense_decoder_node([x1_0], x2_0, FILTER_NUM[1], "X1_1")
    x2_1 = dense_decoder_node([x2_0], x3_0, FILTER_NUM[2], "X2_1")
    x3_1 = dense_decoder_node([x3_0], x4_0, FILTER_NUM[3], "X3_1")

    # Verschachtelte Decoderstufe j=2
    x0_2 = dense_decoder_node([x0_0, x0_1], x1_1, FILTER_NUM[0], "X0_2")
    x1_2 = dense_decoder_node([x1_0, x1_1], x2_1, FILTER_NUM[1], "X1_2")
    x2_2 = dense_decoder_node([x2_0, x2_1], x3_1, FILTER_NUM[2], "X2_2")

    # Verschachtelte Decoderstufe j=3
    x0_3 = dense_decoder_node(
        [x0_0, x0_1, x0_2],
        x1_2,
        FILTER_NUM[0],
        "X0_3",
    )
    x1_3 = dense_decoder_node(
        [x1_0, x1_1, x1_2],
        x2_2,
        FILTER_NUM[1],
        "X1_3",
    )

    # Verschachtelte Decoderstufe j=4; finale hochaufgelöste Repräsentation
    x0_4 = dense_decoder_node(
        [x0_0, x0_1, x0_2, x0_3],
        x1_3,
        FILTER_NUM[0],
        "X0_4",
    )

    logits = tf.keras.layers.Conv2D(
        filters=1,
        kernel_size=1,
        padding="same",
        activation=None,
        name="segmentation_logits",
    )(x0_4)

    return tf.keras.Model(
        inputs=inputs,
        outputs=logits,
        name="unetplusplus_model",
    )


def build_optimized_model() -> tf.keras.Model:
    base_model = build_unetplusplus_base()

    inputs = tf.keras.Input(
        shape=(IMG_SIZE, IMG_SIZE, 3),
        name="input_image",
    )
    logits = base_model(inputs)

    # float32-Ausgang für numerisch stabile Loss-/Metrikberechnung
    outputs = tf.keras.layers.Activation(
        "sigmoid",
        dtype="float32",
        name="predictions",
    )(logits)

    return tf.keras.Model(
        inputs=inputs,
        outputs=outputs,
        name="unetplusplus_training_model",
    )


# =============================================================================
# 8. LOSS UND METRIKEN
# =============================================================================

def dice_coef_soft(
    y_true: tf.Tensor,
    y_pred: tf.Tensor,
    smooth: float = 1e-7,
) -> tf.Tensor:
    y_true = tf.cast(y_true, tf.float32)
    # Im Self-Training trägt y_true beim Training drei Kanäle:
    # [Target, Source-Flag, Confidence]. Für die Dice-Metrik zählt nur Target.
    if y_true.shape.rank == 4 and y_true.shape[-1] is not None and y_true.shape[-1] > 1:
        y_true = y_true[..., :1]
    y_pred = tf.cast(y_pred, tf.float32)

    intersection = tf.reduce_sum(y_true * y_pred, axis=[1, 2, 3])
    union = tf.reduce_sum(y_true + y_pred, axis=[1, 2, 3])

    dice_per_sample = (2.0 * intersection + smooth) / (union + smooth)
    return tf.reduce_mean(dice_per_sample)


def dice_loss(y_true: tf.Tensor, y_pred: tf.Tensor) -> tf.Tensor:
    return 1.0 - dice_coef_soft(y_true, y_pred)


def binary_crossentropy_loss(y_true: tf.Tensor, y_pred: tf.Tensor) -> tf.Tensor:
    y_true = tf.cast(y_true, tf.float32)
    y_pred = tf.cast(y_pred, tf.float32)
    bce = tf.keras.backend.binary_crossentropy(y_true, y_pred)
    return tf.reduce_mean(bce)


def bce_dice_loss(y_true: tf.Tensor, y_pred: tf.Tensor) -> tf.Tensor:
    return 0.5 * binary_crossentropy_loss(y_true, y_pred) + 0.5 * dice_loss(y_true, y_pred)


def tversky_loss(
    y_true: tf.Tensor,
    y_pred: tf.Tensor,
    alpha: float = 0.3,
    beta: float = 0.7,
    smooth: float = 1e-7,
) -> tf.Tensor:
    """Tversky-Loss; beta > alpha bestraft False Negatives stärker."""
    y_true = tf.cast(y_true, tf.float32)
    y_pred = tf.cast(y_pred, tf.float32)
    tp = tf.reduce_sum(y_true * y_pred, axis=[1, 2, 3])
    fp = tf.reduce_sum((1.0 - y_true) * y_pred, axis=[1, 2, 3])
    fn = tf.reduce_sum(y_true * (1.0 - y_pred), axis=[1, 2, 3])
    tversky = (tp + smooth) / (tp + alpha * fp + beta * fn + smooth)
    return tf.reduce_mean(1.0 - tversky)


def focal_loss(
    y_true: tf.Tensor,
    y_pred: tf.Tensor,
    alpha: float = 0.75,
    gamma: float = 2.0,
    eps: float = 1e-7,
) -> tf.Tensor:
    """Binary Focal Loss; alpha=0.75 gewichtet die seltene Rissklasse stärker."""
    y_true = tf.cast(y_true, tf.float32)
    y_pred = tf.clip_by_value(tf.cast(y_pred, tf.float32), eps, 1.0 - eps)
    pt = tf.where(tf.equal(y_true, 1.0), y_pred, 1.0 - y_pred)
    alpha_t = tf.where(tf.equal(y_true, 1.0), alpha, 1.0 - alpha)
    loss = -alpha_t * tf.pow(1.0 - pt, gamma) * tf.math.log(pt)
    return tf.reduce_mean(loss)


def _soft_boundary_map(x: tf.Tensor) -> tf.Tensor:
    """Differenzierbare 1-Pixel-Randkarte über morphologischen Gradient."""
    x = tf.cast(x, tf.float32)
    dilated = tf.nn.max_pool2d(x, ksize=3, strides=1, padding="SAME")
    eroded = -tf.nn.max_pool2d(-x, ksize=3, strides=1, padding="SAME")
    return tf.clip_by_value(dilated - eroded, 0.0, 1.0)


def boundary_loss(
    y_true: tf.Tensor,
    y_pred: tf.Tensor,
    smooth: float = 1e-7,
) -> tf.Tensor:
    """Boundary-Dice-Loss auf differenzierbaren Randkarten."""
    true_b = _soft_boundary_map(y_true)
    pred_b = _soft_boundary_map(y_pred)
    intersection = tf.reduce_sum(true_b * pred_b, axis=[1, 2, 3])
    denominator = tf.reduce_sum(true_b + pred_b, axis=[1, 2, 3])
    score = (2.0 * intersection + smooth) / (denominator + smooth)
    return tf.reduce_mean(1.0 - score)


def _soft_erode(x: tf.Tensor) -> tf.Tensor:
    p1 = -tf.nn.max_pool2d(-x, ksize=(3, 1), strides=1, padding="SAME")
    p2 = -tf.nn.max_pool2d(-x, ksize=(1, 3), strides=1, padding="SAME")
    return tf.minimum(p1, p2)


def _soft_dilate(x: tf.Tensor) -> tf.Tensor:
    return tf.nn.max_pool2d(x, ksize=3, strides=1, padding="SAME")


def _soft_open(x: tf.Tensor) -> tf.Tensor:
    return _soft_dilate(_soft_erode(x))


def _soft_skeletonize(x: tf.Tensor, iterations: int = 10) -> tf.Tensor:
    """Differenzierbare Soft-Skeletonisierung nach dem clDice-Prinzip."""
    x = tf.clip_by_value(tf.cast(x, tf.float32), 0.0, 1.0)
    opened = _soft_open(x)
    skeleton = tf.nn.relu(x - opened)
    for _ in range(iterations):
        x = _soft_erode(x)
        opened = _soft_open(x)
        delta = tf.nn.relu(x - opened)
        skeleton = skeleton + tf.nn.relu(delta - skeleton * delta)
    return skeleton


def soft_skeleton_loss(
    y_true: tf.Tensor,
    y_pred: tf.Tensor,
    smooth: float = 1e-7,
) -> tf.Tensor:
    """Soft-clDice-Skeleton-Loss zur Erhaltung dünner, zusammenhängender Strukturen."""
    y_true = tf.cast(y_true, tf.float32)
    y_pred = tf.cast(y_pred, tf.float32)
    skel_true = _soft_skeletonize(y_true)
    skel_pred = _soft_skeletonize(y_pred)
    tprec = (tf.reduce_sum(skel_pred * y_true, axis=[1, 2, 3]) + smooth) / (
        tf.reduce_sum(skel_pred, axis=[1, 2, 3]) + smooth
    )
    tsens = (tf.reduce_sum(skel_true * y_pred, axis=[1, 2, 3]) + smooth) / (
        tf.reduce_sum(skel_true, axis=[1, 2, 3]) + smooth
    )
    cldice = (2.0 * tprec * tsens + smooth) / (tprec + tsens + smooth)
    return tf.reduce_mean(1.0 - cldice)


def bce_dice_soft_skeleton_loss(y_true: tf.Tensor, y_pred: tf.Tensor) -> tf.Tensor:
    return (binary_crossentropy_loss(y_true, y_pred) + dice_loss(y_true, y_pred) + soft_skeleton_loss(y_true, y_pred)) / 3.0


def focal_soft_skeleton_loss(y_true: tf.Tensor, y_pred: tf.Tensor) -> tf.Tensor:
    return 0.5 * focal_loss(y_true, y_pred) + 0.5 * soft_skeleton_loss(y_true, y_pred)


def bce_dice_boundary_loss(y_true: tf.Tensor, y_pred: tf.Tensor) -> tf.Tensor:
    return (binary_crossentropy_loss(y_true, y_pred) + dice_loss(y_true, y_pred) + boundary_loss(y_true, y_pred)) / 3.0


def bce_dice_focal_loss(y_true: tf.Tensor, y_pred: tf.Tensor) -> tf.Tensor:
    return (binary_crossentropy_loss(y_true, y_pred) + dice_loss(y_true, y_pred) + focal_loss(y_true, y_pred)) / 3.0


# =============================================================================
# SELF-TRAINING-HILFSFUNKTIONEN
# =============================================================================

def list_unlabeled_images() -> list[Path]:
    if not UNLABELED_DIR.is_dir():
        raise FileNotFoundError(
            f"UNLABELED_DIR existiert nicht: {UNLABELED_DIR}. "
            "Passe den Pfad in der Konfiguration an."
        )
    paths = sorted(
        p for p in UNLABELED_DIR.rglob("*")
        if p.is_file() and p.suffix.lower() in UNLABELED_EXTENSIONS
    )
    if not paths:
        raise RuntimeError(f"Keine ungelabelten Bilder in {UNLABELED_DIR} gefunden.")
    return paths


def build_pseudo_cache_signature(
    model_paths: Iterable[Path],
    extra: dict[str, Any],
) -> tuple[dict[str, Any], list[Path]]:
    """Erzeugt eine reproduzierbare Signatur für den Offline-Pseudo-Cache.

    Dadurch wird ein alter Cache nicht stillschweigend weiterverwendet, wenn sich
    Teacher-Dateien, Confidence-/Threshold-Konfiguration oder die ungelabelten
    Eingangsdaten geändert haben. Für große Modelldateien werden Größe und mtime_ns
    statt eines vollständigen Datei-Hashes verwendet.
    """
    unlabeled_paths = list_unlabeled_images()

    model_identity = []
    for model_path in model_paths:
        resolved = Path(model_path).resolve()
        if not resolved.is_file():
            raise FileNotFoundError(f"Teacher-Modell fehlt: {resolved}")
        stat = resolved.stat()
        model_identity.append({
            "path": str(resolved),
            "size": int(stat.st_size),
            "mtime_ns": int(stat.st_mtime_ns),
        })

    unlabeled_identity = []
    root = UNLABELED_DIR.resolve()
    for image_path in unlabeled_paths:
        resolved = image_path.resolve()
        stat = resolved.stat()
        try:
            relative = str(resolved.relative_to(root))
        except ValueError:
            relative = str(resolved)
        unlabeled_identity.append({
            "path": relative,
            "size": int(stat.st_size),
            "mtime_ns": int(stat.st_mtime_ns),
        })

    payload = {
        "schema_version": 3,
        "teacher_type": TEACHER_TYPE,
        "confidence_odds_ratio": PSEUDO_CONFIDENCE_ODDS_RATIO,
        "patch_confidence_threshold": PSEUDO_PATCH_CONFIDENCE_THRESHOLD,
        "pixel_confidence_threshold": PSEUDO_PIXEL_CONFIDENCE_THRESHOLD,
        "min_confident_pixel_fraction": PSEUDO_MIN_CONFIDENT_PIXEL_FRACTION,
        "min_positive_pixels": PSEUDO_MIN_POSITIVE_PIXELS,
        "models": model_identity,
        "unlabeled": unlabeled_identity,
        "extra": json_safe(extra),
    }
    canonical = json.dumps(payload, sort_keys=True, separators=(",", ":"), ensure_ascii=False)
    return {"digest": hashlib.sha256(canonical.encode("utf-8")).hexdigest(), "payload": payload}, unlabeled_paths


def read_matching_pseudo_cache(signature: dict[str, Any]) -> list[dict[str, Any]]:
    if not (PSEUDO_CACHE_SIGNATURE_FILE.is_file() and PSEUDO_MANIFEST_FILE.is_file()):
        return []
    try:
        with PSEUDO_CACHE_SIGNATURE_FILE.open("r", encoding="utf-8") as file:
            cached_signature = json.load(file)
    except Exception:
        return []
    if cached_signature.get("digest") != signature.get("digest"):
        print("Pseudo-Cache-Signatur geändert -> Pseudo-Labels werden neu erzeugt.")
        return []
    return read_pseudo_manifest()


def write_pseudo_cache_signature(signature: dict[str, Any]) -> None:
    write_json_atomic(PSEUDO_CACHE_SIGNATURE_FILE, signature)


def load_image_rgb_cv(path: Path) -> np.ndarray:
    image_bgr = cv2.imread(str(path), cv2.IMREAD_COLOR)
    if image_bgr is None:
        raise ValueError(f"Bild konnte nicht gelesen werden: {path}")
    return cv2.cvtColor(image_bgr, cv2.COLOR_BGR2RGB)


def validate_unlabeled_sample(image: np.ndarray, path: Path) -> None:
    """Unlabeled-Samples müssen bereits fertige IMG_SIZE x IMG_SIZE Patches sein."""
    if image.ndim != 3 or image.shape[2] != 3:
        raise ValueError(f"Ungültiges RGB-Bild {path}: shape={image.shape}")
    if image.shape[0] != IMG_SIZE or image.shape[1] != IMG_SIZE:
        raise ValueError(
            f"Unlabeled-Bild hat nicht {IMG_SIZE}x{IMG_SIZE} px: {path} | "
            f"shape={image.shape}. Dieses Dataset darf hier nicht erneut gepatcht/resized werden."
        )


def extract_patches_cv(image: np.ndarray, patch_size: int = IMG_SIZE, overlap: int = 0):
    h, w, _ = image.shape
    stride = patch_size - overlap
    if stride <= 0:
        raise ValueError("overlap muss kleiner als patch_size sein.")
    y_positions = list(range(0, max(h - patch_size + 1, 1), stride))
    x_positions = list(range(0, max(w - patch_size + 1, 1), stride))
    if not y_positions or y_positions[-1] != max(h - patch_size, 0):
        y_positions.append(max(h - patch_size, 0))
    if not x_positions or x_positions[-1] != max(w - patch_size, 0):
        x_positions.append(max(w - patch_size, 0))

    patches, positions = [], []
    for y in y_positions:
        for x in x_positions:
            patch = image[y:y + patch_size, x:x + patch_size]
            ph, pw = patch.shape[:2]
            if ph < patch_size or pw < patch_size:
                padded = np.zeros((patch_size, patch_size, 3), dtype=image.dtype)
                padded[:ph, :pw] = patch
                patch = padded
            patches.append(patch)
            positions.append((x, y, pw, ph))
    return patches, positions


def stable_patch_prefix(image_path: Path, patch_index: int) -> str:
    try:
        relative = image_path.resolve().relative_to(UNLABELED_DIR.resolve())
        key = str(relative)
    except Exception:
        key = str(image_path.resolve())
    digest = hashlib.sha1(key.encode("utf-8")).hexdigest()[:12]
    return f"{image_path.stem}_{digest}_p{patch_index:05d}"


def save_rgb_png(path: Path, image_rgb: np.ndarray) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    image_bgr = cv2.cvtColor(image_rgb.astype(np.uint8), cv2.COLOR_RGB2BGR)
    if not cv2.imwrite(str(path), image_bgr):
        raise IOError(f"Bild konnte nicht gespeichert werden: {path}")


def save_mask_u8(path: Path, mask: np.ndarray) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    data = (np.asarray(mask) > 0).astype(np.uint8) * 255
    if not cv2.imwrite(str(path), data):
        raise IOError(f"Maske konnte nicht gespeichert werden: {path}")


def save_probability_u16(path: Path, probability: np.ndarray) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    data = np.clip(np.asarray(probability, dtype=np.float32), 0.0, 1.0)
    data = np.rint(data * 65535.0).astype(np.uint16)
    if not cv2.imwrite(str(path), data):
        raise IOError(f"Probability-Map konnte nicht gespeichert werden: {path}")


def compute_decision_confidence_map(
    probability: np.ndarray,
    decision_threshold: float | np.ndarray,
) -> np.ndarray:
    """Pixelweise Confidence als Abstand zur realen Entscheidungsgrenze im Log-Odds-Raum."""
    eps = np.float32(1e-7)
    p = np.clip(np.asarray(probability, dtype=np.float32), eps, 1.0 - eps)
    t = np.asarray(decision_threshold, dtype=np.float32)
    if t.ndim == 0:
        t = np.full_like(p, float(t), dtype=np.float32)
    else:
        t = np.broadcast_to(t, p.shape).astype(np.float32, copy=False)
    t = np.clip(t, eps, 1.0 - eps)

    logit_p = np.log(p) - np.log1p(-p)
    logit_t = np.log(t) - np.log1p(-t)
    required_margin = max(float(np.log(PSEUDO_CONFIDENCE_ODDS_RATIO)), 1e-6)
    return np.clip(np.abs(logit_p - logit_t) / required_margin, 0.0, 1.0).astype(np.float32)


def compute_patch_confidence(
    probability: np.ndarray,
    decision_threshold: float | np.ndarray,
) -> dict[str, float]:
    """Decision-aware, class-balanced Pseudo-Label-Confidence.

    Positive und negative Pixel werden bei positiven Patches gleich gewichtet, damit
    der große Hintergrundanteil die Unsicherheit an Risspixeln nicht überdeckt.
    """
    eps = np.float32(1e-7)
    p = np.clip(np.asarray(probability, dtype=np.float32), eps, 1.0 - eps)
    t = np.asarray(decision_threshold, dtype=np.float32)
    if t.ndim == 0:
        t = np.full_like(p, float(t), dtype=np.float32)
    else:
        t = np.broadcast_to(t, p.shape).astype(np.float32, copy=False)
    t = np.clip(t, eps, 1.0 - eps)
    pixel_confidence = compute_decision_confidence_map(p, t)

    predicted_positive = p >= t
    predicted_negative = ~predicted_positive

    def _stats(mask: np.ndarray) -> tuple[float, float]:
        if not np.any(mask):
            return float("nan"), float("nan")
        values = pixel_confidence[mask]
        return (
            float(np.mean(values)),
            float(np.mean(values >= PSEUDO_PIXEL_CONFIDENCE_THRESHOLD)),
        )

    pos_mean, pos_fraction = _stats(predicted_positive)
    neg_mean, neg_fraction = _stats(predicted_negative)

    if np.any(predicted_positive) and np.any(predicted_negative):
        mean_confidence = 0.5 * (pos_mean + neg_mean)
        confident_fraction = 0.5 * (pos_fraction + neg_fraction)
    elif np.any(predicted_positive):
        mean_confidence, confident_fraction = pos_mean, pos_fraction
    else:
        mean_confidence, confident_fraction = neg_mean, neg_fraction

    return {
        "confidence": float(mean_confidence),
        "confident_fraction": float(confident_fraction),
        "positive_confidence": float(pos_mean),
        "positive_confident_fraction": float(pos_fraction),
        "negative_confidence": float(neg_mean),
        "negative_confident_fraction": float(neg_fraction),
        "uncertain_fraction": float(np.mean(pixel_confidence < PSEUDO_PIXEL_CONFIDENCE_THRESHOLD)),
    }


def filter_positive_pseudo_records(records: list[dict[str, Any]]) -> list[dict[str, Any]]:
    """Behält nur Pseudo-Samples mit erkanntem Riss.

    Das Unlabeled-Dataset ist nach Vorwissen praktisch vollständig risspositiv. Leere
    Teacher-Masken werden daher als potenzielle Teacher-False-Negatives verworfen und
    ausdrücklich nicht als negative Trainingsbeispiele genutzt.
    """
    positive = [
        row for row in records
        if int(row["positive_pixels"]) >= PSEUDO_MIN_POSITIVE_PIXELS
    ]
    rng = random.Random(SEED)
    rng.shuffle(positive)
    return positive


def write_pseudo_manifest(records: list[dict[str, Any]]) -> None:
    PSEUDO_CACHE_DIR.mkdir(parents=True, exist_ok=True)
    if not records:
        raise RuntimeError("Keine Pseudo-Labels haben die Confidence-Filter passiert.")
    fieldnames = list(records[0].keys())
    with PSEUDO_MANIFEST_FILE.open("w", encoding="utf-8", newline="") as file:
        writer = csv.DictWriter(file, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(records)


def read_pseudo_manifest() -> list[dict[str, Any]]:
    if not PSEUDO_MANIFEST_FILE.is_file():
        return []
    with PSEUDO_MANIFEST_FILE.open("r", encoding="utf-8", newline="") as file:
        rows = list(csv.DictReader(file))
    valid = []
    for row in rows:
        confidence_path = row.get("confidence_path", "")
        if (
            Path(row["image_path"]).is_file()
            and Path(row["target_path"]).is_file()
            and confidence_path
            and Path(confidence_path).is_file()
        ):
            valid.append(row)
    return valid


def pack_ground_truth(image: tf.Tensor, mask: tf.Tensor) -> tuple[tf.Tensor, tf.Tensor]:
    mask = tf.cast(mask, tf.float32)
    source = tf.zeros_like(mask, dtype=tf.float32)
    confidence = tf.ones_like(mask, dtype=tf.float32)
    packed = tf.concat([mask, source, confidence], axis=-1)
    packed.set_shape([IMG_SIZE, IMG_SIZE, 3])
    return image, packed


def build_ground_truth_stream() -> tuple[tf.data.Dataset, int, dict[str, Any]]:
    image_paths, mask_paths, info = collect_image_mask_pairs(TRAIN_SPLIT)
    total_pairs = len(image_paths)
    regular = _dataset_from_paths(image_paths, mask_paths, shuffle_and_repeat=True)

    hn_images, hn_masks, hn_info = collect_hard_negative_pairs(TRAIN_SPLIT)
    info["hard_negatives"] = hn_info
    info["hard_negative_target_share"] = HARD_NEGATIVE_TARGET_SHARE
    if HARD_NEGATIVE_TARGET_SHARE > 0.0:
        if not 0.0 < HARD_NEGATIVE_TARGET_SHARE < 1.0:
            raise ValueError("HARD_NEGATIVE_TARGET_SHARE muss zwischen 0 und 1 liegen.")
        if not hn_images:
            raise RuntimeError("Hard-Negative-Sampling aktiviert, aber keine HN-Paare gefunden.")
        hn = _dataset_from_paths(hn_images, hn_masks, shuffle_and_repeat=True)
        stream = tf.data.Dataset.sample_from_datasets(
            [regular, hn],
            weights=[1.0 - HARD_NEGATIVE_TARGET_SHARE, HARD_NEGATIVE_TARGET_SHARE],
            seed=SEED,
            stop_on_empty_dataset=False,
        )
        info["hard_negative_sampling_active"] = True
    else:
        stream = regular
        info["hard_negative_sampling_active"] = False

    info["regular_matched_pairs"] = total_pairs
    info["hard_negative_matched_pairs"] = len(hn_images)
    info["effective_training_pool_pairs"] = total_pairs + len(hn_images)
    stream = stream.map(pack_ground_truth, num_parallel_calls=DATA_NUM_PARALLEL_CALLS, deterministic=True)
    return stream, total_pairs, info


def load_pseudo_image(path: tf.Tensor) -> tf.Tensor:
    image = tf.io.read_file(path)
    image = tf.image.decode_png(image, channels=3)
    image = tf.image.convert_image_dtype(image, tf.float32)
    image.set_shape([IMG_SIZE, IMG_SIZE, 3])
    return image


def _load_hard_pseudo_target(path: tf.Tensor) -> tf.Tensor:
    target = tf.io.read_file(path)
    target = tf.image.decode_png(target, channels=1)
    target = tf.cast(target > 127, tf.float32)
    target.set_shape([IMG_SIZE, IMG_SIZE, 1])
    return target


def _load_probability_u16(path: tf.Tensor) -> tf.Tensor:
    target = tf.io.read_file(path)
    target = tf.io.decode_png(target, channels=1, dtype=tf.uint16)
    target = tf.cast(target, tf.float32) / 65535.0
    target.set_shape([IMG_SIZE, IMG_SIZE, 1])
    return target


def _load_soft_pseudo_target(path: tf.Tensor) -> tf.Tensor:
    return _load_probability_u16(path)


def build_pseudo_stream(records: list[dict[str, Any]], soft_targets: bool) -> tf.data.Dataset:
    image_paths = [row["image_path"] for row in records]
    target_paths = [row["target_path"] for row in records]
    confidence_paths = [row["confidence_path"] for row in records]

    dataset = tf.data.Dataset.from_tensor_slices((image_paths, target_paths, confidence_paths))
    dataset = dataset.shuffle(len(records), seed=SEED, reshuffle_each_iteration=True).repeat()

    def load(image_path, target_path, confidence_path):
        image = load_pseudo_image(image_path)
        target = _load_soft_pseudo_target(target_path) if soft_targets else _load_hard_pseudo_target(target_path)
        source = tf.ones_like(target, dtype=tf.float32)
        confidence_map = _load_probability_u16(confidence_path)
        packed = tf.concat([target, source, confidence_map], axis=-1)
        packed.set_shape([IMG_SIZE, IMG_SIZE, 3])
        return image, packed

    return dataset.map(load, num_parallel_calls=DATA_NUM_PARALLEL_CALLS, deterministic=True)



# Die fruehere probabilistische Curriculum-Dataset-Funktion wurde entfernt.
# Dieses Skript baut pro Epoche einen endlichen Datensatz mit exakt geplanter
# Anzahl GT- und Pseudo-Samples.


def tversky_loss_per_sample(
    y_true: tf.Tensor,
    y_pred: tf.Tensor,
    pixel_weight: tf.Tensor | None = None,
    alpha: float = 0.3,
    beta: float = 0.7,
    smooth: float = 1e-7,
) -> tf.Tensor:
    y_true = tf.cast(y_true, tf.float32)
    y_pred = tf.cast(y_pred, tf.float32)
    if pixel_weight is None:
        weight = tf.ones_like(y_true, dtype=tf.float32)
    else:
        weight = tf.clip_by_value(tf.cast(pixel_weight, tf.float32), 0.0, 1.0)
    tp = tf.reduce_sum(weight * y_true * y_pred, axis=[1, 2, 3])
    fp = tf.reduce_sum(weight * (1.0 - y_true) * y_pred, axis=[1, 2, 3])
    fn = tf.reduce_sum(weight * y_true * (1.0 - y_pred), axis=[1, 2, 3])
    score = (tp + smooth) / (tp + alpha * fp + beta * fn + smooth)
    return 1.0 - score


def pseudo_share_for_epoch(epoch_number: int) -> float:
    """1-basierte Epoche -> exakter Pseudo-Anteil der Epoche."""
    if epoch_number < PSEUDO_START_EPOCH:
        return 0.0
    share = PSEUDO_START_SHARE + (epoch_number - PSEUDO_START_EPOCH) * PSEUDO_SHARE_INCREMENT
    return float(min(PSEUDO_MAX_SAMPLING_SHARE, share))


def pseudo_count_for_epoch(epoch_number: int) -> int:
    return int(round(SAMPLES_PER_EPOCH * pseudo_share_for_epoch(epoch_number)))


def clear_current_pseudo_cache() -> None:
    """Nur die Targets der aktuell bevorstehenden Epoche werden vorgehalten."""
    for directory in (PSEUDO_TARGET_DIR, PSEUDO_CONFIDENCE_DIR):
        if directory.exists():
            shutil.rmtree(directory)
        directory.mkdir(parents=True, exist_ok=True)


def build_finite_pseudo_stream(records: list[dict[str, Any]]) -> tf.data.Dataset:
    if not records:
        raise ValueError("build_finite_pseudo_stream benötigt mindestens einen Record.")
    image_paths = [row["image_path"] for row in records]
    target_paths = [row["target_path"] for row in records]
    confidence_paths = [row["confidence_path"] for row in records]
    dataset = tf.data.Dataset.from_tensor_slices((image_paths, target_paths, confidence_paths))

    def load(image_path, target_path, confidence_path):
        image = load_pseudo_image(image_path)
        target = _load_hard_pseudo_target(target_path)
        source = tf.ones_like(target, dtype=tf.float32)
        confidence_map = _load_probability_u16(confidence_path)
        packed = tf.concat([target, source, confidence_map], axis=-1)
        packed.set_shape([IMG_SIZE, IMG_SIZE, 3])
        return image, packed

    return dataset.map(load, num_parallel_calls=DATA_NUM_PARALLEL_CALLS, deterministic=True)


def build_exact_epoch_dataset(
    gt_stream: tf.data.Dataset,
    pseudo_records: list[dict[str, Any]],
    epoch_number: int,
) -> tf.data.Dataset:
    """Erzeugt exakt STEPS_PER_EPOCH * BATCH Samples mit exakt geplantem Pseudo-Anteil."""
    pseudo_count = len(pseudo_records)
    gt_count = SAMPLES_PER_EPOCH - pseudo_count
    if gt_count < 0:
        raise ValueError("Mehr Pseudo-Samples als Samples pro Epoche angefordert.")

    epoch_ds = gt_stream.take(gt_count)
    if pseudo_count:
        pseudo_ds = build_finite_pseudo_stream(pseudo_records)
        epoch_ds = epoch_ds.concatenate(pseudo_ds)

    epoch_ds = epoch_ds.shuffle(
        buffer_size=min(EPOCH_SHUFFLE_BUFFER, SAMPLES_PER_EPOCH),
        seed=SEED + int(epoch_number),
        reshuffle_each_iteration=False,
    )
    epoch_ds = epoch_ds.batch(BATCH, drop_remainder=True).prefetch(DATA_PREFETCH_BATCHES)
    options = tf.data.Options()
    options.experimental_deterministic = True
    options.experimental_optimization.apply_default_optimizations = True
    return epoch_ds.with_options(options)


def generate_online_pseudo_labels(
    teacher_model: tf.keras.Model,
    unlabeled_paths: list[Path],
    cursor: int,
    target_count: int,
    epoch_number: int,
) -> tuple[list[dict[str, Any]], int, dict[str, int]]:
    """
    Labelt zyklisch nur so viele neue Unlabeled-Samples, bis target_count akzeptierte
    Pseudolabels für die kommende Epoche vorliegen. Der Teacher ist das Modell vom Ende
    der vorherigen Epoche. Leere Targets werden wegen des nahezu vollständig
    risspositiven Unlabeled-Pools verworfen und nicht als Negative trainiert.
    """
    if target_count <= 0:
        return [], cursor, {"attempted": 0, "rejected_confidence": 0, "rejected_no_crack": 0, "wraps": 0}
    if not unlabeled_paths:
        raise RuntimeError(f"Keine ungelabelten Bilder in {UNLABELED_DIR} gefunden.")

    clear_current_pseudo_cache()
    accepted: list[dict[str, Any]] = []
    attempted = rejected_confidence = rejected_no_crack = wraps = 0
    n = len(unlabeled_paths)
    # Schutz gegen eine Konfiguration, bei der praktisch nichts akzeptiert wird.
    max_attempts = max(n * 2, target_count * 20)

    while len(accepted) < target_count and attempted < max_attempts:
        remaining = target_count - len(accepted)
        request = min(PSEUDO_INFERENCE_BATCH_SIZE, remaining)
        batch_paths: list[Path] = []
        for _ in range(request):
            if cursor >= n:
                cursor = 0
                wraps += 1
            batch_paths.append(unlabeled_paths[cursor])
            cursor += 1

        batch_images: list[np.ndarray] = []
        for image_path in batch_paths:
            image_rgb = load_image_rgb_cv(image_path)
            validate_unlabeled_sample(image_rgb, image_path)
            batch_images.append(image_rgb)

        batch = np.asarray(batch_images, dtype=np.float32) / 255.0
        predictions = np.asarray(teacher_model.predict(batch, verbose=0), dtype=np.float32)
        if predictions.ndim == 3:
            predictions = predictions[..., None]

        for image_path, pred in zip(batch_paths, predictions):
            attempted += 1
            prob = np.clip(pred[..., 0], 0.0, 1.0)
            hard_mask = (prob >= SINGLE_TEACHER_MASK_THRESHOLD).astype(np.uint8)
            positive_pixels = int(hard_mask.sum())
            if positive_pixels < PSEUDO_MIN_POSITIVE_PIXELS:
                rejected_no_crack += 1
                continue

            stats = compute_patch_confidence(prob, SINGLE_TEACHER_MASK_THRESHOLD)
            confidence = stats["confidence"]
            confident_fraction = stats["confident_fraction"]
            if (
                confidence < PSEUDO_PATCH_CONFIDENCE_THRESHOLD
                or confident_fraction < PSEUDO_MIN_CONFIDENT_PIXEL_FRACTION
            ):
                rejected_confidence += 1
                continue

            pixel_confidence = compute_decision_confidence_map(
                prob, SINGLE_TEACHER_MASK_THRESHOLD
            ) * np.float32(confidence)

            prefix = stable_patch_prefix(image_path, 0)
            target_out = PSEUDO_TARGET_DIR / f"{prefix}.png"
            confidence_out = PSEUDO_CONFIDENCE_DIR / f"{prefix}.png"
            save_mask_u8(target_out, hard_mask)
            save_probability_u16(confidence_out, pixel_confidence)
            accepted.append({
                # Originalbild direkt referenzieren: keine unnötige Bildkopie.
                "image_path": str(image_path),
                "target_path": str(target_out),
                "confidence_path": str(confidence_out),
                "source_image": str(image_path),
                "patch_index": 0,
                "epoch_generated": epoch_number,
                "confidence": f"{confidence:.8f}",
                "confident_fraction": f"{confident_fraction:.8f}",
                "positive_confidence": f"{stats['positive_confidence']:.8f}",
                "positive_confident_fraction": f"{stats['positive_confident_fraction']:.8f}",
                "negative_confidence": f"{stats['negative_confidence']:.8f}",
                "negative_confident_fraction": f"{stats['negative_confident_fraction']:.8f}",
                "uncertain_fraction": f"{stats['uncertain_fraction']:.8f}",
                "positive_pixels": positive_pixels,
                "target_type": "hard",
            })

    if len(accepted) < target_count:
        raise RuntimeError(
            f"Epoche {epoch_number}: Nur {len(accepted)}/{target_count} benötigten "
            f"Pseudo-Samples akzeptiert nach {attempted} Versuchen. "
            "Confidence-Filter/Decision-Threshold prüfen."
        )

    write_pseudo_manifest(accepted)
    stats_out = {
        "attempted": attempted,
        "rejected_confidence": rejected_confidence,
        "rejected_no_crack": rejected_no_crack,
        "wraps": wraps,
    }
    return accepted, cursor, stats_out


def write_self_training_config(extra: dict[str, Any]) -> None:
    payload = {
        "teacher_type": TEACHER_TYPE,
        "unlabeled_dir": str(UNLABELED_DIR),
        "pseudo_cache_dir": str(PSEUDO_CACHE_DIR),
        "schedule": {
            "first_pseudo_epoch": PSEUDO_START_EPOCH,
            "start_share": PSEUDO_START_SHARE,
            "increment_per_epoch": PSEUDO_SHARE_INCREMENT,
            "max_share": PSEUDO_MAX_SAMPLING_SHARE,
            "samples_per_epoch": SAMPLES_PER_EPOCH,
        },
        "confidence": {
            "decision_threshold": SINGLE_TEACHER_MASK_THRESHOLD,
            "patch_threshold": PSEUDO_PATCH_CONFIDENCE_THRESHOLD,
            "pixel_threshold": PSEUDO_PIXEL_CONFIDENCE_THRESHOLD,
            "min_confident_pixel_fraction": PSEUDO_MIN_CONFIDENT_PIXEL_FRACTION,
        },
        **extra,
    }
    write_json_atomic(SELF_TRAINING_CONFIG_FILE, payload)


@tf.keras.utils.register_keras_serializable(package="crack_self_training")
def self_training_loss(y_true_packed: tf.Tensor, y_pred: tf.Tensor) -> tf.Tensor:
    target = tf.cast(y_true_packed[..., :1], tf.float32)
    source_map = tf.cast(y_true_packed[..., 1:2], tf.float32)
    confidence_map = tf.clip_by_value(tf.cast(y_true_packed[..., 2:3], tf.float32), 0.0, 1.0)
    source = tf.reduce_mean(source_map, axis=[1, 2, 3])
    mean_confidence = tf.reduce_mean(confidence_map, axis=[1, 2, 3])

    # GT hat confidence=1. Pseudo-Pixel nahe der Teacher-Entscheidungsgrenze
    # werden innerhalb des Tversky-Loss gezielt heruntergewichtet.
    per_sample = tversky_loss_per_sample(target, y_pred, pixel_weight=confidence_map)
    pseudo_weight = tf.cast(PSEUDO_LOSS_WEIGHT, tf.float32) * mean_confidence
    effective_weight = (1.0 - source) + source * pseudo_weight
    return tf.reduce_mean(per_sample * effective_weight)

def compute_confusion_from_binary(
    y_true_binary: np.ndarray,
    y_pred_binary: np.ndarray,
) -> tuple[int, int, int, int]:
    y_true_bool = y_true_binary.astype(bool)
    y_pred_bool = y_pred_binary.astype(bool)

    true_positive = int(np.logical_and(y_true_bool, y_pred_bool).sum())
    false_positive = int(np.logical_and(~y_true_bool, y_pred_bool).sum())
    false_negative = int(np.logical_and(y_true_bool, ~y_pred_bool).sum())
    true_negative = int(np.logical_and(~y_true_bool, ~y_pred_bool).sum())

    return true_positive, false_positive, false_negative, true_negative


def compute_fg_metrics_from_confusion(
    true_positive: int,
    false_positive: int,
    false_negative: int,
    true_negative: int,
) -> dict[str, float]:
    precision = safe_div(true_positive, true_positive + false_positive)
    recall = safe_div(true_positive, true_positive + false_negative)
    dice = safe_div(
        2 * true_positive,
        2 * true_positive + false_positive + false_negative,
    )
    iou = safe_div(
        true_positive,
        true_positive + false_positive + false_negative,
    )
    f1 = safe_div(2 * precision * recall, precision + recall)

    # F2 gewichtet Recall stärker als Precision. Das passt zur Zielsetzung,
    # Risspixel möglichst vollständig zu erfassen und FN stärker zu bestrafen.
    beta2 = 4.0
    f2 = safe_div((1.0 + beta2) * precision * recall, beta2 * precision + recall)

    # Klassenbalancierte Fehlermetriken. FPR und FNR werden jeweils innerhalb
    # ihrer Ground-Truth-Klasse normiert; Balanced Error gewichtet beide Klassen gleich.
    false_positive_rate = safe_div(false_positive, false_positive + true_negative)
    false_negative_rate = safe_div(false_negative, false_negative + true_positive)
    balanced_error = 0.5 * (false_positive_rate + false_negative_rate)
    balanced_accuracy = 1.0 - balanced_error

    return {
        "precision_fg": precision,
        "recall_fg": recall,
        "dice_fg": dice,
        "iou_fg": iou,
        "f1_fg": f1,
        "f2_fg": f2,
        "false_positive_rate": false_positive_rate,
        "false_negative_rate": false_negative_rate,
        "balanced_error": balanced_error,
        "balanced_accuracy": balanced_accuracy,
    }


def update_threshold_confusions(
    y_true_binary: np.ndarray,
    y_pred_probability: np.ndarray,
    thresholds: np.ndarray,
    true_positive: np.ndarray,
    false_positive: np.ndarray,
    false_negative: np.ndarray,
) -> None:
    """Akkumuliert TP/FP/FN für jede Konfidenzschwelle.

    Vorher: Python-for-Schleife über alle 101 Schwellen, die pro Schwelle
    mehrere volle Arrayoperationen über alle Pixel eines Batches ausgeführt
    hat (compute_confusion_from_binary). Bei VALIDATION_STEPS=250 und zwei
    Aufrufen pro Batch (Vordergrund + Hintergrund) ergab das rund 50.000
    einzelne Python-/NumPy-Aufrufe pro Epoche – das war der dominante
    Zeitfresser.

    Jetzt: einmal sortieren + np.searchsorted (Vektorbinärsuche über alle
    Schwellen gleichzeitig). Liefert exakt dieselben TP/FP/FN-Werte, aber in
    O(N log N + T log N) statt O(T · N) und ohne Python-Schleife.
    """
    y_true_flat = y_true_binary.reshape(-1).astype(bool)
    y_score_flat = y_pred_probability.reshape(-1).astype(np.float32)

    positive_scores = np.sort(y_score_flat[y_true_flat])
    negative_scores = np.sort(y_score_flat[~y_true_flat])

    total_positive = positive_scores.size

    # Anzahl Scores >= threshold = N - Einfügeindex im aufsteigend
    # sortierten Array (side="left" passt zum ">="-Vergleich des Originals).
    tp_counts = total_positive - np.searchsorted(positive_scores, thresholds, side="left")
    fp_counts = negative_scores.size - np.searchsorted(negative_scores, thresholds, side="left")

    true_positive += tp_counts
    false_positive += fp_counts
    false_negative += (total_positive - tp_counts)


def compute_ap_from_threshold_confusions(
    true_positive: np.ndarray,
    false_positive: np.ndarray,
    false_negative: np.ndarray,
) -> float:
    """
    Pixelweise interpolierte Average Precision aus der globalen PR-Kurve.
    """
    total_positives = float(np.max(true_positive + false_negative))
    if total_positives <= 0:
        return float("nan")

    predicted_positives = true_positive + false_positive
    precision = np.divide(
        true_positive,
        predicted_positives,
        out=np.ones_like(true_positive, dtype=np.float64),
        where=predicted_positives > 0,
    )
    recall = true_positive / total_positives

    order = np.argsort(recall)
    recall = recall[order]
    precision = precision[order]

    # Doppelte Recall-Werte zusammenfassen: je Recall den höchsten Precision-Wert.
    unique_recall, inverse = np.unique(recall, return_inverse=True)
    max_precision = np.zeros_like(unique_recall, dtype=np.float64)
    for index, precision_value in zip(inverse, precision):
        max_precision[index] = max(max_precision[index], precision_value)

    recall = np.concatenate(([0.0], unique_recall, [1.0]))
    precision = np.concatenate(
        ([max_precision[0] if max_precision.size else 0.0], max_precision, [0.0])
    )

    # Monotone Precision-Hüllkurve
    for index in range(precision.size - 2, -1, -1):
        precision[index] = max(precision[index], precision[index + 1])

    return float(np.sum((recall[1:] - recall[:-1]) * precision[1:]))


def compute_roc_auc_from_threshold_confusions(
    true_positive: np.ndarray,
    false_positive: np.ndarray,
    false_negative: np.ndarray,
    true_negative: np.ndarray,
) -> float:
    """ROC-AUC aus einer globalen, gleichmäßig aufgelösten Threshold-Kurve."""
    positives = true_positive + false_negative
    negatives = false_positive + true_negative

    tpr = np.divide(
        true_positive,
        positives,
        out=np.zeros_like(true_positive, dtype=np.float64),
        where=positives > 0,
    )
    fpr = np.divide(
        false_positive,
        negatives,
        out=np.zeros_like(false_positive, dtype=np.float64),
        where=negatives > 0,
    )

    # Arrays liegen nach aufsteigendem Threshold vor. Für die Kurve wird von
    # streng nach locker ausgewertet, sodass FPR und TPR monoton ansteigen.
    tpr = tpr[::-1]
    fpr = fpr[::-1]
    tpr = np.concatenate(([0.0], tpr, [1.0]))
    fpr = np.concatenate(([0.0], fpr, [1.0]))

    order = np.argsort(fpr, kind="stable")
    return float(np.trapezoid(tpr[order], fpr[order]))


def compute_pr_auc_from_threshold_confusions(
    true_positive: np.ndarray,
    false_positive: np.ndarray,
    false_negative: np.ndarray,
) -> float:
    """PR-AUC als Trapezfläche über der globalen Precision-Recall-Kurve."""
    predicted_positive = true_positive + false_positive
    positives = true_positive + false_negative

    precision = np.divide(
        true_positive,
        predicted_positive,
        out=np.ones_like(true_positive, dtype=np.float64),
        where=predicted_positive > 0,
    )
    recall = np.divide(
        true_positive,
        positives,
        out=np.zeros_like(true_positive, dtype=np.float64),
        where=positives > 0,
    )

    precision = precision[::-1]
    recall = recall[::-1]
    recall = np.concatenate(([0.0], recall))
    precision = np.concatenate(([1.0], precision))

    order = np.argsort(recall, kind="stable")
    recall = recall[order]
    precision = precision[order]

    unique_recall, inverse = np.unique(recall, return_inverse=True)
    max_precision = np.zeros_like(unique_recall, dtype=np.float64)
    for index, precision_value in zip(inverse, precision):
        max_precision[index] = max(max_precision[index], precision_value)

    return float(np.trapezoid(max_precision, unique_recall))


# =============================================================================
# 9. PLOTS
# =============================================================================

def save_plot(
    x_values: list[int],
    y_series: list[list[float]],
    labels: list[str],
    title: str,
    y_label: str,
    output_path: Path,
    y_limits: tuple[float, float] | None = None,
) -> None:
    plt.figure(figsize=(11, 6.5))
    for values, label in zip(y_series, labels):
        plt.plot(x_values, values, label=label)
    plt.xlabel("Epoche")
    plt.ylabel(y_label)
    plt.title(title)
    plt.grid(True, alpha=0.3)
    if y_limits is not None:
        plt.ylim(*y_limits)
    plt.legend(loc="best")
    plt.tight_layout()
    plt.savefig(output_path, dpi=200)
    plt.close()


def save_training_plots(
    history_rows: list[dict[str, float]],
    plot_dir: Path,
) -> None:
    plot_dir.mkdir(parents=True, exist_ok=True)
    if not history_rows:
        return

    epochs = [int(row["epoch"]) for row in history_rows]

    def values(field: str) -> list[float]:
        return [float(row[field]) for row in history_rows]

    def dynamic_lower(series: list[list[float]], upper: float) -> tuple[float, float]:
        finite = [v for seq in series for v in seq if np.isfinite(v)]
        if not finite:
            return (0.0, upper)
        return (min(finite), upper)

    save_plot(
        epochs,
        [values("train_loss"), values("val_loss")],
        ["train_loss", "val_loss"],
        "Loss-Verlauf",
        "Loss",
        plot_dir / "loss_curve.png",
    )

    save_plot(
        epochs,
        [
            values("train_dice_soft"),
            values("val_dice_soft"),
            values("val_dice_fg"),
        ],
        ["train_dice_soft", "val_dice_soft", "val_dice_fg"],
        "Dice-Verlauf",
        "Dice",
        plot_dir / "dice_curve.png",
        y_limits=(0.0, 1.02),
    )

    save_plot(
        epochs,
        [values("val_iou_fg")],
        ["val_iou_fg"],
        "IoU-Verlauf",
        "IoU",
        plot_dir / "iou_curve.png",
        y_limits=(0.0, 1.02),
    )

    save_plot(
        epochs,
        [
            values("val_precision_fg"),
            values("val_recall_fg"),
            values("val_f1_fg"),
            values("val_f2_fg"),
        ],
        ["val_precision_fg", "val_recall_fg", "val_f1_fg", "val_f2_fg"],
        "Precision / Recall / F1 / F2",
        "Score",
        plot_dir / "precision_recall_f1_f2_curve.png",
        y_limits=(0.0, 1.02),
    )

    save_plot(
        epochs,
        [
            values("val_balanced_accuracy"),
            values("val_balanced_error"),
            values("val_fpr"),
            values("val_fnr"),
        ],
        [
            "val_balanced_accuracy",
            "val_balanced_error",
            "val_fpr",
            "val_fnr",
        ],
        "Balanced Error / Accuracy / FPR / FNR",
        "Rate",
        plot_dir / "balanced_error_accuracy_fpr_fnr_curve.png",
        y_limits=(0.0, 1.02),
    )

    save_plot(
        epochs,
        [values("val_ap")],
        ["val_ap_fg"],
        "Average Precision der Rissklasse",
        "AP",
        plot_dir / "ap_curve.png",
        y_limits=dynamic_lower([values("val_ap")], 1.02),
    )

    save_plot(
        epochs,
        [values("val_f2_fg")],
        ["val_f2_fg"],
        "F2-Verlauf der Rissklasse",
        "F2",
        plot_dir / "f2_curve.png",
        y_limits=(0.0, 1.02),
    )

    if "val_selection_distance" in history_rows[0]:
        selection_distance = values("val_selection_distance")
        if any(np.isfinite(value) for value in selection_distance):
            save_plot(
                epochs,
                [selection_distance],
                ["val_selection_distance"],
                "Dice-F2-Idealpunkt-Distanz zur Epochenauswahl",
                "D (kleiner ist besser)",
                plot_dir / "selection_distance_curve.png",
                y_limits=(0.0, max(1.0, max(
                    (value for value in selection_distance if np.isfinite(value)),
                    default=1.0,
                ) * 1.05)),
            )

    save_plot(
        epochs,
        [
            values("train_dice_soft"),
            values("val_dice_soft"),
            values("val_dice_fg"),
            values("val_iou_fg"),
            values("val_precision_fg"),
            values("val_recall_fg"),
            values("val_f1_fg"),
            values("val_f2_fg"),
            values("val_balanced_accuracy"),
            values("val_ap"),
        ],
        [
            "train_dice_soft",
            "val_dice_soft",
            "val_dice_fg",
            "val_iou_fg",
            "val_precision_fg",
            "val_recall_fg",
            "val_f1_fg",
            "val_f2_fg",
            "val_balanced_accuracy",
            "val_ap_fg",
        ],
        "Alle vergleichbaren höher-ist-besser-Metriken",
        "Score (0–1)",
        plot_dir / "all_metrics_same_scale.png",
        y_limits=(0.0, 1.02),
    )


# =============================================================================
# 10. ARCHITEKTUR-EXPORT
# =============================================================================

def tensor_shape_string(tensor_or_tensors: Any) -> str:
    try:
        if isinstance(tensor_or_tensors, (list, tuple)):
            return "[" + ", ".join(str(t.shape) for t in tensor_or_tensors) + "]"
        return str(tensor_or_tensors.shape)
    except Exception:
        return "nicht verfügbar"


def keras_tensor_source(tensor: Any) -> str:
    try:
        history = getattr(tensor, "_keras_history", None)
        if history is None:
            return "unbekannt"

        operation = getattr(history, "operation", None)
        node_index = getattr(history, "node_index", None)
        tensor_index = getattr(history, "tensor_index", None)

        if operation is None and isinstance(history, (tuple, list)) and history:
            operation = history[0]
            if len(history) > 1:
                node_index = history[1]
            if len(history) > 2:
                tensor_index = history[2]

        operation_name = getattr(operation, "name", str(operation))
        return f"{operation_name}[node={node_index}, tensor={tensor_index}]"
    except Exception as exc:
        return f"unbekannt ({exc})"


def flatten_tensors(tensors: Any) -> list[Any]:
    if isinstance(tensors, (list, tuple)):
        result: list[Any] = []
        for item in tensors:
            result.extend(flatten_tensors(item))
        return result
    return [tensors]


def iter_layers_recursive(
    model: tf.keras.Model,
    prefix: str = "",
) -> Iterable[tuple[str, tf.keras.layers.Layer]]:
    for index, layer in enumerate(model.layers):
        path = f"{prefix}{index:03d}:{layer.name}"
        yield path, layer
        if isinstance(layer, tf.keras.Model):
            yield from iter_layers_recursive(layer, prefix=path + "/")


def write_model_summary(file, model: tf.keras.Model, title: str) -> None:
    file.write("=" * 200 + "\n")
    file.write(title + "\n")
    file.write("=" * 200 + "\n\n")
    model.summary(
        expand_nested=True,
        line_length=200,
        print_fn=lambda line: file.write(line + "\n"),
    )
    file.write("\n\n")


def export_architecture(model: tf.keras.Model) -> dict[str, Any]:
    ARCH_DIR.mkdir(parents=True, exist_ok=True)

    # Maschinenlesbare Konfiguration
    write_json_atomic(ARCHITECTURE_JSON_FILE, model.get_config())
    ARCHITECTURE_KERAS_JSON_FILE.write_text(
        model.to_json(),
        encoding="utf-8",
    )

    all_layers = list(iter_layers_recursive(model))
    concat_layers = [
        (path, layer)
        for path, layer in all_layers
        if isinstance(layer, tf.keras.layers.Concatenate)
        or "concatenate" in layer.__class__.__name__.lower()
    ]
    add_layers = [
        (path, layer)
        for path, layer in all_layers
        if isinstance(layer, tf.keras.layers.Add)
    ]
    nested_models = [
        (path, layer)
        for path, layer in all_layers
        if isinstance(layer, tf.keras.Model) and layer is not model
    ]

    with ARCHITECTURE_TXT_FILE.open("w", encoding="utf-8") as file:
        file.write(f"Run: {RUN_NAME}\n")
        file.write("Architecture: U-Net++ mit dichten verschachtelten Skip-Connections\n")
        file.write(f"Input: ({IMG_SIZE}, {IMG_SIZE}, 3)\n")
        file.write("Output: binäre Wahrscheinlichkeitsmaske, 1 Kanal\n")
        file.write(f"Filter pro Ebene: {FILTER_NUM}\n")
        file.write(f"Convs pro Block: {CONVS_PER_BLOCK}\n")
        file.write(f"Aktivierung: {ACTIVATION}\n")
        file.write("Encoder-Tiefe: 5 Ebenen\n")
        file.write("Verschachtelte Decoderstufen: 4\n")
        file.write(f"Kernel initializer: {KERNEL_INITIALIZER}\n")
        file.write(f"Batch Normalization: {BATCH_NORM}\n")
        file.write("Pooling: MaxPooling2D, Faktor 2\n")
        file.write("Upsampling: Conv2DTranspose, Faktor 2\n")
        file.write(f"Deep Supervision: {DEEP_SUPERVISION}\n")
        file.write(f"Mixed Precision: {mixed_precision.global_policy().name}\n")
        file.write(f"Gesamtparameter: {model.count_params():,}\n")
        file.write(f"Rekursiv gefundene Layer: {len(all_layers)}\n")
        file.write(f"Gefundene Concatenate-Layer: {len(concat_layers)}\n")
        file.write(f"Gefundene Add-Layer: {len(add_layers)}\n\n")

        if not concat_layers:
            file.write(
                "WARNUNG: Es wurde kein Concatenate-Layer gefunden. "
                "Die tatsächliche Skip-Konnektivität sollte geprüft werden.\n\n"
            )

        write_model_summary(file, model, "1. VOLLSTÄNDIGE MODELLZUSAMMENFASSUNG")

        for nested_index, (path, nested_model) in enumerate(nested_models, start=1):
            write_model_summary(
                file,
                nested_model,
                f"2.{nested_index} DETAILLIERTE SUMMARY DES INNEREN MODELLS: {path}",
            )

        file.write("=" * 200 + "\n")
        file.write("3. REKURSIVE LAYERLISTE MIT INPUT-/OUTPUTQUELLEN\n")
        file.write("=" * 200 + "\n\n")

        for path, layer in all_layers:
            try:
                layer_input = layer.input
            except Exception:
                layer_input = None
            try:
                layer_output = layer.output
            except Exception:
                layer_output = None

            input_tensors = flatten_tensors(layer_input) if layer_input is not None else []
            input_sources = [keras_tensor_source(tensor) for tensor in input_tensors]

            try:
                parameters = int(layer.count_params())
            except Exception:
                parameters = -1

            file.write(f"Pfad: {path}\n")
            file.write(f"  Klasse: {layer.__class__.__name__}\n")
            file.write(f"  Trainable: {layer.trainable}\n")
            file.write(f"  dtype: {getattr(layer, 'dtype', 'nicht verfügbar')}\n")
            file.write(f"  Parameter: {parameters}\n")
            file.write(f"  Input shape: {tensor_shape_string(layer_input)}\n")
            file.write(f"  Output shape: {tensor_shape_string(layer_output)}\n")
            file.write(f"  Input-Quellen: {input_sources}\n")
            try:
                file.write(
                    "  Konfiguration: "
                    + json.dumps(
                        json_safe(layer.get_config()),
                        ensure_ascii=False,
                        sort_keys=True,
                    )
                    + "\n"
                )
            except Exception as exc:
                file.write(f"  Konfiguration nicht verfügbar: {exc}\n")
            file.write("\n")

        file.write("=" * 200 + "\n")
        file.write("4. CONCATENATE-/SKIP-CONNECTION-AUDIT\n")
        file.write("=" * 200 + "\n\n")

        for concat_index, (path, layer) in enumerate(concat_layers, start=1):
            try:
                inputs = flatten_tensors(layer.input)
            except Exception:
                inputs = []
            file.write(f"Concat {concat_index}: {path}\n")
            file.write(f"  Anzahl Inputs: {len(inputs)}\n")
            for input_index, tensor in enumerate(inputs):
                file.write(
                    f"  Input {input_index}: Quelle={keras_tensor_source(tensor)}, "
                    f"Shape={getattr(tensor, 'shape', 'nicht verfügbar')}\n"
                )
            try:
                file.write(f"  Output shape: {layer.output.shape}\n")
            except Exception:
                file.write("  Output shape: nicht verfügbar\n")
            file.write("\n")

        file.write("=" * 200 + "\n")
        file.write("5. VOLLSTÄNDIGE MODELLKONFIGURATION ALS JSON\n")
        file.write("=" * 200 + "\n\n")
        json.dump(
            json_safe(model.get_config()),
            file,
            indent=2,
            ensure_ascii=False,
        )
        file.write("\n")

    plot_error = None
    try:
        plot_model(
            model,
            to_file=str(ARCHITECTURE_PNG_FILE),
            show_shapes=True,
            show_layer_names=True,
            expand_nested=True,
            dpi=200,
            rankdir="TB",
        )
    except Exception as exc:
        plot_error = str(exc)
        (ARCH_DIR / f"{RUN_NAME}_architecture_plot_error.txt").write_text(
            "Die PNG-Architektur konnte nicht erstellt werden.\n"
            f"Fehler: {exc}\n"
            "Prüfe insbesondere die Installation von pydot und Graphviz.\n",
            encoding="utf-8",
        )

    return {
        "total_parameters": int(model.count_params()),
        "recursive_layer_count": len(all_layers),
        "nested_model_count": len(nested_models),
        "concatenate_layer_count": len(concat_layers),
        "add_layer_count": len(add_layers),
        "architecture_txt": str(ARCHITECTURE_TXT_FILE),
        "architecture_json": str(ARCHITECTURE_JSON_FILE),
        "architecture_keras_json": str(ARCHITECTURE_KERAS_JSON_FILE),
        "architecture_png": str(ARCHITECTURE_PNG_FILE),
        "plot_error": plot_error,
    }


# =============================================================================
# 11. LAUFMETADATEN UND KONFIGURATIONSDATEIEN
# =============================================================================

def build_run_metadata(
    environment_info: dict[str, Any],
    dataset_info: dict[str, Any],
    architecture_info: dict[str, Any],
) -> dict[str, Any]:
    train_count = int(dataset_info[TRAIN_SPLIT]["matched_pairs"])
    val_count = int(dataset_info[VAL_SPLIT]["matched_pairs"])
    test_count = int(dataset_info[TEST_SPLIT]["matched_pairs"])

    return {
        "run": RUN_NAME,
        "seed": SEED,
        "dataset_root": str(SEG_DIR),
        "dataset_splits": {
            "train": str(SEG_DIR / TRAIN_SPLIT),
            "validation": str(SEG_DIR / VAL_SPLIT),
            "test": str(SEG_DIR / TEST_SPLIT),
        },
        "output_dir": str(RUN_DIR),
        "threshold": THRESHOLD,
        "hard_negative_target_share": HARD_NEGATIVE_TARGET_SHARE,
        "hard_negative_target_share_percent": HARD_NEGATIVE_TARGET_SHARE * 100.0,
        "hard_negative_note": (
            "HN-Sampling aktiv, wenn HARD_NEGATIVE_TARGET_SHARE > 0; "
            "Quellen: images_<IMG_SIZE>px_hard_negatives / masks_<IMG_SIZE>px_hard_negatives."
        ),
        "loss": LOSS_NAME,
        "self_training": {
            "teacher_type": TEACHER_TYPE,
            "unlabeled_dir": str(UNLABELED_DIR),
            "pseudo_patch_confidence_threshold": PSEUDO_PATCH_CONFIDENCE_THRESHOLD,
            "pseudo_pixel_confidence_threshold": PSEUDO_PIXEL_CONFIDENCE_THRESHOLD,
            "pseudo_min_confident_pixel_fraction": PSEUDO_MIN_CONFIDENT_PIXEL_FRACTION,
            "pseudo_max_sampling_share": PSEUDO_MAX_SAMPLING_SHARE,
            "pseudo_max_loss_weight": PSEUDO_MAX_LOSS_WEIGHT,
            "warmup_epochs": PSEUDO_WARMUP_EPOCHS,
            "ramp_epochs": PSEUDO_RAMP_EPOCHS,
            "reuse_pseudo_cache": REUSE_PSEUDO_CACHE,
        },
        "optimizer": OPTIMIZER_NAME,
        "initial_learning_rate": INITIAL_LR,
        "architecture": "U-Net++ mit dichten verschachtelten Skip-Connections",
        "filter_num": FILTER_NUM,
        "convs_per_block": CONVS_PER_BLOCK,
        "kernel_initializer": KERNEL_INITIALIZER,
        "encoder_levels": len(FILTER_NUM),
        "nested_decoder_stages": len(FILTER_NUM) - 1,
        "activation": ACTIVATION,
        "batch_normalization": BATCH_NORM,
        "pooling": "MaxPooling2D factor 2",
        "upsampling": "Conv2DTranspose factor 2",
        "deep_supervision": DEEP_SUPERVISION,
        "patch_resolution": f"{IMG_SIZE} x {IMG_SIZE} px",
        "image_channels": 3,
        "mask_format": MASK_FORMAT_DESCRIPTION,
        "batch_size": BATCH,
        "steps_per_epoch": STEPS_PER_EPOCH,
        "images_per_epoch_effective": STEPS_PER_EPOCH * BATCH,
        "validation_steps": VALIDATION_STEPS,
        "validation_images_max_per_epoch": (None if VALIDATION_STEPS is None else VALIDATION_STEPS * BATCH),
        "epochs_planned": EPOCHS,
        "xla_jit": XLA_JIT,
        "mixed_precision_policy": MIXED_PRECISION_POLICY,
        "steps_per_execution": STEPS_PER_EXECUTION,
        "cache_validation": CACHE_VALIDATION,
        "ap_threshold_count": len(AP_THRESHOLDS),
        "auc_threshold_count": AUC_NUM_THRESHOLDS,
        "save_all_epoch_models": SAVE_ALL_EPOCH_MODELS,
        "lr_scheduler": {
            "name": "ReduceLROnPlateau",
            "monitor": "val_loss",
            "mode": "min",
            "patience": LR_REDUCE_PATIENCE,
            "factor": LR_REDUCE_FACTOR,
            "min_delta": MIN_DELTA,
        },
        "early_stopping": {
            "monitor": "val_loss",
            "mode": "min",
            "patience": EARLY_STOPPING_PATIENCE,
            "restore_best_weights": False,
            "min_delta": MIN_DELTA,
        },
        "checkpointing": {
            "save_every_epoch": True,
            "save_best_model": True,
            "monitor_best_model": (
                "min AP/Dice ideal-point distance: "
                "sqrt(0.5*(1-AP)^2 + 0.5*(1-Dice)^2) after training"
            ),
            "save_weights_only": False,
        },
        "dataset_counts": {
            "train": train_count,
            "validation": val_count,
            "test": test_count,
            "total": train_count + val_count + test_count,
        },
        "epochs_for_approx_full_train_pass": (
            train_count / (STEPS_PER_EPOCH * BATCH)
            if STEPS_PER_EPOCH * BATCH > 0
            else float("inf")
        ),
        "map_definition": (
            "Single-class pixel-wise AP for the foreground crack class. "
            "val_ap is the pixel-wise Average Precision of the crack foreground class."
        ),
        "environment": environment_info,
        "dataset_details": dataset_info,
        "architecture_export": architecture_info,
    }


def write_run_configuration_file(metadata: dict[str, Any]) -> None:
    environment = metadata["environment"]
    counts = metadata["dataset_counts"]

    with RUN_CONFIG_FILE.open("w", encoding="utf-8") as file:
        file.write(f"Run: {RUN_NAME}\n")
        file.write(f"Zeitpunkt: {environment['timestamp_start']}\n")
        file.write(f"Seed: {SEED}\n")
        file.write(f"Dataset: {SEG_DIR}\n")
        file.write(f"Train-Split: {SEG_DIR / TRAIN_SPLIT}\n")
        file.write(f"Validation-Split: {SEG_DIR / VAL_SPLIT}\n")
        file.write(f"Test-Split: {SEG_DIR / TEST_SPLIT}\n")
        file.write(f"Output: {RUN_DIR}\n")
        file.write(f"Threshold: {THRESHOLD}\n")
        file.write(
            "Hard-negative target share (train only): "
            f"{HARD_NEGATIVE_TARGET_SHARE * 100.0:.1f}%\n"
        )
        file.write(
            "Hard-negative Hinweis: HN-Sampling wird bei Anteil > 0 aus den parallelen "
            f"Ordnern {HN_IMAGE_DIRNAME} / {HN_MASK_DIRNAME} aktiviert.\n"
        )
        file.write(f"Loss: {LOSS_NAME}\n")
        file.write(f"Optimizer: {OPTIMIZER_NAME}\n")
        file.write(f"Initial learning rate: {INITIAL_LR}\n")
        file.write("Architecture: U-Net++ mit dichten verschachtelten Skip-Connections\n")
        file.write(f"Filter pro Ebene: {FILTER_NUM}\n")
        file.write(f"Convs pro Block: {CONVS_PER_BLOCK}\n")
        file.write(f"Aktivierung: {ACTIVATION}\n")
        file.write("Encoder-Tiefe: 5 Ebenen\n")
        file.write("Verschachtelte Decoderstufen: 4\n")
        file.write(f"Kernel initializer: {KERNEL_INITIALIZER}\n")
        file.write(f"Batch normalization: {BATCH_NORM}\n")
        file.write("Pooling: MaxPooling2D, Faktor 2\n")
        file.write("Upsampling: Conv2DTranspose, Faktor 2\n")
        file.write(f"Deep supervision: {DEEP_SUPERVISION}\n")
        file.write(f"Patch resolution: {IMG_SIZE} x {IMG_SIZE} px\n")
        file.write(f"Mask format: {MASK_FORMAT_DESCRIPTION}\n")
        file.write(f"Batch size: {BATCH}\n")
        file.write(f"Steps per epoch: {STEPS_PER_EPOCH}\n")
        file.write(f"Effective images per epoch: {STEPS_PER_EPOCH * BATCH}\n")
        file.write(f"Validation steps: {VALIDATION_STEPS if VALIDATION_STEPS is not None else 'ALLE'}\n")
        file.write(f"Planned epochs: {EPOCHS}\n")
        file.write(f"XLA/JIT: {XLA_JIT}\n")
        file.write(f"Mixed precision policy: {MIXED_PRECISION_POLICY}\n")
        file.write(f"Steps per execution: {STEPS_PER_EXECUTION}\n")
        file.write(f"Validation cache: {CACHE_VALIDATION}\n")
        file.write(f"AP threshold count: {len(AP_THRESHOLDS)}\n")
        file.write(f"AUC threshold count: {AUC_NUM_THRESHOLDS}\n")
        file.write(f"Save all epoch models: {SAVE_ALL_EPOCH_MODELS}\n")
        file.write(
            f"ReduceLROnPlateau: monitor=val_loss, patience={LR_REDUCE_PATIENCE}, "
            f"factor={LR_REDUCE_FACTOR}\n"
        )
        file.write(
            f"EarlyStopping: monitor=val_loss, patience={EARLY_STOPPING_PATIENCE}, "
            "restore_best_weights=False\n"
        )
        file.write(f"Train images: {counts['train']}\n")
        file.write(f"Validation images: {counts['validation']}\n")
        file.write(f"Test images: {counts['test']}\n")
        file.write(f"Dataset total: {counts['total']}\n")
        file.write(
            "Epochs for approximately one complete train-set pass: "
            f"{metadata['epochs_for_approx_full_train_pass']:.4f}\n"
        )
        file.write(f"Python version: {environment['python_version']}\n")
        file.write(f"Python executable: {environment['python_executable']}\n")
        file.write(f"TensorFlow version: {environment['tensorflow_version']}\n")
        file.write(f"Keras version: {environment['keras_version']}\n")
        file.write(
            "keras_unet_collection version: "
            f"{environment['keras_unet_collection_version']}\n"
        )
        file.write(f"NVIDIA Windows driver: {environment['nvidia_windows_driver']}\n")
        file.write(f"CUDA runtime: {environment['cuda_runtime']}\n")
        file.write(f"cuDNN version: {environment['cudnn_version']}\n")
        file.write(f"Mixed precision policy: {environment['mixed_precision_policy']}\n")
        file.write(f"Platform: {environment['platform']}\n")
        file.write(f"GPU: {environment['nvidia_gpu_query']}\n")
        file.write(
            "AP definition: val_ap ist die pixelweise Average Precision der Rissklasse.\n"
        )
        file.write("=" * 180 + "\n")
        file.write("VOLLSTÄNDIGE METADATEN ALS JSON\n")
        file.write("=" * 180 + "\n")
        json.dump(json_safe(metadata), file, indent=2, ensure_ascii=False)
        file.write("\n")


# =============================================================================
# 12. VALIDIERUNGS- UND LOGGING-CALLBACK
# =============================================================================

class ValidationMetricsLogger(tf.keras.callbacks.Callback):
    FIELDNAMES = [
        "epoch",
        "train_loss",
        "val_loss",
        "train_dice_soft",
        "val_dice_soft",
        "val_dice_fg",
        "val_iou_fg",
        "val_precision_fg",
        "val_recall_fg",
        "val_f1_fg",
        "val_f2_fg",
        "val_balanced_error",
        "val_balanced_accuracy",
        "val_fpr",
        "val_fnr",
        "val_ap",
        "val_selection_distance",
        "val_tp",
        "val_fp",
        "val_fn",
        "val_tn",
    ]

    def __init__(
        self,
        validation_dataset: tf.data.Dataset,
        validation_steps: int | None,
        metrics_txt_path: Path,
        metrics_csv_path: Path,
        metrics_json_path: Path,
        run_metadata: dict[str, Any],
        threshold: float = 0.5,
        plot_dir: Path | None = None,
    ) -> None:
        super().__init__()
        self.validation_dataset = validation_dataset
        self.validation_steps = validation_steps
        self.metrics_txt_path = Path(metrics_txt_path)
        self.metrics_csv_path = Path(metrics_csv_path)
        self.metrics_json_path = Path(metrics_json_path)
        self.run_metadata = run_metadata
        self.threshold = threshold
        self.plot_dir = Path(plot_dir) if plot_dir is not None else self.metrics_txt_path.parent / "plots"

        self.best_epoch: int | None = None
        self.best_selection_distance: float | None = None
        self.epoch_history: list[dict[str, float]] = []
        self.training_started_at = datetime.now().astimezone()

        self._threshold_tensor = tf.constant(self.threshold, dtype=tf.float32)

        self._initialize_log_files()
        self._write_json(status="initialized")

    def _initialize_log_files(self) -> None:
        self.metrics_txt_path.parent.mkdir(parents=True, exist_ok=True)
        self.metrics_csv_path.parent.mkdir(parents=True, exist_ok=True)
        self.metrics_json_path.parent.mkdir(parents=True, exist_ok=True)
        self.plot_dir.mkdir(parents=True, exist_ok=True)

        environment = self.run_metadata["environment"]
        counts = self.run_metadata["dataset_counts"]

        with self.metrics_txt_path.open("w", encoding="utf-8") as file:
            file.write(f"Run: {RUN_NAME}\n")
            file.write(f"Seed: {SEED}\n")
            file.write(f"Dataset: {SEG_DIR}\n")
            file.write(f"Output: {RUN_DIR}\n")
            file.write(f"Threshold: {self.threshold}\n")
            file.write(
                "Hard-negative target share (train only): "
                f"{HARD_NEGATIVE_TARGET_SHARE * 100.0:.1f}%\n"
            )
            file.write(f"Loss: {LOSS_NAME}\n")
            file.write(f"Teacher type: {TEACHER_TYPE}\n")
            file.write(f"Unlabeled dir: {UNLABELED_DIR}\n")
            file.write(f"Pseudo max sampling share: {PSEUDO_MAX_SAMPLING_SHARE:.3f}\n")
            file.write(f"Pseudo max loss weight: {PSEUDO_MAX_LOSS_WEIGHT:.3f}\n")
            file.write(f"Pseudo warmup epochs: {PSEUDO_WARMUP_EPOCHS}\n")
            file.write(f"Pseudo ramp epochs: {PSEUDO_RAMP_EPOCHS}\n")
            file.write(f"Architecture: U-Net++ mit dichten verschachtelten Skip-Connections\n")
            file.write(f"Filter pro Ebene: {FILTER_NUM}\n")
            file.write(f"Convs pro Block: {CONVS_PER_BLOCK}\n")
            file.write(f"Aktivierung: {ACTIVATION}\n")
            file.write(f"Deep supervision: {DEEP_SUPERVISION}\n")
            file.write(f"Patch resolution: {IMG_SIZE} x {IMG_SIZE} px\n")
            file.write(f"Mask format: {MASK_FORMAT_DESCRIPTION}\n")
            file.write(f"Batch size: {BATCH}\n")
            file.write(f"Optimizer: {OPTIMIZER_NAME}\n")
            file.write(f"Initial learning rate: {INITIAL_LR}\n")
            file.write(f"Steps per epoch: {STEPS_PER_EPOCH}\n")
            file.write(f"Validation steps: {VALIDATION_STEPS if VALIDATION_STEPS is not None else 'ALLE'}\n")
            file.write(f"Planned epochs: {EPOCHS}\n")
            file.write(f"XLA/JIT: {XLA_JIT}\n")
            file.write(f"Mixed precision policy: {MIXED_PRECISION_POLICY}\n")
            file.write(f"Steps per execution: {STEPS_PER_EXECUTION}\n")
            file.write(f"Validation cache: {CACHE_VALIDATION}\n")
            file.write(f"AP threshold count: {len(AP_THRESHOLDS)}\n")
            file.write(f"AUC threshold count: {AUC_NUM_THRESHOLDS}\n")
            file.write(f"Save all epoch models: {SAVE_ALL_EPOCH_MODELS}\n")
            file.write(f"Train images: {counts['train']}\n")
            file.write(f"Validation images: {counts['validation']}\n")
            file.write(f"Test images: {counts['test']}\n")
            file.write(f"Dataset total: {counts['total']}\n")
            file.write(f"Python version: {environment['python_version']}\n")
            file.write(f"Keras version: {environment['keras_version']}\n")
            file.write(f"NVIDIA Windows driver: {environment['nvidia_windows_driver']}\n")
            file.write(f"CUDA runtime: {environment['cuda_runtime']}\n")
            file.write(f"cuDNN version: {environment['cudnn_version']}\n")
            file.write(
                "val_ap: pixelweise Average Precision der Rissklasse.\n"
            )
            file.write(
                "val_f2_fg: F2-Score der Rissklasse; Recall wird stärker als Precision gewichtet.\n"
            )
            file.write(
                "Finale Epochenauswahl: euklidische Idealpunkt-Distanz aus val_dice_fg "
                "und val_f2_fg: D = sqrt(0.5*(1-Dice)^2 + 0.5*(1-F2)^2). "
                "Kleinster D-Wert gewinnt.\n"
            )
            file.write(
                "val_selection_distance wird in jeder Epoche direkt aus val_dice_fg "
                "und val_f2_fg berechnet und protokolliert.\n"
            )
            file.write("Alle Validierungsmetriken werden in jeder Epoche berechnet.\n")
            file.write("=" * 180 + "\n")
            file.write("\t".join(self.FIELDNAMES) + "\n")

        with self.metrics_csv_path.open("w", encoding="utf-8", newline="") as file:
            writer = csv.DictWriter(file, fieldnames=self.FIELDNAMES)
            writer.writeheader()

    @tf.function(jit_compile=XLA_JIT, reduce_retracing=True)
    def _validation_step_gpu(
        self,
        images: tf.Tensor,
        masks: tf.Tensor,
    ) -> tuple[tf.Tensor, ...]:
        """Ein Validierungsbatch vollständig auf GPU/XLA, ohne NumPy-Bildkopien."""
        predictions = self.model(images, training=False)
        masks_float = tf.cast(masks, tf.float32)
        predictions_float = tf.cast(predictions, tf.float32)

        batch_size = tf.cast(tf.shape(images)[0], tf.int64)

        intersection = tf.reduce_sum(
            masks_float * predictions_float,
            axis=[1, 2, 3],
        )
        union = tf.reduce_sum(
            masks_float + predictions_float,
            axis=[1, 2, 3],
        )
        dice_per_sample = (2.0 * intersection + 1e-7) / (union + 1e-7)
        dice_sum = tf.reduce_sum(dice_per_sample)
        loss_sum = tf.reduce_sum(1.0 - dice_per_sample)


        y_true = masks_float >= 0.5
        y_pred = predictions_float >= self._threshold_tensor

        tp = tf.reduce_sum(tf.cast(tf.logical_and(y_true, y_pred), tf.int64))
        fp = tf.reduce_sum(
            tf.cast(tf.logical_and(tf.logical_not(y_true), y_pred), tf.int64)
        )
        fn = tf.reduce_sum(
            tf.cast(tf.logical_and(y_true, tf.logical_not(y_pred)), tf.int64)
        )
        tn = tf.reduce_sum(
            tf.cast(
                tf.logical_and(tf.logical_not(y_true), tf.logical_not(y_pred)),
                tf.int64,
            )
        )

        # Ein einziges Histogramm pro Klasse ersetzt 21/101 vollständige
        # Pixelvergleiche. Der Index floor(p * 100) bildet Thresholds von
        # 0.00 bis 1.00 exakt auf ein gleichmäßiges Raster ab.
        labels_flat = tf.reshape(y_true, [-1])
        scores_flat = tf.reshape(tf.clip_by_value(predictions_float, 0.0, 1.0), [-1])
        bin_indices = tf.cast(
            tf.floor(scores_flat * float(CURVE_GRID_MAX_INDEX)),
            tf.int32,
        )
        bin_indices = tf.clip_by_value(
            bin_indices,
            0,
            CURVE_GRID_MAX_INDEX,
        )

        # Int32 ist pro Batch sicher (maximal BATCH * IMG_SIZE² Pixel) und auf
        # der GPU günstiger. Vor dem Rückgabewert wird auf Int64 erweitert.
        positive_histogram = tf.math.unsorted_segment_sum(
            tf.cast(labels_flat, tf.int32),
            bin_indices,
            AUC_NUM_THRESHOLDS,
        )
        negative_histogram = tf.math.unsorted_segment_sum(
            tf.cast(tf.logical_not(labels_flat), tf.int32),
            bin_indices,
            AUC_NUM_THRESHOLDS,
        )

        curve_tp = tf.cast(
            tf.reverse(
                tf.math.cumsum(tf.reverse(positive_histogram, axis=[0])),
                axis=[0],
            ),
            tf.int64,
        )
        curve_fp = tf.cast(
            tf.reverse(
                tf.math.cumsum(tf.reverse(negative_histogram, axis=[0])),
                axis=[0],
            ),
            tf.int64,
        )
        total_positive = tf.reduce_sum(tf.cast(positive_histogram, tf.int64))
        total_negative = tf.reduce_sum(tf.cast(negative_histogram, tf.int64))
        curve_fn = total_positive - curve_tp
        curve_tn = total_negative - curve_fp

        return (
            batch_size,
            loss_sum,
            dice_sum,
            tp,
            fp,
            fn,
            tn,
            curve_tp,
            curve_fp,
            curve_fn,
            curve_tn,
        )

    def _evaluate_validation(self) -> dict[str, float]:
        # Alle Akkumulatoren bleiben während der kompletten Validierung als kleine
        # Tensoren auf dem Gerät. Erst am Ende werden aggregierte Werte übertragen.
        total_samples = tf.constant(0, dtype=tf.int64)
        total_loss = tf.constant(0.0, dtype=tf.float32)
        total_dice_soft = tf.constant(0.0, dtype=tf.float32)

        tp_total = tf.constant(0, dtype=tf.int64)
        fp_total = tf.constant(0, dtype=tf.int64)
        fn_total = tf.constant(0, dtype=tf.int64)
        tn_total = tf.constant(0, dtype=tf.int64)

        curve_tp = tf.zeros(AUC_NUM_THRESHOLDS, dtype=tf.int64)
        curve_fp = tf.zeros(AUC_NUM_THRESHOLDS, dtype=tf.int64)
        curve_fn = tf.zeros(AUC_NUM_THRESHOLDS, dtype=tf.int64)

        validation_iter = (
            self.validation_dataset
            if self.validation_steps is None
            else self.validation_dataset.take(self.validation_steps)
        )
        for images, masks in validation_iter:
            (
                batch_size,
                batch_loss_sum,
                batch_dice_sum,
                batch_tp,
                batch_fp,
                batch_fn,
                batch_tn,
                batch_curve_tp,
                batch_curve_fp,
                batch_curve_fn,
                _batch_curve_tn,
            ) = self._validation_step_gpu(images, masks)

            total_samples += batch_size
            total_loss += batch_loss_sum
            total_dice_soft += batch_dice_sum
            tp_total += batch_tp
            fp_total += batch_fp
            fn_total += batch_fn
            tn_total += batch_tn
            curve_tp += batch_curve_tp
            curve_fp += batch_curve_fp
            curve_fn += batch_curve_fn

        # Eine einzige kleine Ergebnisübertragung statt vollständiger Masken und
        # Wahrscheinlichkeitskarten in jedem Batch.
        (
            total_samples_value,
            total_loss_value,
            total_dice_value,
            tp_value,
            fp_value,
            fn_value,
            tn_value,
            curve_tp_value,
            curve_fp_value,
            curve_fn_value,
        ) = [
            tensor.numpy()
            for tensor in (
                total_samples,
                total_loss,
                total_dice_soft,
                tp_total,
                fp_total,
                fn_total,
                tn_total,
                curve_tp,
                curve_fp,
                curve_fn,
            )
        ]

        total_samples_int = int(total_samples_value)
        if total_samples_int == 0:
            return {
                field: float("nan")
                for field in self.FIELDNAMES
                if field not in {"epoch", "train_loss", "train_dice_soft"}
            }

        curve_tp_value = curve_tp_value.astype(np.float64)
        curve_fp_value = curve_fp_value.astype(np.float64)
        curve_fn_value = curve_fn_value.astype(np.float64)

        foreground_metrics = compute_fg_metrics_from_confusion(
            int(tp_value),
            int(fp_value),
            int(fn_value),
            int(tn_value),
        )

        ap_foreground = compute_ap_from_threshold_confusions(
            curve_tp_value[AP_GRID_INDICES],
            curve_fp_value[AP_GRID_INDICES],
            curve_fn_value[AP_GRID_INDICES],
        )

        return {
            "val_loss": float(total_loss_value) / total_samples_int,
            "val_dice_soft": float(total_dice_value) / total_samples_int,
            "val_dice_fg": foreground_metrics["dice_fg"],
            "val_iou_fg": foreground_metrics["iou_fg"],
            "val_precision_fg": foreground_metrics["precision_fg"],
            "val_recall_fg": foreground_metrics["recall_fg"],
            "val_f1_fg": foreground_metrics["f1_fg"],
            "val_f2_fg": foreground_metrics["f2_fg"],
            "val_balanced_error": foreground_metrics["balanced_error"],
            "val_balanced_accuracy": foreground_metrics["balanced_accuracy"],
            "val_fpr": foreground_metrics["false_positive_rate"],
            "val_fnr": foreground_metrics["false_negative_rate"],
            "val_ap": ap_foreground,
            "val_tp": float(tp_value),
            "val_fp": float(fp_value),
            "val_fn": float(fn_value),
            "val_tn": float(tn_value),
        }

    def _append_epoch_row(self, row: dict[str, float]) -> None:
        with self.metrics_txt_path.open("a", encoding="utf-8") as file:
            values = [str(int(row["epoch"]))]
            values.extend(f"{float(row[field]):.6f}" for field in self.FIELDNAMES[1:])
            file.write("\t".join(values) + "\n")

        with self.metrics_csv_path.open("a", encoding="utf-8", newline="") as file:
            writer = csv.DictWriter(file, fieldnames=self.FIELDNAMES)
            writer.writerow(row)

    def _write_json(self, status: str) -> None:
        elapsed_seconds = (
            datetime.now().astimezone() - self.training_started_at
        ).total_seconds()

        payload = {
            "status": status,
            "run_metadata": self.run_metadata,
            "best_epoch": self.best_epoch,
            "best_selection_distance": self.best_selection_distance,
            "epochs_completed": len(self.epoch_history),
            "elapsed_seconds": elapsed_seconds,
            "history": self.epoch_history,
        }
        write_json_atomic(self.metrics_json_path, payload)

    def on_epoch_end(self, epoch: int, logs: dict[str, Any] | None = None) -> None:
        # Nicht "logs = logs or {}" verwenden, da bei einem leeren Dict sonst
        # ein neues Objekt entstehen könnte. Spätere Callbacks müssen genau das
        # von Keras übergebene Dict mit val_dice_fg erhalten.
        if logs is None:
            logs = {}

        validation_metrics = self._evaluate_validation()

        row: dict[str, float] = {
            "epoch": float(epoch + 1),
            "train_loss": float(logs.get("loss", np.nan)),
            "val_loss": float(validation_metrics["val_loss"]),
            "train_dice_soft": float(logs.get("dice_coef_soft", np.nan)),
            "val_dice_soft": float(validation_metrics["val_dice_soft"]),
            "val_dice_fg": float(validation_metrics["val_dice_fg"]),
            "val_iou_fg": float(validation_metrics["val_iou_fg"]),
            "val_precision_fg": float(validation_metrics["val_precision_fg"]),
            "val_recall_fg": float(validation_metrics["val_recall_fg"]),
            "val_f1_fg": float(validation_metrics["val_f1_fg"]),
            "val_f2_fg": float(validation_metrics["val_f2_fg"]),
            "val_balanced_error": float(validation_metrics["val_balanced_error"]),
            "val_balanced_accuracy": float(validation_metrics["val_balanced_accuracy"]),
            "val_fpr": float(validation_metrics["val_fpr"]),
            "val_fnr": float(validation_metrics["val_fnr"]),
            "val_ap": float(validation_metrics["val_ap"]),
            "val_tp": float(validation_metrics["val_tp"]),
            "val_fp": float(validation_metrics["val_fp"]),
            "val_fn": float(validation_metrics["val_fn"]),
            "val_tn": float(validation_metrics["val_tn"]),
        }
        row["val_selection_distance"] = math.sqrt(
            0.5 * (1.0 - row["val_dice_fg"]) ** 2
            + 0.5 * (1.0 - row["val_f2_fg"]) ** 2
        )

        self.epoch_history.append(row)

        # Entscheidend: alle berechneten Werte in das originale logs-Dict
        # zurückschreiben. Dadurch funktionieren die nachfolgenden Checkpoint-,
        # LR-Scheduler- und Early-Stopping-Callbacks mit val_loss.
        for key, value in row.items():
            if key != "epoch":
                logs[key] = value
        logs["loss"] = row["train_loss"]
        logs["dice_coef_soft"] = row["train_dice_soft"]
        logs["learning_rate"] = get_current_learning_rate(self.model.optimizer)

        self._append_epoch_row(row)
        self._write_json(status="training")

        if PLOTS_EVERY_N_EPOCHS > 0 and (epoch + 1) % PLOTS_EVERY_N_EPOCHS == 0:
            save_training_plots(self.epoch_history, self.plot_dir)

        print(
            "\nVALIDIERUNG: "
            f"loss={row['val_loss']:.6f} | "
            f"dice_soft={row['val_dice_soft']:.6f} | "
            f"dice_fg={row['val_dice_fg']:.6f} | "
            f"iou={row['val_iou_fg']:.6f} | "
            f"precision={row['val_precision_fg']:.6f} | "
            f"recall={row['val_recall_fg']:.6f} | "
            f"f1={row['val_f1_fg']:.6f} | "
            f"f2={row['val_f2_fg']:.6f} | "
            f"bal_err={row['val_balanced_error']:.6f} | "
            f"bal_acc={row['val_balanced_accuracy']:.6f} | "
            f"fpr={row['val_fpr']:.6f} | "
            f"fnr={row['val_fnr']:.6f} | "
            f"ap_fg={row['val_ap']:.6f} | "
            f"D={row['val_selection_distance']:.6f} | "
            f"lr={logs['learning_rate']:.8g}"
        )

    def on_train_end(self, logs: dict[str, Any] | None = None) -> None:
        valid_rows = [
            row for row in self.epoch_history
            if (
                np.isfinite(row["val_dice_fg"])
                and np.isfinite(row["val_f2_fg"])
                and np.isfinite(row["val_selection_distance"])
            )
        ]

        if valid_rows:
            # Kleinste Dice/F2-Distanz gewinnt. Tie-Break:
            # höherer Dice, dann höherer F2, dann frühere Epoche.
            best_row = min(
                valid_rows,
                key=lambda row: (
                    float(row["val_selection_distance"]),
                    -float(row["val_dice_fg"]),
                    -float(row["val_f2_fg"]),
                    int(row["epoch"]),
                ),
            )
            self.best_epoch = int(best_row["epoch"])
            self.best_selection_distance = float(best_row["val_selection_distance"])

            selection_path = (
                self.metrics_txt_path.parent
                / f"{RUN_NAME}_epoch_selection_dice_f2_distance.csv"
            )
            selection_fields = [
                "epoch",
                "val_dice_fg",
                "val_f2_fg",
                "val_selection_distance",
            ]
            with selection_path.open("w", encoding="utf-8", newline="") as file:
                writer = csv.DictWriter(file, fieldnames=selection_fields)
                writer.writeheader()
                for row in sorted(valid_rows, key=lambda item: int(item["epoch"])):
                    writer.writerow({field: row[field] for field in selection_fields})

            with self.metrics_txt_path.open("a", encoding="utf-8") as file:
                file.write("=" * 180 + "\n")
                file.write("FINALE EPOCHENAUSWAHL\n")
                file.write("=" * 180 + "\n")
                file.write(
                    "Formel: D = sqrt(0.5*(1-Dice)^2 + 0.5*(1-F2)^2); "
                    "Dice=val_dice_fg, F2=val_f2_fg; kleiner ist besser.\n"
                )
                file.write(
                    f"Best selection distance: {self.best_selection_distance:.8f}\n"
                )
                file.write(
                    f"Best val_dice_fg: {float(best_row['val_dice_fg']):.8f}\n"
                )
                file.write(
                    f"Best val_f2_fg: {float(best_row['val_f2_fg']):.8f}\n"
                )
                # Die beste Epoche steht immer in der letzten Zeile.
                file.write(f"Best epoch: {self.best_epoch}\n")
        else:
            with self.metrics_txt_path.open("a", encoding="utf-8") as file:
                file.write("=" * 180 + "\n")
                file.write("FINALE EPOCHENAUSWAHL\n")
                file.write("=" * 180 + "\n")
                file.write(
                    "Keine gültige Epochenauswahl möglich: val_dice_fg, val_f2_fg "
                    "und/oder val_selection_distance enthalten keine endlichen Werte.\n"
                )
                file.write("Best epoch: nicht verfügbar\n")

        save_training_plots(self.epoch_history, self.plot_dir)
        self._write_json(status="completed")

        print(f"\nMetrik-TXT:  {self.metrics_txt_path}")
        print(f"Metrik-CSV:  {self.metrics_csv_path}")
        print(f"Metrik-JSON: {self.metrics_json_path}")
        print(f"Plots:       {self.plot_dir}")
        if self.best_epoch is not None:
            print(
                f"Beste Epoche nach Dice-F2-Idealpunkt-Distanz: "
                f"{self.best_epoch} | D={self.best_selection_distance:.8f}"
            )


# =============================================================================
# 13. MAIN – SELF-TRAINING
# =============================================================================

def main() -> None:
    print("Initialisiere TensorFlow/GPU WSL-schonend ...", flush=True)
    physical_gpus = tf.config.list_physical_devices("GPU")
    if physical_gpus:
        for gpu in physical_gpus:
            try:
                tf.config.experimental.set_memory_growth(gpu, True)
            except RuntimeError as exc:
                print(f"Hinweis: GPU memory growth konnte nicht gesetzt werden: {exc}")

    for directory in (RUN_DIR, MODEL_DIR, METRICS_DIR, PLOT_DIR, ARCH_DIR, PSEUDO_CACHE_DIR):
        directory.mkdir(parents=True, exist_ok=True)

    print("Ermittle System- und Softwareinformationen ...", flush=True)
    environment_info = collect_environment_info()

    print("Erstelle Ground-Truth- und Validierungsdatenströme ...")
    gt_stream, train_count, train_info = build_ground_truth_stream()
    validation_dataset, validation_count, validation_info = build_dataset(VAL_SPLIT)
    test_images, _test_masks, test_info = collect_image_mask_pairs(TEST_SPLIT)
    test_count = len(test_images)
    unlabeled_paths = list_unlabeled_images()
    for path in unlabeled_paths:
        # Die eigentliche Pixelgrößenprüfung erfolgt beim ersten Labeln; hier nur Bestand.
        if not path.is_file():
            raise FileNotFoundError(path)

    dataset_info = {
        TRAIN_SPLIT: train_info,
        VAL_SPLIT: validation_info,
        TEST_SPLIT: test_info,
    }

    print(f"Seed:                         {SEED}")
    print(f"GT Train samples:             {train_count}")
    print(f"Unlabeled 512x512 samples:    {len(unlabeled_paths)}")
    print(f"Validation samples (nur GT):  {validation_count}")
    print(f"Test samples (nur GT):        {test_count}")
    print(f"Samples pro Epoche:           {SAMPLES_PER_EPOCH}")
    print(f"Pseudo ab Epoche:             {PSEUDO_START_EPOCH}")
    print(f"Pseudo Startanteil:           {PSEUDO_START_SHARE:.2%}")
    print(f"Pseudo Zuwachs/Epoche:        {PSEUDO_SHARE_INCREMENT:.2%}")
    print(f"Pseudo Maximalanteil:         {PSEUDO_MAX_SAMPLING_SHARE:.2%}")
    print(f"Mixed Precision:              {MIXED_PRECISION_POLICY}")
    print(f"XLA/JIT:                      {XLA_JIT}")

    print("Baue U-Net++ ohne vortrainierten Teacher ...")
    model = build_optimized_model()

    print("Exportiere ausführliche Architektur ...")
    architecture_info = export_architecture(model)
    run_metadata = build_run_metadata(
        environment_info=environment_info,
        dataset_info=dataset_info,
        architecture_info=architecture_info,
    )
    run_metadata["self_training"].update({
        "teacher_type": TEACHER_TYPE,
        "no_pretrained_teacher": True,
        "pseudo_start_epoch": PSEUDO_START_EPOCH,
        "pseudo_start_share": PSEUDO_START_SHARE,
        "pseudo_share_increment": PSEUDO_SHARE_INCREMENT,
        "pseudo_max_sampling_share": PSEUDO_MAX_SAMPLING_SHARE,
        "unlabeled_count": len(unlabeled_paths),
        "samples_per_epoch": SAMPLES_PER_EPOCH,
    })
    write_run_configuration_file(run_metadata)
    write_self_training_config({
        "teacher_source": "student weights from end of previous epoch",
        "teacher_mask_threshold": SINGLE_TEACHER_MASK_THRESHOLD,
        "validation_source": str(SEG_DIR / VAL_SPLIT),
    })

    optimizer = tf.keras.optimizers.Adam(learning_rate=INITIAL_LR)
    model.compile(
        optimizer=optimizer,
        loss=self_training_loss,
        metrics=[dice_coef_soft],
        jit_compile=XLA_JIT,
        steps_per_execution=STEPS_PER_EXECUTION,
        run_eagerly=False,
        auto_scale_loss=True,
    )

    metrics_logger = ValidationMetricsLogger(
        validation_dataset=validation_dataset,
        validation_steps=VALIDATION_STEPS,
        metrics_txt_path=METRICS_TXT_FILE,
        metrics_csv_path=METRICS_CSV_FILE,
        metrics_json_path=METRICS_JSON_FILE,
        run_metadata=run_metadata,
        threshold=THRESHOLD,
        plot_dir=PLOT_DIR,
    )
    metrics_logger.set_model(model)

    curriculum_log = Path(CURRICULUM_LOG_FILE)
    curriculum_log.parent.mkdir(parents=True, exist_ok=True)
    with curriculum_log.open("w", encoding="utf-8", newline="") as f:
        writer = csv.writer(f)
        writer.writerow([
            "epoch", "pseudo_share", "pseudo_requested", "gt_samples",
            "pseudo_attempted", "rejected_confidence", "rejected_no_crack",
            "unlabeled_cursor_after", "unlabeled_wraps_total"
        ])

    best_checkpoint_path = MODEL_DIR / f"{RUN_NAME}_best_val_loss.keras"
    best_val_loss = float("inf")
    lr_bad_epochs = 0
    early_bad_epochs = 0
    unlabeled_cursor = 0
    total_wraps = 0

    print(
        f"\nIteratives Online-Self-Training startet: {EPOCHS} Epochen, "
        f"{STEPS_PER_EPOCH} Steps/Epoche, Batchsize {BATCH}. "
        "Epochen 1-3 nur Ground Truth; ab Epoche 4 wird jeweils das Modell "
        "vom Ende der vorherigen Epoche als Teacher verwendet."
    )

    for epoch_index in range(EPOCHS):
        epoch_number = epoch_index + 1
        share = pseudo_share_for_epoch(epoch_number)
        requested_pseudo = pseudo_count_for_epoch(epoch_number)
        pseudo_records: list[dict[str, Any]] = []
        pseudo_stats = {
            "attempted": 0,
            "rejected_confidence": 0,
            "rejected_no_crack": 0,
            "wraps": 0,
        }

        if requested_pseudo > 0:
            print(
                f"\nEpoche {epoch_number}: Teacher = Modell nach Epoche {epoch_number - 1}. "
                f"Erzeuge {requested_pseudo} neue Pseudo-Samples ({share:.1%})."
            )
            pseudo_records, unlabeled_cursor, pseudo_stats = generate_online_pseudo_labels(
                teacher_model=model,
                unlabeled_paths=unlabeled_paths,
                cursor=unlabeled_cursor,
                target_count=requested_pseudo,
                epoch_number=epoch_number,
            )
            total_wraps += pseudo_stats["wraps"]
        else:
            clear_current_pseudo_cache()
            print(f"\nEpoche {epoch_number}: reines Ground-Truth-Training.")

        epoch_dataset = build_exact_epoch_dataset(gt_stream, pseudo_records, epoch_number)
        gt_samples = SAMPLES_PER_EPOCH - len(pseudo_records)

        print(
            f"Trainingsmix Epoche {epoch_number}: GT={gt_samples}, "
            f"Pseudo={len(pseudo_records)}, Gesamt={SAMPLES_PER_EPOCH}"
        )

        history = model.fit(
            epoch_dataset,
            initial_epoch=epoch_index,
            epochs=epoch_number,
            steps_per_epoch=STEPS_PER_EPOCH,
            callbacks=[tf.keras.callbacks.TerminateOnNaN()],
            verbose=1,
        )

        logs: dict[str, Any] = {
            key: values[-1] for key, values in history.history.items() if values
        }
        metrics_logger.on_epoch_end(epoch_index, logs)
        val_loss = float(logs.get("val_loss", np.nan))

        epoch_model_path = MODEL_DIR / f"{RUN_NAME}_Epoche{epoch_number:02d}.keras"
        if SAVE_ALL_EPOCH_MODELS:
            model.save(epoch_model_path)
            print(f"Modell Epoche {epoch_number} gespeichert: {epoch_model_path}")

        improved = np.isfinite(val_loss) and val_loss < (best_val_loss - MIN_DELTA)
        if improved:
            best_val_loss = val_loss
            lr_bad_epochs = 0
            early_bad_epochs = 0
            model.save(best_checkpoint_path)
            print(f"Neuer bester val_loss={best_val_loss:.8f}: {best_checkpoint_path}")
        else:
            lr_bad_epochs += 1
            early_bad_epochs += 1

        if lr_bad_epochs >= LR_REDUCE_PATIENCE:
            old_lr = get_current_learning_rate(model.optimizer)
            new_lr = old_lr * LR_REDUCE_FACTOR
            try:
                model.optimizer.learning_rate.assign(new_lr)
            except Exception:
                model.optimizer.learning_rate = new_lr
            print(f"ReduceLROnPlateau: learning_rate {old_lr:.8g} -> {new_lr:.8g}")
            lr_bad_epochs = 0

        with curriculum_log.open("a", encoding="utf-8", newline="") as f:
            csv.writer(f).writerow([
                epoch_number,
                f"{share:.8f}",
                len(pseudo_records),
                gt_samples,
                pseudo_stats["attempted"],
                pseudo_stats["rejected_confidence"],
                pseudo_stats["rejected_no_crack"],
                unlabeled_cursor,
                total_wraps,
            ])

        if early_bad_epochs >= EARLY_STOPPING_PATIENCE:
            print(
                f"EarlyStopping nach Epoche {epoch_number}: "
                f"val_loss seit {EARLY_STOPPING_PATIENCE} Epochen nicht verbessert."
            )
            break

    metrics_logger.on_train_end({})

    if metrics_logger.best_epoch is not None:
        selected_epoch_path = MODEL_DIR / f"{RUN_NAME}_Epoche{metrics_logger.best_epoch:02d}.keras"
        if selected_epoch_path.exists():
            selected_model_path = MODEL_DIR / f"{RUN_NAME}_best_dice_f2_distance.keras"
            shutil.copy2(selected_epoch_path, selected_model_path)
            print(
                f"Bestes Modell nach Dice-F2-Idealpunkt-Distanz: "
                f"Epoche {metrics_logger.best_epoch} | "
                f"D={metrics_logger.best_selection_distance:.8f} | {selected_model_path}"
            )

    print(f"Best-val_loss-Checkpoint: {best_checkpoint_path}")
    print(f"Aktuelles Pseudo-Manifest: {PSEUDO_MANIFEST_FILE}")
    print(f"Curriculum-Log: {CURRICULUM_LOG_FILE}")


if __name__ == "__main__":
    main()
